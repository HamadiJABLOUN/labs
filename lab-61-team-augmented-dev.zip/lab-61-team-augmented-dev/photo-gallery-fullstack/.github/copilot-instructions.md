# Photo Gallery Repository Instructions

Follow these guidelines when working in this repository:

## Architecture & Design

- Follow the layered architecture defined in [references/architecture.md](references/architecture.md)
- Respect module boundaries (UI → Service → Domain → Infrastructure)
- Use dependency injection for all external dependencies
- Reference [references/domain-glossary.md](references/domain-glossary.md) for consistent terminology

### Technology Stack & Key Paths

Use the block that matches the backend running in this workspace:

<details>
<summary><strong>NestJS (TypeScript)</strong></summary>

### Technology Stack

- **Frontend**: Angular 20+ with signals-based state management
- **Backend**: NestJS 11 with TypeORM
- **Database**: SQLite (local file)
- **File Storage**: Local disk (`./dist/uploads/`)
- **Build Tool**: Nx monorepo

### Key Paths

- Frontend: `apps/frontend/src/app/`
- Backend API: `apps/backend-nestjs/src/api/`
- Backend Domain: `apps/backend-nestjs/src/domain/`
- Backend Infrastructure: `apps/backend-nestjs/src/infrastructure/`

</details>

<details>
<summary><strong>Spring Boot (Java 17)</strong></summary>

### Technology Stack

- **Frontend**: Angular 20+ with signals-based state management
- **Backend**: Spring Boot with Spring Data JPA
- **Database**: SQLite (local file)
- **File Storage**: Local disk (`./uploads/`)
- **Build Tool**: Nx monorepo (frontend) + Maven wrapper (backend)

### Key Paths

- Frontend: `apps/frontend/src/app/`
- Backend API: `apps/backend-spring/src/main/java/com/photogallery/backend/api/`
- Backend Domain: `apps/backend-spring/src/main/java/com/photogallery/backend/domain/`
- Backend Infrastructure: `apps/backend-spring/src/main/java/com/photogallery/backend/infrastructure/`

</details>

<details>
<summary><strong>FastAPI (Python 3.12)</strong></summary>

### Technology Stack

- **Frontend**: Angular 20+ with signals-based state management
- **Backend**: FastAPI with SQLModel
- **Database**: SQLite (local file)
- **File Storage**: Local disk (`./uploads/`)
- **Build Tool**: Nx monorepo (frontend) + `uv` (backend)

### Key Paths

- Frontend: `apps/frontend/src/app/`
- Backend API: `apps/backend-fastapi/app/api/`
- Backend Domain: `apps/backend-fastapi/app/domain/`
- Backend Infrastructure: `apps/backend-fastapi/app/infrastructure/`

</details>

<details>
<summary><strong>.NET (C#)</strong></summary>

### Technology Stack

- **Frontend**: Angular 20+ with signals-based state management
- **Backend**: ASP.NET Core 8 with Entity Framework Core
- **Database**: SQLite (local file)
- **File Storage**: Local disk (`./uploads/`)
- **Build Tool**: Nx monorepo (frontend) + .NET 8 SDK (backend)

### Key Paths

- Frontend: `apps/frontend/src/app/`
- Backend API: `apps/backend-dotnet/Api/`
- Backend Domain: `apps/backend-dotnet/Domain/`
- Backend Infrastructure: `apps/backend-dotnet/Infrastructure/`

</details>

<details>
<summary><strong>Gin (Go)</strong></summary>

### Technology Stack

- **Frontend**: Angular 20+ with signals-based state management
- **Backend**: Gin (Go) with GORM
- **Database**: SQLite (local file)
- **File Storage**: Local disk (`./uploads/`)
- **Build Tool**: Nx monorepo (frontend) + Go modules (backend)

### Key Paths

- Frontend: `apps/frontend/src/app/`
- Backend API: `apps/backend-gin/internal/api/`
- Backend Domain: `apps/backend-gin/internal/domain/`
- Backend Infrastructure: `apps/backend-gin/internal/infrastructure/`

</details>

## Coding Standards

- TypeScript for the frontend (strict mode enabled); the backend follows its own stack's idiomatic conventions (see below)
- Use async/await (no callbacks except for legacy refactoring exercises)
- Functions max 50 lines
- Classes follow single responsibility principle
- See [references/coding-standards.md](references/coding-standards.md) for detailed conventions

### Angular (Frontend)

- Use standalone components (no NgModules)
- Use Angular signals for state (`signal()`, `computed()`)
- Use `inject()` function for dependency injection

```typescript
@Component({
  standalone: true,
  imports: [CommonModule]
})
export class PhotoListComponent {
  private readonly photoService = inject(PhotoService);
  readonly photos = this.photoService.photos;
  readonly selectedTags = signal<string[]>([]);
}
```

<details>
<summary><strong>NestJS (Backend)</strong></summary>

- Use decorators: `@Controller`, `@Get`, `@Post`, `@Injectable`
- Use TypeORM for database access with `@InjectRepository`
- Use DTOs with class-validator decorators

```typescript
@Controller('api/photos')
export class PhotosController {
  constructor(private readonly photoService: PhotoService) {}

  @Get()
  async getPhotos(): Promise<Photo[]> {
    return this.photoService.getPhotos();
  }
}
```

</details>

<details>
<summary><strong>Spring Boot (Backend)</strong></summary>

- Use `@RestController` with `@GetMapping`/`@PostMapping`, constructor injection (no field `@Autowired`)
- Use Spring Data JPA repositories for database access — no manual SQL
- Use DTOs with Bean Validation (`@NotBlank`, `@Valid`)

```java
@RestController
@RequestMapping("/api/photos")
public class PhotosController {
    private final PhotoService photoService;

    public PhotosController(PhotoService photoService) {
        this.photoService = photoService;
    }

    @GetMapping
    public List<PhotoResponse> getPhotos() {
        return photoService.getPhotos();
    }
}
```

</details>

<details>
<summary><strong>FastAPI (Backend)</strong></summary>

- Use `APIRouter` with `Depends()` for dependency injection
- Use SQLModel for database access via an injected `Session` — no raw SQL
- Use Pydantic models with `alias_generator=to_camel` for camelCase JSON

```python
router = APIRouter(prefix="/api/photos")

@router.get("", response_model=list[Photo])
def get_photos(service: PhotoService = Depends(get_photo_service)) -> list[Photo]:
    return service.get_photos()
```

</details>

<details>
<summary><strong>.NET (Backend)</strong></summary>

- Use `[ApiController]` with constructor-injected interfaces (e.g. `IPhotoService`)
- Use Entity Framework Core for database access via the repository pattern — no raw SQL
- Use DTOs relying on `System.Text.Json`'s default camelCase policy

```csharp
[ApiController]
[Route("api/photos")]
public class PhotosController : ControllerBase
{
    private readonly IPhotoService _photoService;

    public PhotosController(IPhotoService photoService) => _photoService = photoService;

    [HttpGet]
    public async Task<IEnumerable<PhotoResponse>> GetPhotos() => await _photoService.GetPhotosAsync();
}
```

</details>

<details>
<summary><strong>Gin (Backend)</strong></summary>

- Use `Handler` struct methods registered on the Gin router, constructed via `NewHandler(service, storage)`
- Use GORM for database access — no raw SQL
- Use DTOs with explicit `json:` tags for camelCase JSON

```go
func (h *Handler) GetPhotos(c *gin.Context) {
	photos, err := h.service.GetPhotos(c.Request.Context())
	if err != nil {
		c.JSON(http.StatusInternalServerError, ErrorResponse{Message: err.Error()})
		return
	}
	c.JSON(http.StatusOK, ToResponseList(photos))
}
```

</details>

## Testing

- Minimum 80% code coverage for business logic
- Use AAA pattern (Arrange-Act-Assert)
- Mock external dependencies (HTTP calls, file system in unit tests)
- Use Vitest for unit and integration tests
- Use Playwright for E2E tests
- See [references/testing-guidelines.md](references/testing-guidelines.md) for test strategies

## API Conventions

- RESTful endpoints with proper HTTP verbs
- camelCase for JSON fields
- Consistent error response format:
  ```json
  {
    "statusCode": 400,
    "message": "File size exceeds 5MB limit",
    "error": "Bad Request"
  }
  ```

## Validation Constraints

- Max file size: **5MB**
- Supported image types: JPEG, PNG, GIF, WebP
- Tags: lowercase alphanumeric with hyphens, max 20 tags, max 30 chars each

## Security

- Always validate and sanitize user input
- Use your ORM's repository/query-builder methods (avoid raw SQL)
- Store sensitive data in environment variables
- No hardcoded credentials or API keys

## Performance

- Use Angular signals for reactive state (automatically optimized)
- Lazy load images with `loading="lazy"` attribute
- Use computed values for derived state (memoized automatically)
- Optimize database queries using your backend's query builder/ORM

## Git Workflow

- Branch naming: `feature/`, `bugfix/`, `refactor/`
- Commit messages: `type(scope): description`
- PR descriptions include test strategy and deployment notes
- Code review required from 2+ team members

## On-Call & Incidents

- Follow escalation procedures in [references/oncall.md](references/oncall.md)
- Document incidents using RCA template
- Update runbooks with learnings

When in doubt, reference the comprehensive documentation in the `references/` directory or consult relevant team agents.
