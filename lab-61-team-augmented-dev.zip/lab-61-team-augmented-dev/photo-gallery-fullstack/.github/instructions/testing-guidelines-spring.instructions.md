---
applyTo: '**/*Test.java,**/*IT.java'
---

# Testing Guidelines Instructions

Follow guidelines from references/testing-guidelines.md when writing test files.

## Key Points for Test Files

- **Test Runner**: JUnit 5 + Mockito
- **Testing Pyramid**: 70% unit, 20% integration, 10% E2E
- **Coverage Target**: 80%+ for business logic

## Test Structure (AAA Pattern)

```java
@Test
void shouldRejectFilesLargerThan5MB() {
    // Arrange
    MultipartFile file = new MockMultipartFile("file", "photo.jpg", "image/jpeg", new byte[6 * 1024 * 1024]);

    // Act
    ValidationResult result = validator.validate(file);

    // Assert
    assertThat(result.isValid()).isFalse();
    assertThat(result.getError()).contains("5MB");
}
```

## File Size Validation Example

```java
class PhotoValidatorTest {
    private final PhotoValidator validator = new PhotoValidator();

    @Test
    void shouldRejectFilesLargerThan5MB() {
        MultipartFile file = new MockMultipartFile("file", "photo.jpg", "image/jpeg", new byte[6 * 1024 * 1024]);

        ValidationResult result = validator.validate(file);

        assertThat(result.isValid()).isFalse();
        assertThat(result.getError()).contains("File size exceeds 5MB");
    }
}
```

## Spring Controller Testing

```java
@ExtendWith(MockitoExtension.class)
class PhotosControllerTest {
    @Mock
    private PhotoService photoService;

    @InjectMocks
    private PhotosController controller;

    @Test
    void getPhotosReturnsServiceResult() {
        when(photoService.getPhotos()).thenReturn(List.of());

        List<PhotoResponse> result = controller.getPhotos();

        assertThat(result).isEmpty();
    }
}
```

See [references/testing-guidelines.md](../references/testing-guidelines.md) for complete testing documentation.
