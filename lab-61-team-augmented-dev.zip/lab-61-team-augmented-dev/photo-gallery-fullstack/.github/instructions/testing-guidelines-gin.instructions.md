---
applyTo: '**/*_test.go'
---

# Testing Guidelines Instructions

Follow guidelines from references/testing-guidelines.md when writing test files.

## Key Points for Test Files

- **Test Runner**: `go test` + `testify`
- **Testing Pyramid**: 70% unit, 20% integration, 10% E2E
- **Coverage Target**: 80%+ for business logic

## Test Structure (AAA Pattern)

```go
func TestRejectsFilesLargerThan5MB(t *testing.T) {
	// Arrange
	file := testutil.NewUpload(6 * 1024 * 1024)

	// Act
	result := validator.Validate(file)

	// Assert
	assert.False(t, result.Valid)
	assert.Contains(t, result.Error, "5MB")
}
```

## File Size Validation Example

```go
func TestRejectsFilesLargerThan5MB(t *testing.T) {
	file := testutil.NewUpload(6*1024*1024, "image/jpeg")

	result := validator.Validate(file)

	assert.False(t, result.Valid)
	assert.Contains(t, result.Error, "File size exceeds 5MB")
}
```

## Gin Handler Testing

```go
func TestGetPhotos_ReturnsServiceResult(t *testing.T) {
	mockService := &mocks.PhotoService{}
	mockService.On("GetPhotos", mock.Anything).Return([]domain.Photo{}, nil)
	handler := NewHandler(mockService, nil)

	w := httptest.NewRecorder()
	c, _ := gin.CreateTestContext(w)
	handler.GetPhotos(c)

	assert.Equal(t, http.StatusOK, w.Code)
}
```

See [references/testing-guidelines.md](../references/testing-guidelines.md) for complete testing documentation.
