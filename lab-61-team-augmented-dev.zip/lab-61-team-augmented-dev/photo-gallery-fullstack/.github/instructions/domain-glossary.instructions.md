---
applyTo: '**'
---

# Domain Glossary Instructions

Follow guidelines from references/domain-glossary.md for consistent terminology.

## Core Entity: Photo

The primary entity in the system representing an uploaded image file.

**Backend Properties** — same concepts in every backend stack, use the block matching yours:

<details>
<summary><strong>NestJS</strong> — <code>apps/backend-nestjs/src/domain/entities/photo.entity.ts</code></summary>

- **id** (number): Auto-generated primary key
- **filename** (string): Original filename from upload
- **storedFilename** (string): Unique filename on disk
- **url** (string): URL path to access the file
- **size** (number): File size in bytes
- **tags** (string[]): Array of user-assigned tags
- **createdAt** (Date): Upload timestamp

</details>

<details>
<summary><strong>Spring Boot</strong> — <code>apps/backend-spring/.../domain/model/Photo.java</code></summary>

- **id** (String): Primary key
- **filename** (String): Original filename from upload
- **storedFilename** (String): Unique filename on disk
- **url** (String): URL path to access the file
- **size** (long): File size in bytes
- **tags** (List\<String\>): List of user-assigned tags
- **createdAt** (Instant): Upload timestamp

</details>

<details>
<summary><strong>FastAPI</strong> — <code>apps/backend-fastapi/app/domain/models.py</code></summary>

- **id** (str): Primary key
- **filename** (str): Original filename from upload
- **stored_filename** (str): Unique filename on disk
- **url** (str): URL path to access the file
- **size** (int): File size in bytes
- **tags** (list[str]): List of user-assigned tags
- **created_at** (datetime): Upload timestamp

</details>

<details>
<summary><strong>.NET</strong> — <code>apps/backend-dotnet/Domain/Models/Photo.cs</code></summary>

- **Id** (int): Auto-generated primary key
- **Filename** (string): Original filename from upload
- **StoredFilename** (string): Unique filename on disk
- **Url** (string): URL path to access the file
- **Size** (long): File size in bytes
- **Tags** (List\<string\>): List of user-assigned tags
- **CreatedAt** (DateTime): Upload timestamp

</details>

<details>
<summary><strong>Gin</strong> — <code>apps/backend-gin/internal/domain/photo.go</code></summary>

- **ID** (string): Primary key
- **Filename** (string): Original filename from upload
- **StoredFilename** (string): Unique filename on disk
- **URL** (string): URL path to access the file
- **Size** (int64): File size in bytes
- **Tags** ([]string): Slice of user-assigned tags
- **CreatedAt** (time.Time): Upload timestamp

</details>

**Frontend Properties** (`apps/frontend/src/app/models/photo.model.ts`):
- **id** (string): Unique identifier
- **filename** (string): Original filename
- **dataUrl** (string): Base64 or URL path
- **uploadedAt** (Date): Upload timestamp
- **tags** (string[]): User-assigned tags
- **size** (number): File size in bytes

## Business Rules

- Max file size: **5MB**
- Supported formats: JPEG, PNG, GIF, WebP
- Tags: lowercase alphanumeric with hyphens
- Max 20 tags per photo, max 30 chars per tag

## Terminology Conventions

| ✅ USE | ❌ AVOID |
|--------|---------|
| Photo | Image, Picture |
| Upload | Post, Add |
| Tag | Label, Category |
| Delete | Remove, Trash |

See [references/domain-glossary.md](../references/domain-glossary.md) for complete glossary.
