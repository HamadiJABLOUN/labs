---
applyTo: '**/*Tests.cs'
---

# Testing Guidelines Instructions

Follow guidelines from references/testing-guidelines.md when writing test files.

## Key Points for Test Files

- **Test Runner**: xUnit + Moq
- **Testing Pyramid**: 70% unit, 20% integration, 10% E2E
- **Coverage Target**: 80%+ for business logic

## Test Structure (AAA Pattern)

```csharp
[Fact]
public void ShouldRejectFilesLargerThan5MB()
{
    // Arrange
    var file = TestFile.WithSize(6 * 1024 * 1024);

    // Act
    var result = _validator.Validate(file);

    // Assert
    Assert.False(result.Valid);
    Assert.Contains("5MB", result.Error);
}
```

## File Size Validation Example

```csharp
public class PhotoValidatorTests
{
    private readonly PhotoValidator _validator = new();

    [Fact]
    public void ShouldRejectFilesLargerThan5MB()
    {
        var file = TestFile.WithSize(6 * 1024 * 1024, "image/jpeg");

        var result = _validator.Validate(file);

        Assert.False(result.Valid);
        Assert.Contains("File size exceeds 5MB", result.Error);
    }
}
```

## .NET Controller Testing

```csharp
public class PhotosControllerTests
{
    private readonly Mock<IPhotoService> _photoService = new();
    private readonly PhotosController _controller;

    public PhotosControllerTests() => _controller = new PhotosController(_photoService.Object);

    [Fact]
    public async Task GetPhotos_ReturnsServiceResult()
    {
        _photoService.Setup(s => s.GetPhotosAsync()).ReturnsAsync(new List<PhotoResponse>());

        var result = await _controller.GetPhotos();

        Assert.Empty(result);
    }
}
```

See [references/testing-guidelines.md](../references/testing-guidelines.md) for complete testing documentation.
