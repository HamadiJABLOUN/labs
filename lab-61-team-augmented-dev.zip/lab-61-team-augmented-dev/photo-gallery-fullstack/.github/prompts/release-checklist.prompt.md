---
description: Generate a pre-release checklist to ensure deployment readiness
tools: ['search/codebase']
---

# /release-checklist

Command for release-checklist operations in the photo gallery project.

Refer to coding standards and architecture guidelines.

