---
description: Provide on-call engineers with quick context, troubleshooting guidance, and escalation paths for production issues
tools: ['search/codebase']
---
# /explain-oncall

Provide on-call engineers with quick context, troubleshooting guidance, and escalation paths for production issues.

## Purpose

Help on-call engineers rapidly understand and respond to incidents by:
- Explaining system behavior and architecture context
- Providing troubleshooting steps for common issues
- Identifying relevant logs, metrics, and monitoring dashboards
- Recommending escalation paths when needed

## Usage

Invoke this command with an error message, alert, or incident description:

```
/explain-oncall "High error rate on POST /api/photos/upload"
```

Or with specific error details:

```
/explain-oncall Error: File upload failed in PhotoService
```

## Output Format

The command will generate:

1. **Incident Summary**: Quick understanding of what's happening
2. **Likely Causes**: Most common reasons for this issue
3. **Immediate Actions**: Steps to triage and mitigate
4. **Investigation Steps**: How to gather more diagnostic information
5. **Escalation Path**: When and who to escalate to

## Example Output

_Paths and commands below illustrate the NestJS reference stack; substitute your chosen backend's paths/serve command (see `architecture.md`) if using Spring Boot, FastAPI, .NET, or Gin — all bind port 42621._

```markdown
# Oncall Guide: High Error Rate on POST /api/photos/upload

## Incident Summary

**Severity**: HIGH (user-facing functionality degraded)
**Impact**: Users unable to upload photos
**Component**: PhotosController → PhotoService → Local Storage

---

## Likely Causes

### 1. Disk Storage Issues (Most Common)
- Upload directory doesn't exist or has wrong permissions
- Disk space full
- Check: `ls -la ./dist/uploads/` and `df -h`

### 2. File Validation Failures
- Files exceeding 5MB limit
- Invalid file types (not JPEG/PNG/GIF/WebP)
- Corrupted file uploads

### 3. Database Connectivity
- SQLite database locked by another process
- Database file corrupted or missing

### 4. Configuration Change
- Recent deployment changed upload path or validation rules
- Environment variable misconfiguration

---

## Immediate Actions (TRIAGE - 5 minutes)

### 1. Check Upload Directory
```bash
# Verify uploads directory exists and is writable
ls -la ./dist/uploads/
df -h ./dist/uploads/
```

### 2. Check Backend Logs
```bash
# View backend terminal output for errors
# Look for ERROR messages related to uploads
```

### 3. Test Upload Endpoint
```bash
# Test with a small valid image
curl -X POST http://localhost:42621/api/photos/upload \
  -F "file=@test-image.jpg"
```

### 4. Verify Database
```bash
# Check database file
ls -la ./dist/db/photogallery.db
```

---

## Investigation Steps (DIAGNOSE - 15 minutes)

### Step 1: Review Backend Logs

Check the terminal running your backend (e.g. `nx serve backend-nestjs`, or `npm run serve:backend-<stack>` for another stack) for:
- Error messages
- Stack traces
- Validation failures

**Common error types**:
- "ENOENT" → File/directory not found
- "ENOSPC" → Disk full
- "SQLITE_BUSY" → Database locked
- "Validation failed" → File size or type issue

### Step 2: Check File Constraints

```typescript
// From apps/backend-nestjs/src/domain/services/photo.service.ts
// Valid constraints:
// - Max file size: 5MB (5 * 1024 * 1024 bytes)
// - Allowed types: image/jpeg, image/png, image/gif, image/webp
```

### Step 3: Check Dependent Services

```bash
# Verify database connectivity
ls -la ./dist/db/

# Check if backend is responding
curl http://localhost:42621/api/photos

# Check frontend proxy
curl http://localhost:4200/api/photos
```

### Step 4: Review Recent Changes

```bash
# Check recent commits
git log --oneline -10 -- apps/backend-nestjs/src/

# Check for changes to upload handling
git log --oneline -10 -- apps/backend-nestjs/src/api/photos/
git log --oneline -10 -- apps/backend-nestjs/src/domain/services/photo.service.ts
```

---

## Mitigation Options

### Option 1: Restart Backend Service
```bash
# Stop current process (Ctrl+C)
# Restart:
nx serve backend-nestjs
```
**Impact**: Brief downtime, clears any stuck processes

### Option 2: Fix Upload Directory
```bash
# Create uploads directory if missing
mkdir -p ./dist/uploads/
chmod 755 ./dist/uploads/
```
**Impact**: Immediate fix if directory was missing

### Option 3: Clear Disk Space
```bash
# Check disk usage
df -h
du -sh ./dist/uploads/*

# Remove old/unnecessary files
rm -rf ./dist/uploads/old-files/
```
**Impact**: Frees space for new uploads

### Option 4: Reset Database (Data Loss!)
```bash
# Backup first
cp ./dist/db/photogallery.db ./dist/db/photogallery.db.backup

# Remove locked database
rm ./dist/db/photogallery.db

# Restart to recreate
nx serve backend-nestjs
```
**Impact**: Loses all photo metadata, uploads remain on disk

---

## Escalation Path

### Escalate Immediately If:
- ❌ Error rate > 50% for more than 15 minutes
- ❌ Multiple endpoints affected (not just uploads)
- ❌ Data loss or corruption suspected
- ❌ Security incident suspected

### Escalation Contacts:

1. **Backend Team Lead**: @bob (Slack: #backend-oncall)
   - For application logic, service issues

2. **Tech Lead**: @alice (Slack: #platform-oncall)
   - For infrastructure, deployment issues

3. **CTO**: @charlie (Phone: +1-555-0199)
   - For critical business impact (revenue, data breach)

### Escalation Message Template:
```
🚨 INCIDENT: High error rate on photo uploads (50%+ failures)
Duration: [X] minutes
Impact: Users unable to upload photos
Actions Taken: [list what you've tried]
Current Status: [mitigation in progress / needs escalation]
Logs: [relevant error messages]
```

---

## Post-Incident Actions

After resolution:

1. **Document Issue**: Record what happened and how it was fixed
2. **Update Runbook**: Add learnings to this oncall guide
3. **Review Root Cause**: Schedule RCA meeting if P0/P1
4. **Improve Monitoring**: Add alerts for this failure mode

---

## Related Documentation

- **Architecture**: `architecture.md` (storage layer details)
- **Domain Glossary**: `domain-glossary.md` (entity definitions)
- **Oncall Procedures**: `oncall.md`
- **Testing Guidelines**: `testing-guidelines.md`
```

## Activation Triggers

- Reference `oncall.md` for escalation paths and procedures
- Reference `architecture.md` for system topology and dependencies
- Apply `debug-correlation` skill to identify root causes
- Reference `coding-standards.md` for implementation patterns

You provide calm, structured guidance that helps on-call engineers quickly triage and resolve production issues with confidence.
