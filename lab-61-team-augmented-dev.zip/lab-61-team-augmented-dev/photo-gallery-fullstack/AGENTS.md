# AGENTS.md

Repository instructions for AI coding agents working in `photo-gallery-fullstack`.

## 1) Purpose

This is a training lab repository for team-augmented development workflows.
Code changes should prioritize clarity, architectural consistency, and safe incremental delivery over cleverness.

## 2) Stack and Runtime

- Monorepo: Nx 21.4
- Frontend: Angular 20 (`apps/frontend`)
- Backend: trainee-choosable — NestJS 11 (TypeORM), Spring Boot (JPA/Hibernate), FastAPI (SQLModel), ASP.NET Core (EF Core), or Gin (GORM) — all backed by SQLite behind the same OpenAPI contract (`apps/backend-<stack>`, e.g. `apps/backend-nestjs`)
- Unit tests: Vitest (frontend); the chosen backend's idiomatic framework (Jest/NestJS, JUnit/Spring, pytest/FastAPI, xUnit/.NET, `go test`/Gin)
- E2E tests: Playwright

Local defaults:

- Frontend dev server: `http://localhost:42610`
- Backend is started as a dependency of frontend serve (`frontend:serve` depends on `backend:serve`)

## 3) Canonical Commands

- Install dependencies: `npm ci`
- Start app stack: `npm run start`
- Build all projects: `npm run build`
- Lint all projects: `npm run lint`
- Test all projects: `npm run test`
- Run arbitrary Nx target: `npm run nx -- <target>`

## 4) Project Map

- `apps/frontend/src/app/components`: UI components (upload, list, etc.)
- `apps/frontend/src/app/services`: frontend API/domain-facing services
- `apps/frontend/src/app/models`: frontend data models
- `apps/backend-<stack>/.../api`: controllers/handlers + DTOs (HTTP boundary)
- `apps/backend-<stack>/.../domain`: entities, models, domain services, repository interfaces
- `apps/backend-<stack>/.../infrastructure`: repository/storage implementations

See `.claude/references/architecture.md` for the exact path per backend stack (NestJS/Spring/FastAPI/.NET/Gin).

## 5) Architectural Rules

1. Keep HTTP concerns in `api` (validation, transport, request/response mapping).
2. Keep business rules in `domain`.
3. Keep IO and persistence details in `infrastructure`.
4. Depend inward: `api -> domain`, `infrastructure -> domain`; avoid domain depending on infrastructure.
5. Favor explicit contracts (interfaces/types) at boundaries.

## 6) API Change Policy

- Prefer backward-compatible changes by default.
- Adding optional request fields/params is acceptable if existing clients keep working unchanged.
- For endpoint contract changes, update:
  - controller typing/validation
  - service signature and call sites
  - relevant tests (controller + service)
  - docs/comments that describe API behavior

Current API surface (high level):

- `GET /api/photos`
- `GET /api/photos/:id`
- `POST /api/photos/upload`
- `POST /api/photos/:id/thumbnail`
- `DELETE /api/photos/:id`

## 7) Quality Bar for Changes

When making edits:

1. Keep diffs focused and minimal.
2. Add or update tests for behavior changes.
3. Preserve existing naming/style conventions.
4. Do not perform unrelated refactors unless explicitly requested.
5. Call out risks and assumptions in final handoff.

## 8) Review Checklist

Before considering work complete:

1. Run the most relevant validation (`lint`, `test`, or targeted Nx command).
2. Verify no layer-boundary violations were introduced.
3. Verify API compatibility impact.
4. Summarize changed files and residual risks.

## 9) Multi-Platform AI Config (Reference)

This repo includes assistant-specific configuration directories:

- `.claude`
- `.github`
- `.gemini`
- `.codex`
- `.opencode`
- `.vibe`

Shared skill themes used across platforms include:

- topology/dependency mapping
- change-impact analysis
- incremental refactoring
- framework conventions
- debug correlation

Use the platform-specific config in those directories when running exercises.

## 10) Safety Constraints

- Never run destructive operations (file deletes/reset/reverts) unless explicitly requested.
- Do not revert or overwrite user-authored changes outside the requested scope.
- If requirements are ambiguous, choose the smallest safe implementation and document assumptions.
