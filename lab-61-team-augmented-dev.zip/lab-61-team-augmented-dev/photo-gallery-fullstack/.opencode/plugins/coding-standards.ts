// Docs: https://opencode.ai/docs/plugins

declare const Bun: {
  file(path: URL | string): {
    text(): Promise<string>;
  };
};

type ToolInput = {
  tool?: string;
};

type ToolOutput = {
  args?: Record<string, unknown>;
};

type FileEditedEvent = {
  path?: string;
};

type PluginContext = {
  client: {
    app: {
      log(entry: {
        body: {
          service: string;
          level: string;
          message: string;
          extra?: Record<string, string>;
        };
      }): Promise<void>;
    };
  };
  $: (strings: TemplateStringsArray, ...values: unknown[]) => {
    text(): Promise<string>;
  };
};

const CODING_STANDARDS_REFERENCE = ".opencode/references/coding-standards.md";
const TYPESCRIPT_FILE_PATTERN = /\.(?:[cm]?[jt]sx?)$/;
const DISALLOWED_ANY_PATTERN = /(?:\bas\s+any\b|:\s*any\b)/;

const readText = (value: unknown): string => (typeof value === "string" ? value : "");

const getFilePath = (args: Record<string, unknown>): string =>
  [args.filePath, args.file_path, args.path].map(readText).find(Boolean) ?? "";

const getToolContent = (args: Record<string, unknown>): string =>
  [args.content, args.newString, args.oldString].map(readText).filter(Boolean).join("\n");

const getAddedLines = (diff: string): string =>
  diff
    .split("\n")
    .filter((line) => line.startsWith("+") && !line.startsWith("+++"))
    .join("\n");

export const CodingStandardsPlugin = async ({ client, $ }: PluginContext) => {
  const referenceText = await Bun.file(new URL("../references/coding-standards.md", import.meta.url)).text();
  const enforceAnyRule = referenceText.includes("### Avoid `any`");

  return {
    "tool.execute.before": async (input: ToolInput, output: ToolOutput) => {
      const tool = input.tool ?? "";
      const args = output.args ?? {};

      if ((tool === "edit" || tool === "write") && enforceAnyRule) {
        const content = getToolContent(args);
        if (DISALLOWED_ANY_PATTERN.test(content)) {
          const filePath = getFilePath(args);
          const fileLabel = filePath ? ` in ${filePath}` : "";
          throw new Error(
            `Coding standards violation: avoid \`any\` types${fileLabel}. See ${CODING_STANDARDS_REFERENCE}.`,
          );
        }
      }

      if (tool !== "bash" || !enforceAnyRule) {
        return;
      }

      const command = readText(args.command);
      if (!command.includes("git commit")) {
        return;
      }

      const stagedFiles = (await $`git diff --cached --name-only --diff-filter=ACM`.text())
        .split(/\r?\n/)
        .map((filePath) => filePath.trim())
        .filter((filePath) => TYPESCRIPT_FILE_PATTERN.test(filePath));

      const violations: string[] = [];

      for (const filePath of stagedFiles) {
        const diff = await $`git diff --cached -- ${filePath}`.text();
        if (DISALLOWED_ANY_PATTERN.test(getAddedLines(diff))) {
          violations.push(filePath);
        }
      }

      if (violations.length > 0) {
        throw new Error(
          `Commit blocked by coding standards plugin: avoid \`any\` types in ${violations.join(", ")}. See ${CODING_STANDARDS_REFERENCE}.`,
        );
      }
    },

    "file.edited": async (event: FileEditedEvent) => {
      const filePath = readText(event.path);
      if (!TYPESCRIPT_FILE_PATTERN.test(filePath)) {
        return;
      }

      await client.app.log({
        body: {
          service: "coding-standards",
          level: "info",
          message: `Review ${filePath} against ${CODING_STANDARDS_REFERENCE}.`,
          extra: {
            filePath,
            reference: CODING_STANDARDS_REFERENCE,
          },
        },
      });
    },
  };
};
