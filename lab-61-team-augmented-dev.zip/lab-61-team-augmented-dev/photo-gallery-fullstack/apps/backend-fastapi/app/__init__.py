"""Photo Gallery FastAPI backend."""
