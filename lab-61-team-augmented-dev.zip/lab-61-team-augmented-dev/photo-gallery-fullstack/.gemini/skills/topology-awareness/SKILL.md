---
name: topology-awareness
description: Analyze system topology to identify dependencies, impact zones, and architectural relationships. Use when planning changes that cross module boundaries, reviewing cross-cutting changes, or analyzing API modifications.
---

# Topology Awareness

Analyze system topology to identify dependencies, impact zones, and architectural relationships. This skill helps developers understand how changes in one component affect others.

## Capabilities

### 1. Dependency Mapping
- Identify direct and transitive dependencies for a given module
- Map service-to-service communication patterns
- Visualize data flow across system boundaries

### 2. Impact Zone Identification
- Determine which components are affected by a proposed change
- Flag downstream consumers that may break
- Identify integration points requiring coordination

### 3. Breaking Change Detection
- Analyze API contract changes for backward compatibility
- Identify database schema changes affecting multiple services
- Flag shared library updates impacting multiple consumers

## When to Use

This skill activates automatically when:
- Analyzing code changes that modify public APIs
- Planning refactorings that cross module boundaries
- Reviewing pull requests with cross-cutting changes
- Tracing request flows through the system

## Knowledge Sources

- **architecture.md**: System topology and module relationships
- **Project structure**: Import/export analysis
- **Git history**: Past change correlations

## Example Scenarios

### Scenario 1: API Endpoint Modification

**Input**: Developer modifies `GET /api/photos/:id` response schema

**Analysis**:
```
Dependency Tree:
  PhotoController.getPhoto()
    → PhotoService.findById()
      → PhotoRepository.findOne()
    → PhotoDto (response mapper)

Consumers:
  - Mobile App (iOS/Android): Uses full response
  - Web App: Uses subset (id, url, title)
  - Admin Dashboard: Uses full response with metadata

Impact: HIGH - Removing fields will break mobile app
```

**Recommendation**: Add new fields but don't remove existing ones (backward compatible)

---

### Scenario 2: Database Schema Change

**Input**: Adding `user_id` column to `photos` table

**Analysis**:
```
Direct Dependencies:
  - PhotoRepository.create()  → Must include user_id
  - PhotoRepository.update()  → May need user_id validation
  - Photo entity class        → Add user_id property

Downstream Impact:
  - PhotoService methods      → Update business logic
  - API endpoints             → Add user_id to request validation
  - Migration scripts         → Add NOT NULL constraint

Transitive Dependencies:
  - Photo search service      → Index by user_id for performance
  - Photo cleanup job         → Filter by user_id in batch operations
```

**Recommendation**: Create migration in stages (add nullable column → backfill data → add NOT NULL constraint)

---

### Scenario 3: Shared Utility Refactoring

**Input**: Refactoring `src/utils/image-processor.ts` function signatures

**Analysis**:
```
Consumers (17 files):
  Core Services:
    - PhotoService.processUpload()
    - ThumbnailGenerator.create()
    - WatermarkService.apply()
  
  Background Jobs:
    - PhotoOptimizationJob
    - BulkResizeJob
  
  API Controllers:
    - UploadController
    - AdminPhotoController

Breaking Change Risk: HIGH (17 call sites must be updated atomically)
```

**Recommendation**: Use adapter pattern or feature flag for gradual migration

---

## Integration with Other Skills

- **change-impact-analysis**: Provides dependency data for impact assessment
- **incremental-refactoring**: Uses topology to plan safe refactoring steps
- **framework-conventions**: Applies conventions consistently across topology

## Activation Examples

```typescript
// When reviewing this change:
export class PhotoService {
  async findById(id: string): Promise<Photo> {
    // Changed return type from Photo to PhotoWithUser
  }
}

// Skill activates and reports:
// "⚠️ Return type change affects 5 controllers and 3 services.
//  Consider creating PhotoWithUserDto to avoid breaking consumers."
```

## Metrics

Success criteria for topology awareness:
- ✅ Identifies 95%+ of direct dependencies
- ✅ Flags breaking changes before they reach production
- ✅ Reduces cross-module integration issues by 40%
