#!/usr/bin/env bash
# Pre-commit guard: enforce conventional-commit format and block secrets/denied
# files from entering the index. See .claude/references/coding-standards.md.
#
# Exit 0 = pass, exit 1 = block.

set -u

REPO_ROOT="$(git rev-parse --show-toplevel 2>/dev/null || pwd)"
cd "$REPO_ROOT" || exit 0

VIOLATIONS=0
report() { echo "❌ $1"; VIOLATIONS=$((VIOLATIONS + 1)); }
warn()   { echo "⚠️  $1"; }

mapfile -t STAGED < <(git diff --cached --name-only --diff-filter=ACMR 2>/dev/null)

if [ ${#STAGED[@]} -eq 0 ]; then
  echo "ℹ️  No staged changes — nothing to validate."
  exit 0
fi

FILENAME_DENY='(^|/)\.env(\..+)?$|(^|/)credentials\.json$|(^|/)id_rsa(\.pub)?$'
SECRET_PATTERNS=(
  'AKIA[0-9A-Z]{16}'
  '-----BEGIN (RSA |EC |OPENSSH |DSA |PGP )?PRIVATE KEY-----'
  'sk-[A-Za-z0-9]{32,}'
  'sk-ant-[A-Za-z0-9_-]{20,}'
  'ghp_[A-Za-z0-9]{36}'
  'glpat-[A-Za-z0-9_-]{20}'
  'xox[baprs]-[A-Za-z0-9-]{10,}'
)

for f in "${STAGED[@]}"; do
  [[ "$f" =~ $FILENAME_DENY ]] && report "Disallowed file staged: $f"
  [ -f "$f" ] || continue
  case "$f" in
    node_modules/*|dist/*|.nx/*|.angular/*|package-lock.json) continue ;;
  esac
  for pat in "${SECRET_PATTERNS[@]}"; do
    if git show ":$f" 2>/dev/null | grep -E -q "$pat"; then
      report "Possible secret in staged file: $f"
      break
    fi
  done
done

MSG_FILE=""
for candidate in "${1:-}" "${COMMIT_MSG_FILE:-}" "${GIT_COMMIT_MSG_FILE:-}" ".git/COMMIT_EDITMSG"; do
  [ -n "$candidate" ] && [ -f "$candidate" ] && MSG_FILE="$candidate" && break
done

if [ -n "$MSG_FILE" ]; then
  FIRST_LINE=$(grep -v '^#' "$MSG_FILE" | sed '/./,$!d' | head -1)
  if [ -n "$FIRST_LINE" ]; then
    if ! [[ "$FIRST_LINE" =~ ^(feat|fix|refactor|test|docs|chore|perf|build|ci|style|revert)(\([a-z0-9._-]+\))?!?:\ .+ ]]; then
      report "Commit subject does not follow conventional-commit format: '$FIRST_LINE'"
      echo "    Expected: type(scope): description   (types: feat|fix|refactor|test|docs|chore|perf|build|ci|style|revert)"
    fi
  else
    warn "Commit message file is empty — skipping format check."
  fi
else
  warn "No commit message file available — skipping format check."
fi

if [ "$VIOLATIONS" -gt 0 ]; then
  echo ""
  echo "$VIOLATIONS violation(s) found. Fix before committing."
  exit 1
fi

echo "✅ validate-commit: clean (${#STAGED[@]} staged files)"
exit 0
