#!/usr/bin/env bash
# Post-write advisory: scan recently-modified TS/JS files in apps/ for the
# coding-standards anti-patterns documented in .claude/references/coding-standards.md.
#
# Always exits 0 — produces warnings only. Intended to be informational.

set -u

REPO_ROOT="$(git rev-parse --show-toplevel 2>/dev/null || pwd)"
cd "$REPO_ROOT" || exit 0

mapfile -t FILES < <(
  {
    git diff --name-only --diff-filter=ACMR HEAD 2>/dev/null
    git ls-files --others --exclude-standard 2>/dev/null
  } | sort -u | grep -E '^apps/.*\.(ts|js)$' | grep -v -E '\.(spec|test)\.(ts|js)$'
)

if [ ${#FILES[@]} -eq 0 ]; then
  exit 0
fi

WARN_COUNT=0
warn() { echo "⚠️  $1"; WARN_COUNT=$((WARN_COUNT + 1)); }

for f in "${FILES[@]}"; do
  [ -f "$f" ] || continue

  STRIPPED=$(sed -E -e 's://[^\n]*::g' -e '/\/\*/,/\*\//d' "$f")

  if echo "$STRIPPED" | grep -E -n ':\s*any\b' | grep -v 'eslint-disable' >/dev/null; then
    hit=$(echo "$STRIPPED" | grep -E -n ':\s*any\b' | head -1)
    warn "$f: explicit 'any' type (prefer 'unknown' or a real type) — first hit line ${hit%%:*}"
  fi

  if echo "$STRIPPED" | grep -E -n '\bconsole\.log\(' >/dev/null; then
    hit=$(echo "$STRIPPED" | grep -E -n '\bconsole\.log\(' | head -1)
    warn "$f: leftover console.log — first hit line ${hit%%:*}"
  fi

  case "$f" in
    apps/frontend/*)
      if echo "$STRIPPED" | grep -E -n '@NgModule\b' >/dev/null; then
        warn "$f: @NgModule found — frontend uses standalone components"
      fi
      ;;
  esac
done

if [ "$WARN_COUNT" -gt 0 ]; then
  echo ""
  echo "$WARN_COUNT advisory warning(s). Address if applicable."
fi

exit 0
