#!/usr/bin/env bash
# Pre-write guard: scan tracked + recently-changed files for obvious secrets
# and dangerous patterns. Conservative — block only on high-confidence matches.
#
# Exit 0 = pass, exit 1 = block.

set -u

REPO_ROOT="$(git rev-parse --show-toplevel 2>/dev/null || pwd)"
cd "$REPO_ROOT" || exit 0

# Files to inspect: anything modified vs HEAD plus untracked, excluding deletions.
mapfile -t FILES < <(
  {
    git diff --name-only --diff-filter=ACMR HEAD 2>/dev/null
    git ls-files --others --exclude-standard 2>/dev/null
  } | sort -u
)

[ ${#FILES[@]} -eq 0 ] && exit 0

VIOLATIONS=0
report() {
  echo "❌ $1"
  VIOLATIONS=$((VIOLATIONS + 1))
}

# Patterns that almost always indicate a real secret leaking into a commit.
SECRET_PATTERNS=(
  'AKIA[0-9A-Z]{16}'                                 # AWS access key id
  'aws_secret_access_key[[:space:]]*=[[:space:]]*[A-Za-z0-9/+=]{40}'
  '-----BEGIN (RSA |EC |OPENSSH |DSA |PGP )?PRIVATE KEY-----'
  'sk-[A-Za-z0-9]{32,}'                              # OpenAI-style
  'sk-ant-[A-Za-z0-9_-]{20,}'                        # Anthropic-style
  'ghp_[A-Za-z0-9]{36}'                              # GitHub PAT
  'gho_[A-Za-z0-9]{36}'
  'glpat-[A-Za-z0-9_-]{20}'                          # GitLab PAT
  'xox[baprs]-[A-Za-z0-9-]{10,}'                     # Slack token
)

# Filename denylist — never commit these.
FILENAME_DENY='(^|/)\.env(\..+)?$|(^|/)credentials\.json$|(^|/)id_rsa(\.pub)?$'

for f in "${FILES[@]}"; do
  [ -f "$f" ] || continue
  case "$f" in
    node_modules/*|dist/*|.nx/*|.angular/*|*.lock|package-lock.json) continue ;;
  esac

  if [[ "$f" =~ $FILENAME_DENY ]]; then
    report "Disallowed file staged: $f"
    continue
  fi

  for pat in "${SECRET_PATTERNS[@]}"; do
    if grep -E -n "$pat" "$f" >/dev/null 2>&1; then
      hit=$(grep -E -n "$pat" "$f" | head -1)
      report "Possible secret in $f: ${hit%%:*}"
      break
    fi
  done
done

if [ "$VIOLATIONS" -gt 0 ]; then
  echo ""
  echo "$VIOLATIONS violation(s) found. Fix before writing."
  exit 1
fi

echo "✅ validate-writes: clean (${#FILES[@]} files scanned)"
exit 0
