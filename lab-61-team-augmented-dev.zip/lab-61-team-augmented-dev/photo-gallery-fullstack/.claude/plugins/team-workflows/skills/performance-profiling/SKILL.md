---
name: performance-profiling
description: Measure and analyze application performance metrics including runtime execution, memory usage, bundle size, and rendering performance. Use when optimizing code, investigating slowdowns, or measuring Core Web Vitals.
allowed-tools: Read, Grep, Glob, Bash(npm run build:*), Bash(npx vite-bundle-analyzer:*)
---

# Performance Profiling

Measure and analyze application performance metrics including runtime execution, memory usage, bundle size, and rendering performance. Identify bottlenecks and provide quantified performance insights for optimization.

## Capabilities

This skill provides comprehensive performance analysis by:
- Profiling runtime execution times
- Measuring memory usage and detecting leaks
- Analyzing bundle sizes and code splitting
- Tracking rendering performance (React, Angular, etc.)
- Monitoring API response times
- Calculating algorithm complexity
- Measuring Core Web Vitals (LCP, FID, CLS, FCP, TTFB)
- Detecting performance regressions

## Inputs
- **Source code**: JavaScript/TypeScript files for static analysis
- **Bundle output**: Built files from Vite, Webpack, etc.
- **Runtime metrics**: Performance API data, profiling traces
- **Package.json**: Dependencies for bundle size analysis
- **Baseline data**: Previous performance measurements for comparison

## Outputs
1. **Performance Metrics**: Quantified measurements (ms, MB, %)
2. **Bottleneck Report**: Top performance issues with impact analysis
3. **Algorithm Complexity**: Big-O notation for critical functions
4. **Bundle Analysis**: Size breakdown by dependency and chunk
5. **Optimization Recommendations**: Prioritized list of improvements
6. **Regression Alerts**: Performance degradations vs baseline

## Usage Example

### Runtime Performance Analysis
```
Apply performance-profiling skill to analyze src/components/PhotoList.tsx rendering performance.
```

**Output:**
```
Performance Profile: PhotoList Component
=========================================

Rendering Performance:
├─ Initial Mount: 145ms (⚠️ Target: <100ms)
│  ├─ Component initialization: 15ms
│  ├─ Data fetching: 80ms
│  └─ DOM rendering: 50ms
│  
├─ Re-render (scroll): 8ms ✓
│  └─ Within acceptable range (<16ms for 60fps)
│  
└─ Memory Usage: 45 MB ✓

Algorithm Complexity Analysis:
├─ sortByDate(): O(n²) ⚠️ CRITICAL
│  Current: 2.3s for 1,000 items
│  Expected with O(n log n): ~8ms
│  Performance impact: 287x slower than optimal
│  
└─ filterByTag(): O(n) ✓
   Complexity is acceptable

Rendering Optimizations Needed:
1. Missing React.memo wrapper
   - Component re-renders on every parent update
   - Estimated savings: 40% fewer renders
   
2. Inline function creation in render
   - New function created on each render
   - Fix: Use useCallback hook
   
3. Large list without virtualization
   - Rendering 1,000+ items at once
   - Recommendation: Implement virtual scrolling

Core Web Vitals:
├─ LCP (Largest Contentful Paint): 2.1s (🟡 Needs improvement, target: <2.5s)
├─ FID (First Input Delay): 45ms (✓ Good, target: <100ms)
└─ CLS (Cumulative Layout Shift): 0.05 (✓ Good, target: <0.1)

Recommended Actions (Priority Order):
1. Fix O(n²) sort algorithm → Use Array.sort()
2. Add React.memo to prevent unnecessary re-renders
3. Implement virtual scrolling for large lists
4. Use useCallback for event handlers
```

### Bundle Size Analysis
```
Apply performance-profiling skill to analyze the production bundle size.
```

**Output:**
```
Bundle Size Analysis
====================

Total Bundle Size: 2.4 MB (⚠️ Target: <2 MB)
Gzip Compressed: 680 KB

Main Chunk: 1.2 MB (50%)
├─ react-dom: 350 KB (29%)
├─ lodash: 280 KB (23%) ⚠️
│  └─ Recommendation: Replace with lodash-es for tree-shaking (-60% size)
├─ moment: 230 KB (19%) ⚠️
│  └─ Recommendation: Replace with date-fns (-75% size)
├─ react: 120 KB (10%)
└─ Application code: 220 KB (19%)

Lazy Chunks: 1.2 MB (50%)
├─ PhotoEditor.chunk.js: 450 KB (38%)
├─ AdminPanel.chunk.js: 380 KB (32%)
└─ 6 other chunks: 370 KB (30%)

Optimization Opportunities:

1. Replace lodash with lodash-es
   Current: import _ from 'lodash' (280 KB)
   Optimized: import { chunk, groupBy } from 'lodash-es' (15 KB)
   Savings: 265 KB (94%)

2. Replace moment with date-fns
   Current: import moment from 'moment' (230 KB)
   Optimized: import { format, parseISO } from 'date-fns' (58 KB)
   Savings: 172 KB (75%)

3. Code split PhotoEditor
   Current: Imported in main bundle
   Optimized: React.lazy(() => import('./PhotoEditor'))
   Main bundle reduction: 450 KB (37%)

4. Remove duplicate dependencies
   Found: 3 versions of react-is
   Action: Run npm dedupe
   Savings: ~50 KB

Total Potential Savings: 937 KB (39% reduction)
New Bundle Size: 1.46 MB ✓ Under 2 MB target
```

### API Performance Profiling
```
Apply performance-profiling skill to profile API endpoint /api/photos response time.
```

**Output:**
```
API Performance Profile: GET /api/photos
========================================

Response Time Breakdown:
├─ Total: 180ms (⚠️ Baseline: 120ms, +50% regression)
│  
├─ Database Query: 140ms (78%)
│  ├─ Query execution: 120ms
│  └─ Result mapping: 20ms
│  
├─ Authentication: 25ms (14%)
│  └─ JWT verification: 25ms
│  
├─ Response Serialization: 10ms (6%)
│  
└─ Network Overhead: 5ms (2%)

Database Query Analysis:
```sql
SELECT * FROM photos 
LEFT JOIN users ON photos.user_id = users.id
WHERE photos.gallery_id = $1
ORDER BY photos.created_at DESC
```

Issues Detected:
1. Missing index on photos.gallery_id
   - Current: Full table scan (n=50,000 rows)
   - With index: Estimated 20ms (6x faster)
   
2. SELECT * fetches unnecessary columns
   - Fetching: 15 columns
   - Actually used: 6 columns
   - Recommendation: Specify columns explicitly
   
3. N+1 query pattern potential
   - If paginating, query runs per page
   - Recommendation: Add pagination at DB level

Optimization Recommendations:

1. Add database index (Highest Impact):
```sql
CREATE INDEX idx_photos_gallery_id ON photos(gallery_id);
```
Expected improvement: 180ms → 80ms (56% faster)

2. Optimize query (Medium Impact):
```sql
SELECT photos.id, photos.url, photos.title, 
       photos.created_at, users.name AS author_name
FROM photos 
LEFT JOIN users ON photos.user_id = users.id
WHERE photos.gallery_id = $1
ORDER BY photos.created_at DESC
LIMIT 50 OFFSET $2;
```
Expected improvement: 80ms → 60ms (25% faster)

3. Implement caching (High Impact for repeated queries):
```typescript
const cacheKey = `photos:gallery:${galleryId}`;
const cached = await redis.get(cacheKey);
if (cached) return cached;
// ... fetch from DB and cache
await redis.setex(cacheKey, 300, result); // 5min TTL
```
Expected improvement: 60ms → 5ms (92% faster for cached responses)

Combined Expected Performance:
- Current: 180ms
- With optimizations: ~10ms average (95% improvement)
- Cache hit rate: 70% (estimated)
```

### Memory Leak Detection
```
Apply performance-profiling skill to check for memory leaks in src/components/PhotoGallery.tsx.
```

**Output:**
```
Memory Leak Analysis: PhotoGallery Component
=============================================

🔴 CRITICAL: Event Listener Memory Leak Detected

Issue: Event listener not cleaned up on unmount
File: src/components/PhotoGallery.tsx
Lines: 45-52

Code:
```typescript
useEffect(() => {
  window.addEventListener('resize', handleResize);
  // Missing cleanup!
}, []);
```

Memory Impact:
- Leak rate: ~50 KB per component mount/unmount cycle
- With frequent navigation: 5 MB leaked per 100 page views
- User session (20 min): Potential 20-50 MB leak

Remediation:
```typescript
useEffect(() => {
  window.addEventListener('resize', handleResize);
  
  return () => {
    window.removeEventListener('resize', handleResize);
  };
}, []);
```

---

🟡 WARNING: Potential Subscription Leak

Issue: RxJS subscription not unsubscribed
File: src/services/photo.service.ts
Lines: 78-85

Code:
```typescript
ngOnInit() {
  photoService.updates$.subscribe(this.handleUpdate);
  // Missing unsubscribe!
}
```

Remediation:
```typescript
private subscription: Subscription;

ngOnInit() {
  this.subscription = photoService.updates$.subscribe(this.handleUpdate);
}

ngOnDestroy() {
  this.subscription?.unsubscribe();
}
```

Prevention:
- Always clean up resources in unmount/destroy
- Use useEffect return function for cleanup
- Consider using takeUntil operator for RxJS
- Enable React Strict Mode to detect issues early
```

## Integration Points

### Commands
- `/team-workflows:performance-review`: Primary command using this skill
- `/trace-flow`: Uses this skill to include performance characteristics

### Agents
- `performance-optimizer`: Leverages this skill for detailed analysis
- `release-safety`: Uses this skill to prevent performance regressions

### Hooks
- `post-edit`: Can trigger performance check after code changes
- `pre-commit`: Can block commits with severe performance regressions

## Measurement Techniques

### Runtime Profiling
```typescript
// Uses Performance API
performance.mark('function-start');
expensiveFunction();
performance.mark('function-end');
performance.measure('function-duration', 'function-start', 'function-end');
```

### Memory Profiling
```typescript
// Uses Memory API (Chrome DevTools Protocol)
const before = performance.memory.usedJSHeapSize;
operation();
const after = performance.memory.usedJSHeapSize;
const leaked = after - before;
```

### Bundle Analysis
- Parses webpack/vite bundle stats
- Uses source-map-explorer for size breakdown
- Analyzes treemap visualization data

## Configuration

```json
{
  "skills": {
    "performance-profiling": {
      "thresholds": {
        "response-time": 200,
        "bundle-size": 2000000,
        "memory-usage": 512000000,
        "fps": 60
      },
      "metrics": ["runtime", "memory", "bundle", "core-web-vitals"],
      "baseline-ref": "main",
      "regression-threshold": 20,
      "auto-optimize-suggestions": true
    }
  }
}
```

## Performance Considerations
- Static analysis: Fast (<1s for typical codebase)
- Runtime profiling: Requires app execution
- Memory profiling: Chrome DevTools Protocol integration
- Bundle analysis: Parses existing build artifacts
