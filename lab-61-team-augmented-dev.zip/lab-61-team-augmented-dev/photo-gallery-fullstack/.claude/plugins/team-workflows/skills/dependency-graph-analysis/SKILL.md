---
name: dependency-graph-analysis
description: Analyze and visualize project dependency relationships, identify circular dependencies, and assess impact of dependency changes. Use when planning updates, investigating dependency issues, or understanding module structure.
allowed-tools: Read, Glob, Bash(npm ls:*), Bash(npx depcheck:*)
---

# Dependency Graph Analysis

Analyze and visualize project dependency relationships, identify circular dependencies, calculate dependency depth, and assess the impact of dependency changes on the overall project structure.

## Capabilities

This skill provides deep analysis of dependency graphs for both npm packages and internal module dependencies. It can:
- Map complete dependency trees (direct and transitive)
- Identify circular dependencies and cycles
- Calculate dependency metrics (depth, breadth, complexity)
- Trace impact paths for dependency updates
- Detect duplicate dependencies across the tree
- Visualize dependency relationships

## Inputs
- **package.json**: Project dependencies configuration
- **package-lock.json / yarn.lock / pnpm-lock.yaml**: Lock file for exact versions
- **node_modules/**: Installed dependency tree (if available)
- **tsconfig.json**: Module resolution configuration
- **import statements**: Source code imports to analyze module usage

## Outputs
1. **Dependency Tree**: Hierarchical structure of all dependencies
2. **Circular Dependency Report**: List of cycles with file paths
3. **Dependency Metrics**: Depth, breadth, complexity scores
4. **Impact Analysis**: Which modules are affected by changes
5. **Visualization**: ASCII or graph representation of dependencies
6. **Optimization Recommendations**: Suggestions for reducing complexity

## Usage Example

### Basic Dependency Analysis
```
Apply dependency-graph-analysis skill to analyze the current project structure.
```

**Output:**
```
Dependency Graph Analysis
========================

Direct Dependencies: 45
Total Dependencies (including transitive): 287
Maximum Depth: 8 levels
Average Depth: 3.2 levels

Top-Level Dependencies:
├─ react@18.2.0
│  ├─ loose-envify@1.4.0
│  │  └─ js-tokens@4.0.0
│  └─ scheduler@0.23.0
│     └─ loose-envify@1.4.0 (duplicate)
│  
├─ react-dom@18.2.0
│  ├─ loose-envify@1.4.0 (duplicate)
│  ├─ react@18.2.0 (peer)
│  └─ scheduler@0.23.0 (duplicate)
│  
└─ lodash@4.17.21 (⚠️ No dependencies - consider lodash-es for tree-shaking)

Circular Dependencies: NONE ✓

Duplicate Dependencies: 2 found
├─ loose-envify@1.4.0 (used 3 times)
└─ scheduler@0.23.0 (used 2 times)

Optimization Opportunities:
1. Replace lodash with lodash-es for better tree-shaking
2. Consider deduping: npm dedupe or yarn dedupe
```

### Impact Analysis for Dependency Update
```
Apply dependency-graph-analysis skill to assess impact of updating lodash from 4.17.20 to 4.17.21.
```

**Output:**
```
Impact Analysis: lodash 4.17.20 → 4.17.21
===========================================

Direct Dependents: 1 package
├─ photo-gallery-team-augmented@1.0.0

Transitive Dependents: NONE
(No other packages depend on lodash)

Source Code Usage:
├─ src/utils/array-helpers.ts (3 imports)
│  ├─ import { chunk } from 'lodash'
│  ├─ import { groupBy } from 'lodash'
│  └─ import { sortBy } from 'lodash'
│  
├─ src/services/photo.service.ts (1 import)
│  └─ import { debounce } from 'lodash'
│  
└─ src/components/PhotoList.tsx (1 import)
   └─ import { throttle } from 'lodash'

Impact Level: LOW
- Update type: PATCH (no breaking changes)
- Affected files: 3 files directly import lodash
- Test coverage: 85% of files have tests
- Risk: Minimal (patch version update)

Recommended Action:
1. Update: npm install lodash@4.17.21
2. Run tests: npm test
3. No code changes required
```

### Circular Dependency Detection
```
Apply dependency-graph-analysis skill to check for circular dependencies in src/ directory.
```

**Output:**
```
Circular Dependency Analysis
============================

⚠️ FOUND 2 CIRCULAR DEPENDENCIES

Cycle 1: (Length: 3 modules)
src/services/photo.service.ts
  → imports from src/utils/photo-helpers.ts
    → imports from src/models/Photo.ts
      → imports from src/services/photo.service.ts ⚠️

Resolution Suggestion:
Move shared types to src/types/photo.types.ts to break the cycle.

Cycle 2: (Length: 2 modules)
src/components/PhotoCard.tsx
  → imports from src/components/PhotoActions.tsx
    → imports from src/components/PhotoCard.tsx ⚠️

Resolution Suggestion:
Extract shared logic to a custom hook or separate component.

Impact:
- Build warnings in some bundlers
- Potential initialization issues
- Harder to understand module relationships
- May cause tree-shaking problems

Recommended Refactoring:
1. Extract shared types to dedicated files
2. Use dependency injection for circular service dependencies
3. Consider architectural patterns (layered architecture, hexagonal)
```

## Integration Points

### Commands
- `/team-workflows:analyze-dependencies`: Uses this skill for dependency tree analysis
- `/trace-flow`: Uses this skill to understand module dependencies in flow tracing

### Agents
- `dependency-tracker`: Leverages this skill for compatibility and impact analysis
- `architecture-guardian`: Uses this skill to enforce architectural boundaries

### Hooks
- `pre-commit`: Can trigger circular dependency check before allowing commits

## Algorithm

1. **Parse Dependency Sources**
   - Read package.json for declared dependencies
   - Parse lock files for exact versions
   - Scan source code for import/require statements

2. **Build Dependency Graph**
   - Create nodes for each package/module
   - Create edges for dependency relationships
   - Track version constraints and ranges

3. **Analyze Graph Structure**
   - Calculate depth (longest path from root)
   - Calculate breadth (number of direct dependencies)
   - Detect cycles using DFS with visited set
   - Identify duplicate packages at different locations

4. **Generate Insights**
   - Compare versions across duplicates
   - Calculate metrics (complexity, maintainability)
   - Suggest optimizations (deduping, replacements)
   - Identify security-sensitive packages

## Configuration

```json
{
  "skills": {
    "dependency-graph-analysis": {
      "max-depth-warning": 10,
      "detect-duplicates": true,
      "include-dev-dependencies": false,
      "visualize-format": "ascii",
      "exclude-patterns": ["@types/*", "eslint-*"]
    }
  }
}
```

## Performance Considerations
- Large projects (1000+ dependencies) may take 10-30 seconds
- Uses caching to avoid re-analyzing unchanged dependency trees
- Can run incrementally for focused analysis of specific subgraphs
