---
name: security-pattern-detection
description: Identify security anti-patterns, vulnerabilities, and insecure coding practices. Use when analyzing code for OWASP Top 10 vulnerabilities, CWE patterns, SQL injection, XSS, hardcoded secrets, or security misconfigurations.
allowed-tools: Read, Grep, Glob
---

# Security Pattern Detection

Identify common security anti-patterns, vulnerabilities, and insecure coding practices in source code. This skill analyzes code for OWASP Top 10 vulnerabilities, CWE patterns, and team-specific security rules.

## Capabilities

This skill provides comprehensive security analysis by:
- Detecting SQL injection vulnerabilities
- Identifying XSS (Cross-Site Scripting) risks
- Finding hardcoded secrets and credentials
- Checking authentication/authorization flaws
- Detecting insecure cryptography usage
- Identifying CSRF vulnerabilities
- Finding path traversal risks
- Detecting insecure deserialization
- Checking for security misconfiguration

## Inputs
- **Source code files**: TypeScript, JavaScript, React, Node.js
- **Configuration files**: Security headers, CORS policies, environment configs
- **Dependencies**: package.json for vulnerable package detection
- **Security standards**: Team security guidelines from `.claude/references/coding-standards.md`

## Outputs
1. **Vulnerability Report**: List of security issues with severity levels
2. **CWE Classification**: Standard vulnerability categorization
3. **Exploit Scenarios**: How vulnerabilities could be exploited
4. **Remediation Steps**: Specific fixes for each issue
5. **Prevention Guidance**: Best practices to avoid similar issues
6. **Compliance Status**: OWASP Top 10 coverage assessment

## Usage Example

### SQL Injection Detection
```
Apply security-pattern-detection skill to analyze src/api/users.service.ts for security vulnerabilities.
```

**Output:**
```
Security Pattern Analysis: src/api/users.service.ts
===================================================

🔴 CRITICAL: SQL Injection (CWE-89)
Line 45: const query = `SELECT * FROM users WHERE id = ${req.params.id}`

Pattern Detected: String interpolation in SQL query
Risk: User input directly concatenated into SQL statement
Exploit: Attacker can inject malicious SQL: ?id=1 OR 1=1

Remediation:
Use parameterized queries:
```typescript
const result = await db.query(
  'SELECT * FROM users WHERE id = $1',
  [req.params.id]
);
```

Prevention:
- Always use parameterized queries or ORM
- Never concatenate user input into SQL
- Implement input validation
```

### XSS Vulnerability Detection
```
Apply security-pattern-detection skill to scan src/components/ for XSS risks.
```

**Output:**
```
XSS Vulnerability Analysis
==========================

🟠 HIGH: DOM-based XSS (CWE-79)
File: src/components/UserProfile.tsx
Line 23: <div dangerouslySetInnerHTML={{__html: user.bio}} />

Pattern Detected: Unescaped user content rendered as HTML
Risk: User-controlled HTML can execute scripts
Exploit: User sets bio to: <script>steal Cookies()</script>

Remediation:
Option 1: Use text content (safest):
```typescript
<div>{user.bio}</div>
```

Option 2: Sanitize HTML (if HTML formatting required):
```typescript
import DOMPurify from 'dompurify';
<div dangerouslySetInnerHTML={{
  __html: DOMPurify.sanitize(user.bio)
}} />
```

Prevention:
- Avoid dangerouslySetInnerHTML when possible
- Always sanitize user-controlled HTML
- Use Content Security Policy (CSP) headers
```

### Secret Detection
```
Apply security-pattern-detection skill to check for hardcoded secrets in the codebase.
```

**Output:**
```
Hardcoded Secret Detection
==========================

🔴 CRITICAL: Exposed API Key (CWE-798)
File: src/config/api.config.ts
Line 12: const API_KEY = "sk_live_abc123xyz789"

Pattern Detected: Hardcoded credential in source code
Risk: Secret exposed in version control, visible to all developers
Impact: Unauthorized API access, potential data breach

Remediation:
1. Revoke exposed API key immediately
2. Generate new API key
3. Store in environment variable:
```typescript
const API_KEY = process.env.VITE_API_KEY;
if (!API_KEY) {
  throw new Error('VITE_API_KEY environment variable is required');
}
```

4. Add to .env.example (without actual value):
```
VITE_API_KEY=your_api_key_here
```

5. Ensure .env is in .gitignore

Prevention:
- Never commit secrets to version control
- Use environment variables or secret management
- Enable git hooks to detect secrets (e.g., git-secrets)
- Rotate secrets regularly
```

### Authentication/Authorization Check
```
Apply security-pattern-detection skill to review authentication implementation in src/middleware/auth.ts.
```

**Output:**
```
Authentication Security Analysis
================================

🟡 MEDIUM: Weak JWT Secret (CWE-327)
File: src/middleware/auth.ts
Line 8: const JWT_SECRET = "secret123"

Pattern Detected: Weak cryptographic key
Risk: Easy to brute-force, compromises all JWT tokens
Impact: Attackers can forge valid tokens

Remediation:
```typescript
// Generate strong secret (minimum 256 bits / 32 bytes)
const JWT_SECRET = process.env.JWT_SECRET;
if (!JWT_SECRET || JWT_SECRET.length < 32) {
  throw new Error('JWT_SECRET must be at least 32 characters');
}
```

Generate strong secret:
```bash
openssl rand -hex 32
```

---

🟡 MEDIUM: Missing Token Expiration (CWE-613)
File: src/middleware/auth.ts
Line 15: const token = jwt.sign({userId}, JWT_SECRET)

Pattern Detected: JWT without expiration time
Risk: Stolen tokens remain valid indefinitely
Impact: Increased window for token theft/reuse

Remediation:
```typescript
const token = jwt.sign(
  { userId },
  JWT_SECRET,
  { expiresIn: '1h' } // Add expiration
);
```

Also implement token refresh mechanism.
```

## Integration Points

### Commands
- `/team-workflows:security-scan`: Primary command using this skill
- `/code-reviewer`: Applies this skill for security-focused reviews

### Agents
- `security-auditor`: Leverages this skill for vulnerability assessment
- `release-safety`: Uses this skill to prevent vulnerable code deployment

### Hooks
- `pre-commit`: Can run security pattern detection before allowing commits

## Detection Patterns

### SQL Injection
```regex
Pattern: String concatenation or template literals in SQL queries
Indicators:
- \`SELECT.*\${.*}\`
- "SELECT" + variable
- .query(userInput)
```

### XSS
```regex
Pattern: Unescaped user content in HTML
Indicators:
- dangerouslySetInnerHTML
- innerHTML = userContent
- document.write(userInput)
```

### Secrets
```regex
Pattern: Hardcoded credentials
Indicators:
- API_KEY = "sk_"
- password = "..."
- token: "eyJ..."
- connectionString with credentials
```

### Insecure Crypto
```regex
Pattern: Weak cryptographic practices
Indicators:
- md5, sha1 for passwords
- Math.random() for security tokens
- ECB mode encryption
- Hardcoded encryption keys
```

## Configuration

```json
{
  "skills": {
    "security-pattern-detection": {
      "severity-threshold": "medium",
      "patterns": {
        "sql-injection": true,
        "xss": true,
        "secrets": true,
        "insecure-crypto": true,
        "auth-issues": true
      },
      "custom-rules": [
        {
          "id": "team-rule-001",
          "pattern": "eval\\(",
          "severity": "critical",
          "message": "eval() is forbidden by team policy"
        }
      ],
      "exclude-patterns": ["**/*.test.ts", "**/mocks/**"]
    }
  }
}
```

## Performance Considerations
- Scans ~1000 lines per second
- Regex-based detection (may have false positives)
- Can run incrementally on changed files only
- Caches results for unchanged files
