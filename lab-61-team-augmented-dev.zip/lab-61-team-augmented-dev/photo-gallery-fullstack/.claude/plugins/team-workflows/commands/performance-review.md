# Performance Review Command

**Invocation**: `/team-workflows:performance-review [options]`

## Purpose

Profile application performance, identify bottlenecks, and provide optimization recommendations based on runtime metrics and code analysis.

## Options

- `--component <name>`: Focus on specific component or module
- `--metric <type>`: Analyze specific metric: "response-time", "memory", "cpu", "bundle-size" - default: "all"
- `--baseline <ref>`: Compare against baseline (git ref or saved profile)
- `--threshold <value>`: Alert threshold for regression detection
- `--format <value>`: Output format "table", "json", "html-report" - default: "table"
- `--profile-runtime`: Include runtime profiling data (requires app running)

## Analysis Categories

### 1. Bundle Size Analysis
- Total bundle size and split chunks
- Largest dependencies contributing to bundle
- Unused code detection (tree-shaking opportunities)
- Duplicate dependencies

### 2. Runtime Performance
- Component render times
- API response times
- Memory usage patterns
- CPU-intensive operations
- Event loop blocking

### 3. Code Patterns
- Inefficient algorithms (O(n²) loops, etc.)
- Unnecessary re-renders
- Memory leaks (unclosed subscriptions, event listeners)
- Missing performance optimizations (memoization, lazy loading)

### 4. Asset Optimization
- Image sizes and formats
- Unoptimized assets
- Missing compression
- CDN usage opportunities

## Output Format

```
Performance Review Report
=========================

Bundle Analysis:
├─ Total size: 2.4 MB (⚠️ 20% larger than baseline)
├─ Main chunk: 1.2 MB
│  └─ Largest contributors:
│     ├─ react-dom: 350 KB
│     ├─ lodash: 280 KB (⚠️ Consider lodash-es for tree-shaking)
│     └─ moment: 230 KB (💡 Suggest: Replace with date-fns)
└─ Lazy chunks: 8 files, 1.2 MB total

Runtime Performance:
├─ Gallery Component:
│  ├─ Initial render: 145ms (⚠️ Target: <100ms)
│  ├─ Re-render on scroll: 8ms ✓
│  └─ Memory usage: 45 MB ✓
│  
├─ Image Upload:
│  ├─ Response time: 2.3s (🔴 Target: <1s)
│  ├─ Issue: Large image processing on main thread
│  └─ Recommendation: Use Web Workers for image processing
│  
└─ API Endpoints:
   ├─ GET /api/photos: 180ms (⚠️ Baseline: 120ms, +50% regression)
   ├─ POST /api/upload: 2.1s ✓
   └─ GET /api/user: 45ms ✓

Code Pattern Issues:
├─ 🔴 CRITICAL: O(n²) loop in PhotoList.sortByDate()
│  File: src/components/PhotoList.tsx:89
│  Impact: Performance degrades with >100 items
│  Fix: Use single-pass sort algorithm
│  
├─ 🟡 WARNING: Missing React.memo on expensive component
│  File: src/components/PhotoCard.tsx
│  Impact: Unnecessary re-renders on parent state change
│  Fix: Wrap component with React.memo
│  
└─ 💡 OPTIMIZATION: Lazy load PhotoEditor component
   File: src/pages/EditorPage.tsx:12
   Benefit: Reduce initial bundle by 180 KB
   Fix: Use React.lazy(() => import('./PhotoEditor'))

Asset Optimization:
├─ Unoptimized images: 23 files, 4.5 MB
│  Recommendation: Compress and convert to WebP format
│  Estimated savings: 3.2 MB (71%)
│  
└─ Missing CDN: Static assets served from origin
   Recommendation: Enable CDN for static files
   Expected improvement: 200ms faster load time

Summary:
- 🔴 Critical issues: 1 (performance blocker)
- 🟠 High priority: 3 (performance regression)
- 🟡 Medium priority: 8 (optimization opportunities)
- 💡 Suggestions: 12 (nice-to-have improvements)

Recommended Actions (Priority Order):
1. Fix O(n²) loop in PhotoList component
2. Offload image processing to Web Worker
3. Investigate API endpoint regression (/api/photos)
4. Implement lazy loading for PhotoEditor
5. Compress and optimize image assets
```

## Integration with Skills

- Uses `performance-profiling` skill for runtime analysis
- Applies `framework-conventions` skill to suggest idiomatic optimizations

## Integration with Agents

- Consults `performance-optimizer` agent for detailed optimization strategies
- Can escalate critical performance regressions to `release-safety` agent

## Integration with MCP

- Connects to `metrics-analyzer` MCP server for historical performance tracking
- Can correlate performance with deployment events and code changes

## Continuous Monitoring

Enable post-edit hook to track performance impact:
```json
{
  "post-edit": {
    "enabled": true,
    "command": "performance-review",
    "args": ["--component", "${EDITED_COMPONENT}", "--baseline", "HEAD~1"],
    "alertOnRegression": true
  }
}
```
