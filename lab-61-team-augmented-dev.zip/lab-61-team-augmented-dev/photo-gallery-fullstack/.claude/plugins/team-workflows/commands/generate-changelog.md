# Generate Changelog Command

**Invocation**: `/team-workflows:generate-changelog [options]`

## Purpose

Automatically generate structured changelog from git commit history following conventional commit standards (feat, fix, docs, refactor, etc.).

## Options

- `--since <ref>`: Start from git ref (tag, branch, or commit SHA) - default: last tag
- `--until <ref>`: End at git ref - default: HEAD
- `--format <value>`: Output format "markdown", "json", or "keepachangelog" - default: "markdown"
- `--include-breaking`: Highlight breaking changes (default: true)
- `--group-by <value>`: Group by "type", "scope", or "author" - default: "type"
- `--output <file>`: Write to file instead of stdout

## Behavior

1. Parse git log between specified refs
2. Categorize commits by conventional commit type:
   - `feat`: New features
   - `fix`: Bug fixes
   - `docs`: Documentation changes
   - `refactor`: Code refactoring
   - `perf`: Performance improvements
   - `test`: Test additions/changes
   - `chore`: Build/tooling changes
3. Extract breaking changes from commit bodies (BREAKING CHANGE: ...)
4. Generate structured changelog with version bumping recommendation

## Output Format (Markdown)

```markdown
# Changelog

## [Unreleased] - 2026-01-18

### ⚠️ Breaking Changes
- **api**: Changed authentication endpoint from /auth to /api/auth (#123)

### ✨ Features
- **gallery**: Add image lazy loading (#120)
- **upload**: Support batch file uploads (#118)

### 🐛 Bug Fixes
- **gallery**: Fix image rendering on mobile devices (#119)
- **auth**: Correct token expiration handling (#117)

### 📚 Documentation
- Update API documentation for new endpoints (#121)

### ⚡ Performance
- **gallery**: Optimize thumbnail generation (#116)

### 🔧 Chores
- Update dependencies to latest versions (#115)

Recommended version bump: **MAJOR** (breaking changes detected)
```

## Integration with MCP

- Connects to `changelog-server` MCP server for advanced formatting and version management
- Can publish changelog directly to documentation site if configured

## Agent Context

Consult `dependency-tracker` agent for dependency-related changes to include in changelog.
