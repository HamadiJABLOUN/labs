---
name: add-tests
description: "Slash command (/add-tests): Generate comprehensive test cases for specified code, including edge cases and error scenarios."
---

# /add-tests

Generate comprehensive test cases for specified code, including edge cases and error scenarios.

## Purpose

Assist developers in achieving thorough test coverage by:
- Analyzing code to identify test scenarios
- Generating test stubs or complete test implementations
- Identifying edge cases and error conditions
- Recommending appropriate test type (unit, integration, e2e)

## Usage

Invoke this command with a file path, function, or class to test:

```
/add-tests src/domain/services/photo.service.ts
```

Or specify a particular function:

```
/add-tests PhotoService.processUpload
```

## Output Format

The command will generate:

1. **Test Strategy**: Recommended test type and approach
2. **Test Scenarios**: List of scenarios to cover (happy path, edge cases, errors)
3. **Test Implementation**: Complete test code ready to add to your test suite

## Example Output

```typescript
// Test Strategy: Unit Tests (PhotoService logic should be tested in isolation)
// Mock: S3Storage, PhotoRepository, ImageProcessor

describe('PhotoService.processUpload', () => {
  let service: PhotoService;
  let mockStorage: jest.Mocked<S3Storage>;
  let mockRepository: jest.Mocked<PhotoRepository>;
  let mockImageProcessor: jest.Mocked<ImageProcessor>;

  beforeEach(() => {
    mockStorage = createMockStorage();
    mockRepository = createMockRepository();
    mockImageProcessor = createMockImageProcessor();
    service = new PhotoService(mockStorage, mockRepository, mockImageProcessor);
  });

  describe('Happy Path', () => {
    it('should process and upload valid image successfully', async () => {
      // Arrange
      const file = createMockFile('test.jpg', 1024);
      mockImageProcessor.resize.mockResolvedValue(Buffer.from('resized'));
      mockStorage.upload.mockResolvedValue('https://s3.example.com/photo.jpg');
      mockRepository.create.mockResolvedValue({ id: '123', url: '...' });

      // Act
      const result = await service.processUpload(file);

      // Assert
      expect(result.id).toBe('123');
      expect(mockImageProcessor.resize).toHaveBeenCalledWith(
        expect.any(Buffer),
        { width: 1200, height: 800 }
      );
      expect(mockStorage.upload).toHaveBeenCalled();
      expect(mockRepository.create).toHaveBeenCalled();
    });
  });

  describe('Edge Cases', () => {
    it('should handle very large file sizes within limit', async () => {
      const file = createMockFile('large.jpg', 5 * 1024 * 1024); // 5MB
      // Test implementation...
    });

    it('should handle files at exact size limit', async () => {
      const file = createMockFile('exact.jpg', 10 * 1024 * 1024); // 10MB
      // Test implementation...
    });

    it('should handle unusual but valid file extensions', async () => {
      const file = createMockFile('test.jpeg', 1024); // .jpeg instead of .jpg
      // Test implementation...
    });
  });

  describe('Error Scenarios', () => {
    it('should reject file exceeding size limit', async () => {
      const file = createMockFile('huge.jpg', 11 * 1024 * 1024); // 11MB
      await expect(service.processUpload(file)).rejects.toThrow('File size exceeds limit');
    });

    it('should reject invalid file type', async () => {
      const file = createMockFile('document.pdf', 1024);
      await expect(service.processUpload(file)).rejects.toThrow('Invalid file type');
    });

    it('should handle S3 upload failure gracefully', async () => {
      const file = createMockFile('test.jpg', 1024);
      mockImageProcessor.resize.mockResolvedValue(Buffer.from('resized'));
      mockStorage.upload.mockRejectedValue(new Error('S3 connection failed'));

      await expect(service.processUpload(file)).rejects.toThrow('Upload failed');
      expect(mockRepository.create).not.toHaveBeenCalled(); // Rollback behavior
    });

    it('should handle database insertion failure', async () => {
      const file = createMockFile('test.jpg', 1024);
      mockImageProcessor.resize.mockResolvedValue(Buffer.from('resized'));
      mockStorage.upload.mockResolvedValue('https://s3.example.com/photo.jpg');
      mockRepository.create.mockRejectedValue(new Error('Database error'));

      await expect(service.processUpload(file)).rejects.toThrow('Failed to save metadata');
    });
  });

  describe('Validation', () => {
    it('should validate required file metadata is present', async () => {
      const invalidFile = { ...createMockFile('test.jpg', 1024), mimetype: undefined };
      await expect(service.processUpload(invalidFile)).rejects.toThrow('Missing file metadata');
    });
  });
});
```

## Test Coverage Analysis

The generated tests cover:

- ✅ **Happy Path**: Valid input produces expected output
- ✅ **Edge Cases**: Boundary conditions, unusual but valid inputs
- ✅ **Error Scenarios**: Invalid inputs, external dependency failures
- ✅ **Validation**: Input validation and precondition checks
- ✅ **Rollback Behavior**: Cleanup on failure (if applicable)

## Activation Triggers

- Reference `testing-guidelines.md` for team test standards
- Consult `test-strategist` agent for test strategy recommendations
- Apply appropriate test type based on code layer (unit for business logic, integration for data access)

## Configuration

You can specify test preferences:

```
/add-tests src/api/controllers/photo.controller.ts --type integration
/add-tests PhotoService --framework vitest
/add-tests UserRepository --coverage-target 90
```

You generate practical, comprehensive test suites that catch real bugs and give developers confidence in their changes.
