---
name: debug-correlation
description: Perform root cause analysis for production issues by correlating logs, metrics, and code paths. Use when investigating errors, performance issues, or unexpected behavior.
---

# Debug Correlation

Perform root cause analysis for production issues by correlating logs, metrics, and code paths. This skill helps developers quickly identify the source of problems in the photo gallery application.

## Capabilities

### 1. Error Correlation
- Trace errors from symptoms to root cause
- Correlate errors across service boundaries
- Identify patterns in error occurrences

### 2. Performance Analysis
- Identify slow code paths
- Correlate latency with specific operations
- Find resource contention issues

### 3. Behavioral Debugging
- Understand unexpected behavior
- Trace data flow through the system
- Identify race conditions and timing issues

## Usage Context

This skill activates when:
- Investigating production errors
- Analyzing performance degradation
- Debugging unexpected behavior
- Responding to on-call incidents

## Common Photo Gallery Issues

### Issue 1: Upload Failures

**Symptoms**: Photo upload fails intermittently

**Correlation Points**:
```
1. Frontend logs: Check upload request status
2. Backend logs: PhotosController.upload() entry/exit
3. Service logs: PhotoService.create() errors
4. Storage logs: File system write failures
5. Database logs: TypeORM transaction errors
```

**Common Causes**:
- File size exceeds 5MB limit
- Disk space exhaustion in `dist/uploads/`
- SQLite database locked (concurrent writes)
- Multer configuration issues

### Issue 2: Slow API Response

**Symptoms**: GET /api/photos takes >500ms

**Correlation Points**:
```
1. Request timing: Time from request to response
2. Database queries: TypeORM query logging
3. File operations: Image processing time
4. Memory usage: Node.js heap snapshots
```

**Common Causes**:
- Missing database indexes
- Large result sets without pagination
- Synchronous file operations blocking event loop
- Memory leaks in long-running processes

### Issue 3: Database Lock Errors

**Symptoms**: "SQLITE_BUSY: database is locked"

**Correlation Points**:
```
1. Concurrent requests: Check request timing
2. Transaction duration: Long-running transactions
3. Write operations: Bulk inserts/updates
```

**Resolution Steps**:
1. Enable WAL mode: `PRAGMA journal_mode=WAL;`
2. Add retry logic with exponential backoff
3. Optimize transaction scope

## Debug Workflow

### Step 1: Reproduce
```bash
# Run backend with debug logging
nx serve backend --verbose

# Trigger the issue
curl -X POST http://localhost:3000/api/photos/upload ...
```

### Step 2: Collect Evidence
```bash
# Check logs
tail -f dist/apps/backend-nestjs/logs/*.log

# Check database
sqlite3 dist/db/photogallery.db ".schema"
sqlite3 dist/db/photogallery.db "SELECT * FROM photos ORDER BY createdAt DESC LIMIT 10"
```

### Step 3: Correlate
- Match timestamps across logs
- Identify the failing component
- Trace data flow through the system

### Step 4: Root Cause
- Identify the specific code path
- Understand why it failed
- Determine fix and prevention

## Code Paths to Investigate

### Photo Upload Flow
```
POST /api/photos/upload
  -> PhotosController.upload()
    -> Multer (file handling)
    -> PhotoService.create()
      -> PhotoRepository.save()
        -> TypeORM -> SQLite
      -> File storage (dist/uploads/)
```

### Photo Retrieval Flow
```
GET /api/photos/:id
  -> PhotosController.findOne()
    -> PhotoService.findById()
      -> PhotoRepository.findById()
        -> TypeORM -> SQLite
```

## Integration with Other Skills

- **topology-awareness**: Maps dependencies for tracing
- **change-impact-analysis**: Identifies recent changes that may cause issues
- **framework-conventions**: Ensures debug patterns follow conventions

## On-Call Reference

For common incidents and resolution steps, see:
- `references/oncall.md` - Standard operating procedures
- `references/architecture.md` - System topology for tracing

## Metrics

Success criteria for debug correlation:
- Mean time to identify root cause < 30 minutes
- 90%+ of issues traced to specific code paths
- Runbook accuracy > 95%
