---
name: incremental-refactoring
description: Plan and execute safe, step-by-step refactoring transformations that minimize risk and maintain system stability. Use when modernizing legacy code or restructuring components.
---

# Incremental Refactoring

Plan and execute safe, step-by-step refactoring transformations that minimize risk and maintain system stability. This skill ensures refactorings are reversible and testable at each step.

## Capabilities

### 1. Refactoring Step Planning
- Break large refactorings into atomic, reversible steps
- Identify safe stopping points
- Sequence changes to minimize risk

### 2. Parallel Change Pattern
- Implement new patterns alongside existing code
- Gradually migrate consumers
- Remove legacy code only after full migration

### 3. Verification Strategies
- Define test checkpoints between steps
- Ensure behavior preservation at each stage
- Plan rollback procedures for each step

## Usage Context

This skill activates when:
- Refactoring callback-based code to async/await
- Extracting services from monolithic classes
- Migrating between frameworks or libraries
- Modernizing legacy patterns

## Refactoring Patterns

### Pattern 1: Strangler Fig
Replace legacy components gradually by routing new functionality through new implementation.

### Pattern 2: Branch by Abstraction
Introduce abstraction layer, implement new version, switch consumers, remove old version.

### Pattern 3: Parallel Run
Run old and new implementations simultaneously, compare outputs, switch when confident.

## Example: Callback to Async/Await Migration

**Target**: `legacy-storage.service.ts` with callback-based patterns

### Step 1: Add Wrapper Method
```typescript
// Add async wrapper alongside existing callback method
async saveFileAsync(path: string, data: Buffer): Promise<void> {
  return new Promise((resolve, reject) => {
    this.saveFile(path, data, (err) => {
      if (err) reject(err);
      else resolve();
    });
  });
}
```
**Checkpoint**: Run tests, verify existing consumers still work

### Step 2: Migrate Consumers One-by-One
```typescript
// Before
this.storage.saveFile(path, data, callback);

// After
await this.storage.saveFileAsync(path, data);
```
**Checkpoint**: Run tests after each consumer migration

### Step 3: Replace Implementation
```typescript
// Replace callback internals with async implementation
async saveFile(path: string, data: Buffer): Promise<void> {
  await fs.promises.writeFile(path, data);
}
```
**Checkpoint**: Full test suite, performance comparison

### Step 4: Remove Legacy Code
- Remove callback-based methods
- Update documentation
- Clean up temporary wrappers

## Risk Mitigation

### At Each Step:
- All tests must pass
- No new errors in logs
- Performance within acceptable bounds
- Rollback plan documented

### Red Flags (Stop Refactoring):
- Test failures that can't be quickly resolved
- Unexpected behavior in production logs
- Performance degradation > 10%
- Team member unavailable to support

## Integration with Other Skills

- **topology-awareness**: Identifies consumers needing migration
- **change-impact-analysis**: Assesses risk of each step
- **framework-conventions**: Ensures new code follows patterns

## Photo Gallery Application

Common refactoring targets:
- `legacy-storage.service.ts`: Callback-based file operations
- `PhotoService`: Extract thumbnail generation to separate service
- `PhotoRepository`: Add caching layer using Repository pattern

## Metrics

Success criteria for incremental refactoring:
- Zero production incidents during refactoring
- Each step independently reversible
- Test coverage maintained or improved throughout
