---
name: topology-awareness
description: Analyze system topology to identify dependencies, impact zones, and architectural relationships. Use when planning changes that cross module boundaries or analyzing API modifications.
---

# Topology Awareness

Analyze system topology to identify dependencies, impact zones, and architectural relationships. This skill helps developers understand how changes in one component affect others.

## Capabilities

### 1. Dependency Mapping
- Identify direct and transitive dependencies for a given module
- Map service-to-service communication patterns
- Visualize data flow across system boundaries

### 2. Impact Zone Identification
- Determine which components are affected by a proposed change
- Flag downstream consumers that may break
- Identify integration points requiring coordination

### 3. Breaking Change Detection
- Analyze API contract changes for backward compatibility
- Identify database schema changes affecting multiple services
- Flag shared library updates impacting multiple consumers

## When to Use

This skill activates automatically when:
- Analyzing code changes that modify public APIs
- Planning refactorings that cross module boundaries
- Reviewing pull requests with cross-cutting changes
- Tracing request flows through the system

## Knowledge Sources

- **architecture.md**: System topology and module relationships (see references/)
- **Project structure**: Import/export analysis
- **Git history**: Past change correlations

## Example Analysis

### API Endpoint Modification

**Input**: Developer modifies `GET /api/photos/:id` response schema

**Analysis**:
```
Dependency Tree:
  PhotoController.getPhoto()
    -> PhotoService.findById()
      -> PhotoRepository.findOne()
    -> PhotoDto (response mapper)

Consumers:
  - Mobile App (iOS/Android): Uses full response
  - Web App: Uses subset (id, url, title)
  - Admin Dashboard: Uses full response with metadata

Impact: HIGH - Removing fields will break mobile app
```

**Recommendation**: Add new fields but don't remove existing ones (backward compatible)

## Photo Gallery Project Structure

```
apps/
  frontend/src/         # Angular application
    app/
      components/       # UI components
      services/         # API client services
  backend/src/          # NestJS API
    api/                # HTTP controllers
    domain/             # Business logic (PhotoService)
    infrastructure/     # Data access (TypeORM repositories)
```

## Integration with Other Skills

- **change-impact-analysis**: Provides dependency data for impact assessment
- **incremental-refactoring**: Uses topology to plan safe refactoring steps
- **framework-conventions**: Applies conventions consistently across topology

## Metrics

Success criteria for topology awareness:
- Identifies 95%+ of direct dependencies
- Flags breaking changes before they reach production
- Reduces cross-module integration issues by 40%
