# Lab 41 Solution : Agentic Tools Deep Dive

> **Public : stagiaires.** À lire après avoir tenté le lab. Ce document déroule le résultat
> attendu et le raisonnement qui y mène.

## Référence de la solution

Les solutions complètes de tous les exercices du lab sont les fichiers de configuration pré-construits du projet **photo-gallery-fullstack** :

```
labs/lab-41-agentic-tools-deep-dive-solution/resources/photo-gallery-fullstack-solution/
```

### Emplacements des solutions par plateforme

| Plateforme         | Répertoire de config | Fichiers clés                                                                                                        |
| ------------------ | -------------------- | -------------------------------------------------------------------------------------------------------------------- |
| **Claude Code**    | `.claude/`           | `agents/`, `commands/`, `skills/`, `plugins/`, `rules/`, `settings.json`                                             |
| **GitHub Copilot** | `.github/`           | `agents/`, `prompts/`, `instructions/`, `skills/`, `hooks/`, `copilot-instructions.md`, plugins via `copilot plugin` |
| **Gemini CLI**     | `.gemini/`           | `agents/` (exp.), `commands/`, `skills/`, `hooks/`, `settings.json`, extensions via `gemini extensions`              |
| **Codex CLI**      | `.codex/`            | `agents/*.toml`, `skills/`, `rules/`, `references/`, `config.toml` + `AGENTS.md` à la racine                         |
| **OpenCode**       | `.opencode/`         | `agents/*.md`, `commands/*.md`, `skills/`, `plugins/` + `AGENTS.md` à la racine + `opencode.json`                    |
| **Mistral Vibe**   | `.vibe/`             | `agents/*.md`, `skills/` (slash commands), `references/`, `hooks.toml`, `config.toml` + `AGENTS.md` à la racine      |

### Référence des fonctionnalités multi-plateformes

Toutes les plateformes partagent la même agent skill (format SKILL.md) :

- `change-impact-analysis` - Évaluation des risques et du blast radius

Toutes les plateformes partagent les mêmes 5 documents de référence :

- `architecture.md` - Topologie du système et découpage en couches
- `coding-standards.md` - Conventions TypeScript/Angular/NestJS
- `domain-glossary.md` - Terminologie métier
- `testing-guidelines.md` - Stratégies et patterns de test
- `oncall.md` - Procédures d'escalade des incidents

---

## Déroulé par section

Chaque exercice ci-dessous renvoie à un fichier de
`resources/photo-gallery-fullstack-solution/`. Deux exercices ne produisent aucun artefact commité,
et c'est indiqué.

Trois constantes traversent les six plateformes, et c'est là tout l'objet du lab :

1. **Le fichier de contexte d'abord.** Chaque parcours commence par rédiger le fichier d'instructions
   racine de l'outil. Tout le reste s'y réfère. Un stagiaire qui bâcle cette étape finit avec des
   agents qui ré-expliquent le projet à chaque prompt.
2. **Les cinq fichiers `references/` sont la vraie matière.** Agents, commandes et skills ne sont que
   des enveloppes ; la connaissance vit dans `architecture.md`, `coding-standards.md`,
   `domain-glossary.md`, `testing-guidelines.md` et `oncall.md`. Ils sont pré-installés pour que les
   stagiaires configurent au lieu de rédiger de la prose.
3. **Le même `SKILL.md` fonctionne partout.** `change-impact-analysis` est identique au caractère près
   sur les six plateformes. C'est l'élément le plus transférable de tout le lab.

---

### Section A : Claude Code

| Exercice                                  | Artefact de solution                                                                      | À surveiller                                                                                                                                                   |
| ----------------------------------------- | ----------------------------------------------------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| A1 Initialiser CLAUDE.md                  | `CLAUDE.md` (racine)                                                                      | `/init` produit un brouillon qu'il faut ensuite _éditer_. La version générée décrit l'arborescence, pas les conventions                                        |
| A2 Créer les Claude Rules                 | `.claude/rules/backend-{nestjs,spring,fastapi,dotnet,gin}-rules.md` + `frontend-rules.md` | Six fichiers, un par stack. Le stagiaire n'écrit que celui de son backend                                                                                      |
| A3 Créer un agent                         | `.claude/agents/architecture-guardian.md`                                                 | Frontmatter YAML avec `name` et `description`. Sans `description`, l'agent ne s'active jamais automatiquement                                                  |
| A4 Créer une équipe d'agents              | _aucun artefact_ — `CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS=1` dans `.claude/settings.json`  | Expérimental et gourmand en tokens. Les coéquipiers se parlent entre eux, contrairement aux sous-agents qui ne rapportent qu'à l'appelant                      |
| A5 Créer une commande                     | `.claude/commands/code-reviewer.md`                                                       | Invoquée par `/code-reviewer`. Le nom du fichier _est_ le nom de la commande                                                                                   |
| A6 Créer un skill                         | `.claude/skills/change-impact-analysis/SKILL.md`                                          | Le nom du dossier = nom du skill ; le fichier doit s'appeler exactement `SKILL.md`                                                                             |
| A7 Installer un skill depuis un registre  | _aucun artefact_ — installé à l'exécution                                                 | Rien à commiter. L'exercice porte sur la provenance : lire un skill tiers avant de lui faire confiance                                                         |
| A8 Évaluer un skill                       | _aucun artefact_ — `npx --yes tessl review run …`                                         | La sortie est un score de revue, pas un fichier                                                                                                                |
| A9 Configurer les hooks                   | `.claude/settings.json` (bloc `hooks`)                                                    | Trois hooks configurés. Un hook qui sort en code non nul bloque l'appel d'outil                                                                                |
| A10 Créer un plugin                       | `.claude/plugins/team-workflows/` + `.claude/marketplaces/sfeir-marketplace/`             | L'artefact le plus riche du lab : 4 agents, 4 commandes, 4 skills, `hooks/hooks.json` et 2 définitions de serveurs MCP, le tout derrière un seul `plugin.json` |
| A11 Configurer les settings _(optionnel)_ | `.claude/settings.json`, `settings.local.json`                                            | `settings.local.json` est propre au développeur et git-ignoré ; `settings.json` est celui de l'équipe                                                          |

**La leçon de A10** : un plugin, c'est le moment où la configuration d'une personne devient celle de
l'équipe. Tout ce qui précède, de A3 à A9, était local ; le plugin l'empaquette pour la distribution
via une marketplace.

---

### Section B : GitHub Copilot

| Exercice                              | Artefact de solution                                                                   | À surveiller                                                                                                                             |
| ------------------------------------- | -------------------------------------------------------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------- |
| B1-B2 copilot-instructions.md         | `.github/copilot-instructions.md`                                                      | B1 est la version minimale, B2 la complète. Comparez-les : c'est B2 qui change réellement la sortie de Copilot                           |
| B3 Créer une instruction              | `.github/instructions/architecture-{nestjs,spring,fastapi,dotnet,gin}.instructions.md` | C'est le glob `applyTo` du frontmatter qui restreint une instruction à un chemin. Sans lui, elle s'applique partout                      |
| B4 Créer un prompt                    | `.github/prompts/code-reviewer.prompt.md`                                              | Les prompts sont invoqués par l'utilisateur, les instructions sont automatiques. Cette distinction n'a pas d'équivalent chez Claude Code |
| B5 Créer un agent                     | `.github/agents/architecture-guardian.agent.md`                                        | Noter la double extension `.agent.md`                                                                                                    |
| B6 Utiliser /delegate                 | _aucun artefact_ — fonctionnalité d'exécution                                          | Les agents d'arrière-plan tournent détachés ; c'est la réponse de Copilot aux équipes d'agents de Claude                                 |
| B7-B9 Skill, installation, évaluation | `.github/skills/change-impact-analysis/SKILL.md`                                       | Le même `SKILL.md` que partout ailleurs                                                                                                  |
| B10 Configurer les hooks              | `.github/hooks/code-reviewer.json` + `hooks/scripts/validate-commit.{sh,ps1}`          | **Deux scripts, un par OS.** Copilot est le seul parcours à livrer une variante shell _et_ PowerShell — utile dans une salle mixte       |
| B11 Créer un plugin                   | `.github/plugins/team-workflows/`                                                      | Plus mince que celui de Claude : `plugin.json`, un agent, un prompt                                                                      |

---

### Section C : Gemini CLI

| Exercice                              | Artefact de solution                                                                   | À surveiller                                                                                    |
| ------------------------------------- | -------------------------------------------------------------------------------------- | ----------------------------------------------------------------------------------------------- |
| C1 Initialiser GEMINI.md              | `GEMINI.md` (racine)                                                                   | Gemini ne lit pas `AGENTS.md` ; il lui faut son propre fichier                                  |
| C2 Créer un agent                     | `.gemini/agents/architecture-guardian.md`                                              | Le support des agents est **expérimental** — le comportement change d'une version à l'autre     |
| C3 Créer une commande                 | `.gemini/commands/code-reviewer.toml`                                                  | **TOML, pas Markdown.** Le prompt vit dans une clé `prompt`. Déroutant quand on vient de Claude |
| C4-C6 Skill, installation, évaluation | `.gemini/skills/change-impact-analysis/SKILL.md`                                       | Standard                                                                                        |
| C7 Configurer les hooks               | `.gemini/hooks/validate-{coding-standards,commit,writes}.sh` + `.gemini/settings.json` | Trois hooks, câblés dans `settings.json`. Shell uniquement                                      |
| C8 Explorer les extensions            | _aucun artefact_ — `gemini extensions`                                                 | Exploration à l'exécution                                                                       |
| C9 Configurer les settings            | `.gemini/settings.json`                                                                | Un seul fichier porte les hooks _et_ les réglages, contrairement aux autres plateformes         |

---

### Section D : Codex CLI

| Exercice                              | Artefact de solution                               | À surveiller                                                                                                                                                                                                               |
| ------------------------------------- | -------------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| D1 Initialiser AGENTS.md              | `AGENTS.md` (racine)                               | Codex lit directement le standard multi-plateforme `AGENTS.md`                                                                                                                                                             |
| D2 Créer un agent                     | `.codex/agents/architecture-guardian.toml`         | **TOML**, et il doit être déclaré dans la section `[agents]` de `config.toml`, sinon il est ignoré silencieusement                                                                                                         |
| D3-D5 Skill, installation, évaluation | `.codex/skills/change-impact-analysis/SKILL.md`    | Standard                                                                                                                                                                                                                   |
| D6 Configurer les Codex Rules         | `.codex/rules/project.rules`                       | **Starlark**, un langage proche de Python. C'est le remplacement des hooks chez Codex : une politique statique évaluée au moment de l'invocation d'une commande, sans script shell. À tester avec `codex execpolicy check` |
| D7 Sandbox et approbations            | `.codex/config.toml` (`[sandbox_workspace_write]`) | `writable_roots` plus `network_access = false`. Le bac à sable le plus strict des six plateformes                                                                                                                          |
| D8 Configurer les profils             | `.codex/config.toml` (`[profiles.*]`)              | Les profils nommés changent modèle et politique d'approbation d'un coup                                                                                                                                                    |

**Pourquoi ce parcours est plus court** : pas de système de commandes slash, et les Rules remplacent
les hooks — un exercice là où les autres en demandent deux. Huit exercices, ~95 minutes. Les
stagiaires finissent en avance ; envoyez-les comparer une autre section plutôt que d'inventer du travail.

---

### Section E : OpenCode

| Exercice                              | Artefact de solution                                           | À surveiller                                                                                                                                                                      |
| ------------------------------------- | -------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| E1 Initialiser AGENTS.md              | `AGENTS.md` (racine) + `opencode.json`                         | Lit le standard `AGENTS.md`, comme Codex et Vibe                                                                                                                                  |
| E2 Explorer les modes intégrés        | _aucun artefact_                                               | Modes Build / Plan, bascule avec `Tab`                                                                                                                                            |
| E3 Créer un agent                     | `.opencode/agents/architecture-guardian.md`                    | Markdown avec frontmatter, comme Claude                                                                                                                                           |
| E4 Créer une commande                 | `.opencode/commands/code-reviewer.md`                          | ⚠️ Dans le **lab 61**, le répertoire est `.opencode/command/` (au singulier). Vérifiez ce qu'attend votre version — un mauvais nom échoue en silence                              |
| E5-E7 Skill, installation, évaluation | `.opencode/skills/change-impact-analysis/SKILL.md`             | Standard                                                                                                                                                                          |
| E8 Créer un plugin                    | `.opencode/plugins/coding-standards.ts` et `env-protection.js` | **Modules TypeScript/JavaScript**, pas de la configuration. Ils exportent une fonction asynchrone qui renvoie des handlers de cycle de vie (`tool.execute.before`, `file.edited`) |
| E9 Configurer OpenCode                | `opencode.json`                                                | À la racine, pas dans `.opencode/`                                                                                                                                                |

**La leçon de E8** : `coding-standards.ts` lit `references/coding-standards.md` au chargement et
dérive sa règle de ce document. La convention et son application ne peuvent pas diverger, puisqu'il
n'y a qu'une source. Ce motif se transpose à toutes les autres plateformes.

---

### Section F : Mistral Vibe

| Exercice                          | Artefact de solution                             | À surveiller                                                                                                                                                                                         |
| --------------------------------- | ------------------------------------------------ | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| F1 Initialiser AGENTS.md          | `AGENTS.md` (racine)                             | Lu automatiquement au démarrage de la session, une fois le dossier approuvé                                                                                                                          |
| F2 Explorer les agents intégrés   | _aucun artefact_                                 | Exploration à l'exécution                                                                                                                                                                            |
| F3 Créer un agent                 | `.vibe/agents/architecture-guardian.md`          | Markdown avec frontmatter                                                                                                                                                                            |
| F4 Créer une commande             | `.vibe/skills/code-reviewer/SKILL.md`            | **Vibe unifie skills et commandes slash en un seul système.** Une « commande » est un skill invoqué avec `/`                                                                                         |
| F5-F6 Skill et installation       | `.vibe/skills/change-impact-analysis/SKILL.md`   | Même fichier, chemin d'invocation différent                                                                                                                                                          |
| F7 Configurer les hooks           | `.vibe/hooks.toml`                               | **Du TOML, et aucun script.** Les deux hooks sont `type = "prompt"` : la barrière est une instruction en langage naturel évaluée par le modèle, pas un code de sortie. Unique parmi les six parcours |
| F8 Continuation de session et ACP | _aucun artefact_ — `vibe --continue`, `vibe-acp` | ACP permet à Vibe de piloter un éditeur externe                                                                                                                                                      |
| F9 Configurer Vibe                | `.vibe/config.toml`                              | C'est ici que se règle la confiance du dossier ; sans elle, la config projet n'est pas chargée du tout                                                                                               |

---

## Comparaison multi-plateformes

Les mêmes cinq capacités, six formes différentes. C'est le tableau à projeter en fin de lab :

| Capacité            | Claude Code          | Copilot                   | Gemini CLI   | Codex CLI           | OpenCode       | Mistral Vibe          |
| ------------------- | -------------------- | ------------------------- | ------------ | ------------------- | -------------- | --------------------- |
| Fichier de contexte | `CLAUDE.md`          | `copilot-instructions.md` | `GEMINI.md`  | `AGENTS.md`         | `AGENTS.md`    | `AGENTS.md`           |
| Agents              | `.md` + frontmatter  | `.agent.md`               | `.md` (exp.) | `.toml`             | `.md`          | `.md`                 |
| Commandes           | `.md`                | `.prompt.md`              | `.toml`      | **aucune**          | `.md`          | skill invoqué par `/` |
| Skills              | `SKILL.md`           | `SKILL.md`                | `SKILL.md`   | `SKILL.md`          | `SKILL.md`     | `SKILL.md`            |
| Application         | hooks JSON           | JSON + sh/ps1             | hooks sh     | **règles Starlark** | **plugins TS** | TOML + Python         |
| Empaquetage         | plugin + marketplace | plugin                    | extensions   | profils             | plugins        | skills                |

**Lisez les lignes, pas les colonnes.** Les skills sont identiques partout — écrivez-en un, utilisez-le
sur six outils. L'application des règles diffère partout — et une équipe qui se standardise sur le
format de hooks d'un seul outil s'est acheté un coût de migration qu'elle n'a pas chiffré.

---

## Échecs les plus fréquents

Ce qui se passe réellement en salle, par ordre de fréquence approximatif :

1. **Coquille dans le frontmatter → l'agent ne s'active jamais.** Aucun message d'erreur ; l'agent
   n'est simplement pas proposé. Faites lister les agents avant de déboguer le prompt.
2. **Mauvais nom de répertoire.** `commands/` vs `command/`, `.agent.md` vs `.md`, `skills/` vs
   `skill/`. Tous échouent en silence.
3. **Le dossier du skill ne correspond pas au nom du skill.** Le nom du dossier est l'identifiant ;
   `SKILL.md` est le nom de fichier fixe. Les inverser est une erreur de première tentative classique.
4. **Agent Codex non déclaré dans `config.toml`.** Le fichier `.toml` existe et reste ignoré.
5. **Hook non exécutable.** Sous Unix, un `.sh` sans `+x` échoue d'une façon que l'outil rapporte
   comme une erreur de hook générique.
6. **Édition de la solution au lieu du projet d'exercice.** Vérifiez le chemin avant de déboguer
   quoi que ce soit.

### Critères d'évaluation

Vos exercices de lab sont réussis si :

1. **Les fichiers sont correctement structurés** : le frontmatter YAML est valide, les suffixes de fichiers respectent les conventions de la plateforme
2. **Les fonctionnalités sont opérationnelles** : les agents répondent quand ils sont invoqués, les commands s'exécutent, les hooks se déclenchent
3. **Le contenu est pertinent** : les agents référencent les fichiers de contexte appropriés, les commands produisent une sortie utile
4. **La configuration est sécurisée** : les hooks valident la qualité, les settings restreignent les opérations dangereuses
