# Critical Accessibility Fix Proposal

**Application**: Photo Gallery  
**URL**: http://localhost:42511/  
**Date**: January 3, 2026  

---

## Most Critical Issue

### Problematic Element (from snapshot)
- **Element**: File picker trigger labeled visually as "Choose File" (ref=e20)
- **Current Role/Type**: Appears to be a generic clickable element (e.g., `<div>`/`<button>` without proper file input semantics)

### Why This Is a Problem
- **WCAG Criterion**: 1.3.1 Info and Relationships (semantic structure), 4.1.2 Name, Role, Value
- **Impact**: Screen readers and keyboard users may not perceive or interact with this as a file input. Native file inputs provide built-in keyboard, focus, and accessibility behavior that generic elements do not. Without proper semantics/ARIA, the control may be invisible or unusable to assistive technologies.

---

## Corrected HTML

Use a native file input paired with a label. Keep the custom UI but ensure the input is focusable, labeled, and operable.

```html
<div class="upload-dropzone" aria-label="Upload photo" role="group">
  <label for="file-input" class="file-trigger">
    Choose File
  </label>
  <input
    id="file-input"
    type="file"
    accept="image/png,image/jpeg,image/webp"
    aria-label="Choose a photo to upload"
    hidden
  />
  <p class="hint">Max 5MB · JPEG, PNG, or WebP</p>
</div>
```

### Notes
- The `label` ties to the hidden native `<input type="file">`, preserving native accessibility while allowing a styled trigger.
- `aria-label` on the input ensures a clear accessible name; the visible label also provides context.
- `role="group"` with `aria-label` on the container helps screen readers understand the upload area.

### Optional Enhancements
- Add keyboard focus styles on `.file-trigger` for visible focus.
- Announce selected filename via a live region if you show it in the UI: `<div aria-live="polite">Selected: …</div>`
- Ensure dropzone also handles `Enter`/`Space` to activate the file picker if clickable.
