# Solution du Lab 51 : MCP Playground

> **Public : stagiaires.** À lire après avoir tenté le lab. Ce document déroule le résultat
> attendu et le raisonnement qui y mène.

## Déroulé de la solution

Ce document fournit les solutions et les sorties attendues pour chaque exercice du Lab 51.

---

## Rappel de configuration MCP

> **Fichiers de configuration prêts à l'emploi** : `resources/mcp-configs/` contient une
> configuration fonctionnelle par plateforme — `claude/.mcp.json`, `copilot/.mcp.json`,
> `gemini/settings.json`, `codex/config.toml`, `opencode/.mcp.json`, `vibe/config.toml`. À donner au
> stagiaire dont la CLI refuse d'enregistrer le serveur, plutôt que de perdre dix minutes sur une
> coquille. Chaque fichier indique où il doit être placé dans le projet.

<details>
<summary><strong>🔹 Claude Code</strong></summary>

```bash
claude mcp add --scope project playwright -- npx @playwright/mcp --browser=firefox --isolated
```

**Vérifier** :

```bash
claude mcp list
```

</details>

<details>
<summary><strong>🔹 GitHub Copilot (VS Code)</strong></summary>

Ajouter dans `.vscode/mcp.json` :

```json
{
  "servers": {
    "playwright": {
      "command": "npx",
      "args": ["@playwright/mcp", "--browser=firefox", "--isolated"]
    }
  }
}
```

**Redémarrer ou recharger VS Code** après toute modification de la configuration.

</details>

<details>
<summary><strong>🔹 Gemini CLI</strong></summary>

```bash
gemini mcp add playwright npx @playwright/mcp --browser=firefox --isolated
```

**Vérifier** :

```bash
gemini mcp list
```

</details>

<details>
<summary><strong>🔹 Codex CLI</strong></summary>

```bash
codex mcp add playwright -- npx @playwright/mcp --browser=firefox --isolated
```

**Vérifier** :

```bash
codex mcp list
```

</details>

<details>
<summary><strong>🔹 Mistral Vibe</strong></summary>

Ajouter dans `.vibe/config.toml` à la racine du projet :

```toml
[[mcp_servers]]
name = "playwright-chrome"
transport = "stdio"
command = "npx"
args = [
    "-y",
    "@playwright/mcp@0.0.83",
    "--browser",
    "chrome",
]
```

**Vérifier** : lancer `vibe`, accepter l'invite de confiance du dossier, puis lui demander de lister ses outils MCP disponibles (ou exécuter `vibe --setup`).

</details>

---

## Solution de l'exercice 1 : tests de régression visuelle

### Tâche 1.1 : Naviguer et capturer

**Prompt IA** :

> « Navigue vers http://localhost:42511 et prends une capture d'écran pleine page. Enregistre-la sous baseline-home.png »

**Réponse IA attendue** :

```
I'll navigate to the URL and capture a screenshot.

Using browser_navigate: http://localhost:42511
Using browser_screenshot: full page

Screenshot saved as baseline-home.png
The page shows the Photo Gallery application with:
- Header with application title
- Navigation elements
- Main content area with photo grid/upload section
```

### Tâche 1.2 : Différents états

**État galerie vide** :

```
Navigate to http://localhost:42511
Screenshot: baseline-empty-gallery.png
```

**Avec photos** :

```
Upload test image using browser_fill and browser_click
Screenshot: baseline-with-photos.png
```

**Avec filtre** :

```
Apply filter using UI interactions
Screenshot: baseline-filtered.png
```

---

## Solution de l'exercice 2 : audit d'accessibilité

### Tâche 2.1 : Résultats de l'audit initial

**Sortie attendue** :

```
Accessibility Audit Results for http://localhost:42511

Summary:
- Violations: 3
- Passes: 24
- Incomplete: 2

Critical Issues:
1. [CRITICAL] Images missing alt text
   - Rule: image-alt (WCAG 1.1.1)
   - Elements: 2 <img> tags in gallery

2. [SERIOUS] Form input missing label
   - Rule: label (WCAG 1.3.1)
   - Element: File upload input

3. [MODERATE] Insufficient color contrast
   - Rule: color-contrast (WCAG 1.4.3)
   - Element: Secondary button text
```

### Tâche 2.2 : Analyse par composant

**Formulaire d'upload de photo** :

```
Form Accessibility Analysis:
✅ Submit button has accessible name
❌ File input missing visible label
❌ No error message association with aria-describedby
💡 Recommendation: Add <label for="file-input">
```

**Grille de la galerie photo** :

```
Gallery Grid Accessibility:
✅ Grid uses proper list semantics
❌ Photo items not keyboard focusable
❌ No focus visible indicator
💡 Recommendation: Add tabindex="0" and :focus-visible styles
```

### Tâche 2.3 : Recommandations de correction

**Exemple de correction pour un texte alternatif manquant** :

```typescript
// File: src/app/components/photo-card/photo-card.component.html
// Before:
<img [src]="photo.url" class="photo-image">

// After:
<img
  [src]="photo.url"
  [alt]="photo.title || 'Photo uploaded by ' + photo.uploadedBy"
  class="photo-image">
```

---

## Solution de l'exercice 3 : génération de tests E2E

### Fichier de test généré

Voir `resources/photo-gallery-mcp-solution/e2e/photo-filter.spec.ts` pour le test généré complet.

**Structure clé du test** :

```typescript
import { test, expect } from '@playwright/test';

test.describe('Photo Gallery Filter', () => {
  test('should apply filter to uploaded photo', async ({ page }) => {
    // Navigate to gallery
    await page.goto('http://localhost:42511');

    // Upload a test image
    const fileInput = page.locator('input[type="file"]');
    await fileInput.setInputFiles('./test-assets/sample-photo.jpg');

    // Wait for upload to complete
    await expect(page.locator('.photo-card')).toBeVisible();

    // Apply a filter
    await page.locator('.filter-button').first().click();

    // Verify filter was applied
    await expect(page.locator('.photo-card img')).toHaveCSS('filter', /grayscale|sepia|blur/);
  });
});
```

### Exécuter le test

```bash
cd labs/lab-51-mcp-playground-solution/resources/photo-gallery-mcp-solution
npx playwright test e2e/photo-filter.spec.ts
```

**Sortie attendue** :

```
Running 1 test using 1 worker

  ✓ photo-filter.spec.ts:5:3 › Photo Gallery Filter › should apply filter (2.3s)

  1 passed (3.1s)
```

---

### Annexe : le même test en Python et en Java

Les exercices 1 et 2 passent par le serveur MCP : c'est l'IA qui pilote le navigateur, aucun langage
de programmation n'entre en jeu. L'exercice 3 est le seul à produire du code, et Playwright dispose
de bindings officiels au-delà de TypeScript. Si vos stagiaires travaillent en Python ou en Java, le
même scénario s'écrit ainsi.

Ce sont des **extraits de référence, pas un projet** : le lab reste sur le runner TypeScript, car
ajouter pytest ou Maven à un workspace Nx pour un exercice optionnel de 10 minutes ne vaut pas le
coût d'installation. Demandez à l'IA le binding que vous utilisez — l'interaction MCP est identique,
seul le code produit change.

<details>
<summary><strong>Python — pytest-playwright</strong></summary>

```python
# test_photo_filter.py  —  pip install pytest-playwright && playwright install firefox
import re

from playwright.sync_api import Page, expect


def test_applies_filter_to_uploaded_photo(page: Page) -> None:
    page.goto("http://localhost:42511")

    page.locator('input[type="file"]').set_input_files("./test-assets/sample-photo.jpg")
    expect(page.locator(".photo-card")).to_be_visible()

    page.locator(".filter-button").first.click()

    expect(page.locator(".photo-card img")).to_have_css("filter", re.compile(r"grayscale|sepia|blur"))
```

```bash
pytest test_photo_filter.py --browser firefox
```

</details>

<details>
<summary><strong>Java — Playwright for Java + JUnit 5</strong></summary>

```java
// PhotoFilterTest.java  —  com.microsoft.playwright:playwright dans le classpath de test
import static com.microsoft.playwright.assertions.PlaywrightAssertions.assertThat;

import com.microsoft.playwright.*;
import java.nio.file.Paths;
import java.util.regex.Pattern;
import org.junit.jupiter.api.*;

class PhotoFilterTest {

    static Playwright playwright;
    static Browser browser;
    Page page;

    @BeforeAll
    static void launch() {
        playwright = Playwright.create();
        browser = playwright.firefox().launch();
    }

    @AfterAll
    static void close() {
        browser.close();
        playwright.close();
    }

    @BeforeEach
    void newPage() {
        page = browser.newPage();
    }

    @Test
    @DisplayName("applique un filtre a une photo uploadee")
    void appliesFilterToUploadedPhoto() {
        page.navigate("http://localhost:42511");

        page.locator("input[type=file]").setInputFiles(Paths.get("./test-assets/sample-photo.jpg"));
        assertThat(page.locator(".photo-card")).isVisible();

        page.locator(".filter-button").first().click();

        assertThat(page.locator(".photo-card img"))
                .hasCSS("filter", Pattern.compile("grayscale|sepia|blur"));
    }
}
```

```bash
./mvnw test -Dtest=PhotoFilterTest
```

</details>

**Ce qui ne change pas entre les trois** : les sélecteurs, les assertions, et les ajustements listés
ci-dessous. Un sélecteur trop fragile en TypeScript l'est tout autant en Python — et c'est le point à
faire passer au débriefing. Le binding est un détail ; la qualité des sélecteurs générés, non.

---

## Ajustements courants à prévoir

### Mise à jour des sélecteurs

Les sélecteurs générés par l'IA peuvent nécessiter un ajustement selon le DOM réel :

```typescript
// Generated (generic)
page.locator('.filter-button');

// Adjusted (specific)
page.locator('[data-testid="filter-grayscale"]');
```

### Temps d'attente

Ajouter des attentes explicites pour les opérations asynchrones :

```typescript
// Before upload verification
await page.waitForResponse((resp) => resp.url().includes('/api/photos'));

// After filter application
await page.waitForTimeout(500); // Allow CSS transition
```

---

## Ressources complémentaires

### Gestion des captures de référence

Stocker les références dans le gestionnaire de versions :

```
labs/lab-51-mcp-playground-solution/
├── resources/
│   └── photo-gallery-mcp-solution/
│       ├── screenshots/
│       │   ├── baseline-home.png
│       │   ├── baseline-empty-gallery.png
│       │   └── baseline-with-photos.png
│       └── e2e/
│           └── photo-filter.spec.ts
```

### Intégration CI

Exemple de workflow GitHub Actions pour la régression visuelle :

```yaml
- name: Run Visual Regression
  run: |
    npx nx serve photo-gallery-mcp &
    sleep 10
    npx playwright test --update-snapshots
```

---

## Points clés à retenir

1. **MCP rend possible le test piloté par l'IA** : l'IA peut interagir avec de vrais navigateurs via un protocole standardisé
2. **L'accessibilité est automatisable** : l'intégration d'axe-core détecte les violations WCAG courantes
3. **La génération de tests est un point de départ** : les tests générés par l'IA demandent relecture et affinage humains
4. **Les références visuelles demandent de la maintenance** : mettre à jour les références lors de changements d'UI intentionnels
