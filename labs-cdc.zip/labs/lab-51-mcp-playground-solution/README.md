# Lab 51 Solution: MCP Playground

> **Audience: trainees.** Read this after attempting the lab. It walks through the expected
> result and the reasoning behind it.

## Solution Walkthrough

This document provides solutions and expected outputs for each exercise in Lab 51.

---

## MCP Setup Reminder

> **Ready-made config files**: `resources/mcp-configs/` holds a working configuration per platform —
> `claude/.mcp.json`, `copilot/.mcp.json`, `gemini/settings.json`, `codex/config.toml`,
> `opencode/.mcp.json`, `vibe/config.toml`. Hand them to a trainee whose CLI refuses to register the
> server, rather than losing ten minutes to a typo. Each file names where it belongs in the project.

<details>
<summary><strong>🔹 Claude Code</strong></summary>

```bash
claude mcp add --scope project playwright -- npx @playwright/mcp --browser=firefox --isolated
```

**Verify**:

```bash
claude mcp list
```

</details>

<details>
<summary><strong>🔹 GitHub Copilot (VS Code)</strong></summary>

Add to `.vscode/mcp.json`:

```json
{
  "servers": {
    "playwright": {
      "command": "npx",
      "args": ["@playwright/mcp", "--browser=firefox", "--isolated"]
    }
  }
}
```

**Restart or reload VS Code** after configuration changes.

</details>

<details>
<summary><strong>🔹 Gemini CLI</strong></summary>

```bash
gemini mcp add playwright npx @playwright/mcp --browser=firefox --isolated
```

**Verify**:

```bash
gemini mcp list
```

</details>

<details>
<summary><strong>🔹 Codex CLI</strong></summary>

```bash
codex mcp add playwright -- npx @playwright/mcp --browser=firefox --isolated
```

**Verify**:

```bash
codex mcp list
```

</details>

<details>
<summary><strong>🔹 Mistral Vibe</strong></summary>

Add to `.vibe/config.toml` at the project root:

```toml
[[mcp_servers]]
name = "playwright-chrome"
transport = "stdio"
command = "npx"
args = [
    "-y",
    "@playwright/mcp@0.0.83",
    "--browser",
    "chrome",
]
```

**Verify**: start `vibe`, accept the folder-trust prompt, and ask it to list its available MCP tools (or run `vibe --setup`).

</details>

---

## Exercise 1 Solution: Visual Regression Testing

### Task 1.1: Navigate and Screenshot

**AI Prompt**:

> "Navigate to http://localhost:42511 and take a full-page screenshot. Save it as baseline-home.png"

**Expected AI Response**:

```
I'll navigate to the URL and capture a screenshot.

Using browser_navigate: http://localhost:42511
Using browser_screenshot: full page

Screenshot saved as baseline-home.png
The page shows the Photo Gallery application with:
- Header with application title
- Navigation elements
- Main content area with photo grid/upload section
```

### Task 1.2: Different States

**Empty Gallery State**:

```
Navigate to http://localhost:42511
Screenshot: baseline-empty-gallery.png
```

**With Photos**:

```
Upload test image using browser_fill and browser_click
Screenshot: baseline-with-photos.png
```

**With Filter**:

```
Apply filter using UI interactions
Screenshot: baseline-filtered.png
```

---

## Exercise 2 Solution: Accessibility Auditing

### Task 2.1: Initial Audit Results

**Expected Output**:

```
Accessibility Audit Results for http://localhost:42511

Summary:
- Violations: 3
- Passes: 24
- Incomplete: 2

Critical Issues:
1. [CRITICAL] Images missing alt text
   - Rule: image-alt (WCAG 1.1.1)
   - Elements: 2 <img> tags in gallery

2. [SERIOUS] Form input missing label
   - Rule: label (WCAG 1.3.1)
   - Element: File upload input

3. [MODERATE] Insufficient color contrast
   - Rule: color-contrast (WCAG 1.4.3)
   - Element: Secondary button text
```

### Task 2.2: Component-Specific Analysis

**Photo Upload Form**:

```
Form Accessibility Analysis:
✅ Submit button has accessible name
❌ File input missing visible label
❌ No error message association with aria-describedby
💡 Recommendation: Add <label for="file-input">
```

**Photo Gallery Grid**:

```
Gallery Grid Accessibility:
✅ Grid uses proper list semantics
❌ Photo items not keyboard focusable
❌ No focus visible indicator
💡 Recommendation: Add tabindex="0" and :focus-visible styles
```

### Task 2.3: Fix Recommendations

**Example Fix for Missing Alt Text**:

```typescript
// File: src/app/components/photo-card/photo-card.component.html
// Before:
<img [src]="photo.url" class="photo-image">

// After:
<img
  [src]="photo.url"
  [alt]="photo.title || 'Photo uploaded by ' + photo.uploadedBy"
  class="photo-image">
```

---

## Exercise 3 Solution: E2E Test Generation

### Generated Test File

See `resources/photo-gallery-mcp-solution/e2e/photo-filter.spec.ts` for the complete generated test.

**Key Test Structure**:

```typescript
import { test, expect } from '@playwright/test';

test.describe('Photo Gallery Filter', () => {
  test('should apply filter to uploaded photo', async ({ page }) => {
    // Navigate to gallery
    await page.goto('http://localhost:42511');

    // Upload a test image
    const fileInput = page.locator('input[type="file"]');
    await fileInput.setInputFiles('./test-assets/sample-photo.jpg');

    // Wait for upload to complete
    await expect(page.locator('.photo-card')).toBeVisible();

    // Apply a filter
    await page.locator('.filter-button').first().click();

    // Verify filter was applied
    await expect(page.locator('.photo-card img')).toHaveCSS('filter', /grayscale|sepia|blur/);
  });
});
```

### Running the Test

```bash
cd labs/lab-51-mcp-playground-solution/resources/photo-gallery-mcp-solution
npx playwright test e2e/photo-filter.spec.ts
```

**Expected Output**:

```
Running 1 test using 1 worker

  ✓ photo-filter.spec.ts:5:3 › Photo Gallery Filter › should apply filter (2.3s)

  1 passed (3.1s)
```

---

### Appendix: the same test in Python and Java

Exercises 1 and 2 go through the MCP server — the AI drives the browser, and no programming language
is involved. Exercise 3 is the only one that produces code, and Playwright has official bindings
beyond TypeScript. If your trainees work in Python or Java, the same scenario reads like this.

These are **reference snippets, not a project**: the lab stays on the TypeScript runner, because
adding pytest or Maven to an Nx workspace for one optional 10-minute exercise is not worth the setup.
Ask the AI for the binding you use — the MCP interaction is identical, only the emitted code changes.

<details>
<summary><strong>Python — pytest-playwright</strong></summary>

```python
# test_photo_filter.py  —  pip install pytest-playwright && playwright install firefox
import re

from playwright.sync_api import Page, expect


def test_applies_filter_to_uploaded_photo(page: Page) -> None:
    page.goto("http://localhost:42511")

    page.locator('input[type="file"]').set_input_files("./test-assets/sample-photo.jpg")
    expect(page.locator(".photo-card")).to_be_visible()

    page.locator(".filter-button").first.click()

    expect(page.locator(".photo-card img")).to_have_css("filter", re.compile(r"grayscale|sepia|blur"))
```

```bash
pytest test_photo_filter.py --browser firefox
```

</details>

<details>
<summary><strong>Java — Playwright for Java + JUnit 5</strong></summary>

```java
// PhotoFilterTest.java  —  com.microsoft.playwright:playwright on the test classpath
import static com.microsoft.playwright.assertions.PlaywrightAssertions.assertThat;

import com.microsoft.playwright.*;
import java.nio.file.Paths;
import java.util.regex.Pattern;
import org.junit.jupiter.api.*;

class PhotoFilterTest {

    static Playwright playwright;
    static Browser browser;
    Page page;

    @BeforeAll
    static void launch() {
        playwright = Playwright.create();
        browser = playwright.firefox().launch();
    }

    @AfterAll
    static void close() {
        browser.close();
        playwright.close();
    }

    @BeforeEach
    void newPage() {
        page = browser.newPage();
    }

    @Test
    @DisplayName("applies a filter to an uploaded photo")
    void appliesFilterToUploadedPhoto() {
        page.navigate("http://localhost:42511");

        page.locator("input[type=file]").setInputFiles(Paths.get("./test-assets/sample-photo.jpg"));
        assertThat(page.locator(".photo-card")).isVisible();

        page.locator(".filter-button").first().click();

        assertThat(page.locator(".photo-card img"))
                .hasCSS("filter", Pattern.compile("grayscale|sepia|blur"));
    }
}
```

```bash
./mvnw test -Dtest=PhotoFilterTest
```

</details>

**What does not change across the three**: the selectors, the assertions, and the adjustments listed
below. A selector that is too brittle in TypeScript is just as brittle in Python — which is the point
worth making at the debrief. The binding is a detail; the quality of the generated selectors is not.

---

## Common Adjustments Needed

### Selector Updates

The AI-generated selectors may need adjustment based on actual DOM:

```typescript
// Generated (generic)
page.locator('.filter-button');

// Adjusted (specific)
page.locator('[data-testid="filter-grayscale"]');
```

### Wait States

Add explicit waits for async operations:

```typescript
// Before upload verification
await page.waitForResponse((resp) => resp.url().includes('/api/photos'));

// After filter application
await page.waitForTimeout(500); // Allow CSS transition
```

---

## Additional Resources

### Screenshot Baseline Management

Store baselines in version control:

```
labs/lab-51-mcp-playground-solution/
├── resources/
│   └── photo-gallery-mcp-solution/
│       ├── screenshots/
│       │   ├── baseline-home.png
│       │   ├── baseline-empty-gallery.png
│       │   └── baseline-with-photos.png
│       └── e2e/
│           └── photo-filter.spec.ts
```

### CI Integration

Example GitHub Actions workflow for visual regression:

```yaml
- name: Run Visual Regression
  run: |
    npx nx serve photo-gallery-mcp &
    sleep 10
    npx playwright test --update-snapshots
```

---

## Key Learnings

1. **MCP enables AI-driven testing**: AI can interact with real browsers through standardized protocol
2. **Accessibility is automatable**: axe-core integration catches common WCAG violations
3. **Test generation is a starting point**: AI-generated tests need human review and refinement
4. **Visual baselines require maintenance**: Update baselines when intentional UI changes occur
