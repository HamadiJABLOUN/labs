# Exercise 2: Structured Prompting - Solution (Java)

> Java variant of [`../exercise-2-structured.md`](../exercise-2-structured.md).

## Techniques Used

- **Role**: Senior developer persona
- **Context**: Detailed input/output specification
- **Format**: Explicit output structure requested

## Example Prompt

```
You are a senior Java developer working on Java 17.

I need a method that processes student scores:
- Input: List of records with 'name' (String) and 'score' (int)
- Filter: Keep only scores >= 70
- Sort: By score, highest first
- Output: List of names only

Please provide:
- The record definition and the method, with Javadoc and inline comments
- Example usage in a main method
```

## Typical Output

```java
import java.util.Comparator;
import java.util.List;

public class StudentScores {

    /** A single student assessment record. */
    public record Student(String name, int score) {}

    /**
     * Filters and sorts student scores, returning the names of passing students.
     *
     * @param students the assessment records to process
     * @return names of students scoring 70 or more, best score first
     */
    public static List<String> getPassingStudentNames(List<Student> students) {
        return students.stream()
                // Keep only the students with a passing score (>= 70)
                .filter(student -> student.score() >= 70)
                // Sort by score, highest first
                .sorted(Comparator.comparingInt(Student::score).reversed())
                // Extract just the names
                .map(Student::name)
                .toList();
    }

    public static void main(String[] args) {
        List<Student> students = List.of(
                new Student("Alice", 85),
                new Student("Bob", 65),
                new Student("Charlie", 92),
                new Student("Diana", 70));

        System.out.println(getPassingStudentNames(students));
        // Output: [Charlie, Alice, Diana]
    }
}
```

## Analysis

**Improvements over Exercise 1**:

- **The `Student` type is defined** — the code compiles and runs as pasted. Naming "record" in the prompt is what bought this
- Javadoc with `@param` and `@return`
- Meaningful method name
- Inline comments explaining each stage of the pipeline
- `Comparator.comparingInt(...).reversed()` instead of the overflow-prone subtraction
- `.toList()` (Java 16+) instead of `Collectors.toList()`
- Runnable example in `main`

**Still missing**:

- Null handling (`students == null`, or a null entry in the list)
- Empty-list edge case (works by accident, never stated)
- The threshold `70` is a magic number
- No real tests — a `println` is not an assertion

## What to Look For

When evaluating your structured prompt results:

- Naming the Java version in the prompt changes the output a lot — compare with and without it
- Did specifying "record" stop the AI from inventing a getter-based bean?
- Did you get the Javadoc _and_ the inline comments, or only one?
- Is the magic number still there?
