# Exercise 3: Advanced Prompting - Solution (Java)

> Java variant of [`../exercise-3-advanced.md`](../exercise-3-advanced.md).

## Techniques Used

- **Role**: Specialized senior developer persona
- **Context**: Structured requirements with headings
- **Format**: Precise output contract
- **Few-Shot**: Concrete input/output example
- **Chain-of-Thought**: Explicit request to reason through the steps first

## Example Prompt

```
You are a senior Java developer specializing in data transformations, working on Java 17.

## Task
Create a utility to process student assessment data.

## Requirements
- Filter students with passing scores (>= 70)
- Sort by score in descending order
- Return only student names

## Example
Input:
List.of(new Student("Alice", 85), new Student("Bob", 65))

Expected Output:
["Alice"]

## Instructions
1. First, think through the algorithm steps
2. Implement with records and the Stream API
3. Include error handling for edge cases (null list, null entries, empty list)
4. Make the threshold and sort direction configurable
5. Add comprehensive Javadoc

## Output Format
- The records and enum needed
- The method with full Javadoc
- Brief explanation of approach
- JUnit 5 test cases covering normal, edge, and error scenarios
```

## Typical Output

```java
import java.util.Comparator;
import java.util.List;
import java.util.Objects;

/** Transformations over student assessment data. */
public final class StudentAssessments {

    public static final int PASSING_SCORE = 70;

    /** A single student assessment record. */
    public record Student(String name, int score) {
        public Student {
            Objects.requireNonNull(name, "name must not be null");
        }
    }

    /** Sort direction applied to the qualifying students. */
    public enum SortOrder { ASC, DESC }

    /** Optional filtering configuration. */
    public record FilterOptions(int minScore, SortOrder sortOrder) {
        public FilterOptions {
            Objects.requireNonNull(sortOrder, "sortOrder must not be null");
        }

        /** @return the defaults: passing score threshold, best score first. */
        public static FilterOptions defaults() {
            return new FilterOptions(PASSING_SCORE, SortOrder.DESC);
        }
    }

    private StudentAssessments() {}

    /**
     * Returns the names of students meeting the score threshold.
     *
     * <p>Algorithm:
     * <ol>
     *   <li>Reject a null roster.</li>
     *   <li>Keep the students at or above {@code minScore}.</li>
     *   <li>Sort the survivors by score in the requested direction.</li>
     *   <li>Project the names out.</li>
     * </ol>
     *
     * @param students the roster to process, never {@code null}
     * @param options  the threshold and sort direction
     * @return the qualifying names, ordered by score
     * @throws NullPointerException if {@code students}, {@code options},
     *                              or any roster entry is {@code null}
     */
    public static List<String> getQualifyingStudentNames(List<Student> students, FilterOptions options) {
        Objects.requireNonNull(students, "students must not be null");
        Objects.requireNonNull(options, "options must not be null");

        if (students.isEmpty()) {
            return List.of();
        }

        Comparator<Student> byScore = Comparator.comparingInt(Student::score);
        Comparator<Student> ordering =
                options.sortOrder() == SortOrder.DESC ? byScore.reversed() : byScore;

        return students.stream()
                .map(student -> Objects.requireNonNull(student, "roster entries must not be null"))
                .filter(student -> student.score() >= options.minScore())
                .sorted(ordering)
                .map(Student::name)
                .toList();
    }

    /** Convenience overload using {@link FilterOptions#defaults()}. */
    public static List<String> getQualifyingStudentNames(List<Student> students) {
        return getQualifyingStudentNames(students, FilterOptions.defaults());
    }
}
```

```java
// ============ TEST CASES (JUnit 5) ============

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

class StudentAssessmentsTest {

    private static final List<StudentAssessments.Student> ROSTER = List.of(
            new StudentAssessments.Student("Alice", 85),
            new StudentAssessments.Student("Bob", 65),
            new StudentAssessments.Student("Charlie", 92),
            new StudentAssessments.Student("Diana", 70));

    @Test
    @DisplayName("returns passing names, best score first")
    void returnsPassingNamesBestFirst() {
        assertEquals(
                List.of("Charlie", "Alice", "Diana"),
                StudentAssessments.getQualifyingStudentNames(ROSTER));
    }

    @Test
    @DisplayName("an empty roster yields an empty list")
    void emptyRosterYieldsEmptyList() {
        assertEquals(List.of(), StudentAssessments.getQualifyingStudentNames(List.of()));
    }

    @Test
    @DisplayName("nobody passing yields an empty list")
    void noPassersYieldsEmptyList() {
        List<StudentAssessments.Student> failing = List.of(
                new StudentAssessments.Student("Eve", 50),
                new StudentAssessments.Student("Frank", 60));

        assertEquals(List.of(), StudentAssessments.getQualifyingStudentNames(failing));
    }

    @Test
    @DisplayName("honours a custom threshold and ascending order")
    void honoursCustomThresholdAndAscendingOrder() {
        StudentAssessments.FilterOptions options =
                new StudentAssessments.FilterOptions(80, StudentAssessments.SortOrder.ASC);

        assertEquals(
                List.of("Alice", "Charlie"),
                StudentAssessments.getQualifyingStudentNames(ROSTER, options));
    }

    @Test
    @DisplayName("rejects a null roster and null entries")
    void rejectsNullInput() {
        assertThrows(
                NullPointerException.class,
                () -> StudentAssessments.getQualifyingStudentNames(null));

        List<StudentAssessments.Student> withNull = new ArrayList<>();
        withNull.add(null);
        assertThrows(
                NullPointerException.class,
                () -> StudentAssessments.getQualifyingStudentNames(withNull));
    }
}
```

## Analysis

**Major improvements over Exercises 1-2**:

- Compact canonical constructors validating the records at construction time
- A `SortOrder` enum instead of a stringly-typed `"asc"` / `"desc"`
- A `FilterOptions` record with a `defaults()` factory, plus a convenience overload — the caller pays for configurability only when they use it
- `Objects.requireNonNull` with _messages_, at every entry point
- Empty-list fast path, returning the immutable `List.of()`
- `PASSING_SCORE` constant instead of the magic `70`
- Javadoc documenting the algorithm as an ordered list, and the thrown exceptions
- Private constructor — a utility class nobody can instantiate
- Five JUnit 5 cases with `@DisplayName`, covering normal, edge, and error paths

**The Java-specific tell**: null handling. Python raises on a malformed record whether you planned for it or not; Java lets a `null` entry travel silently through a stream until a `NullPointerException` surfaces far from its cause. The `Objects.requireNonNull` mapping stage exists only because the advanced prompt asked for edge cases explicitly — no basic prompt produces it.

## What to Look For

When evaluating your advanced prompt results:

- Did chain-of-thought produce the algorithm as Javadoc, or only as throwaway prose in the chat?
- Did the AI reach for records, Lombok, or a hand-written bean? Ask it to justify the choice
- Is the sort direction an enum or a raw `String`?
- Did it validate nulls at the boundary, or trust the caller?
- Are the test cases real assertions, or `System.out.println` in disguise?
