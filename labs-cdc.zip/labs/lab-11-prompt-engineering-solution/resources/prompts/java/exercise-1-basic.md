# Exercise 1: Basic Prompting - Solution (Java)

> Java variant of [`../exercise-1-basic.md`](../exercise-1-basic.md). Same task, same three prompts — only the target language changes.

## Techniques Used

- **Role**: Basic persona assignment
- **Context**: Direct task description

## Example Prompt

```
You are a Java developer.
Write a method that filters a list by score >= 70, sorts by score descending, and returns names.
```

## Typical Output

```java
import java.util.List;
import java.util.stream.Collectors;

public class StudentFilter {

    public static List<String> filterAndSort(List<Student> items) {
        return items.stream()
                .filter(s -> s.getScore() >= 70)
                .sorted((a, b) -> b.getScore() - a.getScore())
                .map(Student::getName)
                .collect(Collectors.toList());
    }
}
```

## Analysis

**Pros**:

- Correct stream pipeline, reads top to bottom
- Concise

**Cons**:

- **Does not compile as given** — it references a `Student` type the AI never defined. This is the single most common failure of a basic prompt in Java, and it has no JavaScript equivalent
- Assumes a JavaBean with `getScore()` / `getName()`; you may have a `record`, a POJO with public fields, or nothing at all
- `(a, b) -> b.getScore() - a.getScore()` uses subtraction as a comparator — overflows on extreme `int` values. `Comparator.comparingInt(...).reversed()` is the safe form
- `Collectors.toList()` rather than `.toList()` (Java 16+) — returns a mutable list, and betrays a pre-Java-16 training bias
- No Javadoc, no null handling, no tests

## What to Look For

When evaluating your basic prompt results:

- Did the AI define the `Student` type, or silently assume it? Try to compile the answer verbatim
- Did it target a modern Java, or default to Java 8 idioms?
- Did it use a subtraction comparator?
- How many follow-up prompts before the code compiles?
