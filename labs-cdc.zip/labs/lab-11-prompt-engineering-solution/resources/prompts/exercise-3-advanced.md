# Exercise 3: Advanced Prompting - Solution

## Techniques Used

- **Role**: Expert persona with specialization
- **Context**: Detailed task description
- **Format**: Structured output requirements
- **Examples**: Input/output demonstration
- **Chain-of-Thought**: Step-by-step reasoning request

## Example Prompt

```
You are a senior JavaScript/TypeScript developer specializing in data transformations.

## Task
Create a function to process student assessment data.

## Requirements
- Filter students with passing scores (>= 70)
- Sort by score in descending order
- Return only student names

## Example
Input:
[{ name: "Alice", score: 85 }, { name: "Bob", score: 65 }]

Expected Output:
["Alice"]

## Instructions
1. First, think through the algorithm steps
2. Implement with TypeScript types
3. Include error handling for edge cases (empty array, invalid input)
4. Add comprehensive comments

## Output Format
- TypeScript function with full type definitions
- Brief explanation of approach
- 3 test cases covering normal, edge, and error scenarios
```

## Typical Output

```typescript
/**
 * Student interface defining the shape of input objects
 */
interface Student {
  name: string;
  score: number;
}

/**
 * Configuration options for filtering
 */
interface FilterOptions {
  minScore?: number;
  sortOrder?: 'asc' | 'desc';
}

/**
 * Filters and sorts students by score, returning names of qualifying students.
 *
 * Algorithm:
 * 1. Validate input is an array
 * 2. Filter students meeting minimum score threshold
 * 3. Sort remaining students by score
 * 4. Extract and return names
 *
 * @param students - Array of student objects with name and score
 * @param options - Optional configuration (default: minScore=70, sortOrder='desc')
 * @returns Array of student names meeting criteria
 * @throws Error if students is not a valid array
 */
function getQualifyingStudentNames(students: Student[], options: FilterOptions = {}): string[] {
  // Set defaults
  const { minScore = 70, sortOrder = 'desc' } = options;

  // Validate input
  if (!Array.isArray(students)) {
    throw new Error('Input must be an array of students');
  }

  // Handle empty array edge case
  if (students.length === 0) {
    return [];
  }

  // Filter students with qualifying scores
  const qualifying = students.filter((student) => typeof student.score === 'number' && student.score >= minScore);

  // Sort by score
  const sorted = [...qualifying].sort((a, b) => (sortOrder === 'desc' ? b.score - a.score : a.score - b.score));

  // Extract and return names
  return sorted.map((student) => student.name);
}

// ============ TEST CASES ============

// Test 1: Normal case
const normalInput: Student[] = [
  { name: 'Alice', score: 85 },
  { name: 'Bob', score: 65 },
  { name: 'Charlie', score: 92 },
  { name: 'Diana', score: 70 },
];
console.log(getQualifyingStudentNames(normalInput));
// Expected: ["Charlie", "Alice", "Diana"]

// Test 2: Edge case - empty array
console.log(getQualifyingStudentNames([]));
// Expected: []

// Test 3: Edge case - no qualifying students
const noPassers: Student[] = [
  { name: 'Eve', score: 50 },
  { name: 'Frank', score: 60 },
];
console.log(getQualifyingStudentNames(noPassers));
// Expected: []

// Test 4: Custom threshold
console.log(getQualifyingStudentNames(normalInput, { minScore: 80 }));
// Expected: ["Charlie", "Alice"]
```

## Analysis

**Major improvements over Exercises 1-2**:

- Full TypeScript type definitions
- Configurable options (threshold, sort order)
- Input validation and error handling
- Handles edge cases (empty array, no qualifiers)
- Comprehensive test cases
- Clear algorithm documentation
- Immutable sort (spread operator)

## What to Look For

When evaluating your advanced prompt results:

- Did chain-of-thought produce an algorithm explanation?
- Did the AI include error handling without being asked explicitly?
- Are the test cases meaningful and covering edge cases?
- Is the code production-ready?
