# Exercise 2: Structured Prompting - Solution (Python)

> Python variant of [`../exercise-2-structured.md`](../exercise-2-structured.md).

## Techniques Used

- **Role**: Senior developer persona
- **Context**: Detailed input/output specification
- **Format**: Explicit output structure requested

## Example Prompt

```
You are a senior Python developer.

I need a function that processes student scores:
- Input: List of dicts with 'name' (str) and 'score' (int) keys
- Filter: Keep only scores >= 70
- Sort: By score, highest first
- Output: List of names only

Please provide:
- The function code with a docstring and inline comments
- Example usage
```

## Typical Output

```python
def get_passing_student_names(students):
    """Return the names of passing students, best score first.

    Args:
        students: list of dicts with 'name' (str) and 'score' (int) keys.

    Returns:
        list[str]: names of students scoring 70 or more, sorted descending.
    """
    # Keep only the students with a passing score (>= 70)
    passing = [student for student in students if student["score"] >= 70]

    # Sort by score, highest first
    passing.sort(key=lambda student: student["score"], reverse=True)

    # Extract just the names
    return [student["name"] for student in passing]


# Example usage:
students = [
    {"name": "Alice", "score": 85},
    {"name": "Bob", "score": 65},
    {"name": "Charlie", "score": 92},
    {"name": "Diana", "score": 70},
]

print(get_passing_student_names(students))
# Output: ['Charlie', 'Alice', 'Diana']
```

## Analysis

**Improvements over Exercise 1**:

- Google-style docstring documenting args and return type
- Meaningful function name
- Inline comments explaining each step
- Filter before sort — the natural reading order, and cheaper
- Usage example included
- Better variable names (`student` rather than `i`)

**Still missing**:

- Type hints on the signature
- Error handling
- Edge case handling
- `students.sort()` mutates the caller's list — a side effect nobody asked for

## What to Look For

When evaluating your structured prompt results:

- Did specifying format produce a docstring, and in which convention (Google, NumPy, reST)?
- Is the function name more descriptive?
- Did you get the example usage you requested?
- Did the AI mutate the input list, or copy it?
