# Lab 11: Prompt Engineering Workshop - Solutions

> **Audience: trainees.** Read this after attempting the lab. It walks through the expected
> result and the reasoning behind it.

**Module**: 1 - Introduction to AI for Developers

## Overview

This document provides example prompts and outputs for each exercise, demonstrating how prompt quality affects AI output.

---

## Exercise 1: Basic Prompting - Solution

### Example Prompt

```
You are a JavaScript developer.
Write a function that filters a list by score >= 70, sorts by score descending, and returns names.
```

### Typical Output

```javascript
function filterAndSort(items) {
  return items
    .filter((item) => item.score >= 70)
    .sort((a, b) => b.score - a.score)
    .map((item) => item.name);
}
```

### Analysis

**Pros**:

- Code works correctly
- Concise solution

**Cons**:

- No comments or documentation
- No error handling
- No type information
- No usage examples
- May need follow-up questions to clarify requirements

---

## Exercise 2: Structured Prompting - Solution

### Example Prompt

```
You are a senior JavaScript developer.

I need a function that processes student scores:
- Input: Array of objects with 'name' (string) and 'score' (number)
- Filter: Keep only scores >= 70
- Sort: By score, highest first
- Output: Array of names only

Please provide:
- The function code with inline comments
- Example usage
```

### Typical Output

```javascript
/**
 * Filters and sorts student scores, returning names of passing students.
 * @param {Array<{name: string, score: number}>} students - Array of student objects
 * @returns {string[]} Names of students with score >= 70, sorted by score descending
 */
function getPassingStudentNames(students) {
  // Filter students with passing scores (>= 70)
  const passing = students.filter((student) => student.score >= 70);

  // Sort by score in descending order
  const sorted = passing.sort((a, b) => b.score - a.score);

  // Extract and return just the names
  return sorted.map((student) => student.name);
}

// Example usage:
const students = [
  { name: 'Alice', score: 85 },
  { name: 'Bob', score: 65 },
  { name: 'Charlie', score: 92 },
  { name: 'Diana', score: 70 },
];

console.log(getPassingStudentNames(students));
// Output: ["Charlie", "Alice", "Diana"]
```

### Analysis

**Improvements over Exercise 1**:

- JSDoc comments with types
- Meaningful function name
- Inline comments explaining each step
- Usage example included
- Better variable names

**Still missing**:

- Error handling
- Edge case handling
- TypeScript types (if applicable)

---

## Exercise 3: Advanced Prompting - Solution

### Example Prompt

```
You are a senior JavaScript/TypeScript developer specializing in data transformations.

## Task
Create a function to process student assessment data.

## Requirements
- Filter students with passing scores (>= 70)
- Sort by score in descending order
- Return only student names

## Example
Input:
[{ name: "Alice", score: 85 }, { name: "Bob", score: 65 }]

Expected Output:
["Alice"]

## Instructions
1. First, think through the algorithm steps
2. Implement with TypeScript types
3. Include error handling for edge cases (empty array, invalid input)
4. Add comprehensive comments

## Output Format
- TypeScript function with full type definitions
- Brief explanation of approach
- 3 test cases covering normal, edge, and error scenarios
```

### Typical Output

```typescript
/**
 * Student interface defining the shape of input objects
 */
interface Student {
  name: string;
  score: number;
}

/**
 * Configuration options for filtering
 */
interface FilterOptions {
  minScore?: number;
  sortOrder?: 'asc' | 'desc';
}

/**
 * Filters and sorts students by score, returning names of qualifying students.
 *
 * Algorithm:
 * 1. Validate input is an array
 * 2. Filter students meeting minimum score threshold
 * 3. Sort remaining students by score
 * 4. Extract and return names
 *
 * @param students - Array of student objects with name and score
 * @param options - Optional configuration (default: minScore=70, sortOrder='desc')
 * @returns Array of student names meeting criteria
 * @throws Error if students is not a valid array
 */
function getQualifyingStudentNames(students: Student[], options: FilterOptions = {}): string[] {
  // Set defaults
  const { minScore = 70, sortOrder = 'desc' } = options;

  // Validate input
  if (!Array.isArray(students)) {
    throw new Error('Input must be an array of students');
  }

  // Handle empty array edge case
  if (students.length === 0) {
    return [];
  }

  // Filter students with qualifying scores
  const qualifying = students.filter((student) => typeof student.score === 'number' && student.score >= minScore);

  // Sort by score
  const sorted = [...qualifying].sort((a, b) => (sortOrder === 'desc' ? b.score - a.score : a.score - b.score));

  // Extract and return names
  return sorted.map((student) => student.name);
}

// ============ TEST CASES ============

// Test 1: Normal case
const normalInput: Student[] = [
  { name: 'Alice', score: 85 },
  { name: 'Bob', score: 65 },
  { name: 'Charlie', score: 92 },
  { name: 'Diana', score: 70 },
];
console.log(getQualifyingStudentNames(normalInput));
// Expected: ["Charlie", "Alice", "Diana"]

// Test 2: Edge case - empty array
console.log(getQualifyingStudentNames([]));
// Expected: []

// Test 3: Edge case - no qualifying students
const noPassers: Student[] = [
  { name: 'Eve', score: 50 },
  { name: 'Frank', score: 60 },
];
console.log(getQualifyingStudentNames(noPassers));
// Expected: []

// Test 4: Custom threshold
console.log(getQualifyingStudentNames(normalInput, { minScore: 80 }));
// Expected: ["Charlie", "Alice"]
```

### Analysis

**Major improvements over Exercises 1-2**:

- Full TypeScript type definitions
- Configurable options (threshold, sort order)
- Input validation and error handling
- Handles edge cases (empty array, no qualifiers)
- Comprehensive test cases
- Clear algorithm documentation
- Immutable sort (spread operator)

---

## Comparison Summary

| Aspect           | Basic | Structured | Advanced        |
| ---------------- | ----- | ---------- | --------------- |
| Lines of code    | ~5    | ~15        | ~50             |
| Documentation    | None  | Good       | Excellent       |
| Type safety      | None  | JSDoc      | Full TypeScript |
| Error handling   | None  | None       | Complete        |
| Configurability  | None  | None       | Yes             |
| Test coverage    | None  | 1 example  | 4 test cases    |
| Production-ready | No    | Maybe      | Yes             |

## Language Variants

The walkthrough above uses JavaScript/TypeScript. The same three prompts, run against Python and Java, are documented in full under `resources/prompts/`:

- **Python** — [`resources/prompts/python/`](resources/prompts/python/)
- **Java** — [`resources/prompts/java/`](resources/prompts/java/)

Everything in those variants has been executed: the Python samples run, the Java samples compile and run, and the Exercise 3 test cases pass.

### What the three exercises produce, side by side

| Level          | JavaScript/TypeScript                        | Python                                                  | Java                                                               |
| -------------- | -------------------------------------------- | ------------------------------------------------------- | ------------------------------------------------------------------ |
| **Basic**      | chained `filter`/`sort`/`map`, no types      | one list comprehension over `sorted()`, no type hints   | stream pipeline **referencing a `Student` class it never defines** |
| **Structured** | JSDoc, named function, usage example         | Google-style docstring, filter-then-sort, usage example | `record` + Javadoc, safe `Comparator`, runnable `main`             |
| **Advanced**   | `interface`, options object, 4 console tests | frozen `dataclass`, `Literal` alias, 5 pytest cases     | `record` + `enum` + `FilterOptions`, 5 JUnit 5 cases               |

### The language-specific tell

The most instructive part of running this lab outside JavaScript is that **each language exposes a different failure of the basic prompt**:

- **Java** — the basic prompt yields code that _does not compile_. The AI writes `List<Student>` without ever defining `Student`. There is no JavaScript equivalent to this failure, and it lands hard with a room of Java developers: the first prompt produces something that looks right and cannot be run.
- **Python** — the basic prompt silently assumes the input is a `dict` with `"name"` / `"score"` keys. Nothing says so, nothing validates it, and any malformed record raises a `KeyError` at a distance. The advanced prompt is also the only one that guards against `Sequence` accepting a plain string.
- **JavaScript** — the basic prompt works first try. Which is precisely why it is the weakest language for making this lab's point, and why offering the variants matters.

Use this when debriefing: ask each trainee which of the three levels first produced _runnable_ code in their language. The answers differ, and that difference is the lesson.

## Key Takeaways

1. **Basic prompting** works for quick prototypes but produces minimal output
2. **Structured prompting** adds documentation and examples with small effort
3. **Advanced prompting** produces production-quality code but takes more setup
4. **Choose your approach** based on the task:
   - Quick exploration → Basic
   - Documentation needed → Structured
   - Production code → Advanced

## Additional Resources

See the `resources/prompts/` folder for:

- `exercise-1-basic.md` - Detailed solution for Exercise 1 (JavaScript)
- `exercise-2-structured.md` - Detailed solution for Exercise 2 (JavaScript)
- `exercise-3-advanced.md` - Detailed solution for Exercise 3 (TypeScript)
- `examples.md` - Additional prompts organized by technique level for other tasks
- `python/exercise-{1,2,3}-*.md` - The same three exercises in Python
- `java/exercise-{1,2,3}-*.md` - The same three exercises in Java
