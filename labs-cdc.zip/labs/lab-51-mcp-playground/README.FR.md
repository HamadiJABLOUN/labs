# Lab 51 : MCP Playground

## Pratique du Model Context Protocol

**Durée** : ~45 minutes
**Difficulté** : Intermédiaire
**Prérequis** : Node.js v22+, assistant IA compatible MCP — la mise en place ci-dessous couvre les six : Claude Code, GitHub Copilot, Gemini CLI, Codex CLI, OpenCode, Mistral Vibe

---

## Vue d'ensemble

Dans ce lab, vous allez utiliser le **serveur MCP Playwright** pour interagir avec une application Angular en cours d'exécution via votre assistant IA. Vous allez pratiquer :

1. **Tests de régression visuelle** (~20 min) - Capture de screenshots pour comparaison de référence
2. **Audit d'accessibilité** (~15 min) - Audits A11y automatisés avec [`axe-core`](https://github.com/dequelabs/axe-core)
3. **Génération de tests E2E** (Optionnel, ~10 min) - Génération de tests Playwright à partir d'interactions

---

## Mise en place

### 1. Démarrer l'application

```bash
# From workspace root
npx nx serve photo-gallery-mcp
```

L'application sera disponible sur **http://localhost:42511**

### 2. Configurer Playwright MCP

<details>
<summary><strong>🔹 Claude Code</strong></summary>

```bash
claude mcp add --scope project playwright -- npx @playwright/mcp --browser=firefox --isolated
```

**Vérifier** :

```bash
claude mcp list
```

</details>

<details>
<summary><strong>🔹 GitHub Copilot</strong></summary>

Exécuter en ligne de commande :

```bash
copilot mcp add playwright -- npx @playwright/mcp@latest
```

</details>

<details>
<summary><strong>🔹 Gemini CLI</strong></summary>

```bash
gemini mcp add playwright npx @playwright/mcp --browser=firefox --isolated
```

**Vérifier** :

```bash
gemini mcp list
```

</details>

<details>
<summary><strong>🔹 Codex CLI</strong></summary>

```bash
CODEX_HOME=. codex mcp add playwright -- npx @playwright/mcp --browser=firefox --isolated
```

**Vérifier** :

```bash
codex mcp list
```

</details>

<details>
<summary><strong>🔹 OpenCode CLI</strong></summary>

Ajouter dans `opencode.json` à la racine du projet (à créer s'il n'existe pas) :

```json
{
  "mcp": {
    "playwright": {
      "type": "local",
      "command": ["npx", "@playwright/mcp", "--browser=firefox", "--isolated"]
    }
  }
}
```

**Vérifier** :

```bash
opencode mcp list
```

</details>

<details>
<summary><strong>🔹 Mistral Vibe</strong></summary>

Ajouter dans `.vibe/config.toml` à la racine du projet (créer le fichier et le répertoire s'ils n'existent pas) :

```toml
[[mcp_servers]]
name = "playwright-chrome"
transport = "stdio"
command = "npx"
args = [
    "-y",
    "@playwright/mcp@0.0.83",
    "--browser",
    "chrome",
]
```

**Vérifier** : démarrez `vibe` et demandez-lui de lister ses outils MCP disponibles. Au premier lancement, acceptez la demande de confiance du dossier pour que Vibe charge la configuration du projet. Vous pouvez aussi lancer `vibe --setup` pour une configuration guidée.

</details>

### 3. Vérifier la connexion MCP

Demandez à votre assistant IA :

> "Quels outils MCP as-tu à disposition ? Liste ceux de playwright."

Vous devriez voir des outils Playwright comme `browser_navigate`, `browser_screenshot` ou `browser_snapshot`.

---

## Exercice 1 : Tests de régression visuelle (~20 min)

### Objectif

Capturer des screenshots de l'application Photo Gallery pour établir des références visuelles.

### Tâches

#### Tâche 1.1 : Naviguer et capturer

Demandez à votre assistant IA :

```markdown
Navigate to http://localhost:42511 and take a full-page screenshot. Save it as `.playwright-mcp/baseline-home.png`
```

**Résultat attendu** : un screenshot de la page d'accueil enregistré dans votre workspace.

#### Tâche 1.2 : Capturer différents états

Prenez des screenshots de différents états de l'application :

1. **Galerie vide**

```markdown
Navigate to the gallery and capture a screenshot when no photos are displayed". Save it as `.playwright-mcp/screenshot-empty-gallery.png`
```

2. **Avec des photos chargées**

```markdown
Enter the followings tags in the text box with id `tag-input`: `tourist, luxembourg` then click `Add tag` button next to it.
Upload the test image located at `labs/lab-51-mcp-playground/photo-gallery-mcp/public/tourist-lux.png` using the upload feature, then capture a screenshot showing the photo in the gallery".
Save it as `.playwright-mcp/screenshot-with-1-photo.png`
```

```markdown
Enter the followings tags (comma-separated) in the text box with id `tag-input`: `tourist, luxembourg, france` then click `Add tag` button next to it.
Upload the test image located at `labs/lab-51-mcp-playground/photo-gallery-mcp/public/tourist-world.png` using the upload feature, then capture a screenshot showing the photo in the gallery".
Save it as `.playwright-mcp/screenshot-with-2-photos.png`
```

3. **Filtre appliqué**

```markdown
Apply the filter `france` in the `Photo Gallery` section and capture a screenshot of the result. Save it as `.playwright-mcp/screenshot-filter-applied.png`
```

#### Tâche 1.3 : Comparer les screenshots

> "Compare la page d'accueil actuelle avec la référence (`baseline-home.png`). Y a-t-il des différences visuelles ?"

### Critères de réussite

- [ ] Au moins 3 états différents de l'application capturés
- [ ] Screenshots enregistrés avec des noms explicites
- [ ] L'assistant IA sait décrire les différences visuelles lors de la comparaison

---

## Exercice 2 : Audit d'accessibilité et débogage (~15 min)

### Objectif

Identifier les problèmes d'accessibilité et déboguer l'état du DOM avec les outils MCP.

### Tâches

#### Tâche 2.1 : Lancer l'audit initial

```markdown
Navigate to http://localhost:42511 and run an accessibility audit (by adding the [`axe-core`](https://github.com/dequelabs/axe-core#contents-of-the-api-package) script from local file path instead of the one from CDN). Summarize findings by severity: critical, serious, moderate, minor.
```

**Résultat attendu** : un rapport listant les violations WCAG avec leur niveau de sévérité.

#### Tâche 2.2 : Déboguer l'état du DOM avec un snapshot

Cette tâche montre l'usage de `browser_snapshot` pour inspecter le DOM et l'arbre d'accessibilité.

```markdown
Take a snapshot of the current page and analyze it:

1. List all interactive elements (buttons, inputs, links)
2. Check if each button has an accessible name
3. Identify any elements with missing ARIA attributes
```

**Résultat attendu** : un rapport détaillé de la structure du DOM mettant en évidence les problèmes d'accessibilité.

#### Tâche 2.3 : Générer des recommandations de correction

```markdown
For the most critical accessibility issue found:

1. Show the problematic element from the snapshot
2. Explain why it's a problem (WCAG criterion)
3. Provide the corrected HTML code"
```

### Critères de réussite

- [ ] Audit d'accessibilité complet de la page effectué
- [ ] browser_snapshot utilisé pour inspecter la structure du DOM
- [ ] Au moins 2 problèmes d'accessibilité identifiés
- [ ] Recommandations de correction actionnables reçues avec références WCAG

### Problèmes courants à rechercher

| Type de problème          | Critère WCAG | Correction                                    |
| ------------------------- | ------------ | --------------------------------------------- |
| Texte alternatif manquant | 1.1.1        | Ajouter l'attribut `alt` aux images           |
| Contraste faible          | 1.4.3        | Augmenter le ratio de contraste texte/fond    |
| Libellés manquants        | 1.3.1        | Ajouter `<label>` ou `aria-label`             |
| Pas d'indicateur de focus | 2.4.7        | Ajouter des styles CSS `:focus`               |
| Pièges au clavier         | 2.1.2        | Permettre la fermeture de la modale par Échap |

---

## Exercice 3 : Génération de tests E2E (Optionnel, ~10 min)

### Objectif

Générer un test E2E Playwright à partir d'une description en langage naturel.

### Tâches

#### Tâche 3.1 : Décrire le scénario de test

```markdown
Generate a Playwright E2E test that:

1. Opens the photo gallery
2. Uploads a test image
3. Applies a filter
4. Verifies the filter was applied

Save the test to `labs/lab-51-mcp-playground/photo-gallery-mcp/e2e/photo-filter.spec.ts`

DON'T attempt to run the test yet (I will do it myself), just generate the code for now.
```

#### Tâche 3.2 : Relire le test généré

Examinez le fichier de test généré :

- Utilise-t-il les bons sélecteurs Playwright ?
- Les assertions sont-elles pertinentes ?
- Le test est-il maintenable ?

#### Tâche 3.3 : Lancer le test

```bash
npx nx e2e photo-gallery-mcp
```

### Critères de réussite

- [ ] Test Playwright syntaxiquement correct généré
- [ ] Le test couvre le scénario décrit
- [ ] Le test s'exécute sans erreur (des ajustements de sélecteurs peuvent être nécessaires)

---

## Dépannage

### Serveur MCP introuvable

```
Error: MCP server 'playwright' not found
```

**Solution** :

```bash
npm install -g @playwright/mcp
npx @playwright/mcp --version
```

### Le navigateur ne démarre pas

```
Error: Browser closed unexpectedly
```

**Solution** :
Essayez un autre navigateur en changeant la config MCP (section `args`) en `--browser=chromium` ou `--browser=webkit`.

### L'application ne tourne pas

```
Error: Connection refused on localhost:42511
```

**Solution** :

```bash
curl -I http://localhost:42511
# If not running:
npx nx serve photo-gallery-mcp
```

---

### Les outils MCP n'apparaissent pas

<details>
<summary><strong>🔹 Claude Code</strong></summary>

1. Redémarrer complètement Claude Code
2. Vérifier la config : `claude mcp list`

</details>

<details>
<summary><strong>🔹 GitHub Copilot</strong></summary>

1. Consulter les logs de votre IDE pour les erreurs MCP
2. Vérifier la syntaxe de `mcp.json`
3. Redémarrer votre IDE

</details>

<details>
<summary><strong>🔹 Gemini CLI</strong></summary>

1. Redémarrer Gemini CLI
2. Vérifier la config : `gemini mcp list`
3. Confirmer que le fichier de config existe : `~/.gemini/settings.json` ou `.gemini/settings.json`

</details>

<details>
<summary><strong>🔹 Codex CLI</strong></summary>

1. Redémarrer la TUI Codex ou l'extension IDE
2. Vérifier la config : `codex mcp list`
3. Confirmer que le fichier de config existe : `~/.codex/config.toml` ou `.codex/config.toml`

</details>

<details>
<summary><strong>🔹 Mistral Vibe</strong></summary>

1. Redémarrer Vibe, ou se reconnecter avec `vibe --continue` pour reprendre la session
2. Confirmer que le fichier de config existe et est du TOML valide : `.vibe/config.toml`
3. Vérifier l'entrée `[[mcp_servers]]` (`name = "playwright-chrome"`) et les valeurs `command`/`args`
4. S'assurer d'avoir accepté la demande de confiance du dossier pour le répertoire du projet

</details>

## Résumé

Dans ce lab, vous avez pratiqué :

| Exercice                | Outils/fonctionnalités utilisés           |
| ----------------------- | ----------------------------------------- |
| **Tests visuels**       | `browser_navigate`, `browser_screenshot`  |
| **A11y et débogage**    | `browser_snapshot`, arbre d'accessibilité |
| **Génération de tests** | Langage naturel vers tests Playwright     |

### Points clés à retenir

- MCP étend votre assistant IA avec des outils externes (navigateur, APIs, bases de données)
- `browser_snapshot` est puissant pour déboguer - il expose l'arbre d'accessibilité + le DOM
- Les mêmes serveurs MCP fonctionnent sur tous les agents supportés (Claude Code, GitHub Copilot, Gemini CLI, Codex CLI, OpenCode et Mistral Vibe)

### Prochaines étapes

- Intégrer la régression visuelle dans votre pipeline CI/CD
- Créer des screenshots de référence pour les parcours utilisateur critiques
- Mettre en place des contrôles d'accessibilité automatisés sur les PR

---

## Solution de référence

Voir `labs/lab-51-mcp-playground-solution/` pour :

- Le répertoire de screenshots avec les références
- Les rapports d'audit d'accessibilité
- Les fichiers de tests E2E générés
