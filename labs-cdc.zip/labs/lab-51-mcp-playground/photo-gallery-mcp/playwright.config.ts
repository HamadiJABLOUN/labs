import { defineConfig, devices } from '@playwright/test';
import { nxE2EPreset } from '@nx/playwright/preset';
import { workspaceRoot } from '@nx/devkit';

// For CI, you may want to set BASE_URL to the deployed application.
const baseURL = process.env['BASE_URL'] || 'http://localhost:42511';

/**
 * Read environment variables from file.
 * https://github.com/motdotla/dotenv
 */
// require('dotenv').config();

/**
 * See https://playwright.dev/docs/test-configuration.
 */

const nxPreset = nxE2EPreset(__filename, { testDir: './e2e' });
const htmlReporterConfig = nxPreset.reporter?.[0]?.[1];
export default defineConfig({
  ...nxPreset,
  // Override the default 'html' reporter from above nxE2EPreset
  reporter: [
    [
      'html',
      {
       ...htmlReporterConfig,
        host: '0.0.0.0', // '0.0.0.0' instead of 'localhost' for access from outside the devcontainer
      },
    ],
  ],
  /* Shared settings for all the projects below. See https://playwright.dev/docs/api/class-testoptions. */
  use: {
    baseURL,
    /* Collect trace when retrying the failed test. See https://playwright.dev/docs/trace-viewer */
    trace: 'on-first-retry',
  },
  /* Run your local dev server before starting the tests */
  webServer: {
    command: 'npx nx serve photo-gallery-mcp',
    url: 'http://localhost:42511',
    reuseExistingServer: !process.env.CI,
    cwd: workspaceRoot,
  },
  projects: [
    // Uncomment to run tests in Chromium browser
    /*{
      name: 'chromium',
      use: { ...devices['Desktop Chrome'] },
    },*/

    {
      name: 'firefox',
      use: { ...devices['Desktop Firefox'] },
    },

    // Uncomment to run tests in Webkit browser
    /*{
      name: 'webkit',
      use: { ...devices['Desktop Safari'] },
    },*/

    // Uncomment for mobile browsers support
    /* {
      name: 'Mobile Chrome',
      use: { ...devices['Pixel 5'] },
    },
    {
      name: 'Mobile Safari',
      use: { ...devices['iPhone 12'] },
    }, */

    // Uncomment for branded browsers
    /* {
      name: 'Microsoft Edge',
      use: { ...devices['Desktop Edge'], channel: 'msedge' },
    },
    {
      name: 'Google Chrome',
      use: { ...devices['Desktop Chrome'], channel: 'chrome' },
    } */
  ],
});
