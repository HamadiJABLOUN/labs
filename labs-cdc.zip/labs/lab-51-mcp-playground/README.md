# Lab 51: MCP Playground

## Hands-on Practice with Model Context Protocol

**Duration**: ~45 minutes
**Difficulty**: Intermediate
**Prerequisites**: Node.js v22+, AI assistant with MCP support — the setup below covers all six: Claude Code, GitHub Copilot, Gemini CLI, Codex CLI, OpenCode, Mistral Vibe

---

## Overview

In this lab, you'll use the **Playwright MCP server** to interact with a running Angular application through your AI assistant. You'll practice:

1. **Visual Regression Testing** (~20 min) - Capturing screenshots for baseline comparison
2. **Accessibility Auditing** (~15 min) - Running automated A11y audits with [`axe-core`](https://github.com/dequelabs/axe-core)
3. **E2E Test Generation** (Optional, ~10 min) - Generating Playwright tests from interactions

---

## Setup

### 1. Start the Application

```bash
# From workspace root
npx nx serve photo-gallery-mcp
```

The application will be available at **http://localhost:42511**

### 2. Configure Playwright MCP

<details>
<summary><strong>🔹 Claude Code</strong></summary>

```bash
claude mcp add --scope project playwright -- npx @playwright/mcp --browser=firefox --isolated
```

**Verify**:

```bash
claude mcp list
```

</details>

<details>
<summary><strong>🔹 GitHub Copilot</strong></summary>

Execute in the command line:

```bash
copilot mcp add playwright -- npx @playwright/mcp@latest
```

</details>

<details>
<summary><strong>🔹 Gemini CLI</strong></summary>

```bash
gemini mcp add playwright npx @playwright/mcp --browser=firefox --isolated
```

**Verify**:

```bash
gemini mcp list
```

</details>

<details>
<summary><strong>🔹 Codex CLI</strong></summary>

```bash
CODEX_HOME=. codex mcp add playwright -- npx @playwright/mcp --browser=firefox --isolated
```

**Verify**:

```bash
codex mcp list
```

</details>

<details>
<summary><strong>🔹 OpenCode CLI</strong></summary>

Add to `opencode.json` at the project root (create if it doesn't exist):

```json
{
  "mcp": {
    "playwright": {
      "type": "local",
      "command": ["npx", "@playwright/mcp", "--browser=firefox", "--isolated"]
    }
  }
}
```

**Verify**:

```bash
opencode mcp list
```

</details>

<details>
<summary><strong>🔹 Mistral Vibe</strong></summary>

Add to `.vibe/config.toml` at the project root (create the file and directory if they don't exist):

```toml
[[mcp_servers]]
name = "playwright-chrome"
transport = "stdio"
command = "npx"
args = [
    "-y",
    "@playwright/mcp@0.0.83",
    "--browser",
    "chrome",
]
```

**Verify**: start `vibe` and ask it to list its available MCP tools. On first launch, accept the folder-trust prompt so Vibe loads the project config. You can also run `vibe --setup` for a guided configuration.

</details>

### 3. Verify MCP Connection

Ask your AI assistant:

> "What MCP tools do you have available? List the playwright ones."

You should see Playwright tools like `browser_navigate`, `browser_screenshot`, or `browser_snapshot`.

---

## Exercise 1: Visual Regression Testing (~20 min)

### Goal

Capture screenshots of the Photo Gallery application to establish visual baselines.

### Tasks

#### Task 1.1: Navigate and Screenshot

Ask your AI assistant:

```markdown
Navigate to http://localhost:42511 and take a full-page screenshot. Save it as `.playwright-mcp/baseline-home.png`
```

**Expected Result**: A screenshot of the home page saved to your workspace.

#### Task 1.2: Capture Different States

Take screenshots of different application states:

1. **Empty Gallery State**

```markdown
Navigate to the gallery and capture a screenshot when no photos are displayed". Save it as `.playwright-mcp/screenshot-empty-gallery.png`
```

2. **With Photos Loaded**

```markdown
Enter the followings tags in the text box with id `tag-input`: `tourist, luxembourg` then click `Add tag` button next to it.
Upload the test image located at `labs/lab-51-mcp-playground/photo-gallery-mcp/public/tourist-lux.png` using the upload feature, then capture a screenshot showing the photo in the gallery".
Save it as `.playwright-mcp/screenshot-with-1-photo.png`
```

```markdown
Enter the followings tags (comma-separated) in the text box with id `tag-input`: `tourist, luxembourg, france` then click `Add tag` button next to it.
Upload the test image located at `labs/lab-51-mcp-playground/photo-gallery-mcp/public/tourist-world.png` using the upload feature, then capture a screenshot showing the photo in the gallery".
Save it as `.playwright-mcp/screenshot-with-2-photos.png`
```

3. **Filter Applied**

```markdown
Apply the filter `france` in the `Photo Gallery` section and capture a screenshot of the result. Save it as `.playwright-mcp/screenshot-filter-applied.png`
```

#### Task 1.3: Compare Screenshots

> "Compare the current home page with the baseline (`baseline-home.png`). Are there any visual differences?"

### Success Criteria

- [ ] Captured at least 3 different application states
- [ ] Screenshots are saved with descriptive names
- [ ] AI assistant can describe visual differences when comparing

---

## Exercise 2: Accessibility Auditing & Debugging (~15 min)

### Goal

Identify accessibility issues and debug DOM state using MCP tools.

### Tasks

#### Task 2.1: Run Initial Audit

```markdown
Navigate to http://localhost:42511 and run an accessibility audit (by adding the [`axe-core`](https://github.com/dequelabs/axe-core#contents-of-the-api-package) script from local file path instead of the one from CDN). Summarize findings by severity: critical, serious, moderate, minor.
```

**Expected Result**: A report listing WCAG violations with severity levels.

#### Task 2.2: Debug DOM State with Snapshot

This task demonstrates using `browser_snapshot` to inspect the DOM and accessibility tree.

```markdown
Take a snapshot of the current page and analyze it:

1. List all interactive elements (buttons, inputs, links)
2. Check if each button has an accessible name
3. Identify any elements with missing ARIA attributes
```

**Expected Result**: A detailed report of the DOM structure with accessibility issues highlighted.

#### Task 2.3: Generate Fix Recommendations

```markdown
For the most critical accessibility issue found:

1. Show the problematic element from the snapshot
2. Explain why it's a problem (WCAG criterion)
3. Provide the corrected HTML code"
```

### Success Criteria

- [ ] Ran full page accessibility audit
- [ ] Used browser_snapshot to inspect DOM structure
- [ ] Identified at least 2 accessibility issues
- [ ] Received actionable fix recommendations with WCAG references

### Common Issues to Look For

| Issue Type         | WCAG Criterion | Fix                                     |
| ------------------ | -------------- | --------------------------------------- |
| Missing alt text   | 1.1.1          | Add `alt` attribute to images           |
| Low contrast       | 1.4.3          | Increase text/background contrast ratio |
| Missing labels     | 1.3.1          | Add `<label>` or `aria-label`           |
| No focus indicator | 2.4.7          | Add `:focus` CSS styles                 |
| Keyboard traps     | 2.1.2          | Ensure modal can be closed with Escape  |

---

## Exercise 3: E2E Test Generation (Optional, ~10 min)

### Goal

Generate a Playwright E2E test from natural language description.

### Tasks

#### Task 3.1: Describe the Test Scenario

```markdown
Generate a Playwright E2E test that:

1. Opens the photo gallery
2. Uploads a test image
3. Applies a filter
4. Verifies the filter was applied

Save the test to `labs/lab-51-mcp-playground/photo-gallery-mcp/e2e/photo-filter.spec.ts`

DON'T attempt to run the test yet (I will do it myself), just generate the code for now.
```

#### Task 3.2: Review Generated Test

Examine the generated test file:

- Does it use correct Playwright selectors?
- Are assertions meaningful?
- Is the test maintainable?

#### Task 3.3: Run the Test

```bash
npx nx e2e photo-gallery-mcp
```

### Success Criteria

- [ ] Generated syntactically correct Playwright test
- [ ] Test covers the described scenario
- [ ] Test runs without errors (may need selector adjustments)

---

## Troubleshooting

### MCP Server Not Found

```
Error: MCP server 'playwright' not found
```

**Solution**:

```bash
npm install -g @playwright/mcp
npx @playwright/mcp --version
```

### Browser Not Launching

```
Error: Browser closed unexpectedly
```

**Solution**:
Try another browser by changing the MCP config (`args` section) to `--browser=chromium` or `--browser=webkit`.

### Application Not Running

```
Error: Connection refused on localhost:42511
```

**Solution**:

```bash
curl -I http://localhost:42511
# If not running:
npx nx serve photo-gallery-mcp
```

---

### MCP Tools Not Appearing

<details>
<summary><strong>🔹 Claude Code</strong></summary>

1. Restart Claude Code completely
2. Verify config: `claude mcp list`

</details>

<details>
<summary><strong>🔹 GitHub Copilot</strong></summary>

1. Check your IDE logs for MCP errors
2. Check `mcp.json` syntax
3. Restart your IDE

</details>

<details>
<summary><strong>🔹 Gemini CLI</strong></summary>

1. Restart Gemini CLI
2. Verify config: `gemini mcp list`
3. Confirm config file exists: `~/.gemini/settings.json` or `.gemini/settings.json`

</details>

<details>
<summary><strong>🔹 Codex CLI</strong></summary>

1. Restart the Codex TUI or IDE extension
2. Verify config: `codex mcp list`
3. Confirm config file exists: `~/.codex/config.toml` or `.codex/config.toml`

</details>

<details>
<summary><strong>🔹 Mistral Vibe</strong></summary>

1. Restart Vibe, or reconnect with `vibe --continue` to resume the session
2. Confirm the config file exists and is valid TOML: `.vibe/config.toml`
3. Check the `[[mcp_servers]]` entry (`name = "playwright-chrome"`) and `command`/`args` values
4. Ensure you accepted the folder-trust prompt for the project directory

</details>

## Summary

In this lab, you practiced:

| Exercise             | Tools/Features Used                      |
| -------------------- | ---------------------------------------- |
| **Visual Testing**   | `browser_navigate`, `browser_screenshot` |
| **A11y & Debugging** | `browser_snapshot`, accessibility tree   |
| **Test Generation**  | Natural language to Playwright tests     |

### Key Takeaways

- MCP extends your AI assistant with external tools (browser, APIs, databases)
- `browser_snapshot` is powerful for debugging - shows accessibility tree + DOM
- The same MCP servers work across every supported agent (Claude Code, GitHub Copilot, Gemini CLI, Codex CLI, OpenCode, and Mistral Vibe)

### Next Steps

- Integrate visual regression into your CI/CD pipeline
- Create baseline screenshots for critical user flows
- Set up automated accessibility checks on PRs

---

## Solution Reference

See `labs/lab-51-mcp-playground-solution/` for:

- Screenshots directory with baselines
- Accessibility audit reports
- Generated E2E test files
