# Lab 21 : Atelier Galerie Photo - Expérimentation Vibe Coding

## Vue d'ensemble

Ce lab pratique vous fait vivre le vibe coding de première main : vous allez générer une application de galerie photo avec l'IA sans relire le code généré. Vous testerez ensuite la galerie, analyserez ce qui a fonctionné (et ce qui n'a pas fonctionné), et acquerrez une compréhension concrète des concepts abordés dans les slides du module.

Cet exercice simule volontairement l'approche vibe coding pour vous aider à comprendre ses bénéfices, ses limites et ses cas d'usage pertinents par l'expérience directe.

## Objectifs pédagogiques

- **Expérimenter** le vibe coding de première main en générant du code sans relecture
- **Identifier** ce qui fonctionne bien et les problèmes qui surgissent en pratique
- **Analyser** quand cette approche est (ou n'est pas) appropriée
- **Relier** les observations pratiques aux concepts théoriques des slides
- **Évaluer** votre niveau de confiance pour déployer du code généré par IA non relu

## Prérequis

### Depuis les slides du module 2

- Compréhension de la définition du vibe coding (acceptation passive de l'IA)
- Conscience des risques de défaillance en production
- Connaissance des limites (visibilité, débogage, contrôle)

### Installation technique

- Ordinateur avec accès internet
- Un agent de codage IA (Claude Code, GitHub Copilot CLI, Codex CLI, Gemini CLI ou similaire)
- Navigateur web pour les tests
- Familiarité de base avec un langage de programmation

## Durée estimée

**Temps total** : 25-30 minutes

- Installation : 5 minutes
- Génération : 10-15 minutes
- Tests : 5 minutes
- Analyse : 5 minutes

## Consignes de l'exercice

### Installation (5 minutes)

#### Étape 1 : Créer le dossier du projet

```bash
mkdir photo-gallery-workshop
cd photo-gallery-workshop
```

### Phase de génération (10-15 minutes)

**⚠️ RÈGLE IMPORTANTE** : NE relisez PAS le code généré. Acceptez les suggestions sans lire l'implémentation. C'est une simulation de vibe coding.

#### Étape 2 : Générer l'application de galerie photo

1. Ouvrez votre agent de codage IA dans le dossier `photo-gallery-workshop/` (par exemple, lancez `claude` pour Claude Code, ou utilisez le CLI de l'agent IA de votre choix)
2. Envoyez le prompt suivant à votre agent IA :

```text
Create a photo gallery web application with the following requirements:

- HTML file (index.html) with a photo gallery interface
- CSS file (style.css) with modern, responsive styling
- JavaScript file (script.js) with gallery logic
- Display a grid of sample photos (use placeholder images from picsum.photos)
- Clicking a photo opens it in a modal/lightbox view
- Navigation arrows (previous/next) in the modal
- Close button to exit modal
- Support for keyboard navigation (arrow keys, ESC)
- Loading state while images load
- Responsive design (works on mobile and desktop)

Make it look professional with smooth transitions and good UX.
```

3. **IMPORTANT** : lorsque l'agent IA génère du code, acceptez toutes les modifications SANS lire le code
4. Vérifiez que les fichiers ont bien été créés (index.html, style.css, script.js)
5. **Rappel** : l'objectif est de vivre le vibe coding - ne relisez pas ce que l'IA a créé

### Phase de test (5 minutes)

#### Étape 3 : Tester la galerie photo

Ouvrez `index.html` dans votre navigateur web et testez ces scénarios :

| Cas de test        | Comportement attendu                    | Comportement réel | Réussi/Échoué |
| ------------------ | --------------------------------------- | ----------------- | ------------- |
| Chargement galerie | Les photos apparaissent en grille       | \***\*\_\*\***    | **\_\_\_**    |
| Mise en page       | La grille s'adapte à la fenêtre         | \***\*\_\*\***    | **\_\_\_**    |
| Clic sur une photo | Ouvre en modale/lightbox                | \***\*\_\*\***    | **\_\_\_**    |
| Bouton suivant     | Navigue vers la photo suivante          | \***\*\_\*\***    | **\_\_\_**    |
| Bouton précédent   | Navigue vers la photo précédente        | \***\*\_\*\***    | **\_\_\_**    |
| Bouton fermer      | Ferme la modale, revient à la grille    | \***\*\_\*\***    | **\_\_\_**    |
| Touche ESC         | Ferme la modale                         | \***\*\_\*\***    | **\_\_\_**    |
| Touches fléchées   | Navigue entre les photos dans la modale | \***\*\_\*\***    | **\_\_\_**    |
| État de chargement | Affiche un retour pendant le chargement | \***\*\_\*\***    | **\_\_\_**    |
| Vue mobile         | Fonctionne bien sur petits écrans       | \***\*\_\*\***    | **\_\_\_**    |

Consignez vos observations dans le tableau ci-dessus.

### Phase d'analyse (5 minutes)

#### Étape 4 : Questions d'analyse

Répondez honnêtement à ces questions en vous basant sur votre expérience :

**1. Qu'est-ce qui a bien fonctionné ?**

- La galerie photo a-t-elle été générée avec succès ?
- La modale/lightbox a-t-elle fonctionné correctement ?
- L'UI/UX était-elle professionnelle et utilisable ?

**2. Quels problèmes avez-vous rencontrés ?**

- Des tests ont-ils échoué ?
- Y a-t-il eu des problèmes d'UI/UX ?
- Avez-vous découvert des bugs pendant les tests ?
- Y avait-il des cas limites oubliés par l'IA ?

**3. Niveau de confiance : s'il s'agissait d'un projet en production, quelle confiance auriez-vous pour déployer cette galerie photo sans relire le code ?**

- Échelle : 1 (pas confiance du tout) à 5 (très confiant)
- Pourquoi avez-vous choisi cette note ?

**4. Scénarios appropriés : d'après cette expérience, quand le vibe coding serait-il approprié pour des applications de type galerie ?**

- Site portfolio personnel ?
- Bibliothèque photo interne à l'entreprise ?
- Vitrine produit face au client ?
- Expliquez votre raisonnement

**5. Impact du niveau d'expérience : comment votre niveau d'expérience a-t-il influencé cet exercice ?**

- Un développeur plus expérimenté détecterait-il plus de problèmes pendant les tests ?
- Un développeur moins expérimenté se sentirait-il plus ou moins confiant pour déployer ceci ?
- Quel rôle joue l'expérience dans la sûreté du vibe coding ?

**6. Comparaison avec des applications de production : comment cette galerie générée par IA se compare-t-elle aux galeries prêtes pour la production que vous avez vues ?**

- Qu'est-ce qui manque et dont une application de production aurait besoin ?
- Quels écarts de qualité remarquez-vous ?
- Que faudrait-il ajouter avant de déployer auprès de vrais utilisateurs ?

## Dépannage

### Problèmes avec l'agent IA

**Problème** : l'agent IA ne démarre pas ou ne s'authentifie pas

- **Solution** : vérifiez votre clé API ou votre connexion ; demandez de l'aide au formateur

**Problème** : l'agent IA plante ou se bloque

- **Solution** : redémarrez l'agent ; si le problème persiste, essayez un autre agent IA

**Problème** : l'IA ne génère pas de code

- **Solution** : vérifiez la connexion internet ; reformulez le prompt ; découpez en plus petits morceaux

### Problèmes de génération

**Problème** : l'IA génère du code incomplet

- **Solution** : demandez à l'IA de "compléter l'application de galerie photo" avec les parties manquantes

**Problème** : les fichiers ne sont pas créés

- **Solution** : créez les fichiers manuellement et demandez à l'IA de générer chaque fichier séparément

**Problème** : les images ne se chargent pas

- **Solution** : c'est un moment d'apprentissage ! Documentez ce qui s'est passé pour la discussion d'analyse

**Problème** : la modale ne fonctionne pas

- **Solution** : notez le problème pour l'analyse - cela illustre les risques du vibe coding

## Prochaines étapes

Après avoir terminé ce lab :

1. **Conservez votre dossier généré** - sauvegardez votre dossier `photo-gallery-workshop/` pour le comparer à la solution
2. **Sauvegardez vos observations** - vous en discuterez avec le groupe
3. **Comparez les résultats** - la galerie de chacun fonctionne-t-elle de la même façon ?
4. **Consultez la solution** - regardez `labs/lab-21-photo-gallery-workshop-solution/` pour comparer
5. **Analysez les concepts du module** - comment votre expérience se relie-t-elle aux slides ?
6. **Considérez l'écart avec la production** - que faudrait-il pour rendre ceci prêt pour la production ?

## Lien avec les labs suivants

Cette application de galerie photo sert de fondation aux labs suivants :

- **Lab 31 (Refactoring de legacy)** : vous verrez une version "legacy" d'une galerie photo et pratiquerez son refactoring avec un workflow agentique
- **Lab 32 (From Scratch)** : vous construirez une galerie photo depuis zéro en appliquant les bonnes pratiques agentiques

Cette progression vous aide à comparer les résultats du vibe coding (ce lab) avec un développement agentique correctement planifié et relu (labs suivants).

## Questions ou problèmes ?

Demandez de l'aide à votre formateur pendant la session de lab.
