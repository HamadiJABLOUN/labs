# Lab 21: Photo Gallery Workshop - Vibe Coding Experiment

## Overview

This hands-on lab provides firsthand experience with vibe coding by having you generate a photo gallery application using AI without reviewing the generated code. You'll then test the gallery, reflect on what worked (and what didn't), and gain practical understanding of the concepts discussed in the module slides.

This exercise intentionally simulates the vibe coding approach to help you understand its benefits, limitations, and appropriate use cases through direct experience.

## Learning Objectives

- **Experience** vibe coding firsthand by generating code without review
- **Identify** what works well and what issues arise in practice
- **Reflect** on when this approach is (and isn't) appropriate
- **Connect** hands-on observations to theoretical concepts from slides
- **Evaluate** your confidence level in deploying unreviewed AI-generated code

## Prerequisites

### From Module 2 Slides

- Understanding of vibe coding definition (passive AI acceptance)
- Awareness of production failure risks
- Knowledge of limitations (visibility, debugging, control)

### Technical Setup

- Computer with internet access
- An AI coding agent (Claude Code, GitHub Copilot CLI, Codex CLI, Gemini CLI, or similar)
- Web browser for testing
- Basic familiarity with any programming language

## Estimated Duration

**Total Time**: 25-30 minutes

- Setup: 5 minutes
- Generation: 10-15 minutes
- Testing: 5 minutes
- Reflection: 5 minutes

## Exercise Instructions

### Setup (5 minutes)

#### Step 1: Create Project Folder

```bash
mkdir photo-gallery-workshop
cd photo-gallery-workshop
```

### Generation Phase (10-15 minutes)

**⚠️ IMPORTANT RULE**: Do NOT review the generated code. Accept suggestions without reading the implementation. This is a vibe coding simulation.

#### Step 2: Generate Photo Gallery Application

1. Open your AI coding agent in the `photo-gallery-workshop/` folder (e.g., run `claude` for Claude Code, or use your preferred AI agent CLI)
2. Send the following prompt to your AI agent:

```text
Create a photo gallery web application with the following requirements:

- HTML file (index.html) with a photo gallery interface
- CSS file (style.css) with modern, responsive styling
- JavaScript file (script.js) with gallery logic
- Display a grid of sample photos (use placeholder images from picsum.photos)
- Clicking a photo opens it in a modal/lightbox view
- Navigation arrows (previous/next) in the modal
- Close button to exit modal
- Support for keyboard navigation (arrow keys, ESC)
- Loading state while images load
- Responsive design (works on mobile and desktop)

Make it look professional with smooth transitions and good UX.
```

3. **IMPORTANT**: When the AI agent generates code, accept all changes WITHOUT reading the code
4. Verify the files were created (index.html, style.css, script.js)
5. **Remember**: The goal is to experience vibe coding - don't review what the AI created

### Testing Phase (5 minutes)

#### Step 3: Test the Photo Gallery

Open `index.html` in your web browser and test these scenarios:

| Test Case         | Expected Behavior                | Actual Behavior | Pass/Fail  |
| ----------------- | -------------------------------- | --------------- | ---------- |
| Gallery loads     | Photos appear in grid layout     | \***\*\_\*\***  | **\_\_\_** |
| Responsive layout | Grid adapts to window size       | \***\*\_\*\***  | **\_\_\_** |
| Click photo       | Opens in modal/lightbox          | \***\*\_\*\***  | **\_\_\_** |
| Next button       | Navigates to next photo          | \***\*\_\*\***  | **\_\_\_** |
| Previous button   | Navigates to previous photo      | \***\*\_\*\***  | **\_\_\_** |
| Close button      | Closes modal and returns to grid | \***\*\_\*\***  | **\_\_\_** |
| ESC key           | Closes modal                     | \***\*\_\*\***  | **\_\_\_** |
| Arrow keys        | Navigate between photos in modal | \***\*\_\*\***  | **\_\_\_** |
| Loading state     | Shows feedback while images load | \***\*\_\*\***  | **\_\_\_** |
| Mobile view       | Works well on small screens      | \***\*\_\*\***  | **\_\_\_** |

Record your observations in the table above.

### Reflection Phase (5 minutes)

#### Step 4: Reflection Questions

Answer these questions honestly based on your experience:

**1. What worked well?**

- Did the photo gallery generate successfully?
- Did the modal/lightbox function correctly?
- Was the UI/UX professional and usable?

**2. What issues did you encounter?**

- Did any tests fail?
- Were there UI/UX problems?
- Did you discover bugs during testing?
- Were there edge cases the AI missed?

**3. Confidence level: If this was a production project, how confident would you feel deploying this photo gallery without reviewing the code?**

- Scale: 1 (not at all confident) to 5 (very confident)
- Why did you choose this rating?

**4. Appropriate scenarios: Based on this experience, when would vibe coding be appropriate for gallery-like applications?**

- Personal portfolio website?
- Internal company photo library?
- Customer-facing product showcase?
- Explain your reasoning

**5. Experience level impact: How do you think your experience level affected this exercise?**

- Would a more experienced developer catch more issues during testing?
- Would a less experienced developer feel more or less confident deploying this?
- What role does experience play in vibe coding safety?

**6. Comparison to production applications: How does this AI-generated gallery compare to production-ready galleries you've seen?**

- What's missing that a production app would need?
- What quality gaps do you notice?
- What would you need to add before deploying to real users?

## Troubleshooting

### AI Agent Issues

**Problem**: AI agent won't start or authenticate

- **Solution**: Check your API key or login; ask trainer for assistance

**Problem**: AI agent crashes or freezes

- **Solution**: Restart the agent; if persistent, try a different AI agent

**Problem**: AI doesn't generate code

- **Solution**: Check internet connection; rephrase prompt; try smaller chunks

### Generation Issues

**Problem**: AI generates incomplete code

- **Solution**: Ask AI to "complete the photo gallery application" with missing pieces

**Problem**: Files not created

- **Solution**: Manually create files and ask AI to generate each file separately

**Problem**: Images don't load

- **Solution**: This is a learning moment! Document what happened for reflection discussion

**Problem**: Modal doesn't work

- **Solution**: Note the issue for reflection - this demonstrates vibe coding risks

## Next Steps

After completing this lab:

1. **Keep your generated folder** - save your `photo-gallery-workshop/` folder to compare with the solution
2. **Save your observations** - you'll discuss them with the group
3. **Compare results** - did everyone's gallery work the same way?
4. **Review solution** - check `labs/lab-21-photo-gallery-workshop-solution/` for comparison
5. **Reflect on module concepts** - how does your experience connect to the slides?
6. **Consider the production gap** - what would be needed to make this production-ready?

## Connection to Later Labs

This photo gallery application serves as the foundation for later labs:

- **Lab 31 (Legacy Refactoring)**: You'll see a "legacy" version of a photo gallery and practice refactoring it using agentic workflow
- **Lab 32 (From Scratch)**: You'll build a photo gallery from scratch using proper agentic practices

This progression helps you compare vibe coding results (this lab) with properly planned and reviewed agentic development (later labs).

## Questions or Issues?

Ask your trainer for assistance during the lab session.
