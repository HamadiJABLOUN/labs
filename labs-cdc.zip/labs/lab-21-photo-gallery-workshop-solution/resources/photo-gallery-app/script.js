/**
 * Photo Gallery - Reference Implementation
 *
 * Features:
 * - Responsive grid layout
 * - Modal/lightbox view
 * - Keyboard navigation (arrows, ESC)
 * - Touch swipe support (mobile)
 * - Lazy loading
 * - Accessibility (ARIA, focus management)
 */

// ============================================================================
// Configuration
// ============================================================================

const CONFIG = {
    // Photo data source (Picsum Photos placeholder service)
    photoCount: 12,
    photoWidth: 800,
    photoHeight: 600,

    // Loading simulation
    minLoadingTime: 500,  // ms
    maxLoadingTime: 1200, // ms

    // Touch gestures
    swipeThreshold: 50, // px minimum swipe distance
};

// ============================================================================
// State Management
// ============================================================================

const state = {
    photos: [],
    currentIndex: 0,
    modalOpen: false,
    touchStartX: 0,
    touchEndX: 0,
    focusedElementBeforeModal: null,
};

// ============================================================================
// DOM Elements
// ============================================================================

let elements = {};

// ============================================================================
// Photo Data Generation
// ============================================================================

/**
 * Generate mock photo data using Picsum Photos service
 * @returns {Array} Array of photo objects
 */
function generatePhotoData() {
    const photos = [];

    for (let i = 1; i <= CONFIG.photoCount; i++) {
        // Use different image IDs from Picsum for variety
        const imageId = i * 10;

        photos.push({
            id: i,
            title: `Photo ${i}`,
            // Thumbnail for gallery grid
            thumbnail: `https://picsum.photos/id/${imageId}/${CONFIG.photoWidth}/${CONFIG.photoHeight}`,
            // Full size for modal
            full: `https://picsum.photos/id/${imageId}/${CONFIG.photoWidth * 2}/${CONFIG.photoHeight * 2}`,
            alt: `Beautiful landscape photo number ${i}`,
        });
    }

    return photos;
}

// ============================================================================
// Gallery Rendering
// ============================================================================

/**
 * Render the photo gallery grid
 */
function renderGallery() {
    // Clear existing content
    elements.gallery.innerHTML = '';

    // Check if we have photos
    if (state.photos.length === 0) {
        elements.emptyState.hidden = false;
        return;
    }

    elements.emptyState.hidden = true;

    // Create photo cards
    state.photos.forEach((photo, index) => {
        const card = createPhotoCard(photo, index);
        elements.gallery.appendChild(card);
    });

    // Announce to screen readers
    announceToScreenReader(`Gallery loaded with ${state.photos.length} photos`);
}

/**
 * Create a photo card element
 * @param {Object} photo - Photo data
 * @param {number} index - Photo index
 * @returns {HTMLElement} Photo card element
 */
function createPhotoCard(photo, index) {
    const card = document.createElement('article');
    card.className = 'photo-card';
    card.setAttribute('role', 'listitem');
    card.setAttribute('tabindex', '0');
    card.setAttribute('aria-label', `${photo.title}, click to view full size`);

    // Image container
    const imageContainer = document.createElement('div');
    imageContainer.className = 'photo-image-container';

    // Image
    const img = document.createElement('img');
    img.className = 'photo-image loading';
    img.src = photo.thumbnail;
    img.alt = photo.alt;
    img.loading = 'lazy'; // Native lazy loading

    // Handle image load
    img.addEventListener('load', () => {
        img.classList.remove('loading');
        img.classList.add('loaded');
    });

    // Handle image error
    img.addEventListener('error', () => {
        img.alt = 'Failed to load image';
        img.src = 'data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" width="400" height="300"%3E%3Crect fill="%23f0f0f0" width="400" height="300"/%3E%3Ctext x="50%25" y="50%25" text-anchor="middle" fill="%236c757d" font-size="20"%3EImage failed to load%3C/text%3E%3C/svg%3E';
    });

    imageContainer.appendChild(img);

    // Photo info
    const info = document.createElement('div');
    info.className = 'photo-info';

    const photoIndex = document.createElement('div');
    photoIndex.className = 'photo-index';
    photoIndex.textContent = `#${index + 1}`;

    const title = document.createElement('div');
    title.className = 'photo-title';
    title.textContent = photo.title;

    info.appendChild(photoIndex);
    info.appendChild(title);

    // Assemble card
    card.appendChild(imageContainer);
    card.appendChild(info);

    // Event listeners
    card.addEventListener('click', () => openModal(index));
    card.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            openModal(index);
        }
    });

    return card;
}

// ============================================================================
// Modal/Lightbox
// ============================================================================

/**
 * Open modal at specific photo index
 * @param {number} index - Photo index to display
 */
function openModal(index) {
    state.currentIndex = index;
    state.modalOpen = true;

    // Store focused element to restore later
    state.focusedElementBeforeModal = document.activeElement;

    // Update modal content
    updateModalContent();

    // Show modal
    elements.modal.hidden = false;
    document.body.classList.add('modal-open');

    // Focus close button for keyboard accessibility
    setTimeout(() => {
        elements.modalClose.focus();
    }, 100);

    // Announce to screen readers
    announceToScreenReader(`Viewing photo ${index + 1} of ${state.photos.length}`);
}

/**
 * Close modal and restore focus
 */
function closeModal() {
    state.modalOpen = false;

    // Hide modal
    elements.modal.hidden = true;
    document.body.classList.remove('modal-open');

    // Restore focus to element that opened modal
    if (state.focusedElementBeforeModal) {
        state.focusedElementBeforeModal.focus();
    }

    // Announce to screen readers
    announceToScreenReader('Modal closed');
}

/**
 * Navigate to previous photo
 */
function previousPhoto() {
    if (state.currentIndex > 0) {
        state.currentIndex--;
        updateModalContent();
        announceToScreenReader(`Photo ${state.currentIndex + 1} of ${state.photos.length}`);
    }
}

/**
 * Navigate to next photo
 */
function nextPhoto() {
    if (state.currentIndex < state.photos.length - 1) {
        state.currentIndex++;
        updateModalContent();
        announceToScreenReader(`Photo ${state.currentIndex + 1} of ${state.photos.length}`);
    }
}

/**
 * Update modal content with current photo
 */
function updateModalContent() {
    const photo = state.photos[state.currentIndex];

    // Show loading spinner
    elements.modalSpinner.hidden = false;
    elements.modalImage.classList.add('loading');

    // Preload image
    const img = new Image();
    img.src = photo.full;

    img.onload = () => {
        // Update image
        elements.modalImage.src = photo.full;
        elements.modalImage.alt = photo.alt;

        // Hide loading spinner
        elements.modalSpinner.hidden = true;
        elements.modalImage.classList.remove('loading');
    };

    img.onerror = () => {
        // Handle error
        elements.modalImage.src = photo.thumbnail; // Fallback to thumbnail
        elements.modalImage.alt = 'Failed to load full-size image';
        elements.modalSpinner.hidden = true;
        elements.modalImage.classList.remove('loading');
    };

    // Update counter
    elements.currentIndex.textContent = state.currentIndex + 1;
    elements.totalCount.textContent = state.photos.length;

    // Update navigation buttons
    elements.modalPrev.disabled = state.currentIndex === 0;
    elements.modalNext.disabled = state.currentIndex === state.photos.length - 1;

    // Preload adjacent images for smoother navigation
    preloadAdjacentImages();
}

/**
 * Preload adjacent images for better UX
 */
function preloadAdjacentImages() {
    // Preload next image
    if (state.currentIndex < state.photos.length - 1) {
        const nextImg = new Image();
        nextImg.src = state.photos[state.currentIndex + 1].full;
    }

    // Preload previous image
    if (state.currentIndex > 0) {
        const prevImg = new Image();
        prevImg.src = state.photos[state.currentIndex - 1].full;
    }
}

// ============================================================================
// Event Handlers
// ============================================================================

/**
 * Handle keyboard navigation
 * @param {KeyboardEvent} e - Keyboard event
 */
function handleKeydown(e) {
    if (!state.modalOpen) return;

    switch (e.key) {
        case 'Escape':
            e.preventDefault();
            closeModal();
            break;
        case 'ArrowLeft':
            e.preventDefault();
            previousPhoto();
            break;
        case 'ArrowRight':
            e.preventDefault();
            nextPhoto();
            break;
    }
}

/**
 * Handle touch start for swipe gestures
 * @param {TouchEvent} e - Touch event
 */
function handleTouchStart(e) {
    if (!state.modalOpen) return;
    state.touchStartX = e.touches[0].clientX;
}

/**
 * Handle touch move for swipe gestures
 * @param {TouchEvent} e - Touch event
 */
function handleTouchMove(e) {
    if (!state.modalOpen) return;
    state.touchEndX = e.touches[0].clientX;
}

/**
 * Handle touch end for swipe gestures
 */
function handleTouchEnd() {
    if (!state.modalOpen) return;

    const swipeDistance = state.touchStartX - state.touchEndX;

    // Swipe left (next photo)
    if (swipeDistance > CONFIG.swipeThreshold) {
        nextPhoto();
    }
    // Swipe right (previous photo)
    else if (swipeDistance < -CONFIG.swipeThreshold) {
        previousPhoto();
    }

    // Reset touch state
    state.touchStartX = 0;
    state.touchEndX = 0;
}

/**
 * Handle clicks on modal backdrop to close
 * @param {MouseEvent} e - Mouse event
 */
function handleModalClick(e) {
    // Close if clicking directly on backdrop (not on content)
    if (e.target === elements.modal || e.target.classList.contains('modal-backdrop')) {
        closeModal();
    }
}

// ============================================================================
// Accessibility
// ============================================================================

/**
 * Announce message to screen readers
 * @param {string} message - Message to announce
 */
function announceToScreenReader(message) {
    elements.srAnnouncements.textContent = message;

    // Clear after announcement
    setTimeout(() => {
        elements.srAnnouncements.textContent = '';
    }, 1000);
}

/**
 * Trap focus within modal when open
 * @param {KeyboardEvent} e - Keyboard event
 */
function trapFocus(e) {
    if (!state.modalOpen) return;

    if (e.key === 'Tab') {
        const focusableElements = elements.modal.querySelectorAll(
            'button:not([disabled]), [href], input, select, textarea, [tabindex]:not([tabindex="-1"])'
        );

        const firstElement = focusableElements[0];
        const lastElement = focusableElements[focusableElements.length - 1];

        // Shift + Tab: Going backwards
        if (e.shiftKey && document.activeElement === firstElement) {
            e.preventDefault();
            lastElement.focus();
        }
        // Tab: Going forwards
        else if (!e.shiftKey && document.activeElement === lastElement) {
            e.preventDefault();
            firstElement.focus();
        }
    }
}

// ============================================================================
// Initialization
// ============================================================================

/**
 * Initialize the gallery
 */
async function init() {
    try {
        // Get DOM elements (must be done after DOM is loaded)
        elements = {
            loading: document.getElementById('loading'),
            gallery: document.getElementById('gallery'),
            emptyState: document.getElementById('empty-state'),
            modal: document.getElementById('modal'),
            modalImage: document.getElementById('modal-image'),
            modalClose: document.getElementById('modal-close'),
            modalPrev: document.getElementById('modal-prev'),
            modalNext: document.getElementById('modal-next'),
            modalSpinner: document.getElementById('modal-spinner'),
            modalCounter: document.getElementById('modal-counter'),
            currentIndex: document.getElementById('current-index'),
            totalCount: document.getElementById('total-count'),
            srAnnouncements: document.getElementById('sr-announcements'),
        };

        // Simulate loading delay for demo purposes
        const loadingTime = Math.random() * (CONFIG.maxLoadingTime - CONFIG.minLoadingTime) + CONFIG.minLoadingTime;
        await new Promise(resolve => setTimeout(resolve, loadingTime));

        // Generate photo data
        state.photos = generatePhotoData();

        // Render gallery
        renderGallery();

        // Hide loading state
        elements.loading.hidden = true;

        // Attach event listeners
        attachEventListeners();

        console.log('✅ Photo gallery initialized successfully');
    } catch (error) {
        console.error('❌ Failed to initialize gallery:', error);
        if (elements.loading) {
            elements.loading.innerHTML = '<p>Failed to load gallery. Please refresh the page.</p>';
        }
    }
}

/**
 * Attach all event listeners
 */
function attachEventListeners() {
    // Modal controls
    elements.modalClose.addEventListener('click', closeModal);
    elements.modalPrev.addEventListener('click', previousPhoto);
    elements.modalNext.addEventListener('click', nextPhoto);
    elements.modal.addEventListener('click', handleModalClick);

    // Keyboard navigation
    document.addEventListener('keydown', handleKeydown);
    document.addEventListener('keydown', trapFocus);

    // Touch gestures
    elements.modal.addEventListener('touchstart', handleTouchStart, { passive: true });
    elements.modal.addEventListener('touchmove', handleTouchMove, { passive: true });
    elements.modal.addEventListener('touchend', handleTouchEnd);
}

// ============================================================================
// Start Application
// ============================================================================

// Initialize when DOM is ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
} else {
    init();
}
