# Lab 11 : Atelier de Prompt Engineering

**Durée** : 30 minutes
**Module** : 1 - Introduction à l'IA pour les développeurs

## Objectif

Comparer trois approches de prompting différentes sur la même tâche algorithmique pour comprendre comment la qualité du prompt influence la sortie de l'IA.

## La tâche

Vous allez demander à une IA de générer le code d'une **fonction de transformation de données** qui :

- Prend une liste d'objets ayant les propriétés `name` et `score`
- Filtre les objets dont le score est >= 70
- Trie les objets restants par score (décroissant)
- Renvoie uniquement les noms sous forme de liste

**Exemple** :

```javascript
Input: [
  { name: 'Alice', score: 85 },
  { name: 'Bob', score: 65 },
  { name: 'Charlie', score: 92 },
  { name: 'Diana', score: 70 },
];

Output: ['Charlie', 'Alice', 'Diana'];
```

## Choisissez votre langage

La tâche est volontairement agnostique du langage. **Choisissez celui que vous pratiquez au quotidien** : vous jugerez bien mieux la sortie de l'IA sur un terrain familier, et ce jugement est justement l'objet de ce lab.

Tout au long des exercices, remplacez `JavaScript` par votre langage dans les exemples de prompts. La solution de référence en couvre trois :

| Langage       | Solution de référence                                               |
| ------------- | ------------------------------------------------------------------- |
| JavaScript/TS | `labs/lab-11-prompt-engineering-solution/README.md`                 |
| **Python**    | `labs/lab-11-prompt-engineering-solution/resources/prompts/python/` |
| **Java**      | `labs/lab-11-prompt-engineering-solution/resources/prompts/java/`   |

La forme de l'entrée s'adapte au langage : dictionnaires en Python, records en Java, littéraux objet en JavaScript. Les trois prompts et les trois observations restent identiques.

## Checklist des prérequis

Avant de commencer, assurez-vous d'avoir :

- [ ] **Accès à un outil d'IA** : Compte et session active sur au moins un outil de codage IA :
  - [ChatGPT (chat.openai.com)](https://chat.openai.com) - L'offre gratuite suffit
  - [Claude (claude.ai)](https://claude.ai) - L'offre gratuite suffit
  - [Gemini (gemini.google.com)](https://gemini.google.com) - L'offre gratuite suffit
  - [GitHub Copilot Chat (github.com/copilot)](https://github.com/copilot) - Abonnement requis
  - Cursor IDE - L'offre gratuite suffit
- [ ] **Connexion Internet** : Connexion stable pour les appels d'API d'IA
- [ ] **Éditeur de code** : N'importe quel éditeur pour tester le code généré (VS Code, WebStorm, IntelliJ IDEA, PyCharm)
- [ ] **De quoi exécuter le code généré**, selon le langage choisi :
  - **JavaScript/TypeScript** : console de développement du navigateur, ou Node.js 22+
  - **Python** : Python 3.12+ (`pytest` optionnel, pour les cas de test de l'exercice 3)
  - **Java** : JDK 17+ (`jshell` suffit pour les exercices 1-2 ; JUnit 5 pour l'exercice 3)

**Repli hors ligne** : Si Internet est indisponible, utilisez les exemples pré-générés dans `labs/lab-11-prompt-engineering-solution/` pour faire l'exercice de réflexion.

---

## Les 5 techniques de prompting

Ce lab utilise 5 techniques progressives pour un prompting efficace :

| #   | Technique            | Description                                                |
| --- | -------------------- | ---------------------------------------------------------- |
| 1   | **Rôle**             | Assigner une persona (ex. : "Tu es un développeur senior") |
| 2   | **Contexte**         | Fournir le contexte et les exigences                       |
| 3   | **Format**           | Spécifier la structure de sortie attendue                  |
| 4   | **Few-Shot**         | Montrer des exemples d'entrée/sortie                       |
| 5   | **Chain-of-Thought** | Demander un raisonnement étape par étape                   |

Chaque exercice s'appuie sur le précédent en ajoutant des techniques.

> **Référence visuelle** : Voir le schéma des techniques dans les slides du module (depuis la racine du repo : `docs/assets/images/10_module_1/prompting-techniques.svg`)

---

## Exercice 1 : Prompting basique (~8 minutes)

### Approche

Utilisez un prompt simple et direct, avec une structure minimale.

### Votre prompt

Rédigez un prompt en utilisant **uniquement les techniques 1-2** (Rôle + Contexte) :

```
[Your prompt here - keep it simple and direct]
```

**Structure d'exemple** (remplacez `JavaScript` par votre propre langage — ici et dans tous les exercices suivants) :

```
You are a JavaScript developer.
Write a function that filters and sorts a list of objects by score.
```

### Étapes

1. Envoyez votre prompt basique à votre outil d'IA
2. Copiez le code généré
3. Testez-le avec l'entrée d'exemple (collez-la dans la console de votre navigateur, un REPL Node.js ou le terminal d'un éditeur de code)
4. Documentez le résultat ci-dessous

### Résultats

**Code généré** :

```
[Paste the AI's code here]
```

**Observations** :

- Est-ce que cela a fonctionné correctement ?
- Qu'est-ce qui manquait ou restait flou dans la sortie ?
- Combien de relances ont été nécessaires ?

---

> 💡 Pensez à **effacer votre session courante** avant de commencer le nouvel exercice !
>
> Tapez "/clear" puis <kbd>ENTER</kbd> depuis votre session IA courante, ou démarrez simplement un nouveau terminal depuis ce dossier de lab

## Exercice 2 : Prompting structuré (~8 minutes)

### Approche

Ajoutez une spécification du format de sortie à votre prompt.

### Votre prompt

Rédigez un prompt en utilisant **les techniques 1-3** (Rôle + Contexte + Format) :

```
[Your prompt here - add role, context, and format specification]
```

**Structure d'exemple** :

```
You are a senior JavaScript developer.

I need a function that processes student scores:
- Input: Array of objects with 'name' (string) and 'score' (number)
- Filter: Keep only scores >= 70
- Sort: By score, highest first
- Output: Array of names only

Please provide:
- The function code
- Brief inline comments
- Example usage
```

### Étapes

1. Envoyez votre prompt structuré à votre outil d'IA
2. Copiez le code généré
3. Testez-le avec l'entrée d'exemple
4. Comparez avec l'exercice 1

### Résultats

**Code généré** :

```
[Paste the AI's code here]
```

**Observations** :

- En quoi la sortie diffère-t-elle de l'exercice 1 ?
- Le code était-il mieux documenté ?
- Spécifier le format a-t-il aidé ?

---

> 💡 Pensez à **effacer votre session courante** avant de commencer le nouvel exercice !
>
> Tapez "/clear" puis <kbd>ENTER</kbd> depuis votre session IA courante, ou démarrez simplement un nouveau terminal depuis ce dossier de lab

## Exercice 3 : Prompting avancé (~9 minutes)

> 💡 Pensez à **effacer votre session courante** avant de commencer le nouvel exercice !
>
> Tapez "/clear" puis <kbd>ENTER</kbd> depuis votre session IA courante, ou démarrez simplement un nouveau terminal depuis ce dossier de lab

### Approche

Utilisez les 5 techniques, y compris les exemples et le chain-of-thought.

### Votre prompt

Rédigez un prompt en utilisant **les 5 techniques** :

```
[Your prompt here - include role, context, format, example, and reasoning request]
```

**Structure d'exemple** :

```
You are a senior JavaScript developer specializing in data transformations.

## Task
Create a function to process student assessment data.

## Requirements
- Filter students with passing scores (>= 70)
- Sort by score in descending order
- Return only student names

## Example
Input:
[{ name: "Alice", score: 85 }, { name: "Bob", score: 65 }]

Expected Output:
["Alice"]

## Instructions
1. First, think through the steps needed
2. Then implement the function
3. Include error handling for edge cases
4. Add static types if your language supports them
5. Provide test cases

## Output Format
- Function code with comments
- Brief explanation of approach
- 2-3 test cases
```

### Étapes

1. Envoyez votre prompt avancé à votre outil d'IA
2. Copiez le code généré
3. Testez-le avec l'entrée d'exemple
4. Comparez avec les exercices 1 et 2

### Résultats

**Code généré** :

```
[Paste the AI's code here]
```

**Observations** :

- En quoi la sortie diffère-t-elle des exercices précédents ?
- Le chain-of-thought a-t-il amélioré la solution ?
- La gestion des erreurs était-elle incluse ?

---

## Réflexion (~5 minutes)

### Comparez vos résultats

| Aspect            | Exercice 1 | Exercice 2 | Exercice 3 |
| ----------------- | ---------- | ---------- | ---------- |
| Exactitude code   |            |            |            |
| Documentation     |            |            |            |
| Gestion erreurs   |            |            |            |
| Couv. de tests    |            |            |            |
| Relances requises |            |            |            |

### Enseignements clés

1. **Quelle technique a fait la plus grande différence ?**

   [Votre réponse]

2. **Quand utiliseriez-vous chaque approche ?**
   - Prompting basique : [Votre réponse]
   - Prompting structuré : [Votre réponse]
   - Prompting avancé : [Votre réponse]

3. **Que ferez-vous différemment dans votre travail quotidien ?**

   [Votre réponse]

---

## Dépannage

| Problème                  | Solution                                                                                                                |
| ------------------------- | ----------------------------------------------------------------------------------------------------------------------- |
| **Limite de débit API**   | Attendez 1-2 minutes, ou passez à un autre outil d'IA                                                                   |
| **Erreur d'authentif.**   | Reconnectez-vous à votre outil d'IA, videz les cookies si besoin                                                        |
| **Modèle indisponible**   | Essayez un autre modèle ou palier (ex. : Opus → Sonnet, GPT-5.3 → GPT-4.1)                                              |
| **Réponse lente**         | Simplifiez votre prompt, réduisez la longueur de sortie attendue                                                        |
| **Le code ne tourne pas** | Vérifiez la syntaxe, précisez explicitement le langage **et sa version** dans le prompt                                 |
| **Type manquant**         | Fréquent en Java : l'IA utilise une classe qu'elle n'a jamais définie. Demandez-lui d'inclure tous les types référencés |
| **Sortie inattendue**     | Relisez votre prompt pour lever les ambiguïtés, ajoutez des contraintes                                                 |

**Toujours bloqué ?** Demandez à votre formateur ou utilisez le fichier de solution comme référence.

---

## Prochaines étapes

- Consultez la solution dans `labs/lab-11-prompt-engineering-solution/README.md` (les variantes Python et Java sont dans `resources/prompts/python/` et `resources/prompts/java/`)
- Essayez ces techniques sur vos propres tâches de code
- Le module 2 explorera différents paradigmes de codage avec l'IA (vibe coding vs agentic coding)
