---
name: security-pattern-detection
description: Identify security anti-patterns, vulnerabilities, and insecure coding practices. Use when analyzing code for OWASP Top 10 vulnerabilities, CWE patterns, SQL injection, XSS, hardcoded secrets, or security misconfigurations.
allowed-tools: Read, Grep, Glob
---

# Security Pattern Detection

Identify common security anti-patterns, vulnerabilities, and insecure coding practices in source code. This skill analyzes code for OWASP Top 10 vulnerabilities, CWE patterns, and team-specific security rules.

## Capabilities

This skill provides comprehensive security analysis by:
- Detecting SQL injection vulnerabilities
- Identifying XSS (Cross-Site Scripting) risks
- Finding hardcoded secrets and credentials
- Checking authentication/authorization flaws
- Detecting insecure cryptography usage
- Identifying CSRF vulnerabilities
- Finding path traversal risks
- Detecting insecure deserialization
- Checking for security misconfiguration

## Inputs
- **Source code files**: TypeScript, JavaScript, Angular, NestJS
- **Configuration files**: Security headers, CORS policies, environment configs
- **Dependencies**: package.json for vulnerable package detection
- **Security standards**: Team security guidelines from `.claude/references/coding-standards.md`

## Outputs
1. **Vulnerability Report**: List of security issues with severity levels
2. **CWE Classification**: Standard vulnerability categorization
3. **Exploit Scenarios**: How vulnerabilities could be exploited
4. **Remediation Steps**: Specific fixes for each issue
5. **Prevention Guidance**: Best practices to avoid similar issues
6. **Compliance Status**: OWASP Top 10 coverage assessment

## Usage Example

### SQL Injection Detection
```
Apply security-pattern-detection skill to analyze apps/backend-nestjs/src/ for security vulnerabilities.
```

**Output:**
```
Security Pattern Analysis: apps/backend-nestjs/src/
============================================

🔴 CRITICAL: SQL Injection (CWE-89)
File: apps/backend-nestjs/src/photos/photos.repository.ts
Line 45: const query = `SELECT * FROM photos WHERE id = ${req.params.id}`

Pattern: String interpolation in SQL query
Exploit: Attacker injects: ?id=1 OR 1=1--
Risk: Full table data exposure

Remediation — use TypeORM parameterized query:
  const result = await this.photoRepository
    .createQueryBuilder('photo')
    .where('photo.id = :id', { id: photoId })
    .getOne();
```

### XSS Vulnerability Detection
```
Apply security-pattern-detection skill to scan apps/frontend/src/app/ for XSS risks.
```

**Output:**
```
XSS Vulnerability Analysis
==========================

🟠 HIGH: DOM-based XSS (CWE-79)
File: apps/frontend/src/app/photos/photo-detail.component.html
Line 12: <div [innerHTML]="photo.description"></div>

Pattern: Unescaped user content bound to innerHTML
Exploit: Malicious description executes JavaScript
Risk: Session hijacking, credential theft

Remediation:
Option 1 (safe): Use text binding
  <div>{{ photo.description }}</div>

Option 2 (if HTML needed): Use DomSanitizer
  // In component:
  sanitizedDesc = this.sanitizer.bypassSecurityTrustHtml(
    DOMPurify.sanitize(photo.description)
  );
  // In template:
  <div [innerHTML]="sanitizedDesc"></div>
```

### Secret Detection
```
Apply security-pattern-detection skill to check for hardcoded secrets.
```

**Output:**
```
Hardcoded Secret Detection
==========================

🔴 CRITICAL: Exposed API Key (CWE-798)
File: apps/backend-nestjs/src/config/storage.config.ts
Line 12: const AWS_SECRET = "AKIAIOSFODNN7EXAMPLE"

Pattern: Hardcoded AWS credential
Risk: Credential exposed in version control
Impact: Unauthorized S3 access, potential data breach

Remediation:
1. Revoke the exposed credential immediately
2. Use environment variable: process.env.AWS_SECRET_ACCESS_KEY
3. Add to .env.example (without value): AWS_SECRET_ACCESS_KEY=
4. Ensure .env is in .gitignore
```

## Detection Patterns

### SQL Injection
```
Pattern: String concatenation or template literals in SQL queries
Indicators:
- `SELECT * WHERE ${variable}`
- .query(userInput)
- TypeORM: .createQueryBuilder().where(`id = ${id}`)
```

### XSS
```
Pattern: Unescaped user content in HTML
Indicators (Angular):
- [innerHTML]="userContent"
- bypassSecurityTrustHtml without DOMPurify
- document.write(userInput)
```

### Secrets
```
Pattern: Hardcoded credentials
Indicators:
- API_KEY = "sk_..."
- password = "..."
- JWT_SECRET = "secret"
- connectionString with @ (inline credentials)
```

### Insecure Crypto
```
Pattern: Weak cryptographic practices
Indicators:
- md5(), sha1() for passwords
- Math.random() for tokens/IDs
- Hardcoded encryption keys
- jwt.sign without expiresIn
```

## Configuration

```json
{
  "skills": {
    "security-pattern-detection": {
      "severity-threshold": "medium",
      "patterns": {
        "sql-injection": true,
        "xss": true,
        "secrets": true,
        "insecure-crypto": true,
        "auth-issues": true
      },
      "custom-rules": [
        {
          "id": "team-rule-001",
          "pattern": "eval\\(",
          "severity": "critical",
          "message": "eval() is forbidden by team policy"
        }
      ],
      "exclude-patterns": ["**/*.spec.ts", "**/mocks/**"]
    }
  }
}
```

## Performance Considerations
- Scans ~1000 lines per second
- Regex-based detection (may have false positives — review before acting)
- Can run incrementally on changed files only
- Caches results for unchanged files
