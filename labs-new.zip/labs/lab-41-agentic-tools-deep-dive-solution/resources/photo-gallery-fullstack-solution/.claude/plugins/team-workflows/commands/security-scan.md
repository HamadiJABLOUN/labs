---
description: Scan the codebase for security vulnerabilities including OWASP Top 10 patterns, hardcoded secrets, authentication flaws, and insecure configurations.
argument-hint: "[path] [--severity critical|high|medium|low] [--format summary|detailed]"
allowed-tools: Read, Grep, Glob, Bash(npm audit:*)
---

# Security Scan

Perform a comprehensive security vulnerability scan of the photo-gallery project.

## Instructions

1. **Determine scan scope**:
   - If a path argument is provided: scan that specific path
   - Otherwise: scan the full project (`apps/frontend/src/` and `apps/backend-nestjs/src/`)

2. **Apply the `security-pattern-detection` skill** to analyze the code

3. **Run dependency vulnerability check**:
   ```bash
   npm audit --json
   ```
   Parse output for CVEs affecting direct dependencies.

4. **Scan for each vulnerability category**:

### A. Hardcoded Secrets
Search for patterns indicating hardcoded credentials:
- API keys (patterns: `sk_`, `pk_`, `api_key`, `apiKey`)
- Passwords in code (`password =`, `pwd =`, `secret =`)
- JWT secrets as string literals
- Database connection strings with credentials
- AWS/GCP/Azure credentials

### B. Injection Vulnerabilities
- **SQL Injection**: Raw query concatenation with user input in TypeORM
- **Command Injection**: `exec()`, `spawn()` with user-controlled args
- **Template Injection**: User input in template literals that get evaluated

### C. XSS Risks (Frontend)
- `[innerHTML]` bindings with user-controlled data in Angular
- `DomSanitizer.bypassSecurityTrust*` usage
- Dynamic script/style injection

### D. Authentication/Authorization
- JWT without expiration (`jwt.sign` without `expiresIn`)
- Weak JWT secrets (short strings, dictionary words)
- Missing `@UseGuards()` on protected NestJS controllers
- Missing Angular route guards on protected routes

### E. Security Misconfiguration
- CORS configured with `origin: '*'` in production
- Missing security headers (check NestJS helmet usage)
- Debug mode enabled in production config
- Sensitive data in error responses

### F. Dependency Vulnerabilities
- Packages with known CVEs from `npm audit`
- Outdated packages with security patches available

5. **Generate vulnerability report** with:
   - Severity level (Critical/High/Medium/Low)
   - File path and line number
   - CWE classification
   - Description of the risk
   - Specific remediation steps

6. **OWASP Top 10 coverage summary** showing which categories were checked

7. **Prioritized fix list**: Sort by severity, provide fix-first recommendations
