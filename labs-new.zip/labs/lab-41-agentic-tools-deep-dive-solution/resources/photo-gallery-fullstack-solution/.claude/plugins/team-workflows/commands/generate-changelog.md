---
description: Generate a structured changelog from git history, categorizing commits into features, fixes, breaking changes, and other relevant categories following Conventional Commits format.
argument-hint: "[--from <tag-or-sha>] [--to <tag-or-sha>] [--format conventional|keepachangelog]"
allowed-tools: Bash(git log:*), Bash(git tag:*), Bash(git show:*), Read
---

# Generate Changelog

Analyze the git history and generate a structured changelog for the photo-gallery project.

## Instructions

1. **Determine commit range**:
   - If `--from` and `--to` arguments provided: use those refs
   - If only `--from` provided: use from that ref to HEAD
   - If no arguments: use commits since the last git tag, or all commits if no tags exist
   - Run `git log --oneline` to preview the commit range

2. **Fetch and parse commits**:
   ```bash
   git log --pretty=format:"%H|%s|%b|%an|%ad" --date=short [range]
   ```

3. **Categorize each commit** using Conventional Commits prefixes:
   - `feat:` → Features
   - `fix:` → Bug Fixes
   - `docs:` → Documentation
   - `refactor:` → Refactoring
   - `test:` → Tests
   - `chore:` → Maintenance
   - `perf:` → Performance
   - `BREAKING CHANGE:` in body or `!` suffix → Breaking Changes
   - Uncategorized → Other Changes

4. **Extract breaking changes**:
   - Look for `BREAKING CHANGE:` in commit body
   - Look for `!` suffix (e.g., `feat!: rename API`)
   - List with migration instructions if provided

5. **Generate the changelog** in the requested format:

### Conventional Format (default)
```markdown
## [Unreleased] — 2024-01-15

### Breaking Changes
- **API**: Renamed `GET /photos` to `GET /api/photos` — update all client calls

### Features
- Add photo tagging support (#42)
- Implement bulk photo upload endpoint (#38)

### Bug Fixes
- Fix CORS headers not set on error responses (#45)
- Resolve memory leak in PhotoGallery component (#41)

### Performance
- Add database index on photos.gallery_id — 6x query speedup (#39)

### Refactoring
- Extract photo validation into dedicated service (#37)

### Maintenance
- Update Angular to 18.2.0 (#43)
- Update NestJS to 10.4.0 (#44)
```

### Keep a Changelog Format
```markdown
## [1.2.0] - 2024-01-15

### Added
- Photo tagging support
- Bulk upload endpoint

### Changed
- API base path now includes /api prefix

### Fixed
- CORS headers on error responses
- Memory leak in gallery component

### Removed
- Deprecated v1 photo endpoint
```

6. **Version bump recommendation**:
   - Breaking changes → MAJOR bump
   - New features → MINOR bump
   - Only fixes/maintenance → PATCH bump
   - Show: `Current: v1.1.0 → Recommended: v1.2.0 (MINOR — new features added)`

7. **Output the changelog** to the terminal and offer to write it to `CHANGELOG.md`
