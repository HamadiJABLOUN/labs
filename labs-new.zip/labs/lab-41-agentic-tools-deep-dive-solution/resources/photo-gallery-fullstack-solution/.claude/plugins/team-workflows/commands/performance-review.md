---
description: Review application performance including bundle size analysis, runtime performance, database query efficiency, and Core Web Vitals. Provides prioritized optimization recommendations.
argument-hint: "[path] [--focus bundle|runtime|database|all]"
allowed-tools: Read, Grep, Glob, Bash(npm run build:*), Bash(npx vite-bundle-analyzer:*)
---

# Performance Review

Perform a comprehensive performance analysis of the photo-gallery application.

## Instructions

1. **Determine review scope**:
   - If `--focus bundle`: only analyze bundle size
   - If `--focus runtime`: only analyze runtime code patterns
   - If `--focus database`: only analyze backend query patterns
   - Otherwise (default `all`): run complete analysis

2. **Apply `performance-profiling` skill** throughout the analysis

### Bundle Size Analysis

3. **Analyze frontend bundle**:
   - Check `apps/frontend/` for large dependencies in `package.json`
   - Identify packages without tree-shaking support (CJS format)
   - Look for common large-package anti-patterns:
     - `import _ from 'lodash'` instead of `import { fn } from 'lodash-es'`
     - `import moment from 'moment'` instead of `date-fns`
     - Full icon library imports instead of individual icons
   - Check for lazy loading opportunities (routes, heavy components)
   - Review `angular.json` / `vite.config.ts` for bundle optimization settings

### Runtime Performance Analysis

4. **Analyze Angular components**:
   - Look for expensive operations in component templates
   - Check change detection strategy (prefer `OnPush` for leaf components)
   - Identify missing `trackBy` in `*ngFor` directives
   - Detect subscriptions without `async` pipe or manual unsubscribe
   - Find `setTimeout`/`setInterval` without cleanup

5. **Algorithm complexity review**:
   - Scan `apps/frontend/src/` for nested loops over large arrays
   - Identify O(n²) patterns in sort/filter/transform operations
   - Review pagination implementation (client-side vs server-side)

### Database Performance Analysis

6. **Review TypeORM queries** in `apps/backend-nestjs/src/`:
   - Find raw queries with string interpolation (also a security risk)
   - Identify N+1 patterns: queries inside loops
   - Check for missing `select` columns (avoid `SELECT *`)
   - Look for missing relations loading (`relations: []` vs eager loading)
   - Review pagination: ensure `take` and `skip` are used

7. **Check for missing indexes**:
   - Identify columns used in `WHERE` clauses without `@Index()` decorator
   - Review foreign key columns for index coverage
   - Check order-by columns (`created_at`, `updated_at`)

### Performance Report

8. **Generate prioritized report**:

```
Performance Review Summary
===========================

Bundle (Target: <2MB)
  Current: 2.4MB ⚠️
  Issues:
    🔴 lodash full import: 280KB → use lodash-es: 15KB (save 265KB)
    🟠 moment.js: 230KB → use date-fns: 58KB (save 172KB)
  Potential savings: 437KB → new size: 1.96MB ✓

Runtime
  🔴 O(n²) sort in PhotoList.filterPhotos() — 287x slower than optimal
  🟡 Missing trackBy in gallery *ngFor loop
  🟡 3 components using default change detection (could use OnPush)

Database
  🔴 N+1 query in PhotoService.findWithTags() — 1+N queries per request
  🟠 Missing index on photos.gallery_id (full scan on 50k rows)
  🟡 SELECT * in 4 repository methods

Quick wins (< 1 hour each):
  1. Add @Index() to photos.gallery_id
  2. Fix O(n²) sort → use Array.sort()
  3. Replace moment.js with date-fns

Estimated LCP improvement after fixes: 4.2s → 1.8s (-57%)
```
