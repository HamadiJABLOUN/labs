---
name: dependency-graph-analysis
description: Analyze and visualize project dependency relationships, identify circular dependencies, and assess impact of dependency changes. Use when planning updates, investigating dependency issues, or understanding module structure.
allowed-tools: Read, Glob, Bash(npm ls:*), Bash(npx depcheck:*)
---

# Dependency Graph Analysis

Analyze and visualize project dependency relationships, identify circular dependencies, calculate dependency depth, and assess the impact of dependency changes on the overall project structure.

## Capabilities

This skill provides deep analysis of dependency graphs for both npm packages and internal module dependencies. It can:
- Map complete dependency trees (direct and transitive)
- Identify circular dependencies and cycles
- Calculate dependency metrics (depth, breadth, complexity)
- Trace impact paths for dependency updates
- Detect duplicate dependencies across the tree
- Visualize dependency relationships

## Inputs
- **package.json**: Project dependencies configuration
- **package-lock.json / yarn.lock / pnpm-lock.yaml**: Lock file for exact versions
- **node_modules/**: Installed dependency tree (if available)
- **tsconfig.json**: Module resolution configuration
- **import statements**: Source code imports to analyze module usage

## Outputs
1. **Dependency Tree**: Hierarchical structure of all dependencies
2. **Circular Dependency Report**: List of cycles with file paths
3. **Dependency Metrics**: Depth, breadth, complexity scores
4. **Impact Analysis**: Which modules are affected by changes
5. **Visualization**: ASCII or graph representation of dependencies
6. **Optimization Recommendations**: Suggestions for reducing complexity

## Usage Example

### Basic Dependency Analysis
```
Apply dependency-graph-analysis skill to analyze the current project structure.
```

**Output:**
```
Dependency Graph Analysis
========================

Direct Dependencies: 45
Total Dependencies (including transitive): 287
Maximum Depth: 8 levels
Average Depth: 3.2 levels

Top-Level Dependencies:
├─ @angular/core@18.2.0
│  ├─ rxjs@7.8.1
│  └─ zone.js@0.14.0
│
├─ @nestjs/common@10.4.0
│  ├─ rxjs@7.8.1 (shared)
│  └─ reflect-metadata@0.2.0
│
└─ typeorm@0.3.20
   └─ ...

Circular Dependencies: NONE ✓

Duplicate Dependencies: 1 found
└─ rxjs@7.8.1 (shared between Angular and NestJS — correct)

Optimization Opportunities:
1. Consider using pnpm for better deduplication
2. 3 @types/* packages in dependencies (should be devDependencies)
```

### Impact Analysis for Dependency Update
```
Apply dependency-graph-analysis skill to assess impact of updating @angular/core from 17.x to 18.x.
```

**Output:**
```
Impact Analysis: @angular/core 17.x → 18.x
===========================================

Direct Dependents: 1 workspace
└─ apps/frontend

Affected Source Files: 23
├─ apps/frontend/src/app/app.config.ts
│  └─ import { provideRouter } from '@angular/router'
├─ apps/frontend/src/app/app.component.ts
│  └─ import { Component } from '@angular/core'
└─ ... (21 more)

Breaking Changes Detected:
- NgModule deprecated → migrate to standalone
- HttpClientModule → provideHttpClient()
- CommonModule imports → import directives directly

Impact Level: HIGH
- Update type: MAJOR (breaking API changes)
- Migration schematic available: ng update @angular/core@18
- Estimated effort: 4-6 hours

Recommended Action:
1. Run: ng update @angular/core@18 @angular/cli@18
2. Follow migration guide for standalone components
3. Update all imports of deprecated APIs
4. Run full test suite after migration
```

## Integration Points

### Commands
- `/team-workflows:analyze-dependencies`: Uses this skill for dependency tree analysis

### Agents
- `dependency-tracker`: Leverages this skill for compatibility and impact analysis
- `architecture-guardian`: Uses this skill to enforce architectural boundaries

### Hooks
- `post-edit`: Can trigger circular dependency check after module changes

## Algorithm

1. **Parse Dependency Sources**
   - Read package.json for declared dependencies
   - Parse lock files for exact versions
   - Scan source code for import/require statements

2. **Build Dependency Graph**
   - Create nodes for each package/module
   - Create edges for dependency relationships
   - Track version constraints and ranges

3. **Analyze Graph Structure**
   - Calculate depth (longest path from root)
   - Calculate breadth (number of direct dependencies)
   - Detect cycles using DFS with visited set
   - Identify duplicate packages at different locations

4. **Generate Insights**
   - Compare versions across duplicates
   - Calculate metrics (complexity, maintainability)
   - Suggest optimizations (deduping, replacements)
   - Identify security-sensitive packages

## Configuration

```json
{
  "skills": {
    "dependency-graph-analysis": {
      "max-depth-warning": 10,
      "detect-duplicates": true,
      "include-dev-dependencies": false,
      "visualize-format": "ascii",
      "exclude-patterns": ["@types/*", "eslint-*"]
    }
  }
}
```

## Performance Considerations
- Large projects (1000+ dependencies) may take 10-30 seconds
- Uses caching to avoid re-analyzing unchanged dependency trees
- Can run incrementally for focused analysis of specific subgraphs
