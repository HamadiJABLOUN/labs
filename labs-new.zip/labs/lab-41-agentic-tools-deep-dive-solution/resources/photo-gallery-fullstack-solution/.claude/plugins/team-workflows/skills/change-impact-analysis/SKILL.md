---
name: change-impact-analysis
description: Assess the scope and risk of proposed code changes by analyzing affected components, blast radius, and potential side effects. Use when reviewing pull requests, planning large refactorings, assessing deployment readiness, or evaluating rollback complexity.
---

# Change Impact Analysis Skill

## Purpose

Assess the scope and risk of proposed code changes by analyzing affected components, blast radius, and potential side effects. This skill helps teams make informed decisions about change safety.

## Capabilities

### 1. Blast Radius Assessment
- Quantify how many files, modules, and services are affected
- Categorize changes by risk level (low/medium/high/critical)
- Identify cascading effects of a change

### 2. Risk Scoring
- Calculate risk based on change size, complexity, and affected components
- Flag high-risk changes requiring extra review or testing
- Recommend mitigation strategies proportional to risk

### 3. Side Effect Detection
- Identify unintended consequences of changes
- Flag performance implications
- Detect security or compliance impacts

## Usage Context

This skill activates when:
- Reviewing pull requests for approval
- Planning large refactorings or migrations
- Assessing deployment readiness
- Evaluating rollback complexity

## Knowledge Sources

- **testing-guidelines.md**: Test coverage requirements by risk level
- **architecture.md**: Critical paths and high-risk components
- **Git history**: Past incidents correlated with similar changes

## Risk Assessment Framework

### Risk Factors

| Factor | Weight | Criteria |
|--------|--------|----------|
| **Lines Changed** | 20% | <50 (low) / 50-200 (med) / 200-500 (high) / >500 (critical) |
| **Files Affected** | 15% | <5 (low) / 5-10 (med) / 10-20 (high) / >20 (critical) |
| **Test Coverage** | 25% | >80% (low) / 60-80% (med) / 40-60% (high) / <40% (critical) |
| **Critical Path** | 30% | Not on critical path (low) / Near critical (med) / On critical path (high) |
| **Rollback Ease** | 10% | Easy revert (low) / Config change (med) / DB migration (high) / Data loss risk (critical) |

### Risk Categories

**LOW RISK** (Score: 0-30)
- Small, isolated changes
- High test coverage
- Easy to rollback
- Examples: UI text changes, logging improvements, documentation

**MEDIUM RISK** (Score: 31-60)
- Moderate scope changes
- Adequate test coverage
- Standard rollback procedures
- Examples: New features, refactorings, configuration updates

**HIGH RISK** (Score: 61-85)
- Large scope or critical path changes
- Test coverage gaps
- Complex rollback
- Examples: API changes, database migrations, authentication updates

**CRITICAL RISK** (Score: 86-100)
- Changes to payment, security, or data integrity systems
- Insufficient testing
- Irreversible changes
- Examples: Payment logic, user data deletion, schema breaking changes

## Example Scenarios

### Scenario 1: Feature Addition (Low Risk)

**Change**: Add "favorite photos" feature

**Analysis**:
```
Scope:
  - Files: 8 (PhotoService, PhotoController, UI component, tests)
  - Lines: 230 (150 implementation + 80 tests)
  - Modules: 2 (API, UI)

Risk Factors:
  ✅ New feature (no existing behavior modified)
  ✅ 65% test coverage (unit + integration)
  ✅ Not on critical path
  ✅ Easy rollback via feature flag
  ⚠️  Database migration (adds `favorites` table)

Overall Risk: LOW (Score: 28)

Recommendations:
  - ✅ Standard review process
  - ✅ Deploy with feature flag for gradual rollout
  - ✅ Monitor error rates for 24h post-deployment
```

---

### Scenario 2: Refactoring (Medium Risk)

**Change**: Extract photo processing logic into separate service

**Analysis**:
```
Scope:
  - Files: 15 (7 modified, 3 new, 5 test files)
  - Lines: 420 (280 refactored + 140 tests)
  - Modules: 3 (Services, Infrastructure, Tests)

Risk Factors:
  ⚠️  Modifies existing behavior (potential regression)
  ✅ 78% test coverage
  ⚠️  Affects upload flow (medium traffic)
  ✅ Rollback possible via Git revert

Overall Risk: MEDIUM (Score: 52)

Recommendations:
  - ⚠️  Require 2+ reviewers
  - ⚠️  Extended staging validation (3 days)
  - ⚠️  Canary deployment (10% → 50% → 100% over 1 week)
  - ✅ Monitor upload latency and error rates closely
```

---

### Scenario 3: Security Update (High Risk)

**Change**: Update JWT authentication library (v3 → v4)

**Analysis**:
```
Scope:
  - Files: 24 (authentication module, middleware, tests)
  - Lines: 680 (450 updated + 230 tests)
  - Modules: 5 (Auth, API, Admin, Mobile API, Tests)

Risk Factors:
  ❌ Critical path (all API requests)
  ❌ Security-sensitive code
  ⚠️  Breaking changes in library API
  ⚠️  56% test coverage (needs improvement)
  ❌ Rollback requires database state management

Overall Risk: HIGH (Score: 78)

Recommendations:
  - ❌ BLOCK MERGE until test coverage >80%
  - ❌ Require security team review
  - ❌ Stage in non-production for 1 week minimum
  - ❌ Detailed rollback plan with database state handling
  - ❌ Deploy during low-traffic window with on-call ready
  - ⚠️  Consider phased rollout with legacy auth fallback
```

---

### Scenario 4: Data Migration (Critical Risk)

**Change**: Migrate user passwords to bcrypt (from MD5)

**Analysis**:
```
Scope:
  - Files: 12 (auth service, migration scripts, validators)
  - Lines: 350 (200 code + 150 tests)
  - Modules: 2 (Auth, Database)

Risk Factors:
  ❌ CRITICAL: Affects all users
  ❌ IRREVERSIBLE: Cannot decrypt existing passwords
  ❌ Security-sensitive (authentication)
  ⚠️  62% test coverage (needs 90%+ for this risk)
  ❌ Complex rollback (requires maintaining dual auth temporarily)

Overall Risk: CRITICAL (Score: 92)

Recommendations:
  - ❌ BLOCK: Increase test coverage to 90%+
  - ❌ Require CTO and security team approval
  - ❌ Stage in isolated test environment first
  - ❌ Implement dual-authentication support (MD5 fallback for 3 months)
  - ❌ Gradual migration (migrate 1% users/day, monitor for issues)
  - ❌ 24/7 on-call required during migration period
  - ❌ Extensive monitoring: auth failures, login latency, user support tickets
```

---

## Activation Examples

```typescript
// When reviewing this PR:
// - 15 files changed
// - 420 lines added, 280 removed
// - Modifies authentication middleware

// Skill activates and reports:
// "⚠️ HIGH RISK (Score: 74)
//  - Auth middleware affects all API requests
//  - Test coverage 58% (recommend >80% for auth changes)
//  - Recommend: Security review, extended staging, canary deployment"
```

## Metrics

Success criteria for impact analysis:
- ✅ Accurately classifies 90%+ of changes by risk
- ✅ Zero high-risk changes deployed without appropriate safeguards
- ✅ Reduces production incidents by 30% through better risk assessment
