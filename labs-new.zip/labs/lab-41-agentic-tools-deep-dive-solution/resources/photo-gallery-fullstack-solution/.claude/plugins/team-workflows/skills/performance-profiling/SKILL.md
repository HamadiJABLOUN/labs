---
name: performance-profiling
description: Measure and analyze application performance metrics including runtime execution, memory usage, bundle size, and rendering performance. Use when optimizing code, investigating slowdowns, or measuring Core Web Vitals.
allowed-tools: Read, Grep, Glob, Bash(npm run build:*), Bash(npx vite-bundle-analyzer:*)
---

# Performance Profiling

Measure and analyze application performance metrics including runtime execution, memory usage, bundle size, and rendering performance. Identify bottlenecks and provide quantified performance insights for optimization.

## Capabilities

This skill provides comprehensive performance analysis by:
- Profiling runtime execution times
- Measuring memory usage and detecting leaks
- Analyzing bundle sizes and code splitting
- Tracking rendering performance (Angular, React)
- Monitoring API response times
- Calculating algorithm complexity
- Measuring Core Web Vitals (LCP, FID, CLS, FCP, TTFB)
- Detecting performance regressions

## Inputs
- **Source code**: JavaScript/TypeScript files for static analysis
- **Bundle output**: Built files from Vite, Webpack, esbuild
- **Runtime metrics**: Performance API data, profiling traces
- **Package.json**: Dependencies for bundle size analysis
- **Baseline data**: Previous performance measurements for comparison

## Outputs
1. **Performance Metrics**: Quantified measurements (ms, MB, %)
2. **Bottleneck Report**: Top performance issues with impact analysis
3. **Algorithm Complexity**: Big-O notation for critical functions
4. **Bundle Analysis**: Size breakdown by dependency and chunk
5. **Optimization Recommendations**: Prioritized list of improvements
6. **Regression Alerts**: Performance degradations vs baseline

## Usage Example

### Runtime Performance Analysis
```
Apply performance-profiling skill to analyze apps/frontend/src/app/gallery/ rendering performance.
```

**Output:**
```
Performance Profile: Gallery Components
========================================

Rendering Performance:
├─ Initial Mount: 145ms (⚠️ Target: <100ms)
│  ├─ Component initialization: 15ms
│  ├─ Data fetching: 80ms
│  └─ DOM rendering: 50ms
│
├─ Re-render (scroll): 8ms ✓
│  └─ Within acceptable range (<16ms for 60fps)
│
└─ Memory Usage: 45 MB ✓

Algorithm Complexity Analysis:
├─ sortByDate(): O(n²) ⚠️ CRITICAL
│  Current: 2.3s for 1,000 items
│  Expected with O(n log n): ~8ms
│  Performance impact: 287x slower than optimal
│
└─ filterByTag(): O(n) ✓

Rendering Optimizations:
1. Missing OnPush change detection — use ChangeDetectionStrategy.OnPush
2. *ngFor without trackBy — add trackBy: trackByPhotoId
3. 1000+ items rendered without virtual scrolling
   → Use @angular/cdk VirtualScrollViewport

Core Web Vitals:
├─ LCP (Largest Contentful Paint): 2.1s (🟡 Needs improvement)
├─ FID (First Input Delay): 45ms (✓ Good)
└─ CLS (Cumulative Layout Shift): 0.05 (✓ Good)
```

### Bundle Size Analysis
```
Apply performance-profiling skill to analyze the production bundle size.
```

**Output:**
```
Bundle Size Analysis
====================

Total Bundle Size: 2.4 MB (⚠️ Target: <2 MB)
Gzip Compressed: 680 KB

Main Chunk: 1.2 MB (50%)
├─ @angular/core + platform-browser: 420 KB (35%)
├─ lodash: 280 KB (23%) ⚠️
│  └─ Replace with lodash-es for tree-shaking (-94%)
├─ moment: 230 KB (19%) ⚠️
│  └─ Replace with date-fns (-75%)
└─ Application code: 270 KB (22%)

Lazy Chunks: 1.2 MB (50%)
├─ PhotoEditor.chunk.js: 450 KB (38%)
└─ AdminPanel.chunk.js: 380 KB (32%)

Total Potential Savings: 937 KB → New size: 1.46 MB ✓
```

## Integration Points

### Commands
- `/team-workflows:performance-review`: Primary command using this skill

### Agents
- `performance-optimizer`: Leverages this skill for detailed analysis
- `release-safety`: Uses this skill to prevent performance regressions

### Hooks
- `post-edit`: Can trigger performance check after code changes

## Configuration

```json
{
  "skills": {
    "performance-profiling": {
      "thresholds": {
        "response-time": 200,
        "bundle-size": 2000000,
        "memory-usage": 512000000,
        "fps": 60
      },
      "metrics": ["runtime", "memory", "bundle", "core-web-vitals"],
      "baseline-ref": "main",
      "regression-threshold": 20,
      "auto-optimize-suggestions": true
    }
  }
}
```
