# Team Workflows Plugin

A Claude Code plugin providing team workflow automation for the photo-gallery project.

## Features

- **Dependency Analysis** (`/team-workflows:analyze-dependencies`): Analyzes project dependencies, detects circular dependencies, and assesses update impact
- **Changelog Generation** (`/team-workflows:generate-changelog`): Generates structured changelogs from git history
- **Security Scanning** (`/team-workflows:security-scan`): Scans code for OWASP Top 10 vulnerabilities and security anti-patterns
- **Performance Review** (`/team-workflows:performance-review`): Analyzes bundle size, runtime performance, and Core Web Vitals

## Installation

This plugin is automatically discovered by Claude Code when placed in `.claude/plugins/team-workflows/`.

No additional installation steps required.

## Usage

### Analyze Dependencies

```
/team-workflows:analyze-dependencies
```

Analyzes all project dependencies, identifies circular imports, detects duplicate packages, and provides optimization recommendations.

### Generate Changelog

```
/team-workflows:generate-changelog
/team-workflows:generate-changelog --from v1.0.0 --to v1.1.0
```

Generates a structured changelog from git history, categorizing commits into features, fixes, and breaking changes.

### Security Scan

```
/team-workflows:security-scan
/team-workflows:security-scan src/api/
```

Scans the codebase for common security vulnerabilities including SQL injection, XSS, hardcoded secrets, and authentication flaws.

### Performance Review

```
/team-workflows:performance-review
/team-workflows:performance-review src/components/PhotoList.tsx
```

Reviews bundle size, runtime performance, algorithm complexity, and provides optimization recommendations.

## Agents

- `@dependency-tracker`: Monitors dependency health, detects outdated packages, assesses update risk
- `@performance-optimizer`: Identifies and resolves performance bottlenecks
- `@security-auditor`: Comprehensive security vulnerability assessment

## Skills

- `dependency-graph-analysis`: Analyze dependency relationships and detect circular dependencies
- `performance-profiling`: Measure and analyze application performance metrics
- `security-pattern-detection`: Identify security anti-patterns and vulnerabilities

## MCP Servers

- `changelog-server`: MCP server for changelog generation and version management
- `metrics-analyzer`: MCP server for collecting and analyzing performance metrics

## Hooks

Configured hooks in `hooks/hooks.json`:
- **Pre-tool-use (Bash)**: Logs shell commands before execution
- **Post-tool-use (Write/Edit)**: Triggers change impact analysis after file modifications

## Configuration

Plugin behavior can be customized via `.claude/settings.json`:

```json
{
  "plugins": {
    "team-workflows": {
      "security-threshold": "medium",
      "performance-baseline": "main",
      "changelog-format": "conventional"
    }
  }
}
```
