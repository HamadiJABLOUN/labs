---
paths:
  - 'apps/backend-gin/**'
---

## Backend Rules

- Handlers are methods on a `Handler` struct constructed via `NewHandler(service, storage)` — inject the domain service/storage as struct fields, never instantiate inline
- Keep GORM entities (snake_case columns) separate from API DTOs (camelCase `json:` tags) — map between them explicitly
- Business logic lives in `internal/domain/service.go`; handlers in `internal/api/photos/handler.go` only parse the request and call the service
- IDs are serialized as `string` (not numeric) in `PhotoResponse` to match the OpenAPI contract
- Return errors via the shared `ErrorResponse{StatusCode, Message, Error}` envelope — don't let Gin's default error format leak through
