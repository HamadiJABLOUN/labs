---
paths:
  - "apps/backend-nestjs/**"
---

## Backend Rules

- Use NestJS dependency injection — never instantiate services manually
- DTOs must use class-validator decorators for input validation
- Controllers must only delegate to services — no business logic in controllers
- All repository methods must be defined in the interface first (`photo.repository.interface.ts`)
- Use TypeORM decorators: `@Entity()`, `@Column()`, `@PrimaryGeneratedColumn()`
