---
paths:
  - 'apps/backend-spring/**'
---

## Backend Rules

- Use Spring constructor injection with `final` fields — never field-level `@Autowired`
- Controllers (`@RestController`) must only delegate to `@Service`-annotated domain services — no business logic in controllers
- Request DTOs must use Bean Validation (`@NotBlank`, `@NotNull`) combined with `@Valid` on controller parameters
- Keep the domain model (`domain/model/Photo.java`) separate from the JPA entity (`infrastructure/entity/PhotoEntity.java`)
- Use Spring Data JPA repository interfaces (`domain/repository/PhotoRepository.java`) — no manual SQL
- Translate exceptions via `@RestControllerAdvice` into the shared `{statusCode, message, error}` error envelope
