---
paths:
  - "apps/frontend/**"
---

## Frontend Rules

- Use Angular standalone components — no NgModule unless required
- Services must be provided with `providedIn: 'root'`
- Component templates go in separate `.html` files (not inline)
- Use `HttpClient` via dependency injection, never `fetch()` directly
- Models in `src/app/models/` must match backend DTOs
