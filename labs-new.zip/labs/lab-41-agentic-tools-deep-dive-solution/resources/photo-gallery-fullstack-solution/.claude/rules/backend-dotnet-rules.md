---
paths:
  - 'apps/backend-dotnet/**'
---

## Backend Rules

- Controllers (`[ApiController]`) use constructor injection with `readonly` interface fields (e.g. `IPhotoService`) — never `new` a service directly
- Domain owns `Photo` as an immutable `record`; keep EF Core concerns (entities, `AppDbContext`) confined to `Infrastructure/`
- Request/response shapes belong in `Api/Photos/Dto/` and rely on `System.Text.Json`'s default camelCase policy — no manual renaming
- Use a `ValueConverter<T,TStore>` for JSON-encoded columns rather than ad-hoc (de)serialization in the service
- Implement `IExceptionHandler` for the shared `{statusCode, message, error}` error envelope, including model-binding failures
