---
paths:
  - 'apps/backend-fastapi/**'
---

## Backend Rules

- Use FastAPI's dependency injection (`Depends()`) to wire services and sessions into route handlers — no global singletons
- Domain response models are Pydantic `BaseModel` with `alias_generator=to_camel` and `populate_by_name=True` — keep snake_case in Python, camelCase in JSON
- Keep SQLModel entities (`infrastructure/entities.py`) out of the `api/` layer
- Business logic lives only in `domain/services.py` — `api/photos.py` routers only orchestrate
- Register centralized error handlers in `api/errors.py` producing the shared `{statusCode, message, error}` envelope — don't raise raw `HTTPException` with ad-hoc bodies
