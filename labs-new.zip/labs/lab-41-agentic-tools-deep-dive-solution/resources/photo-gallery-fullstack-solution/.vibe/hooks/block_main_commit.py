import sys
import json
import subprocess
import os


def main():
    try:
        payload = json.load(sys.stdin)

        if payload.get("hook_event_name") != "pre_tool":
            sys.exit(0)

        if payload.get("tool_name") != "bash":
            sys.exit(0)

        command = payload.get("tool_input", {}).get("command", "")

        if "git commit" not in command:
            sys.exit(0)

        try:
            result = subprocess.run(
                ["git", "rev-parse", "--abbrev-ref", "HEAD"],
                capture_output=True,
                text=True,
                cwd=payload.get("cwd", os.getcwd()),
            )
            current_branch = result.stdout.strip()
        except Exception:
            sys.exit(0)

        if current_branch == "main":
            response = {
                "decision": "deny",
                "reason": "Erreur: Les commits directs sur la branche main sont interdits. Utilisez une branche de feature et creez une Pull Request.",
            }
            print(json.dumps(response))
            sys.exit(0)
        else:
            sys.exit(0)

    except Exception:
        sys.exit(0)


if __name__ == "__main__":
    main()
