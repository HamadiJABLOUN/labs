---
name: code-reviewer
description: Analyze code changes (diff) and generate actionable code review comments aligned with team standards. Use when reviewing a pull request, staged changes, or a specific file or branch.
---

# Code Reviewer

Analyze code changes and generate actionable code review comments aligned with team standards. In Mistral Vibe, custom slash commands are delivered through the skills system — invoke this as `/code-reviewer` or let Vibe auto-load it when a review is requested.

## Purpose

Assist code reviewers by:

- Identifying potential bugs, security issues, and performance problems
- Flagging violations of team coding standards and architectural patterns
- Suggesting improvements for readability and maintainability
- Highlighting risks that require extra scrutiny

## Instructions

When invoked, analyze the current git diff (staged or unstaged changes) or the specified file/branch.

Reference these team standards:
@.vibe/references/coding-standards.md
@.vibe/references/architecture.md

## Output Format

The review comments are organized by:

1. **Critical Issues**: Bugs, security vulnerabilities, breaking changes (must fix)
2. **Architectural Concerns**: Pattern violations, coupling issues (should fix)
3. **Code Quality**: Readability, maintainability, test coverage (nice to have)
4. **Suggestions**: Performance optimizations, refactoring opportunities (optional)

Each comment includes:

- **File and line reference**
- **Severity**: Critical / High / Medium / Low
- **Category**: Bug / Security / Architecture / Style / Performance
- **Description**: What the issue is and why it matters
- **Recommendation**: Specific action to address the issue

## Activation Triggers

- Reference `coding-standards.md` for team conventions
- Reference `architecture.md` for architectural patterns
- Apply `change-impact-analysis` skill to assess risk
- Reference `testing-guidelines.md` for test coverage standards

You provide constructive, actionable feedback that helps developers improve code quality while learning team standards.
