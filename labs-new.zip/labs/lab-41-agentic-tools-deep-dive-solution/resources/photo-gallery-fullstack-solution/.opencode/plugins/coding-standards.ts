// `app` is injected by the OpenCode runtime environment
interface OpenCodeEvent {
  tool?: string;
  input?: { content?: string; command?: string; file_path?: string; path?: string };
  path?: string;
}
declare const app: { on: (event: string, handler: (event: OpenCodeEvent) => unknown) => void };

// Hook fires BEFORE any file edit — can block/modify
app.on("tool.execute.before", async (event) => {
  if (event.tool !== "edit" && event.tool !== "write") return;
  const content = event.input?.content ?? "";
  if (content.includes(": any") || content.includes("as any")) {
    return {
      abort: true,
      message: "⚠️ Coding standards: 'any' type detected. Use proper types.",
    };
  }
});

// Hook fires AFTER file edit — logs the change
app.on("file.edited", async (event) => {
  console.log(`[coding-standards] File edited: ${event.path}`);
});

// Hook fires BEFORE any shell command — validates git commits follow coding standards
app.on("tool.execute.before", async (event) => {
  if (event.tool !== "bash") return;
  const command = event.input?.command ?? "";
  if (!command.includes("git commit")) return;
  return {
    abort: true,
    message:
      "⚠️ Commit blocked: verify that staged files follow coding standards (no 'any' types, proper DTOs, no business logic in controllers) before committing.",
  };
});

// Hook fires BEFORE any file write/edit — validates changes against coding standards
app.on("tool.execute.before", async (event) => {
  if (event.tool !== "edit" && event.tool !== "write") return;
  const filePath = event.input?.file_path ?? event.input?.path ?? "";
  console.log(
    `[coding-standards] Validating file against coding standards: ${filePath}`
  );
});
