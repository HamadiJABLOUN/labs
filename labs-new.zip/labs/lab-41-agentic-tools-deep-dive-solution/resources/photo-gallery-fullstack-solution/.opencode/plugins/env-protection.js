// .opencode/plugins/env-protection.js
// OpenCode plugin — demonstrates the tool.execute.before and tool.execute.after events
//
// Docs: https://opencode.ai/docs/plugins/

export const EnvProtectionPlugin = async ({ project, client, $, directory, worktree }) => {
  return {
    // Fires before every tool call — throw to block the action
    "tool.execute.before": async (input, output) => {
      // Block the agent from reading .env files
      if (input.tool === "read" && output.args.filePath?.includes(".env")) {
        throw new Error("Reading .env files is not allowed — use environment variables instead")
      }
    },

    // Fires after every tool call — use for logging/auditing
    "tool.execute.after": async (input, output) => {
      if (input.tool === "bash") {
        await client.app.log({
          body: {
            service: "env-protection",
            level: "info",
            message: `bash executed: ${output.args?.command}`,
          },
        })
      }
    },
  }
}
