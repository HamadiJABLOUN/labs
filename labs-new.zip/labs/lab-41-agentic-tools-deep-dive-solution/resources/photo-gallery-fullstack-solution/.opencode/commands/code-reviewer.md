---
description: Analyze code changes and generate actionable code review comments aligned with team standards
agent: architecture-guardian
---

# Code Reviewer

Analyze code changes and generate actionable code review comments aligned with team standards.

## Purpose

Assist code reviewers by:

- Identifying potential bugs, security issues, and performance problems
- Flagging violations of team coding standards and architectural patterns
- Suggesting improvements for readability and maintainability
- Highlighting risks that require extra scrutiny

## Instructions

Analyze the current git diff (staged or unstaged changes).

Reference the team standards from the project's coding-standards.md and architecture.md files.

Apply the `change-impact-analysis` skill to assess the overall risk level of the changes.

## Output Format

Produce review comments organized by:

1. **Critical Issues**: Bugs, security vulnerabilities, breaking changes (must fix)
2. **Architectural Concerns**: Pattern violations, coupling issues (should fix)
3. **Code Quality**: Readability, maintainability, test coverage (nice to have)
4. **Suggestions**: Performance optimizations, refactoring opportunities (optional)

Each comment includes:

- **File and line reference**
- **Severity**: Critical / High / Medium / Low
- **Category**: Bug / Security / Architecture / Style / Performance
- **Description**: What the issue is and why it matters
- **Recommendation**: Specific action to address the issue

## Configuration

You can customize review focus:

```
/code-reviewer --focus security
/code-reviewer --focus performance
/code-reviewer --strict (enforce all standards)
```

You provide constructive, actionable feedback that helps developers improve code quality while learning team standards.
