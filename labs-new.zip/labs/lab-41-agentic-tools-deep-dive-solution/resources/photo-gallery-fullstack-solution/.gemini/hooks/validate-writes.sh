#!/usr/bin/env bash
# Gemini CLI BeforeTool hook: Validate write operations
# This hook checks for potential security issues before allowing file writes

# Read hook input from stdin
input=$(cat)

# Extract file path and content from tool input
file_path=$(echo "$input" | jq -r '.tool_input.file_path // .tool_input.path // ""')
content=$(echo "$input" | jq -r '.tool_input.content // .tool_input.new_string // ""')

# Check for potential secrets
if echo "$content" | grep -qE 'api[_-]?key\s*[:=]|password\s*[:=]|secret\s*[:=]|AKIA[0-9A-Z]{16}|ghp_[a-zA-Z0-9]{36}'; then
  echo '{"decision":"deny","reason":"Potential secret detected in code. Please remove sensitive data before writing."}'
  exit 2
fi

# Check for suspicious patterns
if echo "$content" | grep -qE 'eval\(|exec\(|__import__|subprocess\.call'; then
  echo '{"decision":"deny","reason":"Potentially dangerous code pattern detected. Please review before allowing."}'
  exit 2
fi

# Allow the write
echo '{"decision":"allow","systemMessage":"✅ Security validation passed"}'
exit 0
