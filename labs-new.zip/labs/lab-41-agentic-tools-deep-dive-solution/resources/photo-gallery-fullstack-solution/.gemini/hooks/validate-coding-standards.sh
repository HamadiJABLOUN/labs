#!/usr/bin/env bash
# Gemini CLI AfterTool hook: Validate file changes against coding-standards.md
# Reviews file changes and checks they follow the project's coding standards

# Read hook input from stdin
input=$(cat)

# Extract file path from tool input
file_path=$(echo "$input" | jq -r '.tool_input.file_path // ""')
content=$(echo "$input" | jq -r '.tool_input.content // .tool_input.new_string // ""')

# Skip if no file path
if [ -z "$file_path" ]; then
  exit 0
fi

# Only check TypeScript/JavaScript files
if [[ ! "$file_path" =~ \.(ts|tsx|js|jsx)$ ]]; then
  echo '{"systemMessage":"⏭️ Skipped: Not a TS/JS file"}'
  exit 0
fi

echo "🔍 Validating against coding-standards.md..."

violations=""

# Check for console.log statements
if echo "$content" | grep -q "console\.log"; then
  violations="$violations\n- Remove console.log statements before committing"
fi

# Check for any type usage
if echo "$content" | grep -q ": any"; then
  violations="$violations\n- Avoid using 'any' type - use proper TypeScript types"
fi

# Check for TODO without ticket reference
if echo "$content" | grep -qE "TODO[^:(]" ; then
  violations="$violations\n- TODO comments should reference a ticket (e.g., TODO(TICKET-123))"
fi

# Check for proper error handling in async functions
if echo "$content" | grep -qE "async.*\{" && ! echo "$content" | grep -qE "try\s*\{|\.catch\("; then
  violations="$violations\n- Async functions should have proper error handling (try/catch or .catch())"
fi

# Check for magic numbers
if echo "$content" | grep -qE "[^0-9a-zA-Z_][0-9]{2,}[^0-9a-zA-Z_]" | grep -vE "port|timeout|size|width|height|max|min"; then
  violations="$violations\n- Consider extracting magic numbers into named constants"
fi

if [ -n "$violations" ]; then
  echo -e "⚠️ Coding standards suggestions:$violations"
  echo '{"systemMessage":"⚠️ Review coding standards suggestions above"}'
else
  echo '{"systemMessage":"✅ File follows coding standards"}'
fi

exit 0
