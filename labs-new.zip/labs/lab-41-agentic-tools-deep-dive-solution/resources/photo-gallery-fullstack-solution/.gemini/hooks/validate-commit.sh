#!/usr/bin/env bash
# Gemini CLI BeforeTool hook: Validate git commit commands
# Checks if this is a git commit and validates staged files follow coding standards

# Read hook input from stdin
input=$(cat)

# Extract command from tool input
command=$(echo "$input" | jq -r '.tool_input.command // ""')

# Only process git commit commands
if [[ ! "$command" =~ git[[:space:]]+commit ]]; then
  exit 0
fi

echo "🔍 Running code-reviewer on all modified files (staged and unstaged)..."

# Get list of all modified files (union of staged and unstaged)
files_to_check=$(git diff HEAD --name-only 2>/dev/null)

if [ -z "$files_to_check" ]; then
  echo '{"systemMessage":"✅ No modified files to check"}'
  exit 0
fi

# Check for coding standards violations
violations=""

for file in $files_to_check; do
  # Skip non-existent files (deleted)
  [ ! -f "$file" ] && continue

  # Check TypeScript/JavaScript files
  if [[ "$file" =~ \.(ts|tsx|js|jsx)$ ]]; then
    # Check for console.log statements
    if grep -n "console\.log" "$file" 2>/dev/null; then
      violations="$violations\n- $file: contains console.log statements"
    fi

    # Check for TODO comments without ticket reference
    if grep -n "TODO[^:]" "$file" 2>/dev/null | grep -v "TODO(.*)" | grep -v "TODO:.*#"; then
      violations="$violations\n- $file: TODO comments should reference a ticket"
    fi

    # Check for any/unknown types
    if grep -n ": any" "$file" 2>/dev/null; then
      violations="$violations\n- $file: avoid using 'any' type"
    fi
  fi
done

if [ -n "$violations" ]; then
  # Escape newlines for JSON using perl for better portability
  json_violations=$(echo "$violations" | perl -pe 's/\n/\\n/g')
  echo "{\"decision\":\"deny\",\"reason\":\"Coding standards violations detected:\\n$json_violations\\n\\nReview staged files before committing.\"}"
  exit 2
fi

echo '{"systemMessage":"✅ Staged files pass coding standards check"}'
exit 0
