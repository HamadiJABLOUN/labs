"""HTTP adapter layer — FastAPI routers and exception handlers."""
