"""Infrastructure layer — database, storage, external adapters."""
