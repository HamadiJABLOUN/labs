"""Photo Gallery FastAPI backend."""
