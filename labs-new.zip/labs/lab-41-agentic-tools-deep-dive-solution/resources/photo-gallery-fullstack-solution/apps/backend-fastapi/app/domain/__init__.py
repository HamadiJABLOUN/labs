"""Domain layer — models and services (framework-free)."""
