import { UploadPhoto } from './upload-photo';

describe('UploadPhoto', () => {
  it('should be defined', () => {
    expect(new UploadPhoto()).toBeDefined();
  });
});
