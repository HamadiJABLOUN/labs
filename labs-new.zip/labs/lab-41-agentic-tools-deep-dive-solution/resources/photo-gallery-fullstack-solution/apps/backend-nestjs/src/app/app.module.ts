import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { TypeOrmModule } from '@nestjs/typeorm';
import { join } from 'path';
import { PhotosModule } from '../api/photos/photos.module';
import { PhotoEntity } from '../domain/entities/photo.entity';

/**
 * Root Application Module
 *
 * The main entry point for the NestJS application.
 * Imports all feature modules including the PhotosModule
 * which provides photo management capabilities.
 *
 * TypeORM is configured to use SQLite for persistent storage.
 */
@Module({
  imports: [
    ConfigModule.forRoot({
      isGlobal: true,
      envFilePath: '.env',
    }),
    TypeOrmModule.forRoot({
      type: 'sqlite',
      database: join(process.cwd(), 'dist', 'db', 'photogallery.db'),
      entities: [PhotoEntity],
      synchronize: true, // Auto-create tables (dev only)
    }),
    PhotosModule,
  ],
  controllers: [],
  providers: [],
})
export class AppModule {}
