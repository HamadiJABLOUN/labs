# GitHub Copilot preToolUse hook: Validate git commit commands
# Checks if this is a git commit and validates staged files follow coding standards

$input = $input | ConvertFrom-Json
$command = $input.command

# Only process git commit commands
if ($command -notmatch "^git\s+commit") {
    exit 0
}

Write-Host "🔍 Running code-reviewer on staged files..."

# Get list of staged files
$stagedFiles = git diff --cached --name-only 2>$null

if (-not $stagedFiles) {
    Write-Host "⚠️ No staged files found for commit" -ForegroundColor Yellow
    exit 0
}

$violations = @()

foreach ($file in $stagedFiles) {
    if (-not (Test-Path $file)) { continue }

    # Check TypeScript/JavaScript files
    if ($file -match "\.(ts|tsx|js|jsx)$") {
        $content = Get-Content $file -Raw -ErrorAction SilentlyContinue

        # Check for console.log statements
        if ($content -match "console\.log") {
            $violations += "- $file: contains console.log statements"
        }

        # Check for any type usage
        if ($content -match ": any") {
            $violations += "- $file: avoid using 'any' type"
        }
    }
}

if ($violations.Count -gt 0) {
    Write-Host "⚠️ Coding standards violations found:" -ForegroundColor Yellow
    $violations | ForEach-Object { Write-Host $_ -ForegroundColor Yellow }
    exit 2
}

Write-Host "✅ Staged files pass coding standards check" -ForegroundColor Green
exit 0
