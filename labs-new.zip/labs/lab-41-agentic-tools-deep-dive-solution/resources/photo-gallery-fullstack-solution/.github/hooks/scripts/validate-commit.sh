#!/usr/bin/env bash
# GitHub Copilot preToolUse hook: Validate git commit commands
# Checks if this is a git commit and validates staged files follow coding standards

# Read hook input from stdin
input=$(cat)

# Extract command from tool input
command=$(echo "$input" | jq -r '.command // ""')

# Only process git commit commands
if [[ ! "$command" =~ ^git[[:space:]]+commit ]]; then
  exit 0
fi

echo "🔍 Running code-reviewer on staged files..."

# Get list of staged files
staged_files=$(git diff --cached --name-only 2>/dev/null)

if [ -z "$staged_files" ]; then
  echo "⚠️ No staged files found for commit" >&2
  exit 0
fi

# Check for coding standards violations
violations=""

for file in $staged_files; do
  # Skip non-existent files (deleted)
  [ ! -f "$file" ] && continue

  # Check TypeScript/JavaScript files
  if [[ "$file" =~ \.(ts|tsx|js|jsx)$ ]]; then
    # Check for console.log statements
    if grep -n "console\.log" "$file" 2>/dev/null; then
      violations="$violations\n- $file: contains console.log statements"
    fi

    # Check for TODO comments without ticket reference
    if grep -n "TODO[^:]" "$file" 2>/dev/null | grep -v "TODO(.*)" | grep -v "TODO:.*#"; then
      violations="$violations\n- $file: TODO comments should reference a ticket"
    fi

    # Check for any/unknown types
    if grep -n ": any" "$file" 2>/dev/null; then
      violations="$violations\n- $file: avoid using 'any' type"
    fi
  fi
done

if [ -n "$violations" ]; then
  echo -e "⚠️ Coding standards violations found:$violations" >&2
  exit 2
fi

echo "✅ Staged files pass coding standards check"
exit 0
