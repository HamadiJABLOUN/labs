---
description: Analyze project dependencies to identify outdated packages, security vulnerabilities, unused dependencies, and compatibility issues
tools: ['search/codebase']
---

# Analyze Dependencies Command

**Invocation**: `/team-workflows:analyze-dependencies [options]`

## Purpose

Analyze project dependencies to identify:
- Outdated packages and available updates
- Security vulnerabilities in dependencies
- Unused dependencies that can be removed
- Dependency conflicts and compatibility issues
- License compliance concerns

## Options

- `--scope <value>`: Analyze "prod", "dev", or "all" dependencies (default: "all")
- `--format <value>`: Output format "table", "json", or "markdown" (default: "table")
- `--security-only`: Only show security vulnerabilities
- `--outdated-only`: Only show outdated packages

## Behavior

1. Parse package.json and lock files
2. Check each dependency against npm registry for latest versions
3. Consult security databases (npm audit, Snyk, etc.) for vulnerabilities
4. Analyze dependency tree for conflicts
5. Generate actionable report with update recommendations

## Output Format

```
Dependency Analysis Report
==========================

Outdated Packages (5):
├─ react: 17.0.2 → 18.2.0 (Major update available)
├─ typescript: 5.0.0 → 5.3.3 (Patch update available)
└─ ...

Security Vulnerabilities (2):
├─ [HIGH] lodash@4.17.20: Prototype Pollution
│  Fix: Update to lodash@4.17.21
└─ [MEDIUM] axios@0.21.1: Server-Side Request Forgery
   Fix: Update to axios@1.6.0

Unused Dependencies (3):
├─ moment (not imported anywhere)
├─ ...

Recommended Actions:
1. Run: npm update typescript
2. Run: npm install lodash@4.17.21
3. Run: npm uninstall moment
```
