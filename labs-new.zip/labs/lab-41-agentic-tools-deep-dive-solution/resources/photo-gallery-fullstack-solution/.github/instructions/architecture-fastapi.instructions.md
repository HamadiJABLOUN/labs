---
applyTo: 'apps/backend-fastapi/app/domain/**'
---

# Architecture Instructions

Follow guidelines from references/architecture.md when working with domain layer code.

## Key Points for Domain Layer

- **Technology Stack**: FastAPI backend (Python 3.12), SQLModel with SQLite
- **Path**: `apps/backend-fastapi/app/domain/`
- **Domain Model**: `Photo` is a Pydantic `BaseModel` with `alias_generator=to_camel` and `populate_by_name=True` — keep snake_case in Python, camelCase in JSON
- **Services**: Plain classes with constructor-injected `Session`
- **Dependencies**: Domain layer should not depend on infrastructure — the SQLModel `PhotoEntity` lives in `infrastructure/entities.py` and is mapped to `Photo` in the service

## Domain Layer Structure

```
apps/backend-fastapi/app/domain/
├── __init__.py
├── models.py    # Pydantic domain/response model
└── services.py  # Business logic
```

## Photo Domain Model Example

```python
class Photo(BaseModel):
    """Photo response payload."""
    model_config = ConfigDict(
        alias_generator=_to_camel,
        populate_by_name=True,
        from_attributes=True,
    )
    id: str
    filename: str
    stored_filename: str
    url: str
    size: int
    tags: list[str] = Field(default_factory=list)
    created_at: datetime
```

## Validation Constraints

- Max file size: **5MB**
- Supported formats: JPEG, PNG, GIF, WebP
- Tags: lowercase alphanumeric with hyphens, max 20 tags, max 30 chars each

See [references/architecture.md](../references/architecture.md) for complete architecture documentation.
