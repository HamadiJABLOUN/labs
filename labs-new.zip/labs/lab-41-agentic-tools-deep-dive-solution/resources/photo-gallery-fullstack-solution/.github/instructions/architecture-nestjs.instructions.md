---
applyTo: 'apps/backend-nestjs/src/domain/**'
---

# Architecture Instructions

Follow guidelines from references/architecture.md when working with domain layer code.

## Key Points for Domain Layer

- **Technology Stack**: NestJS 11 backend, TypeORM with SQLite
- **Path**: `apps/backend-nestjs/src/domain/`
- **Entities**: Use TypeORM decorators (@Entity, @Column, @PrimaryGeneratedColumn)
- **Services**: Use @Injectable() decorator
- **Dependencies**: Domain layer should not depend on infrastructure

## Domain Layer Structure

```
apps/backend-nestjs/src/domain/
├── entities/
│   └── photo.entity.ts      # TypeORM entity
├── models/
│   └── photo.model.ts       # Domain interface
└── services/
    └── photo.service.ts     # Business logic
```

## Photo Entity Example

```typescript
@Entity('photos')
export class PhotoEntity {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  filename: string;

  @Column({ name: 'stored_filename', unique: true })
  storedFilename: string;

  @Column()
  url: string;

  @Column()
  size: number;

  @Column('simple-json')
  tags: string[];

  @CreateDateColumn({ name: 'created_at' })
  createdAt: Date;
}
```

## Validation Constraints

- Max file size: **5MB**
- Supported formats: JPEG, PNG, GIF, WebP
- Tags: lowercase alphanumeric with hyphens, max 20 tags, max 30 chars each

See [references/architecture.md](../references/architecture.md) for complete architecture documentation.
