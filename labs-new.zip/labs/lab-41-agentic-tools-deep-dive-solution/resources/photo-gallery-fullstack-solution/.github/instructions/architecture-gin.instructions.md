---
applyTo: 'apps/backend-gin/internal/domain/**'
---

# Architecture Instructions

Follow guidelines from references/architecture.md when working with domain layer code.

## Key Points for Domain Layer

- **Technology Stack**: Gin backend (Go 1.23), GORM with SQLite
- **Path**: `apps/backend-gin/internal/domain/`
- **Domain Model**: `Photo` is a plain struct — no `json:`/`gorm:` tags
- **Services**: Plain structs constructed via `NewPhotoService(repo PhotoRepository)`, depending on a `PhotoRepository` interface
- **Dependencies**: Domain layer should not depend on infrastructure — the GORM entity lives in `internal/infrastructure/`

## Domain Layer Structure

```
apps/backend-gin/internal/domain/
├── photo.go    # Plain struct, no tags
└── service.go  # Business logic
```

## Photo Domain Model Example

```go
type Photo struct {
	ID             string
	Filename       string
	StoredFilename string
	URL            string
	Size           int64
	Tags           []string
	CreatedAt      time.Time
}
```

## Validation Constraints

- Max file size: **5MB**
- Supported formats: JPEG, PNG, GIF, WebP
- Tags: lowercase alphanumeric with hyphens, max 20 tags, max 30 chars each

See [references/architecture.md](../references/architecture.md) for complete architecture documentation.
