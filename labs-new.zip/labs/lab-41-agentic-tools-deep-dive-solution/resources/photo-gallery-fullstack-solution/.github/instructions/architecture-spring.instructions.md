---
applyTo: 'apps/backend-spring/src/main/java/com/photogallery/backend/domain/**'
---

# Architecture Instructions

Follow guidelines from references/architecture.md when working with domain layer code.

## Key Points for Domain Layer

- **Technology Stack**: Spring Boot 3 (Java 17), Spring Data JPA with SQLite
- **Path**: `apps/backend-spring/src/main/java/com/photogallery/backend/domain/`
- **Domain Model**: `Photo` is a plain Java `record` — no persistence annotations
- **Services**: Use `@Service`-annotated classes with constructor injection
- **Dependencies**: Domain layer should not depend on infrastructure — persistence (JPA entity, repository over `PhotoEntity`) is mapped in a `toDomain()` converter

## Domain Layer Structure

```
apps/backend-spring/src/main/java/com/photogallery/backend/domain/
├── model/
│   └── Photo.java            # Plain record, no annotations
├── repository/
│   └── PhotoRepository.java  # Spring Data JPA interface
└── service/
    └── PhotoService.java     # Business logic
```

## Photo Domain Model Example

```java
public record Photo(
        String id,
        String filename,
        String storedFilename,
        String url,
        long size,
        List<String> tags,
        Instant createdAt
) {
    public Photo {
        Objects.requireNonNull(filename, "filename");
        Objects.requireNonNull(storedFilename, "storedFilename");
        Objects.requireNonNull(url, "url");
        tags = tags == null ? List.of() : List.copyOf(tags);
    }
}
```

## Validation Constraints

- Max file size: **5MB**
- Supported formats: JPEG, PNG, GIF, WebP
- Tags: lowercase alphanumeric with hyphens, max 20 tags, max 30 chars each

See [references/architecture.md](../references/architecture.md) for complete architecture documentation.
