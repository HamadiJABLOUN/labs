---
description: Analyze code changes (diff) and generate actionable code review comments aligned with team standards
tools: ['search/codebase']
---
# /code-reviewer

Analyze code changes (diff) and generate actionable code review comments aligned with team standards.

## Purpose

Assist code reviewers by:
- Identifying potential bugs, security issues, and performance problems
- Flagging violations of team coding standards and architectural patterns
- Suggesting improvements for readability and maintainability
- Highlighting risks that require extra scrutiny

## Usage

Invoke this command when reviewing a pull request or code changes:

```
/code-reviewer
```

The command will analyze the current git diff (staged or unstaged changes) and generate review comments.

## Output Format

The command will produce review comments organized by:

1. **Critical Issues**: Bugs, security vulnerabilities, breaking changes (must fix)
2. **Architectural Concerns**: Pattern violations, coupling issues (should fix)
3. **Code Quality**: Readability, maintainability, test coverage (nice to have)
4. **Suggestions**: Performance optimizations, refactoring opportunities (optional)

Each comment includes:
- **File and line reference**
- **Severity**: Critical / High / Medium / Low
- **Category**: Bug / Security / Architecture / Style / Performance
- **Description**: What the issue is and why it matters
- **Recommendation**: Specific action to address the issue

## Example Output

```markdown
# Code Review: PR #342 - Add Bulk Photo Upload

## Critical Issues ❌ (Must Fix Before Merge)

### apps/backend-nestjs/src/domain/services/photo.service.ts:45
**Severity**: CRITICAL
**Category**: Security

**Issue**: User input not sanitized before filesystem access
```typescript
// Current (line 45):
const filePath = path.join(uploadDir, file.filename);

// Problem: file.filename could contain '../' allowing directory traversal
```

**Recommendation**:
```typescript
import { basename } from 'path';
const filePath = path.join(uploadDir, basename(file.filename));
```

**Reference**: `coding-standards.md` § Security → Input Validation

---

### apps/backend-nestjs/src/api/photos/photos.controller.ts:89
**Severity**: CRITICAL
**Category**: Bug

**Issue**: Missing error handling for async operation
```typescript
// Current (line 89):
const result = await photoService.uploadMultiple(files);
return res.json(result);
```

**Recommendation**:
```typescript
try {
  const result = await photoService.uploadMultiple(files);
  return res.json(result);
} catch (error) {
  logger.error('Bulk upload failed', { error, userId: req.user.id });
  return res.status(500).json({ error: 'Upload failed' });
}
```

**Reference**: `coding-standards.md` § Error Handling → Always Catch Async Errors

---

## Architectural Concerns ⚠️ (Should Fix)

### apps/frontend/src/app/components/bulk-upload/bulk-upload.component.ts:120
**Severity**: HIGH
**Category**: Architecture

**Issue**: UI component directly imports backend service (violates layering)
```typescript
import { PhotoService } from '@app/domain/services/photo.service';
```

**Recommendation**: Use dependency injection via frontend service
```typescript
// Inject via constructor:
constructor(private photoService: PhotoService) {}

// Or use Angular inject():
private readonly photoService = inject(PhotoService);
private readonly photoApi = inject(PhotoApiService);
```

**Reference**: `architecture.md` § Layering → UI should use services, not domain directly

---

### apps/backend-nestjs/src/domain/services/photo.service.ts:67
**Severity**: MEDIUM
**Category**: Architecture

**Issue**: Method too large (87 lines), multiple responsibilities
```typescript
async uploadMultiple(files: File[]): Promise<UploadResult[]> {
  // Validation logic (15 lines)
  // Image processing (25 lines)
  // Disk storage (20 lines)
  // Database insert (15 lines)
  // Response building (12 lines)
}
```

**Recommendation**: Extract into smaller, focused methods
```typescript
async uploadMultiple(files: File[]): Promise<UploadResult[]> {
  const validated = await this.validateFiles(files);
  const processed = await this.processImages(validated);
  const stored = await this.saveToStorage(processed);
  const records = await this.saveMetadata(stored);
  return records;
}
```

**Reference**: `coding-standards.md` § Functions → Single Responsibility, <50 lines

---

## Code Quality 📝 (Nice to Have)

### apps/backend-nestjs/src/domain/services/photo.service.ts:34
**Severity**: LOW
**Category**: Readability

**Issue**: Magic number without explanation
```typescript
if (file.size > 5242880) { // What is this number?
  throw new Error('File too large');
}
```

**Recommendation**: Use named constant
```typescript
const MAX_FILE_SIZE_BYTES = 5 * 1024 * 1024; // 5 MB

if (file.size > MAX_FILE_SIZE_BYTES) {
  throw new FileSizeError(`File exceeds maximum size of ${MAX_FILE_SIZE_BYTES} bytes`);
}
```

---

### apps/backend-nestjs/src/domain/services/photo.service.spec.ts:missing
**Severity**: MEDIUM
**Category**: Testing

**Issue**: No tests added for new `uploadMultiple` method

**Recommendation**: Add comprehensive tests covering:
- Happy path (successful bulk upload)
- Partial failure (some uploads succeed, some fail)
- Validation errors (invalid file types, size >5MB)
- Resource limits (max concurrent uploads)

**Reference**: `testing-guidelines.md` § Coverage → All public methods must have tests

---

## Suggestions 💡 (Optional Improvements)

### apps/backend-nestjs/src/domain/services/photo.service.ts:72
**Severity**: LOW
**Category**: Performance

**Issue**: Sequential uploads could be parallelized
```typescript
for (const file of files) {
  await this.saveToStorage(file); // Sequential (slow for multiple files)
}
```

**Recommendation**: Use `Promise.all` for concurrent uploads
```typescript
await Promise.all(
  files.map(file => this.saveToStorage(file))
);

// Or with concurrency limit:
await pLimit(files, 5, file => this.saveToStorage(file));
```

**Impact**: Reduces upload time from O(n) to O(n/concurrency) for n files

---

## Summary

- **Critical Issues**: 2 (must fix before merge)
- **Architectural Concerns**: 2 (should address)
- **Code Quality**: 2 (nice to have)
- **Suggestions**: 1 (optional)

### Risk Assessment

**Overall Risk**: MEDIUM-HIGH

**Blockers**:
- ❌ Security vulnerability (directory traversal)
- ❌ Missing error handling in async code

**Recommendations**:
1. Fix critical security and bug issues
2. Add test coverage for new functionality
3. Consider refactoring large method for maintainability

**Approval**: ❌ **DO NOT MERGE** until critical issues resolved
```

## Activation Triggers

- Reference `coding-standards.md` for team conventions
- Reference `architecture.md` for architectural patterns
- Apply `change-impact-analysis` skill to assess risk
- Reference `testing-guidelines.md` for test coverage standards

## Configuration

You can customize review focus:

```
/code-reviewer --focus security
/code-reviewer --focus performance
/code-reviewer --strict  (enforce all standards)
```

You provide constructive, actionable feedback that helps developers improve code quality while learning team standards.
