# Photo Gallery Project

## Architecture

- **Frontend**: Angular 18+ in `apps/frontend/`
- **Backend**: NestJS in `apps/backend-nestjs/`
- **Monorepo**: Nx workspace — run commands via `nx` or `npm run`
- **API**: REST API on `localhost:3000/api` (proxy configured in `proxy.conf.json`)

## Domain Rules

- Domain layer (`src/domain/`) must NOT depend on infrastructure layer
- All business logic belongs in domain services
- Use TypeORM decorators for entities

## Coding Standards

- TypeScript strict mode — no `any` types
- NestJS patterns: modules, controllers, services, DTOs
- Angular standalone components
- Spec files co-located with source files

## Available Custom Agents

- `@architecture-guardian` — validates design decisions against architectural patterns

## Available Commands

- `/code-reviewer` — AI-assisted code review aligned with team standards

## Available Skills

- `change-impact-analysis` — auto-loaded for risk assessment of code changes
