# Photo Gallery Project

## Architecture

- **Frontend**: Angular 18+ in `apps/frontend/`
- **Backend**: NestJS in `apps/backend-nestjs/`
- **Monorepo**: Nx workspace — run commands via `nx` or `npm run`
- **API**: REST API backend proxied via `proxy.conf.json` (see `apps/frontend/proxy.conf.json` for port details)

## Domain Rules

- Domain layer (`src/domain/`) must NOT depend on infrastructure layer
- All business logic belongs in domain services
- Use TypeORM decorators for entities

## Coding Standards

- TypeScript strict mode — no `any` types
- NestJS patterns: modules, controllers, services, DTOs
- Angular standalone components
- Spec files co-located with source files

## Available Commands

- `/code-reviewer` — AI-assisted code review aligned with team standards

## Configuration

See `.gemini/` for commands, hooks, skills, and settings.
