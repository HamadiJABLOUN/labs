# Module 4: Agentic Tools Deep Dive - Hands-on Lab

**Duration**: 95-135 minutes hands-on lab, depending on the platform you choose

## Overview

This lab provides hands-on experience creating custom agents, commands, skills, hooks, plugins, and configuration files for agentic coding tools. You'll work with the **photo-gallery-fullstack** project included in this lab and build configurations from scratch using your chosen platform's CLI.

The backend is **trainee-choosable**: pick NestJS (TypeScript — reference), Spring Boot (Java 17), FastAPI (Python 3.12), .NET (C# 12 / ASP.NET Core 8), or Gin (Go 1.23). All five implement the same OpenAPI contract at `docs/openapi.yaml` and are interchangeable behind the Angular frontend on port 42621.

**Key Learning Objectives**:

- Create custom agents and commands tailored to a real project
- Define reusable agent skills using the SKILL.md format
- Configure hooks for automated quality validation
- Set up plugins and configuration files for team workflows

## Lab Structure

This lab is organized into six platform-specific sections. **Choose ONE platform** based on your environment:

- **Section A**: Claude Code exercises
- **Section B**: GitHub Copilot exercises
- **Section C**: Gemini CLI exercises
- **Section D**: Codex CLI exercises
- **Section E**: OpenCode exercises
- **Section F**: Mistral Vibe exercises

Each section contains progressive exercises that guide you through creating each AI agent feature type.

**Sections differ in length, and that is the point.** Each tool exposes a different number of
extension points, so the track length reflects the tool's surface area rather than uneven authoring:

| Section | Platform       |       Exercises | Approx. |
| ------- | -------------- | --------------: | ------: |
| A       | Claude Code    | 10 + 1 optional | 135 min |
| B       | GitHub Copilot |              11 | 130 min |
| C       | Gemini CLI     |               9 | 110 min |
| D       | Codex CLI      |               8 |  95 min |
| E       | OpenCode       |               9 | 100 min |
| F       | Mistral Vibe   |               9 | 100 min |

Section D is the shortest because Codex CLI has no slash-command system, and its **Rules** replace
the hook mechanism the other platforms configure separately — one exercise instead of two. Trainees
on the Codex track finish early; point them at another section to compare, rather than padding.

## Setup Instructions

### Prerequisites

- One of: Claude Code, GitHub Copilot CLI, Gemini CLI, Codex CLI, OpenCode, or Mistral Vibe installed
- Node.js 22+ and npm (always required — the frontend is Angular)
- Git
- Additional toolchain for your chosen backend (see **Backend Implementation Options** below):
  - **NestJS** — just Node.js
  - **Spring Boot** — JDK 17+ (Maven wrapper included)
  - **FastAPI** — Python 3.12+ and `uv` (or `pip`)
  - **.NET** — .NET 10 SDK
  - **Gin** — Go 1.23+

### Initial Setup

1. Navigate to the lab directory or open it in your IDE:

```bash
cd labs/lab-41-agentic-tools-deep-dive/photo-gallery-fullstack
```

2. (optional) Initialize a fresh Git repository within that directory:

```bash
git init
git add .
git commit -m "chore: initial commit"
```

3. Install dependencies:

```bash
npm ci
```

> **Note**: The `../lab-41-agentic-tools-deep-dive-solution/resources/photo-gallery-fullstack-solution/` directory contains the complete reference configurations for all platforms. For this lab, you will create these configurations from scratch in `photo-gallery-fullstack/` to understand how they work. Compare your files with the solution at any time.

> **Pre-seeded reference documents**: The lab project already contains platform-specific `references/` folders (`.claude/references/`, `.github/references/`, `.gemini/references/`, `.codex/references/`, `.opencode/references/`, `.vibe/references/`) with 5 shared knowledge files: `architecture.md`, `coding-standards.md`, `domain-glossary.md`, `testing-guidelines.md`, and `oncall.md`. Your commands, skills, and agents will reference these files — they are provided so you can focus on configuration rather than content creation.

---

## Backend Implementation Options

Pick **one** backend to run alongside your agent-config work. All five implement the same OpenAPI contract (`docs/openapi.yaml`) and bind port 42621.

▶ **NestJS (TypeScript) — reference implementation**

```bash
cd labs/lab-41-agentic-tools-deep-dive/photo-gallery-fullstack
npm run serve:backend-nestjs
```

Swagger UI at http://localhost:42621/api/docs. See [`docs/backends/nestjs.md`](photo-gallery-fullstack/docs/backends/nestjs.md).

▶ **Spring Boot (Java 17)**

```bash
cd labs/lab-41-agentic-tools-deep-dive/photo-gallery-fullstack
npm run serve:backend-spring
# or (Unix):    ./apps/backend-spring/mvnw spring-boot:run
# or (Windows): ./apps/backend-spring/mvnw.bat spring-boot:run
```

See [`docs/backends/spring.md`](photo-gallery-fullstack/docs/backends/spring.md).

▶ **FastAPI (Python 3.12)**

```bash
cd labs/lab-41-agentic-tools-deep-dive/photo-gallery-fullstack
npm run serve:backend-fastapi
# or: uv run --directory apps/backend-fastapi uvicorn app.main:app --host 0.0.0.0 --port 42621
```

See [`docs/backends/fastapi.md`](photo-gallery-fullstack/docs/backends/fastapi.md).

▶ **.NET (C#)**

```bash
cd labs/lab-41-agentic-tools-deep-dive/photo-gallery-fullstack
npm run serve:backend-dotnet
# or: dotnet run --project apps/backend-dotnet
```

Swagger UI at http://localhost:42621/api/docs. See [`docs/backends/dotnet.md`](photo-gallery-fullstack/docs/backends/dotnet.md).

▶ **Gin (Go 1.23)**

```bash
cd labs/lab-41-agentic-tools-deep-dive/photo-gallery-fullstack
npm run serve:backend-gin
# or: go -C apps/backend-gin run ./cmd/server
```

See [`docs/backends/gin.md`](photo-gallery-fullstack/docs/backends/gin.md).

---

▶ **Section A: Claude Code Exercises**

**Platform**: Claude Code
**Reference configs**: `../lab-41-agentic-tools-deep-dive-solution/resources/photo-gallery-fullstack-solution/.claude/`

### Exercise A1: Initialize CLAUDE.md (10 min)

**Objective**: Create the project context file for Claude Code using `/init`

`CLAUDE.md` is automatically loaded by Claude Code at session start — it provides project-specific instructions, architecture rules, and conventions that apply globally to all sessions.

1. Run `/init` to analyze the project and auto-generate a `CLAUDE.md`:

```
/init
```

Claude Code scans the codebase and generates a `CLAUDE.md` at the project root with detected patterns, dependencies, and suggested conventions.

2. Review the generated file and customize it. Your final `CLAUDE.md` should include sections like: **Architecture Overview**, **Tech Stack**, **Coding Standard**, etc.

3. Verify Claude loads the file by opening a new Claude Code session in the project root and asking:

```
What do you know about this project?
```

**Expected Outcome**: `CLAUDE.md` created at project root. Claude automatically references these rules in every session without needing to re-explain the project architecture.

**Reference**: Compare with `../lab-41-agentic-tools-deep-dive-solution/resources/photo-gallery-fullstack-solution/CLAUDE.md`

### Exercise A2: Create Claude Rules (15 min)

**Objective**: Create path-scoped instruction files using `.claude/rules/`

Claude Rules are modular instruction files that activate automatically based on the files currently in context. Each rule file uses a `glob` frontmatter field to scope instructions to specific paths — keeping layer-specific conventions out of the global `CLAUDE.md`.

1. Create the rules directory:

```bash
mkdir -p .claude/rules
```

2. Create a backend rules file scoped to **your chosen backend** stack from the **Backend Implementation Options** section above — expand the matching block below:

▶ **NestJS (TypeScript)**

Create `.claude/rules/backend-nestjs-rules.md`:

```markdown
---
paths:
  - 'apps/backend-nestjs/**'
---

## Backend Rules

- Use NestJS dependency injection — never instantiate services manually
- DTOs must use class-validator decorators for input validation
- Controllers must only delegate to services — no business logic in controllers
- All repository methods must be defined in the interface first (`photo.repository.interface.ts`)
- Use TypeORM decorators: `@Entity()`, `@Column()`, `@PrimaryGeneratedColumn()`
```

▶ **Spring Boot (Java 17)**

Create `.claude/rules/backend-spring-rules.md`:

```markdown
---
paths:
  - 'apps/backend-spring/**'
---

## Backend Rules

- Use Spring constructor injection with `final` fields — never field-level `@Autowired`
- Controllers (`@RestController`) must only delegate to `@Service`-annotated domain services — no business logic in controllers
- Request DTOs must use Bean Validation (`@NotBlank`, `@NotNull`) combined with `@Valid` on controller parameters
- Keep the domain model (`domain/model/Photo.java`) separate from the JPA entity (`infrastructure/entity/PhotoEntity.java`)
- Use Spring Data JPA repository interfaces (`domain/repository/PhotoRepository.java`) — no manual SQL
- Translate exceptions via `@RestControllerAdvice` into the shared `{statusCode, message, error}` error envelope
```

▶ **FastAPI (Python 3.12)**

Create `.claude/rules/backend-fastapi-rules.md`:

```markdown
---
paths:
  - 'apps/backend-fastapi/**'
---

## Backend Rules

- Use FastAPI's dependency injection (`Depends()`) to wire services and sessions into route handlers — no global singletons
- Domain response models are Pydantic `BaseModel` with `alias_generator=to_camel` and `populate_by_name=True` — keep snake_case in Python, camelCase in JSON
- Keep SQLModel entities (`infrastructure/entities.py`) out of the `api/` layer
- Business logic lives only in `domain/services.py` — `api/photos.py` routers only orchestrate
- Register centralized error handlers in `api/errors.py` producing the shared `{statusCode, message, error}` envelope — don't raise raw `HTTPException` with ad-hoc bodies
```

▶ **.NET (C#)**

Create `.claude/rules/backend-dotnet-rules.md`:

```markdown
---
paths:
  - 'apps/backend-dotnet/**'
---

## Backend Rules

- Controllers (`[ApiController]`) use constructor injection with `readonly` interface fields (e.g. `IPhotoService`) — never `new` a service directly
- Domain owns `Photo` as an immutable `record`; keep EF Core concerns (entities, `AppDbContext`) confined to `Infrastructure/`
- Request/response shapes belong in `Api/Photos/Dto/` and rely on `System.Text.Json`'s default camelCase policy — no manual renaming
- Use a `ValueConverter<T,TStore>` for JSON-encoded columns rather than ad-hoc (de)serialization in the service
- Implement `IExceptionHandler` for the shared `{statusCode, message, error}` error envelope, including model-binding failures
```

▶ **Gin (Go)**

Create `.claude/rules/backend-gin-rules.md`:

```markdown
---
paths:
  - 'apps/backend-gin/**'
---

## Backend Rules

- Handlers are methods on a `Handler` struct constructed via `NewHandler(service, storage)` — inject the domain service/storage as struct fields, never instantiate inline
- Keep GORM entities (snake_case columns) separate from API DTOs (camelCase `json:` tags) — map between them explicitly
- Business logic lives in `internal/domain/service.go`; handlers in `internal/api/photos/handler.go` only parse the request and call the service
- IDs are serialized as `string` (not numeric) in `PhotoResponse` to match the OpenAPI contract
- Return errors via the shared `ErrorResponse{StatusCode, Message, Error}` envelope — don't let Gin's default error format leak through
```

3. Create `.claude/rules/frontend-rules.md` for Angular frontend patterns:

```markdown
---
paths:
  - 'apps/frontend/**'
---

## Frontend Rules

- Use Angular standalone components — no NgModule unless required
- Services must be provided with `providedIn: 'root'`
- Component templates go in separate `.html` files (not inline)
- Use `HttpClient` via dependency injection, never `fetch()` directly
- Models in `src/app/models/` must match backend DTOs
```

4. **Test it**: Open a file from your chosen backend stack and ask Claude to generate code:

```txt
Create a new endpoint to update a photo's title
```

**Expected Outcome**: Claude applies backend-specific rules (DI conventions, DTOs, ORM/entity patterns) automatically when files from your chosen `apps/backend-<stack>/` are in context, and frontend rules when files from `apps/frontend/` are in context. Only relevant rules are loaded based on the active file paths.

**Note**: Rules differ from `CLAUDE.md`: `CLAUDE.md` is always loaded for every session; Rules are scoped by file path and only loaded when matching files are in context. Use Rules for layer-specific conventions that would clutter a global `CLAUDE.md`.

**Reference**: Compare with `../lab-41-agentic-tools-deep-dive-solution/resources/photo-gallery-fullstack-solution/.claude/rules/` — compare against the file matching your chosen backend stack (`backend-<stack>-rules.md`)

### Exercise A3: Create a Custom Agent (15 min)

**Objective**: Create an architecture guardian agent

1. Open Claude Code in the photo-gallery-fullstack directory

2. Create the agents directory:

```bash
mkdir -p .claude/agents
```

3. **Task**: Create the file `.claude/agents/architecture-guardian.md`:

```markdown
---
name: architecture-guardian
description: Validates design decisions against team architectural patterns and ensures alignment with system topology
model: opus
color: purple
tools: Read, Grep, Glob
---

# Architecture Guardian

You are the **Architecture Guardian** for the photo-gallery project. Your role is to ensure all code changes align with established architectural patterns, maintain system integrity, and follow documented design principles.

## Core Responsibilities

- **Validate Design Decisions**: Review proposed architectural changes against `architecture.md` and ensure alignment with system topology
- **Identify Violations**: Flag deviations from established patterns, anti-patterns, and architectural debt
- **Suggest Refactoring**: Recommend improvements that align with team conventions and long-term maintainability
- **Maintain Boundaries**: Enforce module boundaries and prevent tight coupling between layers
- **Review Dependencies**: Assess impact of new dependencies and ensure they fit architectural vision

## Context Files

You have access to the following knowledge references:

- **architecture.md**: System topology, module boundaries, data flow patterns
- **coding-standards.md**: Team conventions, naming patterns, file organization
- **domain-glossary.md**: Business terminology and domain model definitions

## Interaction Guidelines

When consulted, you should:

1. **Assess Context**: Understand the scope and intent of the proposed change
2. **Reference Standards**: Cite specific sections from architecture.md or coding-standards.md
3. **Evaluate Trade-offs**: Explain pros/cons of different architectural approaches
4. **Provide Specific Recommendations**: Give actionable guidance with code examples where applicable
5. **Flag Risks**: Identify potential scalability, performance, or maintainability concerns

## Example Invocations

- "Should this new feature live in the `api` module or `domain` module?"
- "Is it acceptable to add a direct dependency from `ui` to `storage`?"
- "What's the recommended pattern for handling cross-cutting concerns?"
- "Validate this component structure against our architecture guidelines"

## Decision Framework

When multiple valid approaches exist, prioritize:

1. **Consistency** with existing patterns
2. **Maintainability** and readability
3. **Testability** and isolation
4. **Performance** (only when measurable impact exists)
5. **Future extensibility**

You are an advisor, not a gatekeeper. Provide reasoned guidance but acknowledge when trade-offs are acceptable given project constraints.
```

4. **Test it**: Ask the agent a question:

```
@architecture-guardian I want to add a photo filter feature. Should this go in the API layer or domain layer?
```

**Expected Outcome**: The agent analyzes the architecture and provides a layered recommendation

**Reference**: Compare your file with `../lab-41-agentic-tools-deep-dive-solution/resources/photo-gallery-fullstack-solution/.claude/agents/architecture-guardian.md`

▶ **💡 Alternative way to create a custom agent in Claude Code**

Instead of writing the file manually, use the Claude CLI interactive agent wizard. Inside a Claude Code session, run:

```
/agents
```

Select **"Create new agent"** and follow the on-screen prompts — Claude asks for the agent name, description, allowed tools, and system instructions, then generates `.claude/agents/<name>.md` automatically.

### Exercise A4: Create an Agent Team (15 min) - Experimental

**Objective**: Spawn a multi-agent team for parallel code review

1. **Task**: Enable Agent Teams in `.claude/settings.json`:

```json
{
  "env": {
    "CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS": "1"
  }
}
```

2. Start Claude Code and request a team:

```
Create an agent team to review this photo-gallery project from different angles:
- One teammate focused on security review
- One teammate checking code quality and conventions
- One teammate validating test coverage
```

3. Observe how Claude creates the team lead, spawns teammates, and coordinates work

4. Use `Shift+Down` to cycle through teammates and interact with them directly

5. When teammates finish, ask the lead to synthesize findings

6. Clean up the team:

```
Clean up the team
```

**Expected Outcome**: Multiple Claude Code sessions working in parallel, each with isolated context, communicating findings to each other

**Note**: Agent Teams are experimental. They differ from subagents: subagents report back to the caller only, while team members communicate **with each other** and share a task list. Teams use more tokens but enable parallel research, review, and debugging.

### Exercise A5: Create a Custom Command (10 min)

**Objective**: Create a code reviewer command

1. Create the commands directory:

```bash
mkdir -p .claude/commands
```

2. **Task**: Create the file `.claude/commands/code-reviewer.md`:

```markdown
---
description: Analyze code changes (diff) and generate actionable code review comments aligned with team standards
allowed-tools: Bash(git diff:*), Bash(git log:*), Read, Grep, Glob
argument-hint: [file-path-or-branch]
---

# Code Reviewer

Analyze code changes and generate actionable code review comments aligned with team standards.

## Purpose

Assist code reviewers by:

- Identifying potential bugs, security issues, and performance problems
- Flagging violations of team coding standards and architectural patterns
- Suggesting improvements for readability and maintainability
- Highlighting risks that require extra scrutiny

## Instructions

When invoked, analyze the current git diff (staged or unstaged changes) or the specified file/branch: $ARGUMENTS

Reference these team standards:
@.claude/references/coding-standards.md
@.claude/references/architecture.md

## Output Format

The command will produce review comments organized by:

1. **Critical Issues**: Bugs, security vulnerabilities, breaking changes (must fix)
2. **Architectural Concerns**: Pattern violations, coupling issues (should fix)
3. **Code Quality**: Readability, maintainability, test coverage (nice to have)
4. **Suggestions**: Performance optimizations, refactoring opportunities (optional)

Each comment includes:

- **File and line reference**
- **Severity**: Critical / High / Medium / Low
- **Category**: Bug / Security / Architecture / Style / Performance
- **Description**: What the issue is and why it matters
- **Recommendation**: Specific action to address the issue

## Activation Triggers

- Reference `coding-standards.md` for team conventions
- Reference `architecture.md` for architectural patterns
- Apply `change-impact-analysis` skill to assess risk
- Reference `testing-guidelines.md` for test coverage standards

## Configuration

You can customize review focus:
```

/code-reviewer --focus security
/code-reviewer --focus performance
/code-reviewer --strict (enforce all standards)

```

You provide constructive, actionable feedback that helps developers improve code quality while learning team standards.
```

3. **Test it**: Make a small code change, then run:

```
/code-reviewer
```

**Expected Outcome**: Structured code review with categorized findings

**Reference**: Compare with `../lab-41-agentic-tools-deep-dive-solution/resources/photo-gallery-fullstack-solution/.claude/commands/code-reviewer.md`

### Exercise A6: Create an Agent Skill (10 min)

**Objective**: Create a change impact analysis skill

1. Create the skills directory:

```bash
mkdir -p .claude/skills/change-impact-analysis
```

2. **Task**: Create the file `.claude/skills/change-impact-analysis/SKILL.md`:

```markdown
---
name: change-impact-analysis
description: Assess the scope and risk of proposed code changes by analyzing affected components, blast radius, and potential side effects. Use when reviewing pull requests, planning large refactorings, assessing deployment readiness, or evaluating rollback complexity.
---

# Change Impact Analysis Skill

## Purpose

Assess the scope and risk of proposed code changes by analyzing affected components, blast radius, and potential side effects. This skill helps teams make informed decisions about change safety.

## Capabilities

### 1. Blast Radius Assessment

- Quantify how many files, modules, and services are affected
- Categorize changes by risk level (low/medium/high/critical)
- Identify cascading effects of a change

### 2. Risk Scoring

- Calculate risk based on change size, complexity, and affected components
- Flag high-risk changes requiring extra review or testing
- Recommend mitigation strategies proportional to risk

### 3. Side Effect Detection

- Identify unintended consequences of changes
- Flag performance implications
- Detect security or compliance impacts

## Usage Context

This skill activates when:

- Reviewing pull requests for approval
- Planning large refactorings or migrations
- Assessing deployment readiness
- Evaluating rollback complexity

## Knowledge Sources

- **testing-guidelines.md**: Test coverage requirements by risk level
- **architecture.md**: Critical paths and high-risk components
- **Git history**: Past incidents correlated with similar changes

## Risk Assessment Framework

### Risk Factors

| Factor             | Weight | Criteria                                                                                  |
| ------------------ | ------ | ----------------------------------------------------------------------------------------- |
| **Lines Changed**  | 20%    | <50 (low) / 50-200 (med) / 200-500 (high) / >500 (critical)                               |
| **Files Affected** | 15%    | <5 (low) / 5-10 (med) / 10-20 (high) / >20 (critical)                                     |
| **Test Coverage**  | 25%    | >80% (low) / 60-80% (med) / 40-60% (high) / <40% (critical)                               |
| **Critical Path**  | 30%    | Not on critical path (low) / Near critical (med) / On critical path (high)                |
| **Rollback Ease**  | 10%    | Easy revert (low) / Config change (med) / DB migration (high) / Data loss risk (critical) |

### Risk Categories

**LOW RISK** (Score: 0-30)

- Small, isolated changes
- High test coverage
- Easy to rollback
- Examples: UI text changes, logging improvements, documentation

**MEDIUM RISK** (Score: 31-60)

- Moderate scope changes
- Adequate test coverage
- Standard rollback procedures
- Examples: New features, refactorings, configuration updates

**HIGH RISK** (Score: 61-85)

- Large scope or critical path changes
- Test coverage gaps
- Complex rollback
- Examples: API changes, database migrations, authentication updates

**CRITICAL RISK** (Score: 86-100)

- Changes to payment, security, or data integrity systems
- Insufficient testing
- Irreversible changes
- Examples: Payment logic, user data deletion, schema breaking changes

## Metrics

Success criteria for impact analysis:

- ✅ Accurately classifies 90%+ of changes by risk
- ✅ Zero high-risk changes deployed without appropriate safeguards
- ✅ Reduces production incidents by 30% through better risk assessment
```

3. **Test it**: Ask Claude:

```
If I change the PhotoRepository interface, what files will be affected?
```

**Expected Outcome**: Claude automatically uses the skill to provide an impact analysis

**Reference**: Compare with `../lab-41-agentic-tools-deep-dive-solution/resources/photo-gallery-fullstack-solution/.claude/skills/change-impact-analysis/SKILL.md`

### Exercise A7: Install a Skill from Public Registry (10 min)

**Objective**: Search for and install a community skill from the Tessl registry

1. **Task**: Search for the `skill-creator` skill:

```bash
npx -y skills find skill-creator
```

2. Install it locally:

```bash
npx -y skills add https://github.com/anthropics/skills --skill skill-creator
```

3. Verify the skill was installed in your `.claude/skills/` directory

4. **Test it**: Ask Claude to use the skill:

```
Using the skill-creator skill, help me create a new skill for API documentation generation
```

**Expected Outcome**: The community skill is installed locally and Claude can use it to help create new skills

**Note**: Public skill registries like [tessl.io/registry](https://tessl.io/registry) (93+ curated skills with quality ratings) and [skills.sh](https://skills.sh/) (89K+ skills) allow you to discover and install community-created skills without building everything from scratch

### Exercise A8: Evaluate an Agent Skill (10 min)

**Objective**: Use Tessl CLI combined with Claude Code to iteratively improve the skill quality until it reaches a 100% score

> **Notes: A Tessl account is now required to review skills. Register once at https://tessl.io/login?returnPathname=%2Fregistry**

1. **Log in to Tessl** (one-time; skip if already authenticated):

```bash
npx --yes tessl login
```

This opens a browser to authenticate — required before `tessl review run` will work (verify anytime with `npx --yes tessl whoami`).

2. **Run the initial Tessl skill review**:

```bash
npx --yes tessl review run .claude/skills/change-impact-analysis/SKILL.md
```

3. **Ask Claude Code to improve the skill until the score reaches 100%**:

```
Run `npx --yes tessl review run .claude/skills/change-impact-analysis/SKILL.md` and analyze the output.
Then improve the SKILL.md file based on the quality score, impact score, and improvement suggestions reported.
Repeat — run the review again, apply further improvements — until the reported score is 100%.
```

4. **Validate the final score** — re-run the review one last time to confirm the 100% score:

```bash
npx --yes tessl review run .claude/skills/change-impact-analysis/SKILL.md
```

**Expected Outcome**: SKILL.md reaches a 100% quality score as reported by Tessl CLI

**Reference**: https://tessl.io/registry/skills/submit

### Exercise A9: Configure Hooks (15 min)

**Objective**: Set up pre-tool and post-tool hooks

1. **Task**: Create or edit `.claude/settings.json` with hooks:

```json
{
  "hooks": {
    "PreToolUse": [
      {
        "matcher": "Bash",
        "hooks": [
          {
            "type": "prompt",
            "prompt": "Check if this Bash command is a git commit. If so, verify staged files follow coding standards before allowing the commit."
          }
        ]
      }
    ],
    "PostToolUse": [
      {
        "matcher": "Write|Edit",
        "hooks": [
          {
            "type": "prompt",
            "prompt": "Validate the file changes against coding-standards.md. Check they follow the project's coding standards."
          }
        ]
      }
    ]
  }
}
```

2. **Test it**: Make a code change that violates coding standards (e.g., add a `console.log` statement) and observe the hook behavior

**Expected Outcome**: Post-edit hook flags the coding standards violation

**Reference**: Compare with `../lab-41-agentic-tools-deep-dive-solution/resources/photo-gallery-fullstack-solution/.claude/settings.json`

▶ **💡 Alternative way to configure hooks in Claude Code**

Instead of editing `settings.json` manually, use the Claude CLI interactive hooks manager. Inside a Claude Code session, run:

```
/hooks
```

Choose **"Add hook"**, select the event type (PreToolUse / PostToolUse), set the tool matcher and the prompt or command, and Claude writes the hook configuration to `.claude/settings.json` automatically.

### Exercise A10: Create a Plugin (15 min)

**Objective**: Create a team-workflows plugin

1. **Task**: Create the plugin structure:

```bash
mkdir -p .claude/plugins/team-workflows/.claude-plugin
mkdir -p .claude/plugins/team-workflows/commands
mkdir -p .claude/plugins/team-workflows/agents
```

2. Create the plugin manifest `.claude/plugins/team-workflows/.claude-plugin/plugin.json`:

```json
{
  "name": "team-workflows",
  "version": "1.0.0",
  "description": "Team workflow automation plugin",
  "author": { "name": "SFEIR Team" }
}
```

3. Add a command `.claude/plugins/team-workflows/commands/analyze-dependencies.md` with the following content:

````markdown
# Analyze Dependencies Command

**Invocation**: `/team-workflows:analyze-dependencies [options]`

## Purpose

Analyze project dependencies to identify:

- Outdated packages and available updates
- Security vulnerabilities in dependencies
- Unused dependencies that can be removed
- Dependency conflicts and compatibility issues
- License compliance concerns

## Options

- `--scope <value>`: Analyze "prod", "dev", or "all" dependencies (default: "all")
- `--format <value>`: Output format "table", "json", or "markdown" (default: "table")
- `--security-only`: Only show security vulnerabilities
- `--outdated-only`: Only show outdated packages

## Behavior

1. Parse package.json and lock files
2. Check each dependency against npm registry for latest versions
3. Consult security databases (npm audit, Snyk, etc.) for vulnerabilities
4. Analyze dependency tree for conflicts
5. Generate actionable report with update recommendations

## Output Format

```markdown
# Dependency Analysis Report

Outdated Packages (5):
├─ react: 17.0.2 → 18.2.0 (Major update available)
├─ typescript: 5.0.0 → 5.3.3 (Patch update available)
└─ ...

Security Vulnerabilities (2):
├─ [HIGH] lodash@4.17.20: Prototype Pollution
│ Fix: Update to lodash@4.17.21
└─ [MEDIUM] axios@0.21.1: Server-Side Request Forgery
Fix: Update to axios@1.6.0

Unused Dependencies (3):
├─ moment (not imported anywhere)
├─ ...

Recommended Actions:

1. Run: npm update typescript
2. Run: npm install lodash@4.17.21
3. Run: npm uninstall moment
```
````

4. **Load the plugin for this session**:

```bash
claude --plugin-dir .claude/plugins/team-workflows
```

5. Inside the Claude Code session, run the plugin command to verify it loaded:

```
/team-workflows:analyze-dependencies
```

6. **Register a local marketplace so the plugin auto-loads every session**:

`--plugin-dir` only loads the plugin for the current session. A marketplace lets you install the plugin once and have it load automatically afterward — and a marketplace can be nothing more than a local directory, with no GitHub repo or web server required.

Create the marketplace manifest under `.claude/marketplaces/sfeir-marketplace/`:

```bash
mkdir -p .claude/marketplaces/sfeir-marketplace/.claude-plugin
```

Create `.claude/marketplaces/sfeir-marketplace/.claude-plugin/marketplace.json`:

```json
{
  "name": "sfeir-marketplace",
  "owner": { "name": "SFEIR Team" },
  "plugins": [
    {
      "name": "team-workflows",
      "source": "../../plugins/team-workflows",
      "description": "Team workflow automation plugin"
    }
  ]
}
```

Register the local marketplace and install the plugin from it:

```bash
claude plugin marketplace add ./.claude/marketplaces/sfeir-marketplace --scope project
claude plugin install team-workflows@sfeir-marketplace
```

**Test it**: start a **new** Claude Code session in the project root — without `--plugin-dir` — and confirm the plugin command still works:

```
/team-workflows:analyze-dependencies
```

**Expected Outcome**: Claude Code starts with the plugin loaded and its commands available in the `/team-workflows:` namespace. After registering the local marketplace, the plugin loads automatically in every future session in this project, with no `--plugin-dir` flag, no GitHub repo, and no hosting required.

▶ **💡 Distributing the marketplace to a team (hosted variant)**

To share the marketplace with teammates across other machines — not just locally on this filesystem — publish it to a hosted git repo instead:

1. Push a `marketplace.json` catalog (like the one above) to a hosted repo.
2. Register it in `.claude/settings.json`:

```json
{
  "extraKnownMarketplaces": [{ "name": "my-team", "url": "https://raw.githubusercontent.com/your-org/plugins/main" }]
}
```

3. Then install once:

```bash
claude plugin install team-workflows@my-team
```

After that, the plugin loads automatically in every Claude Code session for anyone who installs it from that marketplace.

**Reference**: Compare with `../lab-41-agentic-tools-deep-dive-solution/resources/photo-gallery-fullstack-solution/.claude/plugins/team-workflows/` and `../lab-41-agentic-tools-deep-dive-solution/resources/photo-gallery-fullstack-solution/.claude/marketplaces/sfeir-marketplace/.claude-plugin/marketplace.json`

### Exercise A11 (Optional): Configure Settings (10 min)

**Objective**: Set up project-level configuration

1. **Task**: Update `.claude/settings.json` to add permissions:

```json
{
  "permissions": {
    "allow": ["Bash(npm:*)", "Bash(npx:*)", "Bash(git:*)"],
    "deny": ["Bash(rm -rf:*)"]
  },
  "env": {
    "NODE_ENV": "development"
  }
}
```

2. Verify the configuration is applied by checking Claude's behavior

**Expected Outcome**: Claude can run npm/git commands without prompting, but rm -rf is blocked

**Reference**: Compare with `../lab-41-agentic-tools-deep-dive-solution/resources/photo-gallery-fullstack-solution/.claude/settings.json`

---

▶ **Section B: GitHub Copilot Exercises**

**Platform**: GitHub Copilot
**Reference configs**: `../lab-41-agentic-tools-deep-dive-solution/resources/photo-gallery-fullstack-solution/.github/`

### Exercise B1: Initialize copilot-instructions.md (10 min)

**Objective**: Auto-generate the project instructions file using `/init`

`.github/copilot-instructions.md` is automatically loaded by GitHub Copilot for all sessions in this repository — it provides project-wide instructions that Copilot follows without any explicit invocation.

1. Run `/init` to scaffold project instructions from codebase analysis:

```
/init
```

GitHub Copilot CLI analyzes your project structure and generates `.github/copilot-instructions.md` with detected patterns and conventions.

2. Review the generated file at `.github/copilot-instructions.md`

3. Verify Copilot is using the instructions:

```
What are the main architectural patterns in this project?
```

**Expected Outcome**: Copilot references the project's structure and conventions from the generated file. This provides a baseline that you will enhance in Exercise B2 with comprehensive team standards covering architecture, coding standards, security, and workflow sections.

**Note**: `/init` creates a starting point from static analysis. Exercise B2 shows how to craft comprehensive project instructions manually.

### Exercise B2: Comprehensive copilot-instructions.md (10 min)

**Objective**: Create project-wide Copilot instructions

0. Remove the auto-generated `.github/copilot-instructions.md` from Exercise B1

1. **Task**: Create `.github/copilot-instructions.md` with the stack-agnostic opening, shared Technology Stack bullets, Coding Standards intro, and the Angular frontend example:

```markdown
# Photo Gallery Repository Instructions

Follow these guidelines when working in this repository:

## Architecture & Design

- Follow the layered architecture defined in [references/architecture.md](references/architecture.md)
- Respect module boundaries (UI → Service → Domain → Infrastructure)
- Use dependency injection for all external dependencies
- Reference [references/domain-glossary.md](references/domain-glossary.md) for consistent terminology

## Technology Stack

- **Frontend**: Angular 20+ with signals-based state management
- **Database**: SQLite (local file)
- **File Storage**: Local disk (`./dist/uploads/`)
- **Backend**: see the backend-specific block below for your chosen stack

## Coding Standards

- TypeScript for the frontend (strict mode enabled); the backend follows its own stack's idiomatic conventions (see below)
- Use async/await (no callbacks except for legacy refactoring exercises)
- Functions max 50 lines
- Classes follow single responsibility principle
- See [references/coding-standards.md](references/coding-standards.md) for detailed conventions

### Angular (Frontend)

**Path**: `apps/frontend/src/app/`

- Use standalone components (no NgModules)
- Use Angular signals for state (`signal()`, `computed()`)
- Use `inject()` function for dependency injection

​`typescript
@Component({
  standalone: true,
  imports: [CommonModule],
})
export class PhotoListComponent {
  private readonly photoService = inject(PhotoService);
  readonly photos = this.photoService.photos;
  readonly selectedTags = signal<string[]>([]);
}
​`
```

2. Append one `<details>` block for **your chosen backend**, containing its Technology Stack, Key Paths, and Coding Standards subsection together:

▶ **NestJS (TypeScript)**

````markdown
### NestJS (Backend)

**Technology Stack**: NestJS 11 with TypeORM (Nx monorepo)
**Key Paths**: API `apps/backend-nestjs/src/api/`, Domain `apps/backend-nestjs/src/domain/`, Infrastructure `apps/backend-nestjs/src/infrastructure/`

- Use decorators: `@Controller`, `@Get`, `@Post`, `@Injectable`
- Use TypeORM for database access with `@InjectRepository`
- Use DTOs with class-validator decorators

​```typescript
@Controller('api/photos')
export class PhotosController {
constructor(private readonly photoService: PhotoService) {}

@Get()
async getPhotos(): Promise<Photo[]> {
return this.photoService.getPhotos();
}
}
​```
````

▶ **Spring Boot (Java 17)**

````markdown
### Spring Boot (Backend)

**Technology Stack**: Spring Boot 3 (Java 17) with Spring Data JPA (Maven wrapper)
**Key Paths**: API `apps/backend-spring/src/main/java/com/photogallery/backend/api/`, Domain `apps/backend-spring/src/main/java/com/photogallery/backend/domain/`, Infrastructure `apps/backend-spring/src/main/java/com/photogallery/backend/infrastructure/`

- Use `@RestController` with `@GetMapping`/`@PostMapping`, constructor injection (no field `@Autowired`)
- Use Spring Data JPA repositories for database access — no manual SQL
- Use DTOs with Bean Validation (`@NotBlank`, `@Valid`)

​```java
@RestController
@RequestMapping("/api/photos")
public class PhotosController {
private final PhotoService photoService;

public PhotosController(PhotoService photoService) {
this.photoService = photoService;
}

@GetMapping
public List<PhotoResponse> getPhotos() {
return photoService.getPhotos();
}
}
​```
````

▶ **FastAPI (Python 3.12)**

````markdown
### FastAPI (Backend)

**Technology Stack**: FastAPI (Python 3.12) with SQLModel (`uv`/`pip`)
**Key Paths**: API `apps/backend-fastapi/app/api/`, Domain `apps/backend-fastapi/app/domain/`, Infrastructure `apps/backend-fastapi/app/infrastructure/`

- Use `APIRouter` with `Depends()` for dependency injection
- Use SQLModel for database access via an injected `Session` — no raw SQL
- Use Pydantic models with `alias_generator=to_camel` for camelCase JSON

​```python
router = APIRouter(prefix="/api/photos")

@router.get("", response_model=list[Photo])
def get_photos(service: PhotoService = Depends(get_photo_service)) -> list[Photo]:
`return service.get_photos()
​```
````

▶ **.NET (C#)**

````markdown
### .NET (Backend)

**Technology Stack**: ASP.NET Core 8 (C# 12) with Entity Framework Core 8 (.NET 8 SDK)
**Key Paths**: API `apps/backend-dotnet/Api/`, Domain `apps/backend-dotnet/Domain/`, Infrastructure `apps/backend-dotnet/Infrastructure/`

- Use `[ApiController]` with constructor-injected interfaces (e.g. `IPhotoService`)
- Use Entity Framework Core for database access via the repository pattern — no raw SQL
- Use DTOs relying on `System.Text.Json`'s default camelCase policy

​```csharp
[ApiController]
[Route("api/photos")]
public class PhotosController : ControllerBase
{
private readonly IPhotoService \_photoService;

public PhotosController(IPhotoService photoService) => \_photoService = photoService;

[HttpGet]
public async Task<IEnumerable<PhotoResponse>> GetPhotos() => await \_photoService.GetPhotosAsync();
}
​```
````

▶ **Gin (Go)**

```markdown
### Gin (Backend)

**Technology Stack**: Gin (Go 1.23) with GORM (Go 1.23 modules)
**Key Paths**: API `apps/backend-gin/internal/api/`, Domain `apps/backend-gin/internal/domain/`, Infrastructure `apps/backend-gin/internal/infrastructure/`

- Use `Handler` struct methods registered on the Gin router, constructed via `NewHandler(service, storage)`
- Use GORM for database access — no raw SQL
- Use DTOs with explicit `json:` tags for camelCase JSON

​`go
func (h *Handler) GetPhotos(c *gin.Context) {
	photos, err := h.service.GetPhotos(c.Request.Context())
	if err != nil {
		c.JSON(http.StatusInternalServerError, ErrorResponse{Message: err.Error()})
		return
	}
	c.JSON(http.StatusOK, ToResponseList(photos))
}
​`
```

3. Append the remaining shared sections, unchanged across all backends:

````markdown
## Testing

- Minimum 80% code coverage for business logic
- Use AAA pattern (Arrange-Act-Assert)
- Mock external dependencies (HTTP calls, file system in unit tests)
- Use Vitest for unit and integration tests
- Use Playwright for E2E tests
- See [references/testing-guidelines.md](references/testing-guidelines.md) for test strategies

## API Conventions

- RESTful endpoints with proper HTTP verbs
- camelCase for JSON fields
- Consistent error response format:
  ```json
  {
    "statusCode": 400,
    "message": "File size exceeds 5MB limit",
    "error": "Bad Request"
  }
  ```

## Validation Constraints

- Max file size: **5MB**
- Supported image types: JPEG, PNG, GIF, WebP
- Tags: lowercase alphanumeric with hyphens, max 20 tags, max 30 chars each

## Security

- Always validate and sanitize user input
- Use your ORM's repository/query-builder methods (avoid raw SQL)
- Store sensitive data in environment variables
- No hardcoded credentials or API keys

## Performance

- Use Angular signals for reactive state (automatically optimized)
- Lazy load images with `loading="lazy"` attribute
- Use computed values for derived state (memoized automatically)
- Optimize database queries using your backend's query builder/ORM

## Git Workflow

- Branch naming: `feature/`, `bugfix/`, `refactor/`
- Commit messages: `type(scope): description`
- PR descriptions include test strategy and deployment notes
- Code review required from 2+ team members

## On-Call & Incidents

- Follow escalation procedures in [references/oncall.md](references/oncall.md)
- Document incidents using RCA template
- Update runbooks with learnings

When in doubt, reference the comprehensive documentation in the `references/` directory or consult relevant team agents.
````

4. Verify Copilot reads the instructions by asking about project conventions

**Expected Outcome**: Copilot responses reflect project-specific instructions

**Reference**: Compare with `../lab-41-agentic-tools-deep-dive-solution/resources/photo-gallery-fullstack-solution/.github/copilot-instructions.md`

### Exercise B3: Create an Instruction (10 min)

**Objective**: Create path-specific coding instructions

1. Create the instructions directory:

```bash
mkdir -p .github/instructions
```

2. **Task**: Create an architecture instructions file scoped to **your chosen backend** stack — expand the matching block below:

▶ **NestJS (TypeScript)**

Create `.github/instructions/architecture-nestjs.instructions.md`:

````markdown
---
applyTo: 'apps/backend-nestjs/src/domain/**'
---

# Architecture Instructions

Follow guidelines from references/architecture.md when working with domain layer code.

## Key Points for Domain Layer

- **Technology Stack**: NestJS 11 backend, TypeORM with SQLite
- **Path**: `apps/backend-nestjs/src/domain/`
- **Entities**: Use TypeORM decorators (@Entity, @Column, @PrimaryGeneratedColumn)
- **Services**: Use @Injectable() decorator
- **Dependencies**: Domain layer should not depend on infrastructure

## Domain Layer Structure

```txt
apps/backend-nestjs/src/domain/
├── entities/
│ └── photo.entity.ts # TypeORM entity
├── models/
│ └── photo.model.ts # Domain interface
└── services/
└── photo.service.ts # Business logic
```

## Photo Entity Example

```typescript
@Entity('photos')
export class PhotoEntity {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  filename: string;

  @Column({ name: 'stored_filename', unique: true })
  storedFilename: string;

  @Column()
  url: string;

  @Column()
  size: number;

  @Column('simple-json')
  tags: string[];

  @CreateDateColumn({ name: 'created_at' })
  createdAt: Date;
}
```

## Validation Constraints

- Max file size: **5MB**
- Supported formats: JPEG, PNG, GIF, WebP
- Tags: lowercase alphanumeric with hyphens, max 20 tags, max 30 chars each

See [references/architecture.md](../references/architecture.md) for complete architecture documentation.
````

▶ **Spring Boot (Java 17)**

Create `.github/instructions/architecture-spring.instructions.md`:

````markdown
---
applyTo: 'apps/backend-spring/src/main/java/com/photogallery/backend/domain/**'
---

# Architecture Instructions

Follow guidelines from references/architecture.md when working with domain layer code.

## Key Points for Domain Layer

- **Technology Stack**: Spring Boot 3 (Java 17), Spring Data JPA with SQLite
- **Path**: `apps/backend-spring/src/main/java/com/photogallery/backend/domain/`
- **Domain Model**: `Photo` is a plain Java `record` — no persistence annotations
- **Services**: Use `@Service`-annotated classes with constructor injection
- **Dependencies**: Domain layer should not depend on infrastructure — persistence (JPA entity, repository over `PhotoEntity`) is mapped in a `toDomain()` converter

## Domain Layer Structure

```txt
apps/backend-spring/src/main/java/com/photogallery/backend/domain/
├── model/
│ └── Photo.java # Plain record, no annotations
├── repository/
│ └── PhotoRepository.java # Spring Data JPA interface
└── service/
└── PhotoService.java # Business logic
```

## Photo Domain Model Example

```java
public record Photo(
        String id,
        String filename,
        String storedFilename,
        String url,
        long size,
        List<String> tags,
        Instant createdAt
) {
    public Photo {
        Objects.requireNonNull(filename, "filename");
        Objects.requireNonNull(storedFilename, "storedFilename");
        Objects.requireNonNull(url, "url");
        tags = tags == null ? List.of() : List.copyOf(tags);
    }
}
```

## Validation Constraints

- Max file size: **5MB**
- Supported formats: JPEG, PNG, GIF, WebP
- Tags: lowercase alphanumeric with hyphens, max 20 tags, max 30 chars each

See [references/architecture.md](../references/architecture.md) for complete architecture documentation.
````

▶ **FastAPI (Python 3.12)**

Create `.github/instructions/architecture-fastapi.instructions.md`:

````markdown
---
applyTo: 'apps/backend-fastapi/app/domain/**'
---

# Architecture Instructions

Follow guidelines from references/architecture.md when working with domain layer code.

## Key Points for Domain Layer

- **Technology Stack**: FastAPI backend (Python 3.12), SQLModel with SQLite
- **Path**: `apps/backend-fastapi/app/domain/`
- **Domain Model**: `Photo` is a Pydantic `BaseModel` with `alias_generator=to_camel` and `populate_by_name=True` — keep snake_case in Python, camelCase in JSON
- **Services**: Plain classes with constructor-injected `Session`
- **Dependencies**: Domain layer should not depend on infrastructure — the SQLModel `PhotoEntity` lives in `infrastructure/entities.py` and is mapped to `Photo` in the service

## Domain Layer Structure

```txt
apps/backend-fastapi/app/domain/
├── __init__.py
├── models.py # Pydantic domain/response model
└── services.py # Business logic
```

## Photo Domain Model Example

```python
class Photo(BaseModel):
    """Photo response payload."""
    model_config = ConfigDict(
        alias_generator=_to_camel,
        populate_by_name=True,
        from_attributes=True,
    )
    id: str
    filename: str
    stored_filename: str
    url: str
    size: int
    tags: list[str] = Field(default_factory=list)
    created_at: datetime
```

## Validation Constraints

- Max file size: **5MB**
- Supported formats: JPEG, PNG, GIF, WebP
- Tags: lowercase alphanumeric with hyphens, max 20 tags, max 30 chars each

See [references/architecture.md](../references/architecture.md) for complete architecture documentation.
````

▶ **.NET (C#)**

Create `.github/instructions/architecture-dotnet.instructions.md`:

````markdown
---
applyTo: 'apps/backend-dotnet/Domain/**'
---

# Architecture Instructions

Follow guidelines from references/architecture.md when working with domain layer code.

## Key Points for Domain Layer

- **Technology Stack**: ASP.NET Core 8 backend (C# 12), Entity Framework Core 8 with SQLite
- **Path**: `apps/backend-dotnet/Domain/`
- **Domain Model**: `Photo` is a plain mutable class with auto-properties — no EF Core attributes
- **Services**: Classes implementing an interface (e.g. `IPhotoService`), constructor-injected `IPhotoRepository`
- **Dependencies**: Domain layer should not depend on infrastructure — the EF Core `PhotoEntity` and `AppDbContext` live in `Infrastructure/`

## Domain Layer Structure

```txt
apps/backend-dotnet/Domain/
├── Models/
│ └── Photo.cs # Plain class, no attributes
├── Repositories/
│ └── IPhotoRepository.cs # Repository port
└── Services/
├── IPhotoService.cs
└── PhotoService.cs # Business logic
```

## Photo Domain Model Example

```csharp
public class Photo
{
    public int Id { get; set; }
    public string Filename { get; set; } = string.Empty;
    public string StoredFilename { get; set; } = string.Empty;
    public string Url { get; set; } = string.Empty;
    public long Size { get; set; }
    public List<string> Tags { get; set; } = new();
    public DateTime CreatedAt { get; set; }
}
```

## Validation Constraints

- Max file size: **5MB**
- Supported formats: JPEG, PNG, GIF, WebP
- Tags: lowercase alphanumeric with hyphens, max 20 tags, max 30 chars each

See [references/architecture.md](../references/architecture.md) for complete architecture documentation.
````

▶ **Gin (Go)**

Create `.github/instructions/architecture-gin.instructions.md`:

````markdown
---
applyTo: 'apps/backend-gin/internal/domain/**'
---

# Architecture Instructions

Follow guidelines from references/architecture.md when working with domain layer code.

## Key Points for Domain Layer

- **Technology Stack**: Gin backend (Go 1.23), GORM with SQLite
- **Path**: `apps/backend-gin/internal/domain/`
- **Domain Model**: `Photo` is a plain struct — no `json:`/`gorm:` tags
- **Services**: Plain structs constructed via `NewPhotoService(repo PhotoRepository)`, depending on a `PhotoRepository` interface
- **Dependencies**: Domain layer should not depend on infrastructure — the GORM entity lives in `internal/infrastructure/`

## Domain Layer Structure

```txt
apps/backend-gin/internal/domain/
├── photo.go # Plain struct, no tags
└── service.go # Business logic
```

## Photo Domain Model Example

```go
type Photo struct {
	ID             string
	Filename       string
	StoredFilename string
	URL            string
	Size           int64
	Tags           []string
	CreatedAt      time.Time
}
```

## Validation Constraints

- Max file size: **5MB**
- Supported formats: JPEG, PNG, GIF, WebP
- Tags: lowercase alphanumeric with hyphens, max 20 tags, max 30 chars each

See [references/architecture.md](../references/architecture.md) for complete architecture documentation.
````

3. **Test it**: Edit a file in your chosen backend's domain layer and observe how Copilot suggestions follow the domain-specific patterns

**Expected Outcome**: Copilot suggestions respect path-specific conventions

**Reference**: Compare with `../lab-41-agentic-tools-deep-dive-solution/resources/photo-gallery-fullstack-solution/.github/instructions/` — compare against the file matching your chosen backend stack (`architecture-<stack>.instructions.md`)

▶ **💡 Alternative way to create a coding instruction in GitHub Copilot**

Instead of writing the file manually, use the GitHub Copilot CLI interactive instruction wizard. Inside a Copilot session, run:

```bash
/instruction
```

Select **"Create New Instruction..."** and follow the on-screen prompts — Copilot asks for the project location and whether to create the instruction manually or with Copilot assistance, then generates `.github/instructions/<name>.instructions.md` automatically.

### Exercise B4: Create a Prompt (10 min)

**Objective**: Create a code reviewer prompt

1. Create the prompts directory:

```bash
mkdir -p .github/prompts
```

2. **Task**: Create `.github/prompts/code-reviewer.prompt.md`:

````markdown
---
description: Analyze code changes (diff) and generate actionable code review comments aligned with team standards
tools: ['search/codebase']
---

# /code-reviewer

Analyze code changes (diff) and generate actionable code review comments aligned with team standards.

## Purpose

Assist code reviewers by:

- Identifying potential bugs, security issues, and performance problems
- Flagging violations of team coding standards and architectural patterns
- Suggesting improvements for readability and maintainability
- Highlighting risks that require extra scrutiny

## Usage

Invoke this command when reviewing a pull request or code changes:

```txt
/code-reviewer
```

The command will analyze the current git diff (staged or unstaged changes) and generate review comments.

## Output Format

The command will produce review comments organized by:

1. **Critical Issues**: Bugs, security vulnerabilities, breaking changes (must fix)
2. **Architectural Concerns**: Pattern violations, coupling issues (should fix)
3. **Code Quality**: Readability, maintainability, test coverage (nice to have)
4. **Suggestions**: Performance optimizations, refactoring opportunities (optional)

Each comment includes:

- **File and line reference**
- **Severity**: Critical / High / Medium / Low
- **Category**: Bug / Security / Architecture / Style / Performance
- **Description**: What the issue is and why it matters
- **Recommendation**: Specific action to address the issue

## Activation Triggers

- Reference `coding-standards.md` for team conventions
- Reference `architecture.md` for architectural patterns
- Apply `change-impact-analysis` skill to assess risk
- Reference `testing-guidelines.md` for test coverage standards

## Configuration

You can customize review focus:

```txt
/code-reviewer --focus security
/code-reviewer --focus performance
/code-reviewer --strict (enforce all standards)
```

You provide constructive, actionable feedback that helps developers improve code quality while learning team standards.
````

3. **Test it**: In Copilot Chat, invoke the prompt with `#` prefix:

```txt
#code-reviewer
```

**Note**: Prompts use the `#` prefix in Copilot Chat (e.g., `#code-reviewer`), which is different from slash commands (`/command`). Prompts are typically referenced within agents and instructions rather than invoked standalone. You can test a prompt directly in chat, but in practice, the `/code-reviewer` command from Exercise B3 (if implemented) would invoke this prompt.

**Expected Outcome**: Structured code review output with organized findings by severity (Critical, High, Medium, Low)

**Reference**: Compare with `../lab-41-agentic-tools-deep-dive-solution/resources/photo-gallery-fullstack-solution/.github/prompts/code-reviewer.prompt.md`

▶ **💡 Alternative way to create a prompt in GitHub Copilot**

Instead of writing the file manually, use the GitHub Copilot CLI interactive prompt wizard. Inside a Copilot session, run:

```txt
/prompt
```

Select **"Create New Prompt..."** and follow the on-screen prompts — Copilot asks for the project location and whether to create the prompt manually or with Copilot assistance, then generates `.github/prompts/<name>.prompt.md` automatically.

### Exercise B5: Create a Custom Agent (15 min)

**Objective**: Create an architecture guardian agent

1. Create the agents directory:

```bash
mkdir -p .github/agents
```

2. **Task**: Create `.github/agents/architecture-guardian.agent.md`:

```markdown
---
name: architecture-guardian
description: Validates design decisions against team architectural patterns and ensures alignment with system topology
---

# Architecture Guardian

You are the **Architecture Guardian** for the photo-gallery project. Your role is to ensure all code changes align with established architectural patterns, maintain system integrity, and follow documented design principles.

## Core Responsibilities

- **Validate Design Decisions**: Review proposed architectural changes against `architecture.md` and ensure alignment with system topology
- **Identify Violations**: Flag deviations from established patterns, anti-patterns, and architectural debt
- **Suggest Refactoring**: Recommend improvements that align with team conventions and long-term maintainability
- **Maintain Boundaries**: Enforce module boundaries and prevent tight coupling between layers
- **Review Dependencies**: Assess impact of new dependencies and ensure they fit architectural vision

## Context Files

You have access to the following knowledge references:

- **architecture.md**: System topology, module boundaries, data flow patterns
- **coding-standards.md**: Team conventions, naming patterns, file organization
- **domain-glossary.md**: Business terminology and domain model definitions

## Interaction Guidelines

When consulted, you should:

1. **Assess Context**: Understand the scope and intent of the proposed change
2. **Reference Standards**: Cite specific sections from architecture.md or coding-standards.md
3. **Evaluate Trade-offs**: Explain pros/cons of different architectural approaches
4. **Provide Specific Recommendations**: Give actionable guidance with code examples where applicable
5. **Flag Risks**: Identify potential scalability, performance, or maintainability concerns

## Example Invocations

- "Should this new feature live in the `api` module or `domain` module?"
- "Is it acceptable to add a direct dependency from `ui` to `storage`?"
- "What's the recommended pattern for handling cross-cutting concerns?"
- "Validate this component structure against our architecture guidelines"

## Decision Framework

When multiple valid approaches exist, prioritize:

1. **Consistency** with existing patterns
2. **Maintainability** and readability
3. **Testability** and isolation
4. **Performance** (only when measurable impact exists)
5. **Future extensibility**

You are an advisor, not a gatekeeper. Provide reasoned guidance but acknowledge when trade-offs are acceptable given project constraints.
```

3. **Test it**:

```txt
@architecture-guardian I want to add a photo filter feature. Should this go in the API layer or domain layer?
```

**Expected Outcome**: Agent provides architecture-based recommendation

**Reference**: Compare with `../lab-41-agentic-tools-deep-dive-solution/resources/photo-gallery-fullstack-solution/.github/agents/architecture-guardian.agent.md`

▶ **💡 Alternative way to create a custom agent in GitHub Copilot**

Instead of writing the file manually, use the GitHub Copilot CLI interactive agent wizard. Inside a Copilot session, run:

```txt
/agent
```

Select **"Create New Agent..."** and follow the on-screen prompts — Copilot asks for the project location and whether to create the agent manually or with Copilot assistance, then generates `.github/agents/<name>.agent.md` automatically.

### Exercise B6: Use /delegate for Background Agents (15 min)

**Objective**: Submit async tasks with `/delegate` and run parallel agents with `/fleet`

`/delegate` sends a task to a background coding agent that works independently — checking out a new branch, making changes, and opening a pull request while you continue working. `/fleet` runs multiple subagents in parallel within your current session.

**Part 1 — Background agent with /delegate**

1. Submit a background task to write unit tests:

```txt
/delegate Write unit tests for PhotoService covering the upload, getAll, and getById methods. Create tests in apps/backend-nestjs/src/domain/services/photo.service.spec.ts following existing test patterns.
```

2. Monitor the delegated task:

```txt
/delegate status
```

3. When complete, review the generated branch and pull request from the GitHub interface.

**Part 2 — Parallel subagents with /fleet**

4. Run parallel agents to review different parts of the codebase simultaneously:

```txt
/fleet
  - Review apps/backend-nestjs/ for NestJS best practices and potential security issues
  - Review apps/frontend/ for Angular standalone component conventions
  - Check all *.spec.ts files for missing test coverage
```

**Expected Outcome**: `/delegate` creates a background PR with unit tests on a new branch. `/fleet` runs three parallel subagents and returns consolidated results from all three.

**Note**: `/delegate` requires GitHub authentication and a connected repository to create pull requests. `/fleet` works locally within the session with no additional setup.

### Exercise B7: Create an Agent Skill (10 min)

**Objective**: Create a change impact analysis skill

1. Create the skills directory:

```bash
mkdir -p .github/skills/change-impact-analysis
```

2. **Task**: Create `.github/skills/change-impact-analysis/SKILL.md`:

```markdown
---
name: change-impact-analysis
description: Assess the scope and risk of proposed code changes by analyzing affected components, blast radius, and potential side effects. Use when reviewing pull requests, planning large refactorings, assessing deployment readiness, or evaluating rollback complexity.
---

# Change Impact Analysis Skill

## Purpose

Assess the scope and risk of proposed code changes by analyzing affected components, blast radius, and potential side effects. This skill helps teams make informed decisions about change safety.

## Capabilities

### 1. Blast Radius Assessment

- Quantify how many files, modules, and services are affected
- Categorize changes by risk level (low/medium/high/critical)
- Identify cascading effects of a change

### 2. Risk Scoring

- Calculate risk based on change size, complexity, and affected components
- Flag high-risk changes requiring extra review or testing
- Recommend mitigation strategies proportional to risk

### 3. Side Effect Detection

- Identify unintended consequences of changes
- Flag performance implications
- Detect security or compliance impacts

## Usage Context

This skill activates when:

- Reviewing pull requests for approval
- Planning large refactorings or migrations
- Assessing deployment readiness
- Evaluating rollback complexity

## Knowledge Sources

- **testing-guidelines.md**: Test coverage requirements by risk level
- **architecture.md**: Critical paths and high-risk components
- **Git history**: Past incidents correlated with similar changes

## Risk Assessment Framework

### Risk Factors

| Factor             | Weight | Criteria                                                                                  |
| ------------------ | ------ | ----------------------------------------------------------------------------------------- |
| **Lines Changed**  | 20%    | <50 (low) / 50-200 (med) / 200-500 (high) / >500 (critical)                               |
| **Files Affected** | 15%    | <5 (low) / 5-10 (med) / 10-20 (high) / >20 (critical)                                     |
| **Test Coverage**  | 25%    | >80% (low) / 60-80% (med) / 40-60% (high) / <40% (critical)                               |
| **Critical Path**  | 30%    | Not on critical path (low) / Near critical (med) / On critical path (high)                |
| **Rollback Ease**  | 10%    | Easy revert (low) / Config change (med) / DB migration (high) / Data loss risk (critical) |

### Risk Categories

**LOW RISK** (Score: 0-30): Small, isolated changes with high test coverage and easy rollback

**MEDIUM RISK** (Score: 31-60): Moderate scope changes with adequate test coverage

**HIGH RISK** (Score: 61-85): Large scope or critical path changes with test coverage gaps

**CRITICAL RISK** (Score: 86-100): Changes to security/data integrity systems with insufficient testing

## Metrics

Success criteria for impact analysis:

- ✅ Accurately classifies 90%+ of changes by risk
- ✅ Zero high-risk changes deployed without appropriate safeguards
- ✅ Reduces production incidents by 30% through better risk assessment
```

**Expected Outcome**: Valid SKILL.md file that works across platforms

**Reference**: Compare with `../lab-41-agentic-tools-deep-dive-solution/resources/photo-gallery-fullstack-solution/.github/skills/change-impact-analysis/SKILL.md`

### Exercise B8: Install a Skill from Public Registry (10 min)

**Objective**: Search for and install a community skill from the Tessl registry

1. **Task**: Search for the `skill-creator` skill:

```bash
npx -y skills find skill-creator
```

2. Install it locally:

```bash
npx -y skills add https://github.com/anthropics/skills --skill skill-creator
```

3. Move the installed skill to `.github/skills/skill-creator/`

4. **Test it** in Copilot Chat to verify the skill is detected

**Expected Outcome**: Community skill installed and available for Copilot

**Note**: Public registries like [tessl.io/registry](https://tessl.io/registry) and [skills.sh](https://skills.sh/) provide community-created skills that work across all SKILL.md-compatible platforms.

### Exercise B9: Evaluate an Agent Skill (10 min)

**Objective**: Use Tessl CLI combined with GitHub Copilot to iteratively improve the skill quality until it reaches a 100% score

> **Notes: A Tessl account is now required to review skills. Register once at https://tessl.io/login?returnPathname=%2Fregistry**

1. **Log in to Tessl** (one-time; skip if already authenticated):

```bash
npx --yes tessl login
```

This opens a browser to authenticate — required before `tessl review run` will work (verify anytime with `npx --yes tessl whoami`).

2. **Run the initial Tessl skill review**:

```bash
npx --yes tessl review run .github/skills/change-impact-analysis/SKILL.md
```

3. **Ask GitHub Copilot to improve the skill until the score reaches 100%**:

```txt
Run `npx --yes tessl review run .github/skills/change-impact-analysis/SKILL.md` and analyze the output.
Then improve the SKILL.md file based on the quality score, impact score, and improvement suggestions reported.
Repeat — run the review again, apply further improvements — until the reported score is 100%.
```

4. **Validate the final score** — re-run the review one last time to confirm the 100% score:

```bash
npx --yes tessl review run .github/skills/change-impact-analysis/SKILL.md
```

**Expected Outcome**: SKILL.md reaches a 100% quality score as reported by Tessl CLI

**Reference**: https://tessl.io/registry/skills/submit

### Exercise B10: Configure Hooks (15 min)

**Objective**: Set up pre-commit validation hooks

1. Create the hooks directory:

```bash
mkdir -p .github/hooks/scripts
```

2. **Task**: Create `.github/hooks/code-reviewer.json`:

```json
{
  "version": 1,
  "description": "Run code-reviewer on staged files for git commits",
  "hooks": {
    "preToolUse": [
      {
        "type": "command",
        "bash": ".github/hooks/scripts/validate-commit.sh",
        "powershell": ".github/hooks/scripts/validate-commit.ps1",
        "env": { "REVIEW_MODE": "strict" },
        "timeoutSec": 15
      }
    ]
  }
}
```

3. Create the validation script `.github/hooks/scripts/validate-commit.sh`:

```bash
#!/usr/bin/env bash
echo "Validating staged files..."
# Add validation logic here
exit 0
```

4. Make the script executable: `chmod +x .github/hooks/scripts/validate-commit.sh`

▶ **Windows (PowerShell) — validate-commit.ps1**

On Windows, skip `chmod +x`. Create `.github/hooks/scripts/validate-commit.ps1` instead of (or alongside) the bash script:

```powershell
# GitHub Copilot preToolUse hook: Validate git commit commands
# Checks if this is a git commit and validates staged files follow coding standards

$input = $input | ConvertFrom-Json
$command = $input.command

# Only process git commit commands
if ($command -notmatch "^git\s+commit") {
    exit 0
}

Write-Host "🔍 Running code-reviewer on staged files..."

# Get list of staged files
$stagedFiles = git diff --cached --name-only 2>$null

if (-not $stagedFiles) {
    Write-Host "⚠️ No staged files found for commit" -ForegroundColor Yellow
    exit 0
}

$violations = @()

foreach ($file in $stagedFiles) {
    if (-not (Test-Path $file)) { continue }

    # Check TypeScript/JavaScript files
    if ($file -match "\.(ts|tsx|js|jsx)$") {
        $content = Get-Content $file -Raw -ErrorAction SilentlyContinue

        # Check for console.log statements
        if ($content -match "console\.log") {
            $violations += "- $file: contains console.log statements"
        }

        # Check for any type usage
        if ($content -match ": any") {
            $violations += "- $file: avoid using 'any' type"
        }
    }
}

if ($violations.Count -gt 0) {
    Write-Host "⚠️ Coding standards violations found:" -ForegroundColor Yellow
    $violations | ForEach-Object { Write-Host $_ -ForegroundColor Yellow }
    exit 2
}

Write-Host "✅ Staged files pass coding standards check" -ForegroundColor Green
exit 0
```

The hook JSON already includes `"powershell": ".github/hooks/scripts/validate-commit.ps1"`, so it is automatically picked up on Windows.

**Expected Outcome**: Hook configuration with cross-platform script support

**Reference**: Compare with `../lab-41-agentic-tools-deep-dive-solution/resources/photo-gallery-fullstack-solution/.github/hooks/code-reviewer.json`

### Exercise B11: Create a Plugin (15 min)

**Objective**: Create a team-workflows plugin for GitHub Copilot

GitHub Copilot plugins bundle agents and prompts under a shared namespace, making team workflows portable and installable across sessions. This mirrors the Claude Code plugin from Exercise A10 — same concepts, adapted to Copilot conventions (`.agent.md` files, `.prompt.md` files, `plugin.json` at the plugin root — unlike Claude Code which places the manifest in a `.claude-plugin/` subdirectory).

1. Create the plugin directory structure:

```bash
mkdir -p .github/plugins/team-workflows/prompts
mkdir -p .github/plugins/team-workflows/agents
```

2. Create the plugin manifest `.github/plugins/team-workflows/plugin.json`:

```json
{
  "name": "team-workflows",
  "version": "1.0.0",
  "description": "Team workflow automation plugin",
  "author": { "name": "Your Team" },
  "license": "MIT",
  "agents": "agents/",
  "skills": "skills/",
  "hooks": "hooks.json"
}
```

3. Add an agent `.github/plugins/team-workflows/agents/dependency-tracker.agent.md`:

````markdown
---
name: dependency-tracker
description: Monitors dependency health, detects outdated or vulnerable packages, assesses compatibility risks, and guides safe dependency updates for the photo-gallery project.
---

# Dependency Tracker Agent

You are a dependency management specialist for the photo-gallery project (Angular frontend + your chosen backend stack, Nx monorepo). Your role is to proactively monitor dependency health, identify risks, and guide safe updates.

## Responsibilities

### Dependency Health Monitoring

- Identify outdated dependencies with available updates
- Detect packages with known security vulnerabilities (CVEs)
- Flag deprecated packages that need replacement
- Monitor peer dependency compatibility

### Update Risk Assessment

- Classify updates as patch/minor/major with associated risk levels
- Identify breaking changes from changelogs and migration guides
- Map which source files will be affected by each update

### Update Planning

- Suggest update order to minimize cascading failures
- Provide step-by-step migration instructions for major updates
- Estimate rollback complexity for each update

## Invocation Patterns

```txt
@dependency-tracker Check if any dependencies have security vulnerabilities
@dependency-tracker What's the safest order to update our Angular dependencies?
@dependency-tracker Assess the risk of updating our backend's ORM library to its next major version
```

## Integration

- Works alongside `/team-workflows:analyze-dependencies` command
- Feeds data to `@architecture-guardian` for boundary validation
````

4. Add a command `.github/plugins/team-workflows/prompts/analyze-dependencies.prompt.md` with the following content:

````markdown
---
description: Analyze project dependencies to identify outdated packages, security vulnerabilities, unused dependencies, and compatibility issues
tools: ['search/codebase']
---

# Analyze Dependencies Command

**Invocation**: `/team-workflows:analyze-dependencies [options]`

## Purpose

Analyze project dependencies to identify:

- Outdated packages and available updates
- Security vulnerabilities in dependencies
- Unused dependencies that can be removed
- Dependency conflicts and compatibility issues
- License compliance concerns

## Options

- `--scope <value>`: Analyze "prod", "dev", or "all" dependencies (default: "all")
- `--format <value>`: Output format "table", "json", or "markdown" (default: "table")
- `--security-only`: Only show security vulnerabilities
- `--outdated-only`: Only show outdated packages

## Behavior

1. Parse package.json and lock files
2. Check each dependency against npm registry for latest versions
3. Consult security databases (npm audit, Snyk, etc.) for vulnerabilities
4. Analyze dependency tree for conflicts
5. Generate actionable report with update recommendations

## Output Format

```markdown
# Dependency Analysis Report

Outdated Packages (5):
├─ react: 17.0.2 → 18.2.0 (Major update available)
├─ typescript: 5.0.0 → 5.3.3 (Patch update available)
└─ ...

Security Vulnerabilities (2):
├─ [HIGH] lodash@4.17.20: Prototype Pollution
│ Fix: Update to lodash@4.17.21
└─ [MEDIUM] axios@0.21.1: Server-Side Request Forgery
Fix: Update to axios@1.6.0

Unused Dependencies (3):
├─ moment (not imported anywhere)
├─ ...

Recommended Actions:

1. Run: npm update typescript
2. Run: npm install lodash@4.17.21
3. Run: npm uninstall moment
```
````

5. **Load the plugin for this session**:

```bash
copilot --plugin-dir .github/plugins/team-workflows
```

6. Inside the Copilot session, run the plugin command to verify it loaded:

```txt
/team-workflows:analyze-dependencies
```

**Expected Outcome**: GitHub Copilot starts with the plugin loaded and its commands available in the `/team-workflows:` namespace

▶ **💡 Persistent plugin loading**

`--plugin-dir` loads the plugin for one session only. To auto-load it in every session without the flag, install it permanently:

```bash
copilot plugin install .github/plugins/team-workflows
```

After that, the plugin loads automatically in every GitHub Copilot session in this project. To list all installed plugins:

```bash
copilot plugin list
```

**Reference**: Compare with `../lab-41-agentic-tools-deep-dive-solution/resources/photo-gallery-fullstack-solution/.github/plugins/team-workflows/`

---

▶ **Section C: Gemini CLI Exercises**

**Platform**: Gemini CLI
**Reference configs**: `../lab-41-agentic-tools-deep-dive-solution/resources/photo-gallery-fullstack-solution/.gemini/`

### Exercise C1: Initialize GEMINI.md (10 min)

**Objective**: Create the project context file for Gemini CLI using `/init`

`GEMINI.md` is automatically loaded by Gemini CLI at session start — it provides project-specific instructions, architecture rules, and conventions that apply globally to all sessions.

1. Run `/init` to analyze the project and auto-generate a `GEMINI.md`:

```txt
/init
```

Gemini CLI scans the codebase and generates a `GEMINI.md` at the project root with detected patterns, dependencies, and suggested conventions.

2. Review the generated file and customize it. Your final `GEMINI.md` should include sections like:

```markdown
# Photo Gallery Project

## Architecture

- **Frontend**: Angular 18+ in `apps/frontend/`
- **Monorepo**: Nx workspace — run commands via `nx` or `npm run`
- **API**: REST API backend proxied via `proxy.conf.json` (see `apps/frontend/proxy.conf.json` for port details)

## Coding Standards

- TypeScript strict mode — no `any` types (frontend)
- Angular standalone components
- Spec files co-located with source files

## Available Commands

- `/code-reviewer` — AI-assisted code review aligned with team standards

## Configuration

See `.gemini/` for commands, hooks, skills, and settings.
```

Then add the **Backend** bullet, **Domain Rules**, and backend **Coding Standards** bullet matching your chosen stack — expand the matching block and merge its lines into the sections above:

▶ **NestJS (TypeScript)**

```markdown
- **Backend**: NestJS in `apps/backend-nestjs/` <!-- add to ## Architecture -->

## Domain Rules

- Domain layer (`apps/backend-nestjs/src/domain/`) must NOT depend on infrastructure layer
- All business logic belongs in domain services
- Use TypeORM decorators for entities

- NestJS patterns: modules, controllers, services, DTOs <!-- add to ## Coding Standards -->
```

▶ **Spring Boot (Java 17)**

```markdown
- **Backend**: Spring Boot in `apps/backend-spring/` <!-- add to ## Architecture -->

## Domain Rules

- Domain layer (`apps/backend-spring/src/main/java/com/photogallery/backend/domain/`) must NOT depend on infrastructure layer
- All business logic belongs in domain services
- Domain model (`Photo`) is a plain Java record — JPA annotations belong only on the infrastructure entity

- Spring Boot patterns: `@RestController`, `@Service`, `@Repository`, DTOs <!-- add to ## Coding Standards -->
```

▶ **FastAPI (Python 3.12)**

```markdown
- **Backend**: FastAPI in `apps/backend-fastapi/` <!-- add to ## Architecture -->

## Domain Rules

- Domain layer (`apps/backend-fastapi/app/domain/`) must NOT depend on infrastructure layer
- All business logic belongs in domain services
- Domain model (`Photo`) is a Pydantic `BaseModel` — SQLModel entities belong only in infrastructure

- FastAPI patterns: `APIRouter`, `Depends()`, Pydantic schemas <!-- add to ## Coding Standards -->
```

▶ **.NET (C#)**

```markdown
- **Backend**: ASP.NET Core in `apps/backend-dotnet/` <!-- add to ## Architecture -->

## Domain Rules

- Domain layer (`apps/backend-dotnet/Domain/`) must NOT depend on infrastructure layer
- All business logic belongs in domain services
- Domain model (`Photo`) is a plain class — EF Core attributes belong only on the infrastructure entity

- ASP.NET Core patterns: `[ApiController]`, DI via constructor, DTOs <!-- add to ## Coding Standards -->
```

▶ **Gin (Go)**

```markdown
- **Backend**: Gin in `apps/backend-gin/` <!-- add to ## Architecture -->

## Domain Rules

- Domain layer (`apps/backend-gin/internal/domain/`) must NOT depend on infrastructure layer
- All business logic belongs in domain services
- Domain model (`Photo`) is a plain struct — GORM tags belong only on the infrastructure entity

- Gin patterns: `Handler` structs, interface-based services, DTOs <!-- add to ## Coding Standards -->
```

3. Verify Gemini loads the file by opening a new Gemini CLI session in the project root and asking:

```
What do you know about this project?
```

**Expected Outcome**: `GEMINI.md` created at project root. Gemini automatically references these rules in every session without needing to re-explain the project architecture.

**Reference**: Compare with `../lab-41-agentic-tools-deep-dive-solution/resources/photo-gallery-fullstack-solution/GEMINI.md`

### Exercise C2: Create a Custom Agent (15 min) - Experimental

**Objective**: Create a subagent for architecture guidance

1. Create the Gemini directories:

```bash
mkdir -p .gemini/agents
```

2. **Task**: First, enable experimental agents in `.gemini/settings.json`:

```json
{
  "experimental": {
    "enableAgents": true
  }
}
```

3. Create the file `.gemini/agents/architecture-guardian.md`, using the version that matches **your chosen backend** — expand the matching block below:

▶ **NestJS (TypeScript)**

```yaml
---
name: architecture-guardian
description: Validates design decisions against team architectural patterns
kind: local
tools:
  - read_file
  - grep_search
  - list_directory
model: gemini-2.5-pro
temperature: 0.3
max_turns: 15
---

## Role

You are a senior architect advisor for the photo-gallery-fullstack project.

## Architecture Rules

- Frontend (Angular) communicates with Backend (NestJS) via REST API
- Domain layer must NOT depend on infrastructure layer
- All business logic belongs in domain services
- Use TypeORM decorators for entities

## Decision Framework

Consistency > Maintainability > Testability > Performance
```

▶ **Spring Boot (Java 17)**

```yaml
---
name: architecture-guardian
description: Validates design decisions against team architectural patterns
kind: local
tools:
  - read_file
  - grep_search
  - list_directory
model: gemini-2.5-pro
temperature: 0.3
max_turns: 15
---

## Role

You are a senior architect advisor for the photo-gallery-fullstack project.

## Architecture Rules

- Frontend (Angular) communicates with Backend (Spring Boot) via REST API
- Domain layer must NOT depend on infrastructure layer
- All business logic belongs in domain services
- Domain model (`Photo`) is a plain Java record — JPA annotations belong only on the infrastructure entity

## Decision Framework

Consistency > Maintainability > Testability > Performance
```

▶ **FastAPI (Python 3.12)**

```yaml
---
name: architecture-guardian
description: Validates design decisions against team architectural patterns
kind: local
tools:
  - read_file
  - grep_search
  - list_directory
model: gemini-2.5-pro
temperature: 0.3
max_turns: 15
---

## Role

You are a senior architect advisor for the photo-gallery-fullstack project.

## Architecture Rules

- Frontend (Angular) communicates with Backend (FastAPI) via REST API
- Domain layer must NOT depend on infrastructure layer
- All business logic belongs in domain services
- Domain model (`Photo`) is a Pydantic `BaseModel` — SQLModel entities belong only in infrastructure

## Decision Framework

Consistency > Maintainability > Testability > Performance
```

▶ **.NET (C#)**

```yaml
---
name: architecture-guardian
description: Validates design decisions against team architectural patterns
kind: local
tools:
  - read_file
  - grep_search
  - list_directory
model: gemini-2.5-pro
temperature: 0.3
max_turns: 15
---

## Role

You are a senior architect advisor for the photo-gallery-fullstack project.

## Architecture Rules

- Frontend (Angular) communicates with Backend (ASP.NET Core) via REST API
- Domain layer must NOT depend on infrastructure layer
- All business logic belongs in domain services
- Domain model (`Photo`) is a plain class — EF Core attributes belong only on the infrastructure entity

## Decision Framework

Consistency > Maintainability > Testability > Performance
```

▶ **Gin (Go)**

```yaml
---
name: architecture-guardian
description: Validates design decisions against team architectural patterns
kind: local
tools:
  - read_file
  - grep_search
  - list_directory
model: gemini-2.5-pro
temperature: 0.3
max_turns: 15
---

## Role

You are a senior architect advisor for the photo-gallery-fullstack project.

## Architecture Rules

- Frontend (Angular) communicates with Backend (Gin) via REST API
- Domain layer must NOT depend on infrastructure layer
- All business logic belongs in domain services
- Domain model (`Photo`) is a plain struct — GORM tags belong only on the infrastructure entity

## Decision Framework

Consistency > Maintainability > Testability > Performance
```

4. **Test it**: Invoke the agent explicitly:

```
@architecture-guardian Should photo filters be implemented in the API layer or domain layer?
```

**Expected Outcome**: The subagent provides architecture guidance using its isolated context

**Note**: Sub-agents are experimental in Gemini CLI. Enable with `enableAgents: true` in settings.json. They run in isolated context loops with their own tool permissions.

### Exercise C3: Create a Custom Command (15 min)

**Objective**: Create a code reviewer command in TOML format

1. Create the commands directory:

```bash
mkdir -p .gemini/commands
```

2. **Task**: Create `.gemini/commands/code-reviewer.toml`:

```toml
# Code Reviewer Command
# Invoked via: /code-reviewer

description = "Analyze code changes (diff) and generate actionable code review comments aligned with team standards."

prompt = """
You are a senior code reviewer for the photo-gallery project. Analyze the following code changes and generate actionable review comments.

## Instructions

1. First, get the current git diff:
!{git diff --staged}

If no staged changes, check unstaged changes:
!{git diff}

2. Reference the team coding standards:
@{.gemini/references/coding-standards.md}

3. Reference the architecture guidelines:
@{.gemini/references/architecture.md}

## Review Categories

Organize your feedback by priority:

1. **Critical Issues** (must fix): Bugs, security vulnerabilities, breaking changes
2. **Architectural Concerns** (should fix): Pattern violations, coupling issues
3. **Code Quality** (nice to have): Readability, maintainability, test coverage
4. **Suggestions** (optional): Performance optimizations, refactoring opportunities

## Output Format

For each issue, provide:
- File and line reference
- Severity: Critical / High / Medium / Low
- Category: Bug / Security / Architecture / Style / Performance
- Description: What the issue is and why it matters
- Recommendation: Specific action to address the issue
- Reference: Link to relevant standard from coding-standards.md or architecture.md

Arguments provided: {{args}}
"""
```

3. **Test it**:

```
/code-reviewer
```

**Expected Outcome**: TOML command executes with shell expansion and file inclusion

**Reference**: Compare with `../lab-41-agentic-tools-deep-dive-solution/resources/photo-gallery-fullstack-solution/.gemini/commands/code-reviewer.toml`

### Exercise C4: Create an Agent Skill (10 min)

**Objective**: Create a change impact analysis skill

1. Create the skills directory:

```bash
mkdir -p .gemini/skills/change-impact-analysis
```

2. **Task**: Create `.gemini/skills/change-impact-analysis/SKILL.md`:

```markdown
---
name: change-impact-analysis
description: Assess the scope and risk of proposed code changes by analyzing affected components, blast radius, and potential side effects. Use when reviewing pull requests, planning large refactorings, assessing deployment readiness, or evaluating rollback complexity.
---

# Change Impact Analysis Skill

## Purpose

Assess the scope and risk of proposed code changes by analyzing affected components, blast radius, and potential side effects. This skill helps teams make informed decisions about change safety.

## Capabilities

### 1. Blast Radius Assessment

- Quantify how many files, modules, and services are affected
- Categorize changes by risk level (low/medium/high/critical)
- Identify cascading effects of a change

### 2. Risk Scoring

- Calculate risk based on change size, complexity, and affected components
- Flag high-risk changes requiring extra review or testing
- Recommend mitigation strategies proportional to risk

### 3. Side Effect Detection

- Identify unintended consequences of changes
- Flag performance implications
- Detect security or compliance impacts

## Usage Context

This skill activates when:

- Reviewing pull requests for approval
- Planning large refactorings or migrations
- Assessing deployment readiness
- Evaluating rollback complexity

## Knowledge Sources

- **testing-guidelines.md**: Test coverage requirements by risk level
- **architecture.md**: Critical paths and high-risk components
- **Git history**: Past incidents correlated with similar changes

## Risk Assessment Framework

### Risk Factors

| Factor             | Weight | Criteria                                                                                  |
| ------------------ | ------ | ----------------------------------------------------------------------------------------- |
| **Lines Changed**  | 20%    | <50 (low) / 50-200 (med) / 200-500 (high) / >500 (critical)                               |
| **Files Affected** | 15%    | <5 (low) / 5-10 (med) / 10-20 (high) / >20 (critical)                                     |
| **Test Coverage**  | 25%    | >80% (low) / 60-80% (med) / 40-60% (high) / <40% (critical)                               |
| **Critical Path**  | 30%    | Not on critical path (low) / Near critical (med) / On critical path (high)                |
| **Rollback Ease**  | 10%    | Easy revert (low) / Config change (med) / DB migration (high) / Data loss risk (critical) |

### Risk Categories

**LOW RISK** (Score: 0-30): Small, isolated changes with high test coverage and easy rollback

**MEDIUM RISK** (Score: 31-60): Moderate scope changes with adequate test coverage

**HIGH RISK** (Score: 61-85): Large scope or critical path changes with test coverage gaps

**CRITICAL RISK** (Score: 86-100): Changes to security/data integrity systems with insufficient testing

## Metrics

Success criteria for impact analysis:

- ✅ Accurately classifies 90%+ of changes by risk
- ✅ Zero high-risk changes deployed without appropriate safeguards
- ✅ Reduces production incidents by 30% through better risk assessment
```

3. **Test it**: Ask about the impact of changing an interface

4. Verify skills are detected:

```bash
gemini skills list
```

**Expected Outcome**: Gemini uses the skill for impact analysis. `gemini skills list` shows the skill.

**Note**: You can also install skills from git repos with `gemini skills install <URL>` or link a local skill with `gemini skills link <path>`

**Reference**: Compare with `../lab-41-agentic-tools-deep-dive-solution/resources/photo-gallery-fullstack-solution/.gemini/skills/change-impact-analysis/SKILL.md`

### Exercise C5: Install a Skill from Public Registry (10 min)

**Objective**: Search for and install a community skill from the Tessl registry

1. **Task**: Search for the `skill-creator` skill:

```bash
npx -y skills find skill-creator
```

2. Install it locally:

```bash
npx -y skills add https://github.com/anthropics/skills --skill skill-creator
```

3. Move the installed skill to `.gemini/skills/skill-creator/`

4. Verify with Gemini CLI:

```bash
gemini skills list
```

**Expected Outcome**: Community skill installed and listed by `gemini skills list`

**Note**: Public registries like [tessl.io/registry](https://tessl.io/registry) and [skills.sh](https://skills.sh/) provide community-created skills that work across all SKILL.md-compatible platforms.

### Exercise C6: Evaluate an Agent Skill (10 min)

**Objective**: Use Tessl CLI combined with Gemini CLI to iteratively improve the skill quality until it reaches a 100% score

> **Notes: A Tessl account is now required to review skills. Register once at https://tessl.io/login?returnPathname=%2Fregistry**

1. **Log in to Tessl** (one-time; skip if already authenticated):

```bash
npx --yes tessl login
```

This opens a browser to authenticate — required before `tessl review run` will work (verify anytime with `npx --yes tessl whoami`).

2. **Run the initial Tessl skill review**:

```bash
npx --yes tessl review run .gemini/skills/change-impact-analysis/SKILL.md
```

3. **Ask Gemini CLI to improve the skill until the score reaches 100%**:

```
Run `npx --yes tessl review run .gemini/skills/change-impact-analysis/SKILL.md` and analyze the output.
Then improve the SKILL.md file based on the quality score, impact score, and improvement suggestions reported.
Repeat — run the review again, apply further improvements — until the reported score is 100%.
```

4. **Validate the final score** — re-run the review one last time to confirm the 100% score:

```bash
npx --yes tessl review run .gemini/skills/change-impact-analysis/SKILL.md
```

**Expected Outcome**: SKILL.md reaches a 100% quality score as reported by Tessl CLI

**Reference**: https://tessl.io/registry/skills/submit

### Exercise C7: Configure Hooks (20 min)

**Objective**: Set up hook validation with shell scripts

1. Create the hooks directory:

```bash
mkdir -p .gemini/hooks
```

2. **Task**: Create `.gemini/settings.json`:

```json
{
  "enableHooks": true,
  "hooks": {
    "BeforeTool": [
      {
        "matcher": "run_shell_command",
        "hooks": [
          {
            "name": "validate-commit",
            "type": "command",
            "command": ".gemini/hooks/validate-commit.sh",
            "timeout": 15000
          }
        ]
      }
    ],
    "AfterTool": [
      {
        "matcher": "write_file|replace",
        "hooks": [
          {
            "name": "validate-coding-standards",
            "type": "command",
            "command": ".gemini/hooks/validate-coding-standards.sh",
            "timeout": 10000
          }
        ]
      }
    ]
  }
}
```

3. Create the hook script `.gemini/hooks/validate-commit.sh`:

```bash
#!/usr/bin/env bash
input=$(cat)
command=$(echo "$input" | jq -r '.tool_input.command // ""')
if [[ ! "$command" =~ git[[:space:]]+commit ]]; then
  exit 0
fi

# Check for violations (console.log, TODO without ticket, etc.)
echo '{"systemMessage":"All commit checks passed"}'
exit 0
```

4. Make scripts executable: `chmod +x .gemini/hooks/*.sh`

▶ **Windows (PowerShell) — Gemini Hook Scripts**

On Windows, skip `chmod +x`. Create PowerShell equivalents of the hook scripts and update `.gemini/settings.json` to point to them.

**Update `.gemini/settings.json`** to use PowerShell commands on Windows:

```json
{
  "enableHooks": true,
  "hooks": {
    "BeforeTool": [
      {
        "matcher": "run_shell_command",
        "hooks": [
          {
            "name": "validate-commit",
            "type": "command",
            "command": "powershell -File .gemini/hooks/validate-commit.ps1",
            "timeout": 15000
          }
        ]
      }
    ],
    "AfterTool": [
      {
        "matcher": "write_file|replace",
        "hooks": [
          {
            "name": "validate-coding-standards",
            "type": "command",
            "command": "powershell -File .gemini/hooks/validate-coding-standards.ps1",
            "timeout": 10000
          }
        ]
      }
    ]
  }
}
```

**Create `.gemini/hooks/validate-commit.ps1`**:

```powershell
# Gemini CLI BeforeTool hook: Validate git commit commands

$inputData = [Console]::In.ReadToEnd() | ConvertFrom-Json
$command = $inputData.tool_input.command

# Only process git commit commands
if ($command -notmatch "git\s+commit") {
    exit 0
}

Write-Host "🔍 Running code-reviewer on all modified files..."

$filesToCheck = git diff HEAD --name-only 2>$null
if (-not $filesToCheck) {
    '{"systemMessage":"✅ No modified files to check"}' | Write-Host
    exit 0
}

$violations = @()

foreach ($file in $filesToCheck) {
    if (-not (Test-Path $file)) { continue }
    if ($file -match "\.(ts|tsx|js|jsx)$") {
        $content = Get-Content $file -Raw -ErrorAction SilentlyContinue
        if ($content -match "console\.log") { $violations += "- ${file}: contains console.log statements" }
        if ($content -match ": any") { $violations += "- ${file}: avoid using 'any' type" }
    }
}

if ($violations.Count -gt 0) {
    $reason = "Coding standards violations detected:`n" + ($violations -join "`n")
    @{ decision = "deny"; reason = $reason } | ConvertTo-Json -Compress | Write-Host
    exit 2
}

'{"systemMessage":"✅ Staged files pass coding standards check"}' | Write-Host
exit 0
```

**Create `.gemini/hooks/validate-coding-standards.ps1`**:

```powershell
# Gemini CLI AfterTool hook: Validate file changes against coding-standards.md

$inputData = [Console]::In.ReadToEnd() | ConvertFrom-Json
$filePath = $inputData.tool_input.file_path
$content = $inputData.tool_input.content

if (-not $filePath) { exit 0 }

# Only check TypeScript/JavaScript files
if ($filePath -notmatch "\.(ts|tsx|js|jsx)$") {
    '{"systemMessage":"⏭️ Skipped: Not a TS/JS file"}' | Write-Host
    exit 0
}

Write-Host "🔍 Validating against coding-standards.md..."

$violations = @()

if ($content -match "console\.log") {
    $violations += "- Remove console.log statements before committing"
}
if ($content -match ": any") {
    $violations += "- Avoid using 'any' type - use proper TypeScript types"
}
if ($content -match "TODO[^:(]") {
    $violations += "- TODO comments should reference a ticket (e.g., TODO(TICKET-123))"
}

if ($violations.Count -gt 0) {
    $violations | ForEach-Object { Write-Host $_ -ForegroundColor Yellow }
    '{"systemMessage":"⚠️ Review coding standards suggestions above"}' | Write-Host
} else {
    '{"systemMessage":"✅ File follows coding standards"}' | Write-Host
}

exit 0
```

> **Alternative**: If you have Git Bash or WSL installed, you can use the original `.sh` scripts unchanged and keep the bash paths in `settings.json`.

**Expected Outcome**: Hook scripts validate commits and coding standards

**Reference**: Compare with `../lab-41-agentic-tools-deep-dive-solution/resources/photo-gallery-fullstack-solution/.gemini/hooks/validate-commit.sh`

### Exercise C8: Explore Extensions (10 min)

**Objective**: Discover and install a Gemini CLI extension

1. **Task**: Browse the extension gallery:

   Visit https://geminicli.com/extensions/ to explore available extensions

2. Install an extension from GitHub:

```bash
gemini extensions install https://github.com/gemini-cli-extensions/workspace
```

3. List installed extensions:

```bash
gemini extensions list
```

4. (Optional) Create a new extension from template:

```bash
gemini extensions new my-extension
```

5. Explore the generated structure:

```
my-extension/
├── gemini-extension.json    # Manifest
├── commands/                # Custom commands (TOML)
├── hooks/                   # Hook definitions
├── skills/                  # Agent skills
├── agents/                  # Sub-agents (*.md)
└── GEMINI.md                # Context file
```

6. (Optional) Validate the extension:

```bash
gemini extensions validate ./my-extension
```

**Expected Outcome**: Understanding of how extensions bundle commands, hooks, skills, and agents into distributable packages

**CLI commands reference**: `gemini extensions install`, `list`, `new`, `validate`, `update`, `enable`, `disable`, `config`

**Note**: Gemini CLI has 557+ extensions in its gallery, including integrations with Figma, Jira, Stripe, and more

### Exercise C9: Configure Settings (10 min)

**Objective**: Complete the Gemini CLI settings configuration

1. **Task**: Update `.gemini/settings.json` to enable hooks and configure tool settings:

```json
{
  "enableHooks": true,
  "hooks": {
    "BeforeTool": [
      {
        "matcher": "run_shell_command",
        "hooks": [
          {
            "name": "validate-commit",
            "type": "command",
            "command": "$GEMINI_PROJECT_DIR/.gemini/hooks/validate-commit.sh",
            "description": "Run code-reviewer on staged files for git commits",
            "timeout": 15000
          }
        ]
      },
      {
        "matcher": "write_file",
        "hooks": [
          {
            "name": "validate-writes",
            "type": "command",
            "command": "$GEMINI_PROJECT_DIR/.gemini/hooks/validate-writes.sh",
            "description": "Validate file write operations for security patterns",
            "timeout": 10000
          }
        ]
      },
      {
        "matcher": "replace",
        "hooks": [
          {
            "name": "validate-writes",
            "type": "command",
            "command": "$GEMINI_PROJECT_DIR/.gemini/hooks/validate-writes.sh",
            "description": "Validate file write operations for security patterns",
            "timeout": 10000
          }
        ]
      }
    ],
    "AfterTool": [
      {
        "matcher": "write_file",
        "hooks": [
          {
            "name": "validate-coding-standards",
            "type": "command",
            "command": "$GEMINI_PROJECT_DIR/.gemini/hooks/validate-coding-standards.sh",
            "description": "Validate against coding-standards.md",
            "timeout": 10000
          }
        ]
      },
      {
        "matcher": "replace",
        "hooks": [
          {
            "name": "validate-coding-standards",
            "type": "command",
            "command": "$GEMINI_PROJECT_DIR/.gemini/hooks/validate-coding-standards.sh",
            "description": "Validate against coding-standards.md",
            "timeout": 10000
          }
        ]
      }
    ]
  }
}
```

**Expected Outcome**: Complete settings configuration with hooks enabled

**Reference**: Compare with `../lab-41-agentic-tools-deep-dive-solution/resources/photo-gallery-fullstack-solution/.gemini/settings.json`

---

▶ **Section D: Codex CLI Exercises**

**Platform**: OpenAI Codex CLI
**Reference configs**: `../lab-41-agentic-tools-deep-dive-solution/resources/photo-gallery-fullstack-solution/.codex/` and `../lab-41-agentic-tools-deep-dive-solution/resources/photo-gallery-fullstack-solution/AGENTS.md`

### Exercise D1: Initialize AGENTS.md (10 min)

**Objective**: Create the project context file for Codex CLI using `/init`

`AGENTS.md` is automatically loaded by Codex CLI at session start (once the project is trusted) — it provides project-specific instructions, architecture rules, and conventions that apply globally to all sessions.

1. Navigate to the project and trust it:

```bash
cd photo-gallery-fullstack
codex trust .
```

2. Run `/init` to analyze the project and auto-generate an `AGENTS.md`:

Codex CLI scans the codebase and generates an `AGENTS.md` at the project root with detected patterns, dependencies, and suggested conventions.

3. Review the generated file and customize it. Your final `AGENTS.md` should include sections like: **Architecture**, **Domain Rules**, **Coding Standards**, etc.

4. Verify Codex loads the file by opening a new Codex session in the project root and asking:

```txt
Describe the architecture of this photo gallery application
```

**Expected Outcome**: `AGENTS.md` created at project root. Codex automatically references these rules in every session without needing to re-explain the project architecture.

**Reference**: Compare with `../lab-41-agentic-tools-deep-dive-solution/resources/photo-gallery-fullstack-solution/AGENTS.md`

### Exercise D2: Create a Custom Agent (Subagent) (15 min)

**Objective**: Create a specialized review agent using TOML format

1. **Task**: Create the agent directory:

```bash
mkdir -p .codex/agents
```

▶ **Windows (PowerShell) equivalent**

```powershell
New-Item -ItemType Directory -Force -Path .codex/agents
```

2. Create `.codex/agents/architecture-guardian.toml`:

```toml
name = "architecture-guardian"
description = "Validates design decisions against team architectural patterns and ensures alignment with system topology"

developer_instructions = """
You are the Architecture Guardian for the photo-gallery project. Your role is to ensure all code changes align with established architectural patterns, maintain system integrity, and follow documented design principles.

## Core Responsibilities

- Validate Design Decisions: Review proposed architectural changes against architecture.md and ensure alignment with system topology
- Identify Violations: Flag deviations from established patterns, anti-patterns, and architectural debt
- Suggest Refactoring: Recommend improvements that align with team conventions and long-term maintainability
- Maintain Boundaries: Enforce module boundaries and prevent tight coupling between layers
- Review Dependencies: Assess impact of new dependencies and ensure they fit architectural vision

## Context Files

You have access to the following knowledge references:
- architecture.md: System topology, module boundaries, data flow patterns
- coding-standards.md: Team conventions, naming patterns, file organization
- domain-glossary.md: Business terminology and domain model definitions

## Interaction Guidelines

When consulted, you should:
1. Assess Context: Understand the scope and intent of the proposed change
2. Reference Standards: Cite specific sections from architecture.md or coding-standards.md
3. Evaluate Trade-offs: Explain pros/cons of different architectural approaches
4. Provide Specific Recommendations: Give actionable guidance with code examples where applicable
5. Flag Risks: Identify potential scalability, performance, or maintainability concerns

## Example Invocations

- "Should this new feature live in the api module or domain module?"
- "Is it acceptable to add a direct dependency from ui to storage?"
- "What's the recommended pattern for handling cross-cutting concerns?"
- "Validate this component structure against our architecture guidelines"

## Decision Framework

When multiple valid approaches exist, prioritize:
1. Consistency with existing patterns
2. Maintainability and readability
3. Testability and isolation
4. Performance (only when measurable impact exists)
5. Future extensibility

You are an advisor, not a gatekeeper. Provide reasoned guidance but acknowledge when trade-offs are acceptable given project constraints.
"""

model = "gpt-5-codex"
sandbox_mode = "read-only"
model_reasoning_effort = "high"
```

3. Configure agent settings in `.codex/config.toml`:

```toml
[agents]
max_threads = 4
max_depth = 1
job_max_runtime_seconds = 300
```

4. **Test it**: Start Codex and ask architecture questions:

```txt
@architecture-guardian Should this photo filter feature live in the api module or domain module?
```

**Expected Outcome**: Custom agents are loaded and can be delegated to for specialized tasks

**Reference**: Compare with `../lab-41-agentic-tools-deep-dive-solution/resources/photo-gallery-fullstack-solution/.codex/agents/`

### Exercise D3: Create an Agent Skill (10 min)

**Objective**: Create the change impact analysis skill

1. Create the skills directory:

```bash
mkdir -p .codex/skills/change-impact-analysis
```

2. **Task**: Create the file `.codex/skills/change-impact-analysis/SKILL.md`:

```markdown
---
name: change-impact-analysis
description: Assess the scope and risk of proposed code changes by analyzing affected components, blast radius, and potential side effects. Use when reviewing pull requests, planning large refactorings, assessing deployment readiness, or evaluating rollback complexity.
---

# Change Impact Analysis Skill

## Purpose

Assess the scope and risk of proposed code changes by analyzing affected components, blast radius, and potential side effects. This skill helps teams make informed decisions about change safety.

## Capabilities

### 1. Blast Radius Assessment

- Quantify how many files, modules, and services are affected
- Categorize changes by risk level (low/medium/high/critical)
- Identify cascading effects of a change

### 2. Risk Scoring

- Calculate risk based on change size, complexity, and affected components
- Flag high-risk changes requiring extra review or testing
- Recommend mitigation strategies proportional to risk

### 3. Side Effect Detection

- Identify unintended consequences of changes
- Flag performance implications
- Detect security or compliance impacts

## Usage Context

This skill activates when:

- Reviewing pull requests for approval
- Planning large refactorings or migrations
- Assessing deployment readiness
- Evaluating rollback complexity

## Knowledge Sources

- **testing-guidelines.md**: Test coverage requirements by risk level
- **architecture.md**: Critical paths and high-risk components
- **Git history**: Past incidents correlated with similar changes

## Risk Assessment Framework

### Risk Factors

| Factor             | Weight | Criteria                                                                                  |
| ------------------ | ------ | ----------------------------------------------------------------------------------------- |
| **Lines Changed**  | 20%    | <50 (low) / 50-200 (med) / 200-500 (high) / >500 (critical)                               |
| **Files Affected** | 15%    | <5 (low) / 5-10 (med) / 10-20 (high) / >20 (critical)                                     |
| **Test Coverage**  | 25%    | >80% (low) / 60-80% (med) / 40-60% (high) / <40% (critical)                               |
| **Critical Path**  | 30%    | Not on critical path (low) / Near critical (med) / On critical path (high)                |
| **Rollback Ease**  | 10%    | Easy revert (low) / Config change (med) / DB migration (high) / Data loss risk (critical) |

### Risk Categories

**LOW RISK** (Score: 0-30): Small, isolated changes with high test coverage and easy rollback

**MEDIUM RISK** (Score: 31-60): Moderate scope changes with adequate test coverage

**HIGH RISK** (Score: 61-85): Large scope or critical path changes with test coverage gaps

**CRITICAL RISK** (Score: 86-100): Changes to security/data integrity systems with insufficient testing

## Metrics

Success criteria for impact analysis:

- ✅ Accurately classifies 90%+ of changes by risk
- ✅ Zero high-risk changes deployed without appropriate safeguards
- ✅ Reduces production incidents by 30% through better risk assessment
```

3. **Test it**: Ask Codex:

```txt
$change-impact-analysis If I modify the PhotoRepository interface, what is the risk level?
```

**Expected Outcome**: Codex applies the skill to assess the change risk

**Reference**: Compare with `../lab-41-agentic-tools-deep-dive-solution/resources/photo-gallery-fullstack-solution/.codex/skills/change-impact-analysis/SKILL.md`

### Exercise D4: Install a Skill from Public Registry (10 min)

**Objective**: Search for and install a community skill from the Tessl registry

1. **Task**: Search for the `skill-creator` skill:

```bash
npx tessl search skill-creator
```

2. Install it locally:

```bash
npx tessl install anthropics/claude-plugins-official/skill-creator
```

3. Move the installed skill to `.codex/skills/skill-creator/`

4. **Test it** with explicit invocation:

```
$skill-creator "Help me create a skill for API documentation generation"
```

**Expected Outcome**: Community skill installed and invocable via `$skill-creator`

**Reference**: https://tessl.io/registry/skills/github/anthropics/claude-plugins-official/skill-creator

### Exercise D5: Evaluate an Agent Skill (10 min)

**Objective**: Use Tessl CLI combined with Codex CLI to iteratively improve the skill quality until it reaches a 100% score

> **Notes: A Tessl account is now required to review skills. Register once at https://tessl.io/login?returnPathname=%2Fregistry**

1. **Log in to Tessl** (one-time; skip if already authenticated):

```bash
npx --yes tessl login
```

This opens a browser to authenticate — required before `tessl review run` will work (verify anytime with `npx --yes tessl whoami`).

2. **Run the initial Tessl skill review**:

```bash
npx --yes tessl review run .codex/skills/change-impact-analysis/SKILL.md
```

3. **Ask Codex CLI to improve the skill until the score reaches 100%**:

```
Run `npx --yes tessl review run .codex/skills/change-impact-analysis/SKILL.md` and analyze the output.
Then improve the SKILL.md file based on the quality score, impact score, and improvement suggestions reported.
Repeat — run the review again, apply further improvements — until the reported score is 100%.
```

4. **Validate the final score** — re-run the review one last time to confirm the 100% score:

```bash
npx --yes tessl review run .codex/skills/change-impact-analysis/SKILL.md
```

**Expected Outcome**: SKILL.md reaches a 100% quality score as reported by Tessl CLI

**Reference**: https://tessl.io/registry/skills/submit

### Exercise D6: Configure Codex Rules (15 min)

**Objective**: Create Starlark-based rules for command allowlisting

Codex CLI uses Rules (`.rules` files written in Starlark) instead of hooks for command control. Rules statically define which commands are allowed, require approval, or are forbidden — evaluated at command invocation time without running any shell scripts.

1. Create the rules directory:

```bash
mkdir -p .codex/rules
```

2. Create `.codex/rules/project.rules`:

```python
# Codex CLI Rules — Starlark-based command policy
# Test with: codex execpolicy check --pretty --rules .codex/rules/project.rules -- <command>

def prefix_rule(ctx):
    cmd = ctx.command

    # Allow all npm/npx commands
    if cmd[:4] == "npm " or cmd[:4] == "npx ":
        return rule(
            decision = "allow",
            justification = "npm/npx commands are safe for this project",
        )

    # Allow all read-only git commands
    if cmd in ["git status", "git log", "git diff", "git show"]:
        return rule(
            decision = "allow",
            justification = "read-only git commands always allowed",
        )

    # Require approval for all other git commands
    if cmd[:4] == "git ":
        return rule(
            decision = "prompt",
            justification = "git write operations require review",
        )

    # Forbid destructive operations
    if "rm -rf" in cmd or "drop table" in cmd.lower():
        return rule(
            decision = "forbidden",
            justification = "destructive operations are not allowed",
        )

    return rule(decision = "prompt")
```

3. Test the rules:

```bash
# Should output: allow
codex execpolicy check --pretty --rules .codex/rules/project.rules -- "npm install"

# Should output: prompt
codex execpolicy check --pretty --rules .codex/rules/project.rules -- "git push"

# Should output: forbidden
codex execpolicy check --pretty --rules .codex/rules/project.rules -- "rm -rf node_modules"
```

4. Reference the rules in `.codex/config.toml`:

```toml
[rules]
files = [".codex/rules/project.rules"]
```

**Expected Outcome**: Rules enforce command policies statically. `npm install` is allowed immediately, `git push` requires approval, and `rm -rf` is forbidden. Rules are evaluated without running any external shell scripts.

**Note**: Codex Rules are Codex CLI's alternative to hooks (which Claude, Copilot, and Gemini use). Rules use Starlark (a Python-like language) and provide a static security boundary evaluated at command invocation time.

**Reference**: Compare with `../lab-41-agentic-tools-deep-dive-solution/resources/photo-gallery-fullstack-solution/.codex/rules/project.rules`

### Exercise D7: Configure Sandbox and Approvals (10 min)

**Objective**: Set up sandbox boundaries

1. **Task**: Add sandbox configuration to `.codex/config.toml`:

```toml
[sandbox_workspace_write]
writable_roots = ["apps/", "dist/", ".codex/"]
network_access = false
```

2. Understand approval policies:

| Policy       | Behavior                    |
| ------------ | --------------------------- |
| `untrusted`  | Ask for every action        |
| `on-failure` | Ask only when command fails |
| `on-request` | Ask for write operations    |
| `never`      | Execute everything          |

3. **Test it**: Try modifying a file outside writable_roots

**Expected Outcome**: Sandbox restricts writes to configured directories

### Exercise D8: Configure Profiles (15 min)

**Objective**: Set up named configuration profiles

1. **Task**: Create `.codex/config.toml`:

```toml
model = "gpt-5-codex"
approval_policy = "on-request"
sandbox_mode = "workspace-write"
model_reasoning_effort = "medium"

[profiles.deep-review]
model = "gpt-5-pro"
model_reasoning_effort = "high"
approval_policy = "on-request"

[profiles.lightweight]
model = "gpt-4.1"
model_reasoning_effort = "low"
approval_policy = "on-failure"

[profiles.testing]
model = "gpt-5-codex"
model_reasoning_effort = "medium"
approval_policy = "on-failure"
```

2. **Test it**: Start Codex with a specific profile:

```bash
codex --profile deep-review
```

3. Check the configuration: `/status`

**Expected Outcome**: Profile settings override defaults

**Note**: The three profiles above cover the core use cases. The solution `config.toml` also includes the sandbox and rules configuration added in Exercises D4 and D5.

**Reference**: Compare with `../lab-41-agentic-tools-deep-dive-solution/resources/photo-gallery-fullstack-solution/.codex/config.toml`

---

▶ **Section E: OpenCode Exercises**

**Platform**: OpenCode
**Reference configs**: `../lab-41-agentic-tools-deep-dive-solution/resources/photo-gallery-fullstack-solution/.opencode/` and `../lab-41-agentic-tools-deep-dive-solution/resources/photo-gallery-fullstack-solution/AGENTS.md`

### Exercise E1: Initialize AGENTS.md (10 min)

**Objective**: Create project instructions using `/init`

`AGENTS.md` is automatically loaded by OpenCode at session start — it provides project-specific instructions, architecture rules, and conventions that apply globally to all sessions.

1. Navigate to the project and start OpenCode:

```bash
cd photo-gallery-fullstack
opencode
```

2. Run `/init` to scan the codebase and generate `AGENTS.md`:

```
/init
```

OpenCode analyzes your project and creates `AGENTS.md` at the project root with detected build steps, dependencies, and conventions.

**Expected Outcome**: `AGENTS.md` created at project root. OpenCode references these rules automatically in every session.

**Reference**: Compare with `../lab-41-agentic-tools-deep-dive-solution/resources/photo-gallery-fullstack-solution/AGENTS.md`

### Exercise E2: Explore Built-in Modes (10 min)

**Objective**: Use the built-in `plan` mode for safe code exploration

OpenCode ships with two built-in primary agents you can switch with `Tab`:

- **build** (default): Full access — file read, write, bash execution
- **plan**: Read-only — no edit tools, safe for analysis

1. Switch to plan mode by pressing `Tab`

2. Ask OpenCode to analyze the codebase without making changes:

```
Analyze the photo-gallery architecture and identify where I should add a photo tagging feature. List all files that would need to change.
```

3. Review the analysis — no files were modified

4. Press `Tab` again to switch back to build mode

5. Use the plan output to start implementation:

```
Based on the plan, implement the photo tagging feature in the domain layer
```

**Expected Outcome**: Plan mode provides safe read-only exploration; switching back to build mode enables implementation using the plan output.

### Exercise E3: Create a Custom Agent (15 min)

**Objective**: Create an architecture guardian agent

1. Create the agents directory:

```bash
mkdir -p .opencode/agents
```

2. Create the file `.opencode/agents/architecture-guardian.md`:

```markdown
---
description: Validates design decisions against team architectural patterns and ensures alignment with system topology
model: anthropic/claude-sonnet-4-6
---

# Architecture Guardian

You are the **Architecture Guardian** for the photo-gallery project. Your role is to ensure all code changes align with established architectural patterns, maintain system integrity, and follow documented design principles.

## Core Responsibilities

- **Validate Design Decisions**: Review proposed architectural changes against `architecture.md` and ensure alignment with system topology
- **Identify Violations**: Flag deviations from established patterns, anti-patterns, and architectural debt
- **Suggest Refactoring**: Recommend improvements that align with team conventions and long-term maintainability
- **Maintain Boundaries**: Enforce module boundaries and prevent tight coupling between layers
- **Review Dependencies**: Assess impact of new dependencies and ensure they fit architectural vision

## Context Files

You have access to the following knowledge references:

- **architecture.md**: System topology, module boundaries, data flow patterns
- **coding-standards.md**: Team conventions, naming patterns, file organization
- **domain-glossary.md**: Business terminology and domain model definitions

## Interaction Guidelines

When consulted, you should:

1. **Assess Context**: Understand the scope and intent of the proposed change
2. **Reference Standards**: Cite specific sections from architecture.md or coding-standards.md
3. **Evaluate Trade-offs**: Explain pros/cons of different architectural approaches
4. **Provide Specific Recommendations**: Give actionable guidance with code examples where applicable
5. **Flag Risks**: Identify potential scalability, performance, or maintainability concerns

## Decision Framework

When multiple valid approaches exist, prioritize:

1. **Consistency** with existing patterns
2. **Maintainability** and readability
3. **Testability** and isolation
4. **Performance** (only when measurable impact exists)
5. **Future extensibility**

You are an advisor, not a gatekeeper. Provide reasoned guidance but acknowledge when trade-offs are acceptable given project constraints.
```

3. **Test it**: Ask OpenCode to use the agent:

```
@architecture-guardian I want to add a photo filter feature. Should this go in the API layer or domain layer?
```

**Expected Outcome**: OpenCode activates the agent based on the description and provides architecture guidance

**Reference**: Compare with `../lab-41-agentic-tools-deep-dive-solution/resources/photo-gallery-fullstack-solution/.opencode/agents/architecture-guardian.md`

### Exercise E4: Create a Custom Command (10 min)

**Objective**: Create a code reviewer slash command

1. Create the commands directory:

```bash
mkdir -p .opencode/commands
```

2. Create the file `.opencode/commands/code-reviewer.md`:

```markdown
---
description: Analyze code changes and generate actionable code review comments aligned with team standards
agent: architecture-guardian
---

# Code Reviewer

Analyze code changes and generate actionable code review comments aligned with team standards.

## Purpose

Assist code reviewers by:

- Identifying potential bugs, security issues, and performance problems
- Flagging violations of team coding standards and architectural patterns
- Suggesting improvements for readability and maintainability
- Highlighting risks that require extra scrutiny

## Instructions

Analyze the current git diff (staged or unstaged changes).

Reference the team standards from the project's coding-standards.md and architecture.md files.

## Output Format

Produce review comments organized by:

1. **Critical Issues**: Bugs, security vulnerabilities, breaking changes (must fix)
2. **Architectural Concerns**: Pattern violations, coupling issues (should fix)
3. **Code Quality**: Readability, maintainability, test coverage (nice to have)
4. **Suggestions**: Performance optimizations, refactoring opportunities (optional)

Each comment includes:

- **File and line reference**
- **Severity**: Critical / High / Medium / Low
- **Category**: Bug / Security / Architecture / Style / Performance
- **Description**: What the issue is and why it matters
- **Recommendation**: Specific action to address the issue
```

3. **Test it**: Make a small code change, then run:

```
/code-reviewer
```

**Expected Outcome**: OpenCode runs the command using the architecture-guardian agent and produces structured review output

**Reference**: Compare with `../lab-41-agentic-tools-deep-dive-solution/resources/photo-gallery-fullstack-solution/.opencode/commands/code-reviewer.md`

### Exercise E5: Create an Agent Skill (10 min)

**Objective**: Create a change impact analysis skill

1. Create the skills directory:

```bash
mkdir -p .opencode/skills/change-impact-analysis
```

2. Create the file `.opencode/skills/change-impact-analysis/SKILL.md`:

```markdown
---
name: change-impact-analysis
description: Assess the scope and risk of proposed code changes by analyzing affected components, blast radius, and potential side effects. Use when reviewing pull requests, planning large refactorings, assessing deployment readiness, or evaluating rollback complexity.
---

# Change Impact Analysis Skill

## Purpose

Assess the scope and risk of proposed code changes by analyzing affected components, blast radius, and potential side effects. This skill helps teams make informed decisions about change safety.

## Capabilities

### 1. Blast Radius Assessment

- Quantify how many files, modules, and services are affected
- Categorize changes by risk level (low/medium/high/critical)
- Identify cascading effects of a change

### 2. Risk Scoring

- Calculate risk based on change size, complexity, and affected components
- Flag high-risk changes requiring extra review or testing
- Recommend mitigation strategies proportional to risk

### 3. Side Effect Detection

- Identify unintended consequences of changes
- Flag performance implications
- Detect security or compliance impacts

## Usage Context

This skill activates when:

- Reviewing pull requests for approval
- Planning large refactorings or migrations
- Assessing deployment readiness
- Evaluating rollback complexity

## Risk Assessment Framework

| Factor             | Weight | Criteria                                                                                  |
| ------------------ | ------ | ----------------------------------------------------------------------------------------- |
| **Lines Changed**  | 20%    | <50 (low) / 50-200 (med) / 200-500 (high) / >500 (critical)                               |
| **Files Affected** | 15%    | <5 (low) / 5-10 (med) / 10-20 (high) / >20 (critical)                                     |
| **Test Coverage**  | 25%    | >80% (low) / 60-80% (med) / 40-60% (high) / <40% (critical)                               |
| **Critical Path**  | 30%    | Not on critical path (low) / Near critical (med) / On critical path (high)                |
| **Rollback Ease**  | 10%    | Easy revert (low) / Config change (med) / DB migration (high) / Data loss risk (critical) |
```

3. **Test it**: Ask OpenCode:

```
If I change the PhotoRepository interface, what files will be affected?
```

**Expected Outcome**: OpenCode automatically uses the skill to provide an impact analysis

**Reference**: Compare with `../lab-41-agentic-tools-deep-dive-solution/resources/photo-gallery-fullstack-solution/.opencode/skills/change-impact-analysis/SKILL.md`

### Exercise E6: Install a Skill from Public Registry (10 min)

**Objective**: Search for and install a community skill from the Tessl registry

1. Search for the `skill-creator` skill:

```bash
npx -y skills find skill-creator
```

2. Install it locally:

```bash
npx -y skills add https://github.com/anthropics/skills --skill skill-creator
```

3. Move the installed skill to `.opencode/skills/skill-creator/`

4. **Test it**: Ask OpenCode to use the skill:

```

Using the skill-creator skill, help me create a new skill for API documentation generation

```

**Expected Outcome**: Community skill installed and available to OpenCode

**Note**: Public registries like [tessl.io/registry](https://tessl.io/registry) and [skills.sh](https://skills.sh/) provide community-created skills that work across all SKILL.md-compatible platforms.

### Exercise E7: Evaluate an Agent Skill (10 min)

**Objective**: Use Tessl CLI combined with OpenCode to iteratively improve the skill quality until it reaches a 100% score

> **Notes: A Tessl account is now required to review skills. Register once at https://tessl.io/login?returnPathname=%2Fregistry**

1. **Log in to Tessl** (one-time; skip if already authenticated):

```bash
npx --yes tessl login
```

This opens a browser to authenticate — required before `tessl review run` will work (verify anytime with `npx --yes tessl whoami`).

2. **Run the initial Tessl skill review**:

```bash
npx --yes tessl review run .opencode/skills/change-impact-analysis/SKILL.md
```

3. **Ask OpenCode to improve the skill until the score reaches 100%**:

```
Run `npx --yes tessl review run .opencode/skills/change-impact-analysis/SKILL.md` and analyze the output.
Then improve the SKILL.md file based on the quality score, impact score, and improvement suggestions reported.
Repeat — run the review again, apply further improvements — until the reported score is 100%.
```

4. **Validate the final score** — re-run the review one last time to confirm the 100% score:

```bash
npx --yes tessl review run .opencode/skills/change-impact-analysis/SKILL.md
```

**Expected Outcome**: SKILL.md reaches a 100% quality score as reported by Tessl CLI

**Reference**: https://tessl.io/registry/skills/submit

### Exercise E8: Create a Plugin (15 min)

**Objective**: Create a pre-validation plugin that gates tool execution using the `"tool.execute.before"` event

OpenCode plugins are JavaScript or TypeScript files placed in `.opencode/plugins/`. Each plugin exports an async function that receives a context object and returns a hooks object keyed by event names. Unlike Claude Code's JSON-based hooks in `settings.json`, OpenCode plugins are full code with access to Bun's shell API (`$`) and the opencode SDK client.

1. Create the plugins directory:

```bash
mkdir -p .opencode/plugins
```

2. Create the file `.opencode/plugins/env-protection.js`:

```js
// .opencode/plugins/env-protection.js
export const EnvProtectionPlugin = async ({ project, client, $, directory, worktree }) => {
  return {
    // Fires before every tool call — can throw to block the action
    'tool.execute.before': async (input, output) => {
      // Block the agent from reading .env files
      if (input.tool === 'read' && output.args.filePath?.includes('.env')) {
        throw new Error('Reading .env files is not allowed — use environment variables instead');
      }
    },
  };
};
```

3. **Test it**: Ask OpenCode to read the `.env` file:

```
Read the .env file and show me the contents
```

**Expected Outcome**: OpenCode's attempt to read `.env` is blocked by the plugin with the error message. The session continues — only that specific tool call is rejected.

> **Notes** Did the agent bypass the restriction and manage to read the `.env` file anyway?
>
> If yes, have a look at https://opencode.ai/docs/tools/#built-in to understand why 😉 (💡 Hint: `bash`...)
> You might need to improve the condition in the plugin to also block `bash` commands that attempt to read `.env` files, or any other tool that could be used to access the file contents.

4. **Extend it**: Add a second hook to log every bash command to the session:

```js
export const EnvProtectionPlugin = async ({ project, client, $, directory, worktree }) => {
  return {
    'tool.execute.before': async (input, output) => {
      if (input.tool === 'read' && output.args.filePath?.includes('.env')) {
        throw new Error('Reading .env files is not allowed — use environment variables instead');
      }
    },

    // Fires after every tool call — use for logging/auditing
    'tool.execute.after': async (input, output) => {
      if (input.tool === 'bash') {
        await client.app.log({
          body: {
            service: 'env-protection',
            level: 'info',
            message: `bash executed: ${output.args?.command}`,
          },
        });
      }
    },
  };
};
```

5. **Test the audit log**: Run a bash command like listing files:

```
List all TypeScript files in the apps/ directory
```

Then check the OpenCode logs to see the audit entry.

**Key Differences from Other Platforms**:

| Platform    | Hook mechanism       | Config location              | Language       |
| ----------- | -------------------- | ---------------------------- | -------------- |
| Claude Code | `settings.json`      | `PreToolUse` / `PostToolUse` | JSON config    |
| GitHub      | `.github/hooks/`     | `preToolUse` / `postToolUse` | Shell scripts  |
| Gemini CLI  | `settings.json`      | `BeforeTool` / `AfterTool`   | Shell commands |
| OpenCode    | `.opencode/plugins/` | `tool.execute.before/after`  | JS / TS code   |

**Note**: Plugins can also load npm packages — add a `package.json` in `.opencode/` and import any package in your plugin code.

**Reference**: Compare with `../lab-41-agentic-tools-deep-dive-solution/resources/photo-gallery-fullstack-solution/.opencode/plugins/env-protection.js`

### Exercise E9: Configure OpenCode (10 min)

**Objective**: Set up project-level configuration with model and provider settings

1. Update `opencode.json` with full project configuration:

```json
{
  "$schema": "https://opencode.ai/config.json",
  "model": "anthropic/claude-sonnet-4-6",
  "instructions": ["./AGENTS.md"],
  "permission": {
    "read": "allow",
    "list": "allow",
    "grep": "allow",
    "glob": "allow",
    "edit": "ask",
    "write": "ask",
    "patch": "ask",
    "bash": "ask"
  }
}
```

3. Verify the configuration is applied:

```txt
/status
```

**Expected Outcome**: OpenCode uses the specified model and loads project instructions from AGENTS.md automatically

**Reference**: Compare with `../lab-41-agentic-tools-deep-dive-solution/resources/photo-gallery-fullstack-solution/opencode.json`

---

▶ **Section F: Mistral Vibe Exercises**

**Platform**: Mistral Vibe
**Reference configs**: `../lab-41-agentic-tools-deep-dive-solution/resources/photo-gallery-fullstack-solution/.vibe/` and `../lab-41-agentic-tools-deep-dive-solution/resources/photo-gallery-fullstack-solution/AGENTS.md`

> **Install Mistral Vibe** if you have not already:
>
> ```bash
> curl -LsSf https://mistral.ai/vibe/install.sh | bash
> # or: uv tool install mistral-vibe
> ```
>
> Run `vibe --setup` once to configure your API key, model, and defaults interactively.

### Exercise F1: Initialize AGENTS.md (10 min)

**Objective**: Create the project context file and trust the workspace

`AGENTS.md` at the project root is automatically loaded by Mistral Vibe at session start — it provides project-specific instructions, architecture rules, and conventions that apply to all sessions.

1. Start Vibe in the project directory:

```bash
cd photo-gallery-fullstack
vibe
```

2. On first launch in a directory, Vibe shows a **folder-trust** prompt before loading any local `.vibe/` config. Confirm the prompt to trust this workspace.

3. Ask Vibe to generate the context file:

```
Analyze this project and generate an AGENTS.md at the root describing the architecture, tech stack, build/test commands, and conventions.
```

Review the generated file and customize it. Your final `AGENTS.md` should include sections like **Project Overview**, **Commands**, **Key Architecture Facts**, and **Tech Patterns**.

**Expected Outcome**: `AGENTS.md` created at project root. Vibe references these rules automatically in every trusted session.

**Reference**: Compare with `../lab-41-agentic-tools-deep-dive-solution/resources/photo-gallery-fullstack-solution/AGENTS.md`

### Exercise F2: Explore Built-in Agents (10 min)

**Objective**: Use Vibe's built-in agents to control autonomy

Mistral Vibe ships with four built-in agents that map to permission behaviors:

- **default**: Asks for approval before edits and shell commands
- **plan**: Read-only — analysis and planning, no changes
- **accept-edits**: Auto-accepts file edits, still gates shell commands
- **auto-approve**: Full autonomy — no prompts

1. Switch to the `plan` agent and ask Vibe to analyze without making changes:

```
Analyze the photo-gallery architecture and identify where I should add a photo tagging feature. List all files that would need to change.
```

2. Review the plan — no files were modified.

3. Switch to `accept-edits` and implement from the plan:

```
Based on the plan, implement the photo tagging feature in the domain layer
```

**Expected Outcome**: `plan` provides safe read-only exploration; `accept-edits` speeds up implementation by auto-accepting edits while still confirming shell commands.

**Note**: The permission mode can also be set persistently via `permission_mode` in `.vibe/config.toml` (see Exercise F9).

### Exercise F3: Create a Custom Agent (15 min)

**Objective**: Create an architecture guardian agent

1. Create the agents directory:

```bash
mkdir -p .vibe/agents
```

2. **Task**: Create the file `.vibe/agents/architecture-guardian.md`:

```markdown
---
name: architecture-guardian
description: Validates design decisions against team architectural patterns and ensures alignment with system topology
---

# Architecture Guardian

You are the **Architecture Guardian** for the photo-gallery project. Your role is to ensure all code changes align with established architectural patterns, maintain system integrity, and follow documented design principles.

## Core Responsibilities

- **Validate Design Decisions**: Review proposed architectural changes against `architecture.md` and ensure alignment with system topology
- **Identify Violations**: Flag deviations from established patterns, anti-patterns, and architectural debt
- **Suggest Refactoring**: Recommend improvements that align with team conventions and long-term maintainability
- **Maintain Boundaries**: Enforce module boundaries and prevent tight coupling between layers
- **Review Dependencies**: Assess impact of new dependencies and ensure they fit architectural vision

## Context Files

You have access to the following knowledge references:

- **architecture.md**: System topology, module boundaries, data flow patterns
- **coding-standards.md**: Team conventions, naming patterns, file organization
- **domain-glossary.md**: Business terminology and domain model definitions

## Interaction Guidelines

When consulted, you should:

1. **Assess Context**: Understand the scope and intent of the proposed change
2. **Reference Standards**: Cite specific sections from architecture.md or coding-standards.md
3. **Evaluate Trade-offs**: Explain pros/cons of different architectural approaches
4. **Provide Specific Recommendations**: Give actionable guidance with code examples where applicable
5. **Flag Risks**: Identify potential scalability, performance, or maintainability concerns

## Decision Framework

When multiple valid approaches exist, prioritize:

1. **Consistency** with existing patterns
2. **Maintainability** and readability
3. **Testability** and isolation
4. **Performance** (only when measurable impact exists)
5. **Future extensibility**

You are an advisor, not a gatekeeper. Provide reasoned guidance but acknowledge when trade-offs are acceptable given project constraints.
```

3. **Test it**: Ask Vibe to consult the agent:

```
@architecture-guardian I want to add a photo filter feature. Should this go in the API layer or domain layer?
```

**Expected Outcome**: Vibe delegates to the agent, which analyzes the architecture and provides a layered recommendation

**Reference**: Compare your file with `../lab-41-agentic-tools-deep-dive-solution/resources/photo-gallery-fullstack-solution/.vibe/agents/architecture-guardian.md`

### Exercise F4: Create a Custom Command (10 min)

**Objective**: Create a code reviewer slash command via the skills system

In Mistral Vibe, custom slash commands are delivered through the **skills system** — a skill with a `name` becomes an invocable `/name` command.

1. Create the skill directory:

```bash
mkdir -p .vibe/skills/code-reviewer
```

2. **Task**: Create the file `.vibe/skills/code-reviewer/SKILL.md`:

```markdown
---
name: code-reviewer
description: Analyze code changes (diff) and generate actionable code review comments aligned with team standards. Use when reviewing a pull request, staged changes, or a specific file or branch.
---

# Code Reviewer

Analyze code changes and generate actionable code review comments aligned with team standards.

## Instructions

When invoked, analyze the current git diff (staged or unstaged changes) or the specified file/branch.

Reference these team standards:
@.vibe/references/coding-standards.md
@.vibe/references/architecture.md

## Output Format

Produce review comments organized by:

1. **Critical Issues**: Bugs, security vulnerabilities, breaking changes (must fix)
2. **Architectural Concerns**: Pattern violations, coupling issues (should fix)
3. **Code Quality**: Readability, maintainability, test coverage (nice to have)
4. **Suggestions**: Performance optimizations, refactoring opportunities (optional)

Each comment includes:

- **File and line reference**
- **Severity**: Critical / High / Medium / Low
- **Category**: Bug / Security / Architecture / Style / Performance
- **Description**: What the issue is and why it matters
- **Recommendation**: Specific action to address the issue
```

3. **Test it**: Make a small code change, then run:

```
/code-reviewer
```

**Expected Outcome**: Vibe runs the skill as a slash command and produces structured review output

**Reference**: Compare with `../lab-41-agentic-tools-deep-dive-solution/resources/photo-gallery-fullstack-solution/.vibe/skills/code-reviewer/SKILL.md`

### Exercise F5: Create an Agent Skill (10 min)

**Objective**: Create a change impact analysis skill

1. Create the skills directory:

```bash
mkdir -p .vibe/skills/change-impact-analysis
```

2. **Task**: Create the file `.vibe/skills/change-impact-analysis/SKILL.md`:

```markdown
---
name: change-impact-analysis
description: Assess the scope and risk of proposed code changes by analyzing affected components, blast radius, and potential side effects. Use when reviewing pull requests, planning large refactorings, assessing deployment readiness, or evaluating rollback complexity.
---

# Change Impact Analysis Skill

## Purpose

Assess the scope and risk of proposed code changes by analyzing affected components, blast radius, and potential side effects. This skill helps teams make informed decisions about change safety.

## Capabilities

### 1. Blast Radius Assessment

- Quantify how many files, modules, and services are affected
- Categorize changes by risk level (low/medium/high/critical)
- Identify cascading effects of a change

### 2. Risk Scoring

- Calculate risk based on change size, complexity, and affected components
- Flag high-risk changes requiring extra review or testing
- Recommend mitigation strategies proportional to risk

### 3. Side Effect Detection

- Identify unintended consequences of changes
- Flag performance implications
- Detect security or compliance impacts

## Usage Context

This skill activates when:

- Reviewing pull requests for approval
- Planning large refactorings or migrations
- Assessing deployment readiness
- Evaluating rollback complexity

## Risk Assessment Framework

| Factor             | Weight | Criteria                                                                                  |
| ------------------ | ------ | ----------------------------------------------------------------------------------------- |
| **Lines Changed**  | 20%    | <50 (low) / 50-200 (med) / 200-500 (high) / >500 (critical)                               |
| **Files Affected** | 15%    | <5 (low) / 5-10 (med) / 10-20 (high) / >20 (critical)                                     |
| **Test Coverage**  | 25%    | >80% (low) / 60-80% (med) / 40-60% (high) / <40% (critical)                               |
| **Critical Path**  | 30%    | Not on critical path (low) / Near critical (med) / On critical path (high)                |
| **Rollback Ease**  | 10%    | Easy revert (low) / Config change (med) / DB migration (high) / Data loss risk (critical) |
```

3. **Test it**: Ask Vibe:

```
If I change the PhotoRepository interface, what files will be affected?
```

**Expected Outcome**: Vibe automatically loads and uses the skill to provide an impact analysis

**Reference**: Compare with `../lab-41-agentic-tools-deep-dive-solution/resources/photo-gallery-fullstack-solution/.vibe/skills/change-impact-analysis/SKILL.md`

### Exercise F6: Install a Skill from Public Registry (10 min)

**Objective**: Search for and install a community skill from the Tessl registry

1. Search for the `skill-creator` skill:

```bash
npx -y skills find skill-creator
```

2. Install it locally:

```bash
npx -y skills add https://github.com/anthropics/skills --skill skill-creator
```

3. Move the installed skill to `.vibe/skills/skill-creator/`

4. **Test it**: Ask Vibe to use the skill:

```
Using the skill-creator skill, help me create a new skill for API documentation generation
```

**Expected Outcome**: Community skill installed and available to Vibe

**Note**: Public registries like [tessl.io/registry](https://tessl.io/registry) and [skills.sh](https://skills.sh/) provide community-created skills that work across all SKILL.md-compatible platforms.

### Exercise F7: Configure Hooks (15 min)

**Objective**: Set up pre-tool and post-tool hooks in TOML

Mistral Vibe defines lifecycle hooks declaratively in `.vibe/hooks.toml`. Hooks run before/after tool execution and can gate or validate actions.

1. **Task**: Create the file `.vibe/hooks.toml`:

```toml
# Mistral Vibe hooks — lifecycle callbacks defined in TOML.

[[hooks.pre_tool_use]]
matcher = "bash"
type = "prompt"
prompt = "Check if this shell command is a git commit. If so, verify staged files follow coding standards before allowing the commit."

[[hooks.post_tool_use]]
matcher = "write|edit"
type = "prompt"
prompt = "Validate the file changes against coding-standards.md. Check they follow the project's coding standards."
```

2. **Test it**: Make a code change that violates coding standards (e.g., add a `console.log` statement) and observe the post-tool hook flag it.

**Expected Outcome**: The post-edit hook flags the coding standards violation; a git commit triggers the pre-tool validation.

**Reference**: Compare with `../lab-41-agentic-tools-deep-dive-solution/resources/photo-gallery-fullstack-solution/.vibe/hooks.toml`

### Exercise F8: Session Continuation & ACP Mode (10 min)

**Objective**: Resume past work and embed Vibe as an ACP server

1. **Continue your most recent session** — pick up exactly where you left off:

```bash
vibe --continue
```

2. **Resume a specific past session** from a picker:

```bash
vibe --resume
```

3. **Launch ACP mode** — run Vibe as an Agent Client Protocol (ACP) server so an ACP-compatible editor or client can drive it:

```bash
vibe-acp
```

**Expected Outcome**: `--continue` restores your latest conversation, `--resume` lets you choose an earlier one, and `vibe-acp` exposes Vibe over ACP for editor integration.

**Note**: ACP mode is useful for wiring Vibe into IDEs and custom clients that speak the Agent Client Protocol, keeping the same agents, skills, and config defined in `.vibe/`.

### Exercise F9: Configure Vibe (10 min)

**Objective**: Set up project-level configuration with permission modes

Vibe reads project configuration from `.vibe/config.toml` (and global settings from `~/.vibe/config.toml`). The project config is only loaded after you trust the folder.

1. **Task**: Create the file `.vibe/config.toml`:

```toml
# Default permission mode: default | plan | accept-edits | auto-approve
permission_mode = "default"

# Context file auto-loaded at session start
context_file = "AGENTS.md"

[permissions]
allow = ["Bash(npm:*)", "Bash(npx:*)", "Bash(git:*)"]
deny = ["Bash(rm -rf:*)"]

[env]
NODE_ENV = "development"
```

2. Restart Vibe and confirm the folder-trust prompt loads the config.

**Expected Outcome**: Vibe allows npm/npx/git commands without prompting, blocks `rm -rf`, and starts in the `default` permission mode.

**Note**: The four permission modes (`default`, `plan`, `accept-edits`, `auto-approve`) can be set here for every session or switched interactively per session (Exercise F2).

**Reference**: Compare with `../lab-41-agentic-tools-deep-dive-solution/resources/photo-gallery-fullstack-solution/.vibe/config.toml`

---

## Assessment

After completing your platform's exercises, evaluate your understanding:

1. **Feature Creation**: Can you create the right type of customization (agent, command, skill, hook, plugin) for a given scenario?
2. **Platform Conventions**: Do you understand the naming conventions and file formats for your chosen platform?
3. **Cross-Platform Awareness**: Can you identify which features are available on which platforms?
4. **Decision Framework**: Can you justify choosing one feature type over another for a specific use case?

## Troubleshooting

- **Agents not recognized**: Verify file naming conventions (`.md` for Claude/Gemini, `.agent.md` for Copilot, `.toml` for Codex)
- **Gemini agents not working**: Ensure `"experimental": { "enableAgents": true }` is set in `.gemini/settings.json`
- **Commands not working**: Check YAML/TOML frontmatter syntax and file location
- **Hooks not executing**: Check file permissions (`chmod +x *.sh`) and matcher patterns (Linux/macOS); on Windows, skip `chmod` and use `.ps1` scripts instead
- **Skills not detected**: Verify SKILL.md is inside a named subdirectory (e.g., `skills/my-skill/SKILL.md`)
- **Plugins not loading**: For Claude Code, ensure `plugin.json` exists in the `.claude-plugin/` subdirectory inside the plugin folder; for GitHub Copilot, `plugin.json` goes directly at the plugin root (e.g., `.github/plugins/team-workflows/plugin.json`)
- **Copilot plugins**: Use `copilot plugin list` to verify installation
- **Gemini extensions**: Use `gemini extensions list` to verify installation
- **Codex agents not loaded**: Verify TOML syntax in `.codex/agents/*.toml` files; check `[agents]` section in config.toml
- **Codex config not loading**: Run `codex trust .` to trust the project
- **OpenCode agents not activated**: Verify the `description` field in the agent's YAML frontmatter — OpenCode uses it to decide when to activate
- **OpenCode commands not found**: Check that `.md` files are inside `.opencode/commands/` (not `.opencode/command/`)
- **OpenCode model not loading**: Verify API key is set for the provider in `~/.config/opencode/opencode.json` or as an environment variable
- **OpenCode plugins not loading**: Files in `.opencode/plugins/` must export a function (e.g., `export const MyPlugin = async (ctx) => { return { ... } }`); verify no syntax errors with `node --input-type=module < .opencode/plugins/env-protection.js`
- **Vibe config not loading**: Vibe only loads a project's local `.vibe/` config after you accept the folder-trust prompt — re-run `vibe` and confirm trust for the directory
- **Vibe agents not activated**: Verify the `name` and `description` fields in the agent's YAML frontmatter in `.vibe/agents/*.md` — Vibe uses the description to decide when to delegate
- **Vibe slash command not found**: Custom slash commands come from the skills system — ensure the skill directory `.vibe/skills/<name>/` contains a `SKILL.md` with a `name` field
- **Vibe hooks not firing**: Check `.vibe/hooks.toml` TOML syntax and that the `matcher` matches the tool name (e.g., `bash`, `write|edit`)
- **Vibe not configured**: Run `vibe --setup` to (re)configure your API key, model, and defaults

## Resources

- [Module 4 Slides](../../docs/markdown/40_module_4_ai_agentic_tools_deepdive/)
- [Photo Gallery Fullstack Solution](../lab-41-agentic-tools-deep-dive-solution/resources/photo-gallery-fullstack-solution/) - Reference implementations for all platforms
- [AGENTS.md - Cross-Platform Reference](../lab-41-agentic-tools-deep-dive-solution/resources/photo-gallery-fullstack-solution/AGENTS.md)
