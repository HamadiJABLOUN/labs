# Module 4 : Agentic Tools Deep Dive - Atelier pratique

**Durée** : 95 à 135 minutes d'atelier pratique, selon la plateforme choisie

## Vue d'ensemble

Cet atelier propose une mise en pratique de la création d'agents, commandes, skills, hooks, plugins et fichiers de configuration personnalisés pour les outils de code agentiques. Vous travaillerez avec le projet **photo-gallery-fullstack** inclus dans cet atelier et construirez les configurations de zéro avec le CLI de la plateforme que vous aurez choisie.

Le backend est **au choix du stagiaire** : NestJS (TypeScript — référence), Spring Boot (Java 17), FastAPI (Python 3.12), .NET (C# 12 / ASP.NET Core 8) ou Gin (Go 1.23). Les cinq implémentent le même contrat OpenAPI dans `docs/openapi.yaml` et sont interchangeables derrière le frontend Angular sur le port 42621.

**Objectifs pédagogiques clés** :

- Créer des agents et des commandes personnalisés adaptés à un vrai projet
- Définir des agent skills réutilisables au format SKILL.md
- Configurer des hooks pour la validation qualité automatisée
- Mettre en place des plugins et des fichiers de configuration pour les workflows d'équipe

## Structure de l'atelier

Cet atelier est organisé en six sections propres à chaque plateforme. **Choisissez UNE seule plateforme** selon votre environnement :

- **Section A** : exercices Claude Code
- **Section B** : exercices GitHub Copilot
- **Section C** : exercices Gemini CLI
- **Section D** : exercices Codex CLI
- **Section E** : exercices OpenCode
- **Section F** : exercices Mistral Vibe

Chaque section contient des exercices progressifs qui vous guident dans la création de chaque type de fonctionnalité d'agent IA.

**Les sections n'ont pas la même longueur, et c'est voulu.** Chaque outil expose un nombre différent
de points d'extension : la longueur d'un parcours reflète la surface de l'outil, pas une rédaction
inégale.

| Section | Plateforme     |        Exercices | Environ |
| ------- | -------------- | ---------------: | ------: |
| A       | Claude Code    | 10 + 1 optionnel | 135 min |
| B       | GitHub Copilot |               11 | 130 min |
| C       | Gemini CLI     |                9 | 110 min |
| D       | Codex CLI      |                8 |  95 min |
| E       | OpenCode       |                9 | 100 min |
| F       | Mistral Vibe   |                9 | 100 min |

La section D est la plus courte parce que Codex CLI n'a pas de système de commandes slash, et que ses
**Rules** remplacent le mécanisme de hooks que les autres plateformes configurent séparément — un
exercice au lieu de deux. Les stagiaires du parcours Codex finissent en avance ; orientez-les vers
une autre section pour comparer, plutôt que d'ajouter du remplissage.

## Instructions d'installation

### Prérequis

- L'un de ces outils installé : Claude Code, GitHub Copilot CLI, Gemini CLI, Codex CLI, OpenCode ou Mistral Vibe
- Node.js 22+ et npm (toujours requis — le frontend est en Angular)
- Git
- Chaîne d'outils supplémentaire pour le backend choisi (voir **Options d'implémentation du backend** ci-dessous) :
  - **NestJS** — Node.js uniquement
  - **Spring Boot** — JDK 17+ (wrapper Maven inclus)
  - **FastAPI** — Python 3.12+ et `uv` (ou `pip`)
  - **.NET** — SDK .NET 10
  - **Gin** — Go 1.23+

### Mise en place initiale

1. Placez-vous dans le répertoire de l'atelier ou ouvrez-le dans votre IDE :

```bash
cd labs/lab-41-agentic-tools-deep-dive/photo-gallery-fullstack
```

2. (optionnel) Initialisez un dépôt Git neuf dans ce répertoire :

```bash
git init
git add .
git commit -m "chore: initial commit"
```

3. Installez les dépendances :

```bash
npm ci
```

> **Note** : Le répertoire `../lab-41-agentic-tools-deep-dive-solution/resources/photo-gallery-fullstack-solution/` contient les configurations de référence complètes pour toutes les plateformes. Dans cet atelier, vous créerez ces configurations de zéro dans `photo-gallery-fullstack/` afin de comprendre leur fonctionnement. Comparez vos fichiers avec la solution à tout moment.

> **Documents de référence pré-installés** : Le projet de l'atelier contient déjà des dossiers `references/` propres à chaque plateforme (`.claude/references/`, `.github/references/`, `.gemini/references/`, `.codex/references/`, `.opencode/references/`, `.vibe/references/`) avec 5 fichiers de connaissance partagés : `architecture.md`, `coding-standards.md`, `domain-glossary.md`, `testing-guidelines.md` et `oncall.md`. Vos commandes, skills et agents référenceront ces fichiers — ils sont fournis pour que vous puissiez vous concentrer sur la configuration plutôt que sur la création de contenu.

---

## Options d'implémentation du backend

Choisissez **un** backend à exécuter en parallèle de votre travail de configuration d'agent. Les cinq implémentent le même contrat OpenAPI (`docs/openapi.yaml`) et écoutent sur le port 42621.

▶ **NestJS (TypeScript) — implémentation de référence**

```bash
cd labs/lab-41-agentic-tools-deep-dive/photo-gallery-fullstack
npm run serve:backend-nestjs
```

Swagger UI sur http://localhost:42621/api/docs. Voir [`docs/backends/nestjs.md`](photo-gallery-fullstack/docs/backends/nestjs.md).

▶ **Spring Boot (Java 17)**

```bash
cd labs/lab-41-agentic-tools-deep-dive/photo-gallery-fullstack
npm run serve:backend-spring
# or (Unix):    ./apps/backend-spring/mvnw spring-boot:run
# or (Windows): ./apps/backend-spring/mvnw.bat spring-boot:run
```

Voir [`docs/backends/spring.md`](photo-gallery-fullstack/docs/backends/spring.md).

▶ **FastAPI (Python 3.12)**

```bash
cd labs/lab-41-agentic-tools-deep-dive/photo-gallery-fullstack
npm run serve:backend-fastapi
# or: uv run --directory apps/backend-fastapi uvicorn app.main:app --host 0.0.0.0 --port 42621
```

Voir [`docs/backends/fastapi.md`](photo-gallery-fullstack/docs/backends/fastapi.md).

▶ **.NET (C#)**

```bash
cd labs/lab-41-agentic-tools-deep-dive/photo-gallery-fullstack
npm run serve:backend-dotnet
# or: dotnet run --project apps/backend-dotnet
```

Swagger UI sur http://localhost:42621/api/docs. Voir [`docs/backends/dotnet.md`](photo-gallery-fullstack/docs/backends/dotnet.md).

▶ **Gin (Go 1.23)**

```bash
cd labs/lab-41-agentic-tools-deep-dive/photo-gallery-fullstack
npm run serve:backend-gin
# or: go -C apps/backend-gin run ./cmd/server
```

Voir [`docs/backends/gin.md`](photo-gallery-fullstack/docs/backends/gin.md).

---

▶ **Section A : exercices Claude Code**

**Plateforme** : Claude Code
**Configurations de référence** : `../lab-41-agentic-tools-deep-dive-solution/resources/photo-gallery-fullstack-solution/.claude/`

### Exercice A1 : Initialiser CLAUDE.md (10 min)

**Objectif** : Créer le fichier de contexte projet pour Claude Code avec `/init`

`CLAUDE.md` est chargé automatiquement par Claude Code au démarrage de la session — il fournit les instructions propres au projet, les règles d'architecture et les conventions qui s'appliquent globalement à toutes les sessions.

1. Lancez `/init` pour analyser le projet et générer automatiquement un `CLAUDE.md` :

```
/init
```

Claude Code parcourt le code et génère un `CLAUDE.md` à la racine du projet avec les patterns détectés, les dépendances et les conventions suggérées.

2. Relisez le fichier généré et personnalisez-le. Votre `CLAUDE.md` final doit contenir des sections telles que : **Architecture Overview**, **Tech Stack**, **Coding Standard**, etc.

3. Vérifiez que Claude charge bien le fichier en ouvrant une nouvelle session Claude Code à la racine du projet et en demandant :

```
What do you know about this project?
```

**Résultat attendu** : `CLAUDE.md` créé à la racine du projet. Claude référence automatiquement ces règles à chaque session, sans qu'il faille réexpliquer l'architecture du projet.

**Référence** : Comparez avec `../lab-41-agentic-tools-deep-dive-solution/resources/photo-gallery-fullstack-solution/CLAUDE.md`

### Exercice A2 : Créer des Claude Rules (15 min)

**Objectif** : Créer des fichiers d'instructions limités à des chemins avec `.claude/rules/`

Les Claude Rules sont des fichiers d'instructions modulaires qui s'activent automatiquement selon les fichiers présents dans le contexte. Chaque fichier de règles utilise un champ de frontmatter `glob` pour limiter les instructions à certains chemins — ce qui sort du `CLAUDE.md` global les conventions propres à une couche.

1. Créez le répertoire des règles :

```bash
mkdir -p .claude/rules
```

2. Créez un fichier de règles backend ciblant **le backend que vous avez choisi** dans la section **Options d'implémentation du backend** ci-dessus — dépliez le bloc correspondant ci-dessous :

▶ **NestJS (TypeScript)**

Créez `.claude/rules/backend-nestjs-rules.md` :

```markdown
---
paths:
  - 'apps/backend-nestjs/**'
---

## Backend Rules

- Use NestJS dependency injection — never instantiate services manually
- DTOs must use class-validator decorators for input validation
- Controllers must only delegate to services — no business logic in controllers
- All repository methods must be defined in the interface first (`photo.repository.interface.ts`)
- Use TypeORM decorators: `@Entity()`, `@Column()`, `@PrimaryGeneratedColumn()`
```

▶ **Spring Boot (Java 17)**

Créez `.claude/rules/backend-spring-rules.md` :

```markdown
---
paths:
  - 'apps/backend-spring/**'
---

## Backend Rules

- Use Spring constructor injection with `final` fields — never field-level `@Autowired`
- Controllers (`@RestController`) must only delegate to `@Service`-annotated domain services — no business logic in controllers
- Request DTOs must use Bean Validation (`@NotBlank`, `@NotNull`) combined with `@Valid` on controller parameters
- Keep the domain model (`domain/model/Photo.java`) separate from the JPA entity (`infrastructure/entity/PhotoEntity.java`)
- Use Spring Data JPA repository interfaces (`domain/repository/PhotoRepository.java`) — no manual SQL
- Translate exceptions via `@RestControllerAdvice` into the shared `{statusCode, message, error}` error envelope
```

▶ **FastAPI (Python 3.12)**

Créez `.claude/rules/backend-fastapi-rules.md` :

```markdown
---
paths:
  - 'apps/backend-fastapi/**'
---

## Backend Rules

- Use FastAPI's dependency injection (`Depends()`) to wire services and sessions into route handlers — no global singletons
- Domain response models are Pydantic `BaseModel` with `alias_generator=to_camel` and `populate_by_name=True` — keep snake_case in Python, camelCase in JSON
- Keep SQLModel entities (`infrastructure/entities.py`) out of the `api/` layer
- Business logic lives only in `domain/services.py` — `api/photos.py` routers only orchestrate
- Register centralized error handlers in `api/errors.py` producing the shared `{statusCode, message, error}` envelope — don't raise raw `HTTPException` with ad-hoc bodies
```

▶ **.NET (C#)**

Créez `.claude/rules/backend-dotnet-rules.md` :

```markdown
---
paths:
  - 'apps/backend-dotnet/**'
---

## Backend Rules

- Controllers (`[ApiController]`) use constructor injection with `readonly` interface fields (e.g. `IPhotoService`) — never `new` a service directly
- Domain owns `Photo` as an immutable `record`; keep EF Core concerns (entities, `AppDbContext`) confined to `Infrastructure/`
- Request/response shapes belong in `Api/Photos/Dto/` and rely on `System.Text.Json`'s default camelCase policy — no manual renaming
- Use a `ValueConverter<T,TStore>` for JSON-encoded columns rather than ad-hoc (de)serialization in the service
- Implement `IExceptionHandler` for the shared `{statusCode, message, error}` error envelope, including model-binding failures
```

▶ **Gin (Go)**

Créez `.claude/rules/backend-gin-rules.md` :

```markdown
---
paths:
  - 'apps/backend-gin/**'
---

## Backend Rules

- Handlers are methods on a `Handler` struct constructed via `NewHandler(service, storage)` — inject the domain service/storage as struct fields, never instantiate inline
- Keep GORM entities (snake_case columns) separate from API DTOs (camelCase `json:` tags) — map between them explicitly
- Business logic lives in `internal/domain/service.go`; handlers in `internal/api/photos/handler.go` only parse the request and call the service
- IDs are serialized as `string` (not numeric) in `PhotoResponse` to match the OpenAPI contract
- Return errors via the shared `ErrorResponse{StatusCode, Message, Error}` envelope — don't let Gin's default error format leak through
```

3. Créez `.claude/rules/frontend-rules.md` pour les patterns du frontend Angular :

```markdown
---
paths:
  - 'apps/frontend/**'
---

## Frontend Rules

- Use Angular standalone components — no NgModule unless required
- Services must be provided with `providedIn: 'root'`
- Component templates go in separate `.html` files (not inline)
- Use `HttpClient` via dependency injection, never `fetch()` directly
- Models in `src/app/models/` must match backend DTOs
```

4. **Testez** : Ouvrez un fichier de la stack backend que vous avez choisie et demandez à Claude de générer du code :

```txt
Create a new endpoint to update a photo's title
```

**Résultat attendu** : Claude applique automatiquement les règles propres au backend (conventions d'injection de dépendances, DTO, patterns ORM/entités) quand des fichiers de votre `apps/backend-<stack>/` sont dans le contexte, et les règles frontend quand des fichiers de `apps/frontend/` y sont. Seules les règles pertinentes sont chargées, selon les chemins des fichiers actifs.

**Note** : Les Rules diffèrent de `CLAUDE.md` : `CLAUDE.md` est toujours chargé à chaque session ; les Rules sont limitées par chemin de fichier et chargées uniquement quand des fichiers correspondants sont dans le contexte. Utilisez les Rules pour les conventions propres à une couche qui alourdiraient un `CLAUDE.md` global.

**Référence** : Comparez avec `../lab-41-agentic-tools-deep-dive-solution/resources/photo-gallery-fullstack-solution/.claude/rules/` — comparez avec le fichier correspondant à la stack backend que vous avez choisie (`backend-<stack>-rules.md`)

### Exercice A3 : Créer un agent personnalisé (15 min)

**Objectif** : Créer un agent gardien de l'architecture

1. Ouvrez Claude Code dans le répertoire photo-gallery-fullstack

2. Créez le répertoire des agents :

```bash
mkdir -p .claude/agents
```

3. **Tâche** : Créez le fichier `.claude/agents/architecture-guardian.md` :

```markdown
---
name: architecture-guardian
description: Validates design decisions against team architectural patterns and ensures alignment with system topology
model: opus
color: purple
tools: Read, Grep, Glob
---

# Architecture Guardian

You are the **Architecture Guardian** for the photo-gallery project. Your role is to ensure all code changes align with established architectural patterns, maintain system integrity, and follow documented design principles.

## Core Responsibilities

- **Validate Design Decisions**: Review proposed architectural changes against `architecture.md` and ensure alignment with system topology
- **Identify Violations**: Flag deviations from established patterns, anti-patterns, and architectural debt
- **Suggest Refactoring**: Recommend improvements that align with team conventions and long-term maintainability
- **Maintain Boundaries**: Enforce module boundaries and prevent tight coupling between layers
- **Review Dependencies**: Assess impact of new dependencies and ensure they fit architectural vision

## Context Files

You have access to the following knowledge references:

- **architecture.md**: System topology, module boundaries, data flow patterns
- **coding-standards.md**: Team conventions, naming patterns, file organization
- **domain-glossary.md**: Business terminology and domain model definitions

## Interaction Guidelines

When consulted, you should:

1. **Assess Context**: Understand the scope and intent of the proposed change
2. **Reference Standards**: Cite specific sections from architecture.md or coding-standards.md
3. **Evaluate Trade-offs**: Explain pros/cons of different architectural approaches
4. **Provide Specific Recommendations**: Give actionable guidance with code examples where applicable
5. **Flag Risks**: Identify potential scalability, performance, or maintainability concerns

## Example Invocations

- "Should this new feature live in the `api` module or `domain` module?"
- "Is it acceptable to add a direct dependency from `ui` to `storage`?"
- "What's the recommended pattern for handling cross-cutting concerns?"
- "Validate this component structure against our architecture guidelines"

## Decision Framework

When multiple valid approaches exist, prioritize:

1. **Consistency** with existing patterns
2. **Maintainability** and readability
3. **Testability** and isolation
4. **Performance** (only when measurable impact exists)
5. **Future extensibility**

You are an advisor, not a gatekeeper. Provide reasoned guidance but acknowledge when trade-offs are acceptable given project constraints.
```

4. **Testez** : Posez une question à l'agent :

```
@architecture-guardian I want to add a photo filter feature. Should this go in the API layer or domain layer?
```

**Résultat attendu** : L'agent analyse l'architecture et fournit une recommandation par couche

**Référence** : Comparez votre fichier avec `../lab-41-agentic-tools-deep-dive-solution/resources/photo-gallery-fullstack-solution/.claude/agents/architecture-guardian.md`

▶ **💡 Autre façon de créer un agent personnalisé dans Claude Code**

Plutôt que d'écrire le fichier à la main, utilisez l'assistant interactif d'agents du CLI Claude. Dans une session Claude Code, lancez :

```
/agents
```

Sélectionnez **"Create new agent"** et suivez les instructions à l'écran — Claude demande le nom de l'agent, sa description, les outils autorisés et les instructions système, puis génère automatiquement `.claude/agents/<name>.md`.

### Exercice A4 : Créer une équipe d'agents (15 min) - Expérimental

**Objectif** : Lancer une équipe multi-agents pour une revue de code en parallèle

1. **Tâche** : Activez les Agent Teams dans `.claude/settings.json` :

```json
{
  "env": {
    "CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS": "1"
  }
}
```

2. Démarrez Claude Code et demandez une équipe :

```
Create an agent team to review this photo-gallery project from different angles:
- One teammate focused on security review
- One teammate checking code quality and conventions
- One teammate validating test coverage
```

3. Observez comment Claude crée le team lead, lance les coéquipiers et coordonne le travail

4. Utilisez `Shift+Down` pour passer d'un coéquipier à l'autre et interagir directement avec eux

5. Quand les coéquipiers ont terminé, demandez au lead de synthétiser les constats

6. Nettoyez l'équipe :

```
Clean up the team
```

**Résultat attendu** : Plusieurs sessions Claude Code travaillent en parallèle, chacune avec un contexte isolé, en se communiquant leurs constats

**Note** : Les Agent Teams sont expérimentales. Elles diffèrent des subagents : un subagent ne rend compte qu'à son appelant, alors que les membres d'une équipe communiquent **entre eux** et partagent une liste de tâches. Les équipes consomment plus de tokens mais permettent recherche, revue et débogage en parallèle.

### Exercice A5 : Créer une commande personnalisée (10 min)

**Objectif** : Créer une commande de revue de code

1. Créez le répertoire des commandes :

```bash
mkdir -p .claude/commands
```

2. **Tâche** : Créez le fichier `.claude/commands/code-reviewer.md` :

```markdown
---
description: Analyze code changes (diff) and generate actionable code review comments aligned with team standards
allowed-tools: Bash(git diff:*), Bash(git log:*), Read, Grep, Glob
argument-hint: [file-path-or-branch]
---

# Code Reviewer

Analyze code changes and generate actionable code review comments aligned with team standards.

## Purpose

Assist code reviewers by:

- Identifying potential bugs, security issues, and performance problems
- Flagging violations of team coding standards and architectural patterns
- Suggesting improvements for readability and maintainability
- Highlighting risks that require extra scrutiny

## Instructions

When invoked, analyze the current git diff (staged or unstaged changes) or the specified file/branch: $ARGUMENTS

Reference these team standards:
@.claude/references/coding-standards.md
@.claude/references/architecture.md

## Output Format

The command will produce review comments organized by:

1. **Critical Issues**: Bugs, security vulnerabilities, breaking changes (must fix)
2. **Architectural Concerns**: Pattern violations, coupling issues (should fix)
3. **Code Quality**: Readability, maintainability, test coverage (nice to have)
4. **Suggestions**: Performance optimizations, refactoring opportunities (optional)

Each comment includes:

- **File and line reference**
- **Severity**: Critical / High / Medium / Low
- **Category**: Bug / Security / Architecture / Style / Performance
- **Description**: What the issue is and why it matters
- **Recommendation**: Specific action to address the issue

## Activation Triggers

- Reference `coding-standards.md` for team conventions
- Reference `architecture.md` for architectural patterns
- Apply `change-impact-analysis` skill to assess risk
- Reference `testing-guidelines.md` for test coverage standards

## Configuration

You can customize review focus:
```

/code-reviewer --focus security
/code-reviewer --focus performance
/code-reviewer --strict (enforce all standards)

```

You provide constructive, actionable feedback that helps developers improve code quality while learning team standards.
```

3. **Testez** : Faites une petite modification de code, puis lancez :

```
/code-reviewer
```

**Résultat attendu** : Une revue de code structurée, avec des constats classés par catégorie

**Référence** : Comparez avec `../lab-41-agentic-tools-deep-dive-solution/resources/photo-gallery-fullstack-solution/.claude/commands/code-reviewer.md`

### Exercice A6 : Créer une agent skill (10 min)

**Objectif** : Créer une skill d'analyse d'impact des changements

1. Créez le répertoire des skills :

```bash
mkdir -p .claude/skills/change-impact-analysis
```

2. **Tâche** : Créez le fichier `.claude/skills/change-impact-analysis/SKILL.md` :

```markdown
---
name: change-impact-analysis
description: Assess the scope and risk of proposed code changes by analyzing affected components, blast radius, and potential side effects. Use when reviewing pull requests, planning large refactorings, assessing deployment readiness, or evaluating rollback complexity.
---

# Change Impact Analysis Skill

## Purpose

Assess the scope and risk of proposed code changes by analyzing affected components, blast radius, and potential side effects. This skill helps teams make informed decisions about change safety.

## Capabilities

### 1. Blast Radius Assessment

- Quantify how many files, modules, and services are affected
- Categorize changes by risk level (low/medium/high/critical)
- Identify cascading effects of a change

### 2. Risk Scoring

- Calculate risk based on change size, complexity, and affected components
- Flag high-risk changes requiring extra review or testing
- Recommend mitigation strategies proportional to risk

### 3. Side Effect Detection

- Identify unintended consequences of changes
- Flag performance implications
- Detect security or compliance impacts

## Usage Context

This skill activates when:

- Reviewing pull requests for approval
- Planning large refactorings or migrations
- Assessing deployment readiness
- Evaluating rollback complexity

## Knowledge Sources

- **testing-guidelines.md**: Test coverage requirements by risk level
- **architecture.md**: Critical paths and high-risk components
- **Git history**: Past incidents correlated with similar changes

## Risk Assessment Framework

### Risk Factors

| Factor             | Weight | Criteria                                                                                  |
| ------------------ | ------ | ----------------------------------------------------------------------------------------- |
| **Lines Changed**  | 20%    | <50 (low) / 50-200 (med) / 200-500 (high) / >500 (critical)                               |
| **Files Affected** | 15%    | <5 (low) / 5-10 (med) / 10-20 (high) / >20 (critical)                                     |
| **Test Coverage**  | 25%    | >80% (low) / 60-80% (med) / 40-60% (high) / <40% (critical)                               |
| **Critical Path**  | 30%    | Not on critical path (low) / Near critical (med) / On critical path (high)                |
| **Rollback Ease**  | 10%    | Easy revert (low) / Config change (med) / DB migration (high) / Data loss risk (critical) |

### Risk Categories

**LOW RISK** (Score: 0-30)

- Small, isolated changes
- High test coverage
- Easy to rollback
- Examples: UI text changes, logging improvements, documentation

**MEDIUM RISK** (Score: 31-60)

- Moderate scope changes
- Adequate test coverage
- Standard rollback procedures
- Examples: New features, refactorings, configuration updates

**HIGH RISK** (Score: 61-85)

- Large scope or critical path changes
- Test coverage gaps
- Complex rollback
- Examples: API changes, database migrations, authentication updates

**CRITICAL RISK** (Score: 86-100)

- Changes to payment, security, or data integrity systems
- Insufficient testing
- Irreversible changes
- Examples: Payment logic, user data deletion, schema breaking changes

## Metrics

Success criteria for impact analysis:

- ✅ Accurately classifies 90%+ of changes by risk
- ✅ Zero high-risk changes deployed without appropriate safeguards
- ✅ Reduces production incidents by 30% through better risk assessment
```

3. **Testez** : Demandez à Claude :

```
If I change the PhotoRepository interface, what files will be affected?
```

**Résultat attendu** : Claude utilise automatiquement la skill pour fournir une analyse d'impact

**Référence** : Comparez avec `../lab-41-agentic-tools-deep-dive-solution/resources/photo-gallery-fullstack-solution/.claude/skills/change-impact-analysis/SKILL.md`

### Exercice A7 : Installer une skill depuis un registre public (10 min)

**Objectif** : Rechercher et installer une skill communautaire depuis le registre Tessl

1. **Tâche** : Recherchez la skill `skill-creator` :

```bash
npx -y skills find skill-creator
```

2. Installez-la localement :

```bash
npx -y skills add https://github.com/anthropics/skills --skill skill-creator
```

3. Vérifiez que la skill a bien été installée dans votre répertoire `.claude/skills/`

4. **Testez** : Demandez à Claude d'utiliser la skill :

```
Using the skill-creator skill, help me create a new skill for API documentation generation
```

**Résultat attendu** : La skill communautaire est installée localement et Claude peut l'utiliser pour aider à créer de nouvelles skills

**Note** : Les registres publics de skills comme [tessl.io/registry](https://tessl.io/registry) (93+ skills sélectionnées avec notes de qualité) et [skills.sh](https://skills.sh/) (89K+ skills) permettent de découvrir et d'installer des skills créées par la communauté sans tout construire de zéro

### Exercice A8 : Évaluer une agent skill (10 min)

**Objectif** : Utiliser le CLI Tessl combiné à Claude Code pour améliorer itérativement la qualité de la skill jusqu'à atteindre un score de 100 %

> **Notes : un compte Tessl est désormais requis pour évaluer des skills. Inscrivez-vous une fois sur https://tessl.io/login?returnPathname=%2Fregistry**

1. **Connectez-vous à Tessl** (une seule fois ; passez cette étape si vous êtes déjà authentifié) :

```bash
npx --yes tessl login
```

Cela ouvre un navigateur pour s'authentifier — c'est nécessaire avant que `tessl review run` fonctionne (vérifiable à tout moment avec `npx --yes tessl whoami`).

2. **Lancez la première revue de skill Tessl** :

```bash
npx --yes tessl review run .claude/skills/change-impact-analysis/SKILL.md
```

3. **Demandez à Claude Code d'améliorer la skill jusqu'à un score de 100 %** :

```
Run `npx --yes tessl review run .claude/skills/change-impact-analysis/SKILL.md` and analyze the output.
Then improve the SKILL.md file based on the quality score, impact score, and improvement suggestions reported.
Repeat — run the review again, apply further improvements — until the reported score is 100%.
```

4. **Validez le score final** — relancez la revue une dernière fois pour confirmer le score de 100 % :

```bash
npx --yes tessl review run .claude/skills/change-impact-analysis/SKILL.md
```

**Résultat attendu** : SKILL.md atteint un score de qualité de 100 % d'après le CLI Tessl

**Référence** : https://tessl.io/registry/skills/submit

### Exercice A9 : Configurer des hooks (15 min)

**Objectif** : Mettre en place des hooks pre-tool et post-tool

1. **Tâche** : Créez ou modifiez `.claude/settings.json` avec des hooks :

```json
{
  "hooks": {
    "PreToolUse": [
      {
        "matcher": "Bash",
        "hooks": [
          {
            "type": "prompt",
            "prompt": "Check if this Bash command is a git commit. If so, verify staged files follow coding standards before allowing the commit."
          }
        ]
      }
    ],
    "PostToolUse": [
      {
        "matcher": "Write|Edit",
        "hooks": [
          {
            "type": "prompt",
            "prompt": "Validate the file changes against coding-standards.md. Check they follow the project's coding standards."
          }
        ]
      }
    ]
  }
}
```

2. **Testez** : Faites une modification de code qui viole les standards de code (par ex. ajoutez un `console.log`) et observez le comportement du hook

**Résultat attendu** : Le hook post-édition signale la violation des standards de code

**Référence** : Comparez avec `../lab-41-agentic-tools-deep-dive-solution/resources/photo-gallery-fullstack-solution/.claude/settings.json`

▶ **💡 Autre façon de configurer des hooks dans Claude Code**

Plutôt que de modifier `settings.json` à la main, utilisez le gestionnaire interactif de hooks du CLI Claude. Dans une session Claude Code, lancez :

```
/hooks
```

Choisissez **"Add hook"**, sélectionnez le type d'événement (PreToolUse / PostToolUse), définissez le matcher d'outil ainsi que le prompt ou la commande, et Claude écrit automatiquement la configuration du hook dans `.claude/settings.json`.

### Exercice A10 : Créer un plugin (15 min)

**Objectif** : Créer un plugin team-workflows

1. **Tâche** : Créez la structure du plugin :

```bash
mkdir -p .claude/plugins/team-workflows/.claude-plugin
mkdir -p .claude/plugins/team-workflows/commands
mkdir -p .claude/plugins/team-workflows/agents
```

2. Créez le manifeste du plugin `.claude/plugins/team-workflows/.claude-plugin/plugin.json` :

```json
{
  "name": "team-workflows",
  "version": "1.0.0",
  "description": "Team workflow automation plugin",
  "author": { "name": "SFEIR Team" }
}
```

3. Ajoutez une commande `.claude/plugins/team-workflows/commands/analyze-dependencies.md` avec le contenu suivant :

````markdown
# Analyze Dependencies Command

**Invocation**: `/team-workflows:analyze-dependencies [options]`

## Purpose

Analyze project dependencies to identify:

- Outdated packages and available updates
- Security vulnerabilities in dependencies
- Unused dependencies that can be removed
- Dependency conflicts and compatibility issues
- License compliance concerns

## Options

- `--scope <value>`: Analyze "prod", "dev", or "all" dependencies (default: "all")
- `--format <value>`: Output format "table", "json", or "markdown" (default: "table")
- `--security-only`: Only show security vulnerabilities
- `--outdated-only`: Only show outdated packages

## Behavior

1. Parse package.json and lock files
2. Check each dependency against npm registry for latest versions
3. Consult security databases (npm audit, Snyk, etc.) for vulnerabilities
4. Analyze dependency tree for conflicts
5. Generate actionable report with update recommendations

## Output Format

```markdown
# Dependency Analysis Report

Outdated Packages (5):
├─ react: 17.0.2 → 18.2.0 (Major update available)
├─ typescript: 5.0.0 → 5.3.3 (Patch update available)
└─ ...

Security Vulnerabilities (2):
├─ [HIGH] lodash@4.17.20: Prototype Pollution
│ Fix: Update to lodash@4.17.21
└─ [MEDIUM] axios@0.21.1: Server-Side Request Forgery
Fix: Update to axios@1.6.0

Unused Dependencies (3):
├─ moment (not imported anywhere)
├─ ...

Recommended Actions:

1. Run: npm update typescript
2. Run: npm install lodash@4.17.21
3. Run: npm uninstall moment
```
````

4. **Chargez le plugin pour cette session** :

```bash
claude --plugin-dir .claude/plugins/team-workflows
```

5. Dans la session Claude Code, lancez la commande du plugin pour vérifier qu'il est bien chargé :

```
/team-workflows:analyze-dependencies
```

6. **Enregistrez une marketplace locale pour que le plugin se charge automatiquement à chaque session** :

`--plugin-dir` ne charge le plugin que pour la session en cours. Une marketplace permet de l'installer une fois et qu'il se charge automatiquement ensuite — et une marketplace peut se réduire à un simple répertoire local, sans dépôt GitHub ni serveur web.

Créez le manifeste de la marketplace dans `.claude/marketplaces/sfeir-marketplace/` :

```bash
mkdir -p .claude/marketplaces/sfeir-marketplace/.claude-plugin
```

Créez `.claude/marketplaces/sfeir-marketplace/.claude-plugin/marketplace.json` :

```json
{
  "name": "sfeir-marketplace",
  "owner": { "name": "SFEIR Team" },
  "plugins": [
    {
      "name": "team-workflows",
      "source": "../../plugins/team-workflows",
      "description": "Team workflow automation plugin"
    }
  ]
}
```

Enregistrez la marketplace locale et installez le plugin depuis celle-ci :

```bash
claude plugin marketplace add ./.claude/marketplaces/sfeir-marketplace --scope project
claude plugin install team-workflows@sfeir-marketplace
```

**Testez** : démarrez une **nouvelle** session Claude Code à la racine du projet — sans `--plugin-dir` — et confirmez que la commande du plugin fonctionne toujours :

```
/team-workflows:analyze-dependencies
```

**Résultat attendu** : Claude Code démarre avec le plugin chargé et ses commandes disponibles dans l'espace de noms `/team-workflows:`. Après l'enregistrement de la marketplace locale, le plugin se charge automatiquement à chaque session future dans ce projet, sans flag `--plugin-dir`, sans dépôt GitHub et sans hébergement.

▶ **💡 Distribuer la marketplace à une équipe (variante hébergée)**

Pour partager la marketplace avec vos coéquipiers sur d'autres machines — et pas seulement localement sur ce système de fichiers — publiez-la sur un dépôt git hébergé :

1. Poussez un catalogue `marketplace.json` (comme celui ci-dessus) sur un dépôt hébergé.
2. Enregistrez-le dans `.claude/settings.json` :

```json
{
  "extraKnownMarketplaces": [{ "name": "my-team", "url": "https://raw.githubusercontent.com/your-org/plugins/main" }]
}
```

3. Puis installez-le une fois :

```bash
claude plugin install team-workflows@my-team
```

Ensuite, le plugin se charge automatiquement dans chaque session Claude Code, pour quiconque l'installe depuis cette marketplace.

**Référence** : Comparez avec `../lab-41-agentic-tools-deep-dive-solution/resources/photo-gallery-fullstack-solution/.claude/plugins/team-workflows/` et `../lab-41-agentic-tools-deep-dive-solution/resources/photo-gallery-fullstack-solution/.claude/marketplaces/sfeir-marketplace/.claude-plugin/marketplace.json`

### Exercice A11 (Optionnel) : Configurer les settings (10 min)

**Objectif** : Mettre en place une configuration au niveau du projet

1. **Tâche** : Mettez à jour `.claude/settings.json` pour ajouter des permissions :

```json
{
  "permissions": {
    "allow": ["Bash(npm:*)", "Bash(npx:*)", "Bash(git:*)"],
    "deny": ["Bash(rm -rf:*)"]
  },
  "env": {
    "NODE_ENV": "development"
  }
}
```

2. Vérifiez que la configuration est appliquée en observant le comportement de Claude

**Résultat attendu** : Claude peut lancer des commandes npm/git sans demander, mais rm -rf est bloqué

**Référence** : Comparez avec `../lab-41-agentic-tools-deep-dive-solution/resources/photo-gallery-fullstack-solution/.claude/settings.json`

---

▶ **Section B : exercices GitHub Copilot**

**Plateforme** : GitHub Copilot
**Configurations de référence** : `../lab-41-agentic-tools-deep-dive-solution/resources/photo-gallery-fullstack-solution/.github/`

### Exercice B1 : Initialiser copilot-instructions.md (10 min)

**Objectif** : Générer automatiquement le fichier d'instructions du projet avec `/init`

`.github/copilot-instructions.md` est chargé automatiquement par GitHub Copilot pour toutes les sessions de ce dépôt — il fournit des instructions valables pour tout le projet, que Copilot suit sans invocation explicite.

1. Lancez `/init` pour générer un squelette d'instructions projet à partir de l'analyse du code :

```
/init
```

GitHub Copilot CLI analyse la structure de votre projet et génère `.github/copilot-instructions.md` avec les patterns et conventions détectés.

2. Relisez le fichier généré dans `.github/copilot-instructions.md`

3. Vérifiez que Copilot utilise bien les instructions :

```
What are the main architectural patterns in this project?
```

**Résultat attendu** : Copilot fait référence à la structure et aux conventions du projet issues du fichier généré. Cela fournit une base que vous enrichirez à l'exercice B2 avec des standards d'équipe complets couvrant l'architecture, les standards de code, la sécurité et le workflow.

**Note** : `/init` crée un point de départ à partir d'une analyse statique. L'exercice B2 montre comment rédiger des instructions projet complètes à la main.

### Exercice B2 : copilot-instructions.md complet (10 min)

**Objectif** : Créer des instructions Copilot valables pour tout le projet

0. Supprimez le `.github/copilot-instructions.md` généré automatiquement à l'exercice B1

1. **Tâche** : Créez `.github/copilot-instructions.md` avec l'introduction indépendante de la stack, les puces Technology Stack partagées, l'intro Coding Standards et l'exemple du frontend Angular :

```markdown
# Photo Gallery Repository Instructions

Follow these guidelines when working in this repository:

## Architecture & Design

- Follow the layered architecture defined in [references/architecture.md](references/architecture.md)
- Respect module boundaries (UI → Service → Domain → Infrastructure)
- Use dependency injection for all external dependencies
- Reference [references/domain-glossary.md](references/domain-glossary.md) for consistent terminology

## Technology Stack

- **Frontend**: Angular 20+ with signals-based state management
- **Database**: SQLite (local file)
- **File Storage**: Local disk (`./dist/uploads/`)
- **Backend**: see the backend-specific block below for your chosen stack

## Coding Standards

- TypeScript for the frontend (strict mode enabled); the backend follows its own stack's idiomatic conventions (see below)
- Use async/await (no callbacks except for legacy refactoring exercises)
- Functions max 50 lines
- Classes follow single responsibility principle
- See [references/coding-standards.md](references/coding-standards.md) for detailed conventions

### Angular (Frontend)

**Path**: `apps/frontend/src/app/`

- Use standalone components (no NgModules)
- Use Angular signals for state (`signal()`, `computed()`)
- Use `inject()` function for dependency injection

​`typescript
@Component({
  standalone: true,
  imports: [CommonModule],
})
export class PhotoListComponent {
  private readonly photoService = inject(PhotoService);
  readonly photos = this.photoService.photos;
  readonly selectedTags = signal<string[]>([]);
}
​`
```

2. Ajoutez un bloc `<details>` pour **le backend que vous avez choisi**, contenant ensemble sa Technology Stack, ses Key Paths et sa sous-section Coding Standards :

▶ **NestJS (TypeScript)**

````markdown
### NestJS (Backend)

**Technology Stack**: NestJS 11 with TypeORM (Nx monorepo)
**Key Paths**: API `apps/backend-nestjs/src/api/`, Domain `apps/backend-nestjs/src/domain/`, Infrastructure `apps/backend-nestjs/src/infrastructure/`

- Use decorators: `@Controller`, `@Get`, `@Post`, `@Injectable`
- Use TypeORM for database access with `@InjectRepository`
- Use DTOs with class-validator decorators

​```typescript
@Controller('api/photos')
export class PhotosController {
constructor(private readonly photoService: PhotoService) {}

@Get()
async getPhotos(): Promise<Photo[]> {
return this.photoService.getPhotos();
}
}
​```
````

▶ **Spring Boot (Java 17)**

````markdown
### Spring Boot (Backend)

**Technology Stack**: Spring Boot 3 (Java 17) with Spring Data JPA (Maven wrapper)
**Key Paths**: API `apps/backend-spring/src/main/java/com/photogallery/backend/api/`, Domain `apps/backend-spring/src/main/java/com/photogallery/backend/domain/`, Infrastructure `apps/backend-spring/src/main/java/com/photogallery/backend/infrastructure/`

- Use `@RestController` with `@GetMapping`/`@PostMapping`, constructor injection (no field `@Autowired`)
- Use Spring Data JPA repositories for database access — no manual SQL
- Use DTOs with Bean Validation (`@NotBlank`, `@Valid`)

​```java
@RestController
@RequestMapping("/api/photos")
public class PhotosController {
private final PhotoService photoService;

public PhotosController(PhotoService photoService) {
this.photoService = photoService;
}

@GetMapping
public List<PhotoResponse> getPhotos() {
return photoService.getPhotos();
}
}
​```
````

▶ **FastAPI (Python 3.12)**

````markdown
### FastAPI (Backend)

**Technology Stack**: FastAPI (Python 3.12) with SQLModel (`uv`/`pip`)
**Key Paths**: API `apps/backend-fastapi/app/api/`, Domain `apps/backend-fastapi/app/domain/`, Infrastructure `apps/backend-fastapi/app/infrastructure/`

- Use `APIRouter` with `Depends()` for dependency injection
- Use SQLModel for database access via an injected `Session` — no raw SQL
- Use Pydantic models with `alias_generator=to_camel` for camelCase JSON

​```python
router = APIRouter(prefix="/api/photos")

@router.get("", response_model=list[Photo])
def get_photos(service: PhotoService = Depends(get_photo_service)) -> list[Photo]:
`return service.get_photos()
​```
````

▶ **.NET (C#)**

````markdown
### .NET (Backend)

**Technology Stack**: ASP.NET Core 8 (C# 12) with Entity Framework Core 8 (.NET 8 SDK)
**Key Paths**: API `apps/backend-dotnet/Api/`, Domain `apps/backend-dotnet/Domain/`, Infrastructure `apps/backend-dotnet/Infrastructure/`

- Use `[ApiController]` with constructor-injected interfaces (e.g. `IPhotoService`)
- Use Entity Framework Core for database access via the repository pattern — no raw SQL
- Use DTOs relying on `System.Text.Json`'s default camelCase policy

​```csharp
[ApiController]
[Route("api/photos")]
public class PhotosController : ControllerBase
{
private readonly IPhotoService \_photoService;

public PhotosController(IPhotoService photoService) => \_photoService = photoService;

[HttpGet]
public async Task<IEnumerable<PhotoResponse>> GetPhotos() => await \_photoService.GetPhotosAsync();
}
​```
````

▶ **Gin (Go)**

```markdown
### Gin (Backend)

**Technology Stack**: Gin (Go 1.23) with GORM (Go 1.23 modules)
**Key Paths**: API `apps/backend-gin/internal/api/`, Domain `apps/backend-gin/internal/domain/`, Infrastructure `apps/backend-gin/internal/infrastructure/`

- Use `Handler` struct methods registered on the Gin router, constructed via `NewHandler(service, storage)`
- Use GORM for database access — no raw SQL
- Use DTOs with explicit `json:` tags for camelCase JSON

​`go
func (h *Handler) GetPhotos(c *gin.Context) {
	photos, err := h.service.GetPhotos(c.Request.Context())
	if err != nil {
		c.JSON(http.StatusInternalServerError, ErrorResponse{Message: err.Error()})
		return
	}
	c.JSON(http.StatusOK, ToResponseList(photos))
}
​`
```

3. Ajoutez les sections partagées restantes, identiques pour tous les backends :

````markdown
## Testing

- Minimum 80% code coverage for business logic
- Use AAA pattern (Arrange-Act-Assert)
- Mock external dependencies (HTTP calls, file system in unit tests)
- Use Vitest for unit and integration tests
- Use Playwright for E2E tests
- See [references/testing-guidelines.md](references/testing-guidelines.md) for test strategies

## API Conventions

- RESTful endpoints with proper HTTP verbs
- camelCase for JSON fields
- Consistent error response format:
  ```json
  {
    "statusCode": 400,
    "message": "File size exceeds 5MB limit",
    "error": "Bad Request"
  }
  ```

## Validation Constraints

- Max file size: **5MB**
- Supported image types: JPEG, PNG, GIF, WebP
- Tags: lowercase alphanumeric with hyphens, max 20 tags, max 30 chars each

## Security

- Always validate and sanitize user input
- Use your ORM's repository/query-builder methods (avoid raw SQL)
- Store sensitive data in environment variables
- No hardcoded credentials or API keys

## Performance

- Use Angular signals for reactive state (automatically optimized)
- Lazy load images with `loading="lazy"` attribute
- Use computed values for derived state (memoized automatically)
- Optimize database queries using your backend's query builder/ORM

## Git Workflow

- Branch naming: `feature/`, `bugfix/`, `refactor/`
- Commit messages: `type(scope): description`
- PR descriptions include test strategy and deployment notes
- Code review required from 2+ team members

## On-Call & Incidents

- Follow escalation procedures in [references/oncall.md](references/oncall.md)
- Document incidents using RCA template
- Update runbooks with learnings

When in doubt, reference the comprehensive documentation in the `references/` directory or consult relevant team agents.
````

4. Vérifiez que Copilot lit les instructions en l'interrogeant sur les conventions du projet

**Résultat attendu** : Les réponses de Copilot reflètent les instructions propres au projet

**Référence** : Comparez avec `../lab-41-agentic-tools-deep-dive-solution/resources/photo-gallery-fullstack-solution/.github/copilot-instructions.md`

### Exercice B3 : Créer une instruction (10 min)

**Objectif** : Créer des instructions de code propres à certains chemins

1. Créez le répertoire des instructions :

```bash
mkdir -p .github/instructions
```

2. **Tâche** : Créez un fichier d'instructions d'architecture ciblant **la stack backend que vous avez choisie** — dépliez le bloc correspondant ci-dessous :

▶ **NestJS (TypeScript)**

Créez `.github/instructions/architecture-nestjs.instructions.md` :

````markdown
---
applyTo: 'apps/backend-nestjs/src/domain/**'
---

# Architecture Instructions

Follow guidelines from references/architecture.md when working with domain layer code.

## Key Points for Domain Layer

- **Technology Stack**: NestJS 11 backend, TypeORM with SQLite
- **Path**: `apps/backend-nestjs/src/domain/`
- **Entities**: Use TypeORM decorators (@Entity, @Column, @PrimaryGeneratedColumn)
- **Services**: Use @Injectable() decorator
- **Dependencies**: Domain layer should not depend on infrastructure

## Domain Layer Structure

```txt
apps/backend-nestjs/src/domain/
├── entities/
│ └── photo.entity.ts # TypeORM entity
├── models/
│ └── photo.model.ts # Domain interface
└── services/
└── photo.service.ts # Business logic
```

## Photo Entity Example

```typescript
@Entity('photos')
export class PhotoEntity {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  filename: string;

  @Column({ name: 'stored_filename', unique: true })
  storedFilename: string;

  @Column()
  url: string;

  @Column()
  size: number;

  @Column('simple-json')
  tags: string[];

  @CreateDateColumn({ name: 'created_at' })
  createdAt: Date;
}
```

## Validation Constraints

- Max file size: **5MB**
- Supported formats: JPEG, PNG, GIF, WebP
- Tags: lowercase alphanumeric with hyphens, max 20 tags, max 30 chars each

See [references/architecture.md](../references/architecture.md) for complete architecture documentation.
````

▶ **Spring Boot (Java 17)**

Créez `.github/instructions/architecture-spring.instructions.md` :

````markdown
---
applyTo: 'apps/backend-spring/src/main/java/com/photogallery/backend/domain/**'
---

# Architecture Instructions

Follow guidelines from references/architecture.md when working with domain layer code.

## Key Points for Domain Layer

- **Technology Stack**: Spring Boot 3 (Java 17), Spring Data JPA with SQLite
- **Path**: `apps/backend-spring/src/main/java/com/photogallery/backend/domain/`
- **Domain Model**: `Photo` is a plain Java `record` — no persistence annotations
- **Services**: Use `@Service`-annotated classes with constructor injection
- **Dependencies**: Domain layer should not depend on infrastructure — persistence (JPA entity, repository over `PhotoEntity`) is mapped in a `toDomain()` converter

## Domain Layer Structure

```txt
apps/backend-spring/src/main/java/com/photogallery/backend/domain/
├── model/
│ └── Photo.java # Plain record, no annotations
├── repository/
│ └── PhotoRepository.java # Spring Data JPA interface
└── service/
└── PhotoService.java # Business logic
```

## Photo Domain Model Example

```java
public record Photo(
        String id,
        String filename,
        String storedFilename,
        String url,
        long size,
        List<String> tags,
        Instant createdAt
) {
    public Photo {
        Objects.requireNonNull(filename, "filename");
        Objects.requireNonNull(storedFilename, "storedFilename");
        Objects.requireNonNull(url, "url");
        tags = tags == null ? List.of() : List.copyOf(tags);
    }
}
```

## Validation Constraints

- Max file size: **5MB**
- Supported formats: JPEG, PNG, GIF, WebP
- Tags: lowercase alphanumeric with hyphens, max 20 tags, max 30 chars each

See [references/architecture.md](../references/architecture.md) for complete architecture documentation.
````

▶ **FastAPI (Python 3.12)**

Créez `.github/instructions/architecture-fastapi.instructions.md` :

````markdown
---
applyTo: 'apps/backend-fastapi/app/domain/**'
---

# Architecture Instructions

Follow guidelines from references/architecture.md when working with domain layer code.

## Key Points for Domain Layer

- **Technology Stack**: FastAPI backend (Python 3.12), SQLModel with SQLite
- **Path**: `apps/backend-fastapi/app/domain/`
- **Domain Model**: `Photo` is a Pydantic `BaseModel` with `alias_generator=to_camel` and `populate_by_name=True` — keep snake_case in Python, camelCase in JSON
- **Services**: Plain classes with constructor-injected `Session`
- **Dependencies**: Domain layer should not depend on infrastructure — the SQLModel `PhotoEntity` lives in `infrastructure/entities.py` and is mapped to `Photo` in the service

## Domain Layer Structure

```txt
apps/backend-fastapi/app/domain/
├── __init__.py
├── models.py # Pydantic domain/response model
└── services.py # Business logic
```

## Photo Domain Model Example

```python
class Photo(BaseModel):
    """Photo response payload."""
    model_config = ConfigDict(
        alias_generator=_to_camel,
        populate_by_name=True,
        from_attributes=True,
    )
    id: str
    filename: str
    stored_filename: str
    url: str
    size: int
    tags: list[str] = Field(default_factory=list)
    created_at: datetime
```

## Validation Constraints

- Max file size: **5MB**
- Supported formats: JPEG, PNG, GIF, WebP
- Tags: lowercase alphanumeric with hyphens, max 20 tags, max 30 chars each

See [references/architecture.md](../references/architecture.md) for complete architecture documentation.
````

▶ **.NET (C#)**

Créez `.github/instructions/architecture-dotnet.instructions.md` :

````markdown
---
applyTo: 'apps/backend-dotnet/Domain/**'
---

# Architecture Instructions

Follow guidelines from references/architecture.md when working with domain layer code.

## Key Points for Domain Layer

- **Technology Stack**: ASP.NET Core 8 backend (C# 12), Entity Framework Core 8 with SQLite
- **Path**: `apps/backend-dotnet/Domain/`
- **Domain Model**: `Photo` is a plain mutable class with auto-properties — no EF Core attributes
- **Services**: Classes implementing an interface (e.g. `IPhotoService`), constructor-injected `IPhotoRepository`
- **Dependencies**: Domain layer should not depend on infrastructure — the EF Core `PhotoEntity` and `AppDbContext` live in `Infrastructure/`

## Domain Layer Structure

```txt
apps/backend-dotnet/Domain/
├── Models/
│ └── Photo.cs # Plain class, no attributes
├── Repositories/
│ └── IPhotoRepository.cs # Repository port
└── Services/
├── IPhotoService.cs
└── PhotoService.cs # Business logic
```

## Photo Domain Model Example

```csharp
public class Photo
{
    public int Id { get; set; }
    public string Filename { get; set; } = string.Empty;
    public string StoredFilename { get; set; } = string.Empty;
    public string Url { get; set; } = string.Empty;
    public long Size { get; set; }
    public List<string> Tags { get; set; } = new();
    public DateTime CreatedAt { get; set; }
}
```

## Validation Constraints

- Max file size: **5MB**
- Supported formats: JPEG, PNG, GIF, WebP
- Tags: lowercase alphanumeric with hyphens, max 20 tags, max 30 chars each

See [references/architecture.md](../references/architecture.md) for complete architecture documentation.
````

▶ **Gin (Go)**

Créez `.github/instructions/architecture-gin.instructions.md` :

````markdown
---
applyTo: 'apps/backend-gin/internal/domain/**'
---

# Architecture Instructions

Follow guidelines from references/architecture.md when working with domain layer code.

## Key Points for Domain Layer

- **Technology Stack**: Gin backend (Go 1.23), GORM with SQLite
- **Path**: `apps/backend-gin/internal/domain/`
- **Domain Model**: `Photo` is a plain struct — no `json:`/`gorm:` tags
- **Services**: Plain structs constructed via `NewPhotoService(repo PhotoRepository)`, depending on a `PhotoRepository` interface
- **Dependencies**: Domain layer should not depend on infrastructure — the GORM entity lives in `internal/infrastructure/`

## Domain Layer Structure

```txt
apps/backend-gin/internal/domain/
├── photo.go # Plain struct, no tags
└── service.go # Business logic
```

## Photo Domain Model Example

```go
type Photo struct {
	ID             string
	Filename       string
	StoredFilename string
	URL            string
	Size           int64
	Tags           []string
	CreatedAt      time.Time
}
```

## Validation Constraints

- Max file size: **5MB**
- Supported formats: JPEG, PNG, GIF, WebP
- Tags: lowercase alphanumeric with hyphens, max 20 tags, max 30 chars each

See [references/architecture.md](../references/architecture.md) for complete architecture documentation.
````

3. **Testez** : Modifiez un fichier de la couche domaine du backend que vous avez choisi et observez comment les suggestions de Copilot suivent les patterns propres au domaine

**Résultat attendu** : Les suggestions de Copilot respectent les conventions propres au chemin

**Référence** : Comparez avec `../lab-41-agentic-tools-deep-dive-solution/resources/photo-gallery-fullstack-solution/.github/instructions/` — comparez avec le fichier correspondant à la stack backend que vous avez choisie (`architecture-<stack>.instructions.md`)

▶ **💡 Autre façon de créer une instruction de code dans GitHub Copilot**

Plutôt que d'écrire le fichier à la main, utilisez l'assistant interactif d'instructions du CLI GitHub Copilot. Dans une session Copilot, lancez :

```bash
/instruction
```

Sélectionnez **"Create New Instruction..."** et suivez les instructions à l'écran — Copilot demande l'emplacement du projet et si l'instruction doit être créée manuellement ou avec son aide, puis génère automatiquement `.github/instructions/<name>.instructions.md`.

### Exercice B4 : Créer un prompt (10 min)

**Objectif** : Créer un prompt de revue de code

1. Créez le répertoire des prompts :

```bash
mkdir -p .github/prompts
```

2. **Tâche** : Créez `.github/prompts/code-reviewer.prompt.md` :

````markdown
---
description: Analyze code changes (diff) and generate actionable code review comments aligned with team standards
tools: ['search/codebase']
---

# /code-reviewer

Analyze code changes (diff) and generate actionable code review comments aligned with team standards.

## Purpose

Assist code reviewers by:

- Identifying potential bugs, security issues, and performance problems
- Flagging violations of team coding standards and architectural patterns
- Suggesting improvements for readability and maintainability
- Highlighting risks that require extra scrutiny

## Usage

Invoke this command when reviewing a pull request or code changes:

```txt
/code-reviewer
```

The command will analyze the current git diff (staged or unstaged changes) and generate review comments.

## Output Format

The command will produce review comments organized by:

1. **Critical Issues**: Bugs, security vulnerabilities, breaking changes (must fix)
2. **Architectural Concerns**: Pattern violations, coupling issues (should fix)
3. **Code Quality**: Readability, maintainability, test coverage (nice to have)
4. **Suggestions**: Performance optimizations, refactoring opportunities (optional)

Each comment includes:

- **File and line reference**
- **Severity**: Critical / High / Medium / Low
- **Category**: Bug / Security / Architecture / Style / Performance
- **Description**: What the issue is and why it matters
- **Recommendation**: Specific action to address the issue

## Activation Triggers

- Reference `coding-standards.md` for team conventions
- Reference `architecture.md` for architectural patterns
- Apply `change-impact-analysis` skill to assess risk
- Reference `testing-guidelines.md` for test coverage standards

## Configuration

You can customize review focus:

```txt
/code-reviewer --focus security
/code-reviewer --focus performance
/code-reviewer --strict (enforce all standards)
```

You provide constructive, actionable feedback that helps developers improve code quality while learning team standards.
````

3. **Testez** : Dans Copilot Chat, invoquez le prompt avec le préfixe `#` :

```txt
#code-reviewer
```

**Note** : Les prompts utilisent le préfixe `#` dans Copilot Chat (par ex. `#code-reviewer`), ce qui diffère des slash commands (`/command`). Les prompts sont généralement référencés depuis des agents et des instructions plutôt qu'invoqués seuls. Vous pouvez tester un prompt directement dans le chat, mais en pratique c'est la commande `/code-reviewer` de l'exercice B3 (si elle est implémentée) qui invoquerait ce prompt.

**Résultat attendu** : Une sortie de revue de code structurée, avec des constats organisés par sévérité (Critical, High, Medium, Low)

**Référence** : Comparez avec `../lab-41-agentic-tools-deep-dive-solution/resources/photo-gallery-fullstack-solution/.github/prompts/code-reviewer.prompt.md`

▶ **💡 Autre façon de créer un prompt dans GitHub Copilot**

Plutôt que d'écrire le fichier à la main, utilisez l'assistant interactif de prompts du CLI GitHub Copilot. Dans une session Copilot, lancez :

```txt
/prompt
```

Sélectionnez **"Create New Prompt..."** et suivez les instructions à l'écran — Copilot demande l'emplacement du projet et si le prompt doit être créé manuellement ou avec son aide, puis génère automatiquement `.github/prompts/<name>.prompt.md`.

### Exercice B5 : Créer un agent personnalisé (15 min)

**Objectif** : Créer un agent gardien de l'architecture

1. Créez le répertoire des agents :

```bash
mkdir -p .github/agents
```

2. **Tâche** : Créez `.github/agents/architecture-guardian.agent.md` :

```markdown
---
name: architecture-guardian
description: Validates design decisions against team architectural patterns and ensures alignment with system topology
---

# Architecture Guardian

You are the **Architecture Guardian** for the photo-gallery project. Your role is to ensure all code changes align with established architectural patterns, maintain system integrity, and follow documented design principles.

## Core Responsibilities

- **Validate Design Decisions**: Review proposed architectural changes against `architecture.md` and ensure alignment with system topology
- **Identify Violations**: Flag deviations from established patterns, anti-patterns, and architectural debt
- **Suggest Refactoring**: Recommend improvements that align with team conventions and long-term maintainability
- **Maintain Boundaries**: Enforce module boundaries and prevent tight coupling between layers
- **Review Dependencies**: Assess impact of new dependencies and ensure they fit architectural vision

## Context Files

You have access to the following knowledge references:

- **architecture.md**: System topology, module boundaries, data flow patterns
- **coding-standards.md**: Team conventions, naming patterns, file organization
- **domain-glossary.md**: Business terminology and domain model definitions

## Interaction Guidelines

When consulted, you should:

1. **Assess Context**: Understand the scope and intent of the proposed change
2. **Reference Standards**: Cite specific sections from architecture.md or coding-standards.md
3. **Evaluate Trade-offs**: Explain pros/cons of different architectural approaches
4. **Provide Specific Recommendations**: Give actionable guidance with code examples where applicable
5. **Flag Risks**: Identify potential scalability, performance, or maintainability concerns

## Example Invocations

- "Should this new feature live in the `api` module or `domain` module?"
- "Is it acceptable to add a direct dependency from `ui` to `storage`?"
- "What's the recommended pattern for handling cross-cutting concerns?"
- "Validate this component structure against our architecture guidelines"

## Decision Framework

When multiple valid approaches exist, prioritize:

1. **Consistency** with existing patterns
2. **Maintainability** and readability
3. **Testability** and isolation
4. **Performance** (only when measurable impact exists)
5. **Future extensibility**

You are an advisor, not a gatekeeper. Provide reasoned guidance but acknowledge when trade-offs are acceptable given project constraints.
```

3. **Testez** :

```txt
@architecture-guardian I want to add a photo filter feature. Should this go in the API layer or domain layer?
```

**Résultat attendu** : L'agent fournit une recommandation fondée sur l'architecture

**Référence** : Comparez avec `../lab-41-agentic-tools-deep-dive-solution/resources/photo-gallery-fullstack-solution/.github/agents/architecture-guardian.agent.md`

▶ **💡 Autre façon de créer un agent personnalisé dans GitHub Copilot**

Plutôt que d'écrire le fichier à la main, utilisez l'assistant interactif d'agents du CLI GitHub Copilot. Dans une session Copilot, lancez :

```txt
/agent
```

Sélectionnez **"Create New Agent..."** et suivez les instructions à l'écran — Copilot demande l'emplacement du projet et si l'agent doit être créé manuellement ou avec son aide, puis génère automatiquement `.github/agents/<name>.agent.md`.

### Exercice B6 : Utiliser /delegate pour des agents en arrière-plan (15 min)

**Objectif** : Soumettre des tâches asynchrones avec `/delegate` et lancer des agents en parallèle avec `/fleet`

`/delegate` envoie une tâche à un agent de code en arrière-plan qui travaille de façon autonome — il crée une nouvelle branche, applique les modifications et ouvre une pull request pendant que vous continuez à travailler. `/fleet` lance plusieurs subagents en parallèle dans votre session courante.

**Partie 1 — Agent en arrière-plan avec /delegate**

1. Soumettez une tâche en arrière-plan pour écrire des tests unitaires :

```txt
/delegate Write unit tests for PhotoService covering the upload, getAll, and getById methods. Create tests in apps/backend-nestjs/src/domain/services/photo.service.spec.ts following existing test patterns.
```

2. Suivez la tâche déléguée :

```txt
/delegate status
```

3. Une fois terminée, examinez la branche et la pull request générées depuis l'interface GitHub.

**Partie 2 — Subagents en parallèle avec /fleet**

4. Lancez des agents en parallèle pour examiner simultanément différentes parties du code :

```txt
/fleet
  - Review apps/backend-nestjs/ for NestJS best practices and potential security issues
  - Review apps/frontend/ for Angular standalone component conventions
  - Check all *.spec.ts files for missing test coverage
```

**Résultat attendu** : `/delegate` crée en arrière-plan une PR avec des tests unitaires sur une nouvelle branche. `/fleet` lance trois subagents en parallèle et renvoie les résultats consolidés des trois.

**Note** : `/delegate` nécessite une authentification GitHub et un dépôt connecté pour créer des pull requests. `/fleet` fonctionne localement dans la session, sans configuration supplémentaire.

### Exercice B7 : Créer une agent skill (10 min)

**Objectif** : Créer une skill d'analyse d'impact des changements

1. Créez le répertoire des skills :

```bash
mkdir -p .github/skills/change-impact-analysis
```

2. **Tâche** : Créez `.github/skills/change-impact-analysis/SKILL.md` :

```markdown
---
name: change-impact-analysis
description: Assess the scope and risk of proposed code changes by analyzing affected components, blast radius, and potential side effects. Use when reviewing pull requests, planning large refactorings, assessing deployment readiness, or evaluating rollback complexity.
---

# Change Impact Analysis Skill

## Purpose

Assess the scope and risk of proposed code changes by analyzing affected components, blast radius, and potential side effects. This skill helps teams make informed decisions about change safety.

## Capabilities

### 1. Blast Radius Assessment

- Quantify how many files, modules, and services are affected
- Categorize changes by risk level (low/medium/high/critical)
- Identify cascading effects of a change

### 2. Risk Scoring

- Calculate risk based on change size, complexity, and affected components
- Flag high-risk changes requiring extra review or testing
- Recommend mitigation strategies proportional to risk

### 3. Side Effect Detection

- Identify unintended consequences of changes
- Flag performance implications
- Detect security or compliance impacts

## Usage Context

This skill activates when:

- Reviewing pull requests for approval
- Planning large refactorings or migrations
- Assessing deployment readiness
- Evaluating rollback complexity

## Knowledge Sources

- **testing-guidelines.md**: Test coverage requirements by risk level
- **architecture.md**: Critical paths and high-risk components
- **Git history**: Past incidents correlated with similar changes

## Risk Assessment Framework

### Risk Factors

| Factor             | Weight | Criteria                                                                                  |
| ------------------ | ------ | ----------------------------------------------------------------------------------------- |
| **Lines Changed**  | 20%    | <50 (low) / 50-200 (med) / 200-500 (high) / >500 (critical)                               |
| **Files Affected** | 15%    | <5 (low) / 5-10 (med) / 10-20 (high) / >20 (critical)                                     |
| **Test Coverage**  | 25%    | >80% (low) / 60-80% (med) / 40-60% (high) / <40% (critical)                               |
| **Critical Path**  | 30%    | Not on critical path (low) / Near critical (med) / On critical path (high)                |
| **Rollback Ease**  | 10%    | Easy revert (low) / Config change (med) / DB migration (high) / Data loss risk (critical) |

### Risk Categories

**LOW RISK** (Score: 0-30): Small, isolated changes with high test coverage and easy rollback

**MEDIUM RISK** (Score: 31-60): Moderate scope changes with adequate test coverage

**HIGH RISK** (Score: 61-85): Large scope or critical path changes with test coverage gaps

**CRITICAL RISK** (Score: 86-100): Changes to security/data integrity systems with insufficient testing

## Metrics

Success criteria for impact analysis:

- ✅ Accurately classifies 90%+ of changes by risk
- ✅ Zero high-risk changes deployed without appropriate safeguards
- ✅ Reduces production incidents by 30% through better risk assessment
```

**Résultat attendu** : Un fichier SKILL.md valide, qui fonctionne sur toutes les plateformes

**Référence** : Comparez avec `../lab-41-agentic-tools-deep-dive-solution/resources/photo-gallery-fullstack-solution/.github/skills/change-impact-analysis/SKILL.md`

### Exercice B8 : Installer une skill depuis un registre public (10 min)

**Objectif** : Rechercher et installer une skill communautaire depuis le registre Tessl

1. **Tâche** : Recherchez la skill `skill-creator` :

```bash
npx -y skills find skill-creator
```

2. Installez-la localement :

```bash
npx -y skills add https://github.com/anthropics/skills --skill skill-creator
```

3. Déplacez la skill installée vers `.github/skills/skill-creator/`

4. **Testez** dans Copilot Chat pour vérifier que la skill est détectée

**Résultat attendu** : Skill communautaire installée et disponible pour Copilot

**Note** : Les registres publics comme [tessl.io/registry](https://tessl.io/registry) et [skills.sh](https://skills.sh/) proposent des skills créées par la communauté, compatibles avec toutes les plateformes qui supportent SKILL.md.

### Exercice B9 : Évaluer une agent skill (10 min)

**Objectif** : Utiliser le CLI Tessl combiné à GitHub Copilot pour améliorer itérativement la qualité de la skill jusqu'à atteindre un score de 100 %

> **Notes : un compte Tessl est désormais requis pour évaluer des skills. Inscrivez-vous une fois sur https://tessl.io/login?returnPathname=%2Fregistry**

1. **Connectez-vous à Tessl** (une seule fois ; passez cette étape si vous êtes déjà authentifié) :

```bash
npx --yes tessl login
```

Cela ouvre un navigateur pour s'authentifier — c'est nécessaire avant que `tessl review run` fonctionne (vérifiable à tout moment avec `npx --yes tessl whoami`).

2. **Lancez la première revue de skill Tessl** :

```bash
npx --yes tessl review run .github/skills/change-impact-analysis/SKILL.md
```

3. **Demandez à GitHub Copilot d'améliorer la skill jusqu'à un score de 100 %** :

```txt
Run `npx --yes tessl review run .github/skills/change-impact-analysis/SKILL.md` and analyze the output.
Then improve the SKILL.md file based on the quality score, impact score, and improvement suggestions reported.
Repeat — run the review again, apply further improvements — until the reported score is 100%.
```

4. **Validez le score final** — relancez la revue une dernière fois pour confirmer le score de 100 % :

```bash
npx --yes tessl review run .github/skills/change-impact-analysis/SKILL.md
```

**Résultat attendu** : SKILL.md atteint un score de qualité de 100 % d'après le CLI Tessl

**Référence** : https://tessl.io/registry/skills/submit

### Exercice B10 : Configurer des hooks (15 min)

**Objectif** : Mettre en place des hooks de validation pre-commit

1. Créez le répertoire des hooks :

```bash
mkdir -p .github/hooks/scripts
```

2. **Tâche** : Créez `.github/hooks/code-reviewer.json` :

```json
{
  "version": 1,
  "description": "Run code-reviewer on staged files for git commits",
  "hooks": {
    "preToolUse": [
      {
        "type": "command",
        "bash": ".github/hooks/scripts/validate-commit.sh",
        "powershell": ".github/hooks/scripts/validate-commit.ps1",
        "env": { "REVIEW_MODE": "strict" },
        "timeoutSec": 15
      }
    ]
  }
}
```

3. Créez le script de validation `.github/hooks/scripts/validate-commit.sh` :

```bash
#!/usr/bin/env bash
echo "Validating staged files..."
# Add validation logic here
exit 0
```

4. Rendez le script exécutable : `chmod +x .github/hooks/scripts/validate-commit.sh`

▶ **Windows (PowerShell) — validate-commit.ps1**

Sur Windows, ignorez `chmod +x`. Créez `.github/hooks/scripts/validate-commit.ps1` à la place du script bash (ou en plus) :

```powershell
# GitHub Copilot preToolUse hook: Validate git commit commands
# Checks if this is a git commit and validates staged files follow coding standards

$input = $input | ConvertFrom-Json
$command = $input.command

# Only process git commit commands
if ($command -notmatch "^git\s+commit") {
    exit 0
}

Write-Host "🔍 Running code-reviewer on staged files..."

# Get list of staged files
$stagedFiles = git diff --cached --name-only 2>$null

if (-not $stagedFiles) {
    Write-Host "⚠️ No staged files found for commit" -ForegroundColor Yellow
    exit 0
}

$violations = @()

foreach ($file in $stagedFiles) {
    if (-not (Test-Path $file)) { continue }

    # Check TypeScript/JavaScript files
    if ($file -match "\.(ts|tsx|js|jsx)$") {
        $content = Get-Content $file -Raw -ErrorAction SilentlyContinue

        # Check for console.log statements
        if ($content -match "console\.log") {
            $violations += "- $file: contains console.log statements"
        }

        # Check for any type usage
        if ($content -match ": any") {
            $violations += "- $file: avoid using 'any' type"
        }
    }
}

if ($violations.Count -gt 0) {
    Write-Host "⚠️ Coding standards violations found:" -ForegroundColor Yellow
    $violations | ForEach-Object { Write-Host $_ -ForegroundColor Yellow }
    exit 2
}

Write-Host "✅ Staged files pass coding standards check" -ForegroundColor Green
exit 0
```

Le JSON du hook contient déjà `"powershell": ".github/hooks/scripts/validate-commit.ps1"`, il est donc pris en compte automatiquement sur Windows.

**Résultat attendu** : Une configuration de hook avec support de scripts multiplateformes

**Référence** : Comparez avec `../lab-41-agentic-tools-deep-dive-solution/resources/photo-gallery-fullstack-solution/.github/hooks/code-reviewer.json`

### Exercice B11 : Créer un plugin (15 min)

**Objectif** : Créer un plugin team-workflows pour GitHub Copilot

Les plugins GitHub Copilot regroupent agents et prompts sous un espace de noms commun, ce qui rend les workflows d'équipe portables et installables d'une session à l'autre. C'est l'équivalent du plugin Claude Code de l'exercice A10 — mêmes concepts, adaptés aux conventions de Copilot (fichiers `.agent.md`, fichiers `.prompt.md`, `plugin.json` à la racine du plugin — contrairement à Claude Code qui place le manifeste dans un sous-répertoire `.claude-plugin/`).

1. Créez la structure de répertoires du plugin :

```bash
mkdir -p .github/plugins/team-workflows/prompts
mkdir -p .github/plugins/team-workflows/agents
```

2. Créez le manifeste du plugin `.github/plugins/team-workflows/plugin.json` :

```json
{
  "name": "team-workflows",
  "version": "1.0.0",
  "description": "Team workflow automation plugin",
  "author": { "name": "Your Team" },
  "license": "MIT",
  "agents": "agents/",
  "skills": "skills/",
  "hooks": "hooks.json"
}
```

3. Ajoutez un agent `.github/plugins/team-workflows/agents/dependency-tracker.agent.md` :

````markdown
---
name: dependency-tracker
description: Monitors dependency health, detects outdated or vulnerable packages, assesses compatibility risks, and guides safe dependency updates for the photo-gallery project.
---

# Dependency Tracker Agent

You are a dependency management specialist for the photo-gallery project (Angular frontend + your chosen backend stack, Nx monorepo). Your role is to proactively monitor dependency health, identify risks, and guide safe updates.

## Responsibilities

### Dependency Health Monitoring

- Identify outdated dependencies with available updates
- Detect packages with known security vulnerabilities (CVEs)
- Flag deprecated packages that need replacement
- Monitor peer dependency compatibility

### Update Risk Assessment

- Classify updates as patch/minor/major with associated risk levels
- Identify breaking changes from changelogs and migration guides
- Map which source files will be affected by each update

### Update Planning

- Suggest update order to minimize cascading failures
- Provide step-by-step migration instructions for major updates
- Estimate rollback complexity for each update

## Invocation Patterns

```txt
@dependency-tracker Check if any dependencies have security vulnerabilities
@dependency-tracker What's the safest order to update our Angular dependencies?
@dependency-tracker Assess the risk of updating our backend's ORM library to its next major version
```

## Integration

- Works alongside `/team-workflows:analyze-dependencies` command
- Feeds data to `@architecture-guardian` for boundary validation
````

4. Ajoutez une commande `.github/plugins/team-workflows/prompts/analyze-dependencies.prompt.md` avec le contenu suivant :

````markdown
---
description: Analyze project dependencies to identify outdated packages, security vulnerabilities, unused dependencies, and compatibility issues
tools: ['search/codebase']
---

# Analyze Dependencies Command

**Invocation**: `/team-workflows:analyze-dependencies [options]`

## Purpose

Analyze project dependencies to identify:

- Outdated packages and available updates
- Security vulnerabilities in dependencies
- Unused dependencies that can be removed
- Dependency conflicts and compatibility issues
- License compliance concerns

## Options

- `--scope <value>`: Analyze "prod", "dev", or "all" dependencies (default: "all")
- `--format <value>`: Output format "table", "json", or "markdown" (default: "table")
- `--security-only`: Only show security vulnerabilities
- `--outdated-only`: Only show outdated packages

## Behavior

1. Parse package.json and lock files
2. Check each dependency against npm registry for latest versions
3. Consult security databases (npm audit, Snyk, etc.) for vulnerabilities
4. Analyze dependency tree for conflicts
5. Generate actionable report with update recommendations

## Output Format

```markdown
# Dependency Analysis Report

Outdated Packages (5):
├─ react: 17.0.2 → 18.2.0 (Major update available)
├─ typescript: 5.0.0 → 5.3.3 (Patch update available)
└─ ...

Security Vulnerabilities (2):
├─ [HIGH] lodash@4.17.20: Prototype Pollution
│ Fix: Update to lodash@4.17.21
└─ [MEDIUM] axios@0.21.1: Server-Side Request Forgery
Fix: Update to axios@1.6.0

Unused Dependencies (3):
├─ moment (not imported anywhere)
├─ ...

Recommended Actions:

1. Run: npm update typescript
2. Run: npm install lodash@4.17.21
3. Run: npm uninstall moment
```
````

5. **Chargez le plugin pour cette session** :

```bash
copilot --plugin-dir .github/plugins/team-workflows
```

6. Dans la session Copilot, lancez la commande du plugin pour vérifier qu'il est bien chargé :

```txt
/team-workflows:analyze-dependencies
```

**Résultat attendu** : GitHub Copilot démarre avec le plugin chargé et ses commandes disponibles dans l'espace de noms `/team-workflows:`

▶ **💡 Chargement persistant du plugin**

`--plugin-dir` ne charge le plugin que pour une seule session. Pour qu'il se charge automatiquement à chaque session sans ce flag, installez-le durablement :

```bash
copilot plugin install .github/plugins/team-workflows
```

Ensuite, le plugin se charge automatiquement dans chaque session GitHub Copilot de ce projet. Pour lister tous les plugins installés :

```bash
copilot plugin list
```

**Référence** : Comparez avec `../lab-41-agentic-tools-deep-dive-solution/resources/photo-gallery-fullstack-solution/.github/plugins/team-workflows/`

---

▶ **Section C : exercices Gemini CLI**

**Plateforme** : Gemini CLI
**Configurations de référence** : `../lab-41-agentic-tools-deep-dive-solution/resources/photo-gallery-fullstack-solution/.gemini/`

### Exercice C1 : Initialiser GEMINI.md (10 min)

**Objectif** : Créer le fichier de contexte projet pour Gemini CLI avec `/init`

`GEMINI.md` est chargé automatiquement par Gemini CLI au démarrage de la session — il fournit les instructions propres au projet, les règles d'architecture et les conventions qui s'appliquent globalement à toutes les sessions.

1. Lancez `/init` pour analyser le projet et générer automatiquement un `GEMINI.md` :

```txt
/init
```

Gemini CLI parcourt le code et génère un `GEMINI.md` à la racine du projet avec les patterns détectés, les dépendances et les conventions suggérées.

2. Relisez le fichier généré et personnalisez-le. Votre `GEMINI.md` final doit contenir des sections telles que :

```markdown
# Photo Gallery Project

## Architecture

- **Frontend**: Angular 18+ in `apps/frontend/`
- **Monorepo**: Nx workspace — run commands via `nx` or `npm run`
- **API**: REST API backend proxied via `proxy.conf.json` (see `apps/frontend/proxy.conf.json` for port details)

## Coding Standards

- TypeScript strict mode — no `any` types (frontend)
- Angular standalone components
- Spec files co-located with source files

## Available Commands

- `/code-reviewer` — AI-assisted code review aligned with team standards

## Configuration

See `.gemini/` for commands, hooks, skills, and settings.
```

Ajoutez ensuite la puce **Backend**, les **Domain Rules** et la puce **Coding Standards** backend correspondant à la stack que vous avez choisie — dépliez le bloc correspondant et fusionnez ses lignes dans les sections ci-dessus :

▶ **NestJS (TypeScript)**

```markdown
- **Backend**: NestJS in `apps/backend-nestjs/` <!-- add to ## Architecture -->

## Domain Rules

- Domain layer (`apps/backend-nestjs/src/domain/`) must NOT depend on infrastructure layer
- All business logic belongs in domain services
- Use TypeORM decorators for entities

- NestJS patterns: modules, controllers, services, DTOs <!-- add to ## Coding Standards -->
```

▶ **Spring Boot (Java 17)**

```markdown
- **Backend**: Spring Boot in `apps/backend-spring/` <!-- add to ## Architecture -->

## Domain Rules

- Domain layer (`apps/backend-spring/src/main/java/com/photogallery/backend/domain/`) must NOT depend on infrastructure layer
- All business logic belongs in domain services
- Domain model (`Photo`) is a plain Java record — JPA annotations belong only on the infrastructure entity

- Spring Boot patterns: `@RestController`, `@Service`, `@Repository`, DTOs <!-- add to ## Coding Standards -->
```

▶ **FastAPI (Python 3.12)**

```markdown
- **Backend**: FastAPI in `apps/backend-fastapi/` <!-- add to ## Architecture -->

## Domain Rules

- Domain layer (`apps/backend-fastapi/app/domain/`) must NOT depend on infrastructure layer
- All business logic belongs in domain services
- Domain model (`Photo`) is a Pydantic `BaseModel` — SQLModel entities belong only in infrastructure

- FastAPI patterns: `APIRouter`, `Depends()`, Pydantic schemas <!-- add to ## Coding Standards -->
```

▶ **.NET (C#)**

```markdown
- **Backend**: ASP.NET Core in `apps/backend-dotnet/` <!-- add to ## Architecture -->

## Domain Rules

- Domain layer (`apps/backend-dotnet/Domain/`) must NOT depend on infrastructure layer
- All business logic belongs in domain services
- Domain model (`Photo`) is a plain class — EF Core attributes belong only on the infrastructure entity

- ASP.NET Core patterns: `[ApiController]`, DI via constructor, DTOs <!-- add to ## Coding Standards -->
```

▶ **Gin (Go)**

```markdown
- **Backend**: Gin in `apps/backend-gin/` <!-- add to ## Architecture -->

## Domain Rules

- Domain layer (`apps/backend-gin/internal/domain/`) must NOT depend on infrastructure layer
- All business logic belongs in domain services
- Domain model (`Photo`) is a plain struct — GORM tags belong only on the infrastructure entity

- Gin patterns: `Handler` structs, interface-based services, DTOs <!-- add to ## Coding Standards -->
```

3. Vérifiez que Gemini charge bien le fichier en ouvrant une nouvelle session Gemini CLI à la racine du projet et en demandant :

```
What do you know about this project?
```

**Résultat attendu** : `GEMINI.md` créé à la racine du projet. Gemini référence automatiquement ces règles à chaque session, sans qu'il faille réexpliquer l'architecture du projet.

**Référence** : Comparez avec `../lab-41-agentic-tools-deep-dive-solution/resources/photo-gallery-fullstack-solution/GEMINI.md`

### Exercice C2 : Créer un agent personnalisé (15 min) - Expérimental

**Objectif** : Créer un subagent pour le conseil en architecture

1. Créez les répertoires Gemini :

```bash
mkdir -p .gemini/agents
```

2. **Tâche** : Activez d'abord les agents expérimentaux dans `.gemini/settings.json` :

```json
{
  "experimental": {
    "enableAgents": true
  }
}
```

3. Créez le fichier `.gemini/agents/architecture-guardian.md`, en utilisant la version correspondant à **votre backend choisi** — dépliez le bloc correspondant ci-dessous :

▶ **NestJS (TypeScript)**

```yaml
---
name: architecture-guardian
description: Validates design decisions against team architectural patterns
kind: local
tools:
  - read_file
  - grep_search
  - list_directory
model: gemini-2.5-pro
temperature: 0.3
max_turns: 15
---

## Role

You are a senior architect advisor for the photo-gallery-fullstack project.

## Architecture Rules

- Frontend (Angular) communicates with Backend (NestJS) via REST API
- Domain layer must NOT depend on infrastructure layer
- All business logic belongs in domain services
- Use TypeORM decorators for entities

## Decision Framework

Consistency > Maintainability > Testability > Performance
```

▶ **Spring Boot (Java 17)**

```yaml
---
name: architecture-guardian
description: Validates design decisions against team architectural patterns
kind: local
tools:
  - read_file
  - grep_search
  - list_directory
model: gemini-2.5-pro
temperature: 0.3
max_turns: 15
---

## Role

You are a senior architect advisor for the photo-gallery-fullstack project.

## Architecture Rules

- Frontend (Angular) communicates with Backend (Spring Boot) via REST API
- Domain layer must NOT depend on infrastructure layer
- All business logic belongs in domain services
- Domain model (`Photo`) is a plain Java record — JPA annotations belong only on the infrastructure entity

## Decision Framework

Consistency > Maintainability > Testability > Performance
```

▶ **FastAPI (Python 3.12)**

```yaml
---
name: architecture-guardian
description: Validates design decisions against team architectural patterns
kind: local
tools:
  - read_file
  - grep_search
  - list_directory
model: gemini-2.5-pro
temperature: 0.3
max_turns: 15
---

## Role

You are a senior architect advisor for the photo-gallery-fullstack project.

## Architecture Rules

- Frontend (Angular) communicates with Backend (FastAPI) via REST API
- Domain layer must NOT depend on infrastructure layer
- All business logic belongs in domain services
- Domain model (`Photo`) is a Pydantic `BaseModel` — SQLModel entities belong only in infrastructure

## Decision Framework

Consistency > Maintainability > Testability > Performance
```

▶ **.NET (C#)**

```yaml
---
name: architecture-guardian
description: Validates design decisions against team architectural patterns
kind: local
tools:
  - read_file
  - grep_search
  - list_directory
model: gemini-2.5-pro
temperature: 0.3
max_turns: 15
---

## Role

You are a senior architect advisor for the photo-gallery-fullstack project.

## Architecture Rules

- Frontend (Angular) communicates with Backend (ASP.NET Core) via REST API
- Domain layer must NOT depend on infrastructure layer
- All business logic belongs in domain services
- Domain model (`Photo`) is a plain class — EF Core attributes belong only on the infrastructure entity

## Decision Framework

Consistency > Maintainability > Testability > Performance
```

▶ **Gin (Go)**

```yaml
---
name: architecture-guardian
description: Validates design decisions against team architectural patterns
kind: local
tools:
  - read_file
  - grep_search
  - list_directory
model: gemini-2.5-pro
temperature: 0.3
max_turns: 15
---

## Role

You are a senior architect advisor for the photo-gallery-fullstack project.

## Architecture Rules

- Frontend (Angular) communicates with Backend (Gin) via REST API
- Domain layer must NOT depend on infrastructure layer
- All business logic belongs in domain services
- Domain model (`Photo`) is a plain struct — GORM tags belong only on the infrastructure entity

## Decision Framework

Consistency > Maintainability > Testability > Performance
```

4. **Testez** : Invoquez l'agent explicitement :

```
@architecture-guardian Should photo filters be implemented in the API layer or domain layer?
```

**Résultat attendu** : Le subagent fournit des conseils d'architecture en s'appuyant sur son contexte isolé

**Note** : Les sub-agents sont expérimentaux dans Gemini CLI. Activez-les avec `enableAgents: true` dans settings.json. Ils s'exécutent dans des boucles de contexte isolées, avec leurs propres permissions d'outils.

### Exercice C3 : Créer une commande personnalisée (15 min)

**Objectif** : Créer une commande de revue de code au format TOML

1. Créez le répertoire des commandes :

```bash
mkdir -p .gemini/commands
```

2. **Tâche** : Créez `.gemini/commands/code-reviewer.toml` :

```toml
# Code Reviewer Command
# Invoked via: /code-reviewer

description = "Analyze code changes (diff) and generate actionable code review comments aligned with team standards."

prompt = """
You are a senior code reviewer for the photo-gallery project. Analyze the following code changes and generate actionable review comments.

## Instructions

1. First, get the current git diff:
!{git diff --staged}

If no staged changes, check unstaged changes:
!{git diff}

2. Reference the team coding standards:
@{.gemini/references/coding-standards.md}

3. Reference the architecture guidelines:
@{.gemini/references/architecture.md}

## Review Categories

Organize your feedback by priority:

1. **Critical Issues** (must fix): Bugs, security vulnerabilities, breaking changes
2. **Architectural Concerns** (should fix): Pattern violations, coupling issues
3. **Code Quality** (nice to have): Readability, maintainability, test coverage
4. **Suggestions** (optional): Performance optimizations, refactoring opportunities

## Output Format

For each issue, provide:
- File and line reference
- Severity: Critical / High / Medium / Low
- Category: Bug / Security / Architecture / Style / Performance
- Description: What the issue is and why it matters
- Recommendation: Specific action to address the issue
- Reference: Link to relevant standard from coding-standards.md or architecture.md

Arguments provided: {{args}}
"""
```

3. **Testez** :

```
/code-reviewer
```

**Résultat attendu** : La commande TOML s'exécute avec expansion shell et inclusion de fichiers

**Référence** : Comparez avec `../lab-41-agentic-tools-deep-dive-solution/resources/photo-gallery-fullstack-solution/.gemini/commands/code-reviewer.toml`

### Exercice C4 : Créer une agent skill (10 min)

**Objectif** : Créer une skill d'analyse d'impact des changements

1. Créez le répertoire des skills :

```bash
mkdir -p .gemini/skills/change-impact-analysis
```

2. **Tâche** : Créez `.gemini/skills/change-impact-analysis/SKILL.md` :

```markdown
---
name: change-impact-analysis
description: Assess the scope and risk of proposed code changes by analyzing affected components, blast radius, and potential side effects. Use when reviewing pull requests, planning large refactorings, assessing deployment readiness, or evaluating rollback complexity.
---

# Change Impact Analysis Skill

## Purpose

Assess the scope and risk of proposed code changes by analyzing affected components, blast radius, and potential side effects. This skill helps teams make informed decisions about change safety.

## Capabilities

### 1. Blast Radius Assessment

- Quantify how many files, modules, and services are affected
- Categorize changes by risk level (low/medium/high/critical)
- Identify cascading effects of a change

### 2. Risk Scoring

- Calculate risk based on change size, complexity, and affected components
- Flag high-risk changes requiring extra review or testing
- Recommend mitigation strategies proportional to risk

### 3. Side Effect Detection

- Identify unintended consequences of changes
- Flag performance implications
- Detect security or compliance impacts

## Usage Context

This skill activates when:

- Reviewing pull requests for approval
- Planning large refactorings or migrations
- Assessing deployment readiness
- Evaluating rollback complexity

## Knowledge Sources

- **testing-guidelines.md**: Test coverage requirements by risk level
- **architecture.md**: Critical paths and high-risk components
- **Git history**: Past incidents correlated with similar changes

## Risk Assessment Framework

### Risk Factors

| Factor             | Weight | Criteria                                                                                  |
| ------------------ | ------ | ----------------------------------------------------------------------------------------- |
| **Lines Changed**  | 20%    | <50 (low) / 50-200 (med) / 200-500 (high) / >500 (critical)                               |
| **Files Affected** | 15%    | <5 (low) / 5-10 (med) / 10-20 (high) / >20 (critical)                                     |
| **Test Coverage**  | 25%    | >80% (low) / 60-80% (med) / 40-60% (high) / <40% (critical)                               |
| **Critical Path**  | 30%    | Not on critical path (low) / Near critical (med) / On critical path (high)                |
| **Rollback Ease**  | 10%    | Easy revert (low) / Config change (med) / DB migration (high) / Data loss risk (critical) |

### Risk Categories

**LOW RISK** (Score: 0-30): Small, isolated changes with high test coverage and easy rollback

**MEDIUM RISK** (Score: 31-60): Moderate scope changes with adequate test coverage

**HIGH RISK** (Score: 61-85): Large scope or critical path changes with test coverage gaps

**CRITICAL RISK** (Score: 86-100): Changes to security/data integrity systems with insufficient testing

## Metrics

Success criteria for impact analysis:

- ✅ Accurately classifies 90%+ of changes by risk
- ✅ Zero high-risk changes deployed without appropriate safeguards
- ✅ Reduces production incidents by 30% through better risk assessment
```

3. **Testez** : Demandez l'impact d'une modification d'interface

4. Vérifiez que les skills sont détectées :

```bash
gemini skills list
```

**Résultat attendu** : Gemini utilise la skill pour l'analyse d'impact. `gemini skills list` affiche la skill.

**Note** : Vous pouvez aussi installer des skills depuis des dépôts git avec `gemini skills install <URL>` ou lier une skill locale avec `gemini skills link <path>`

**Référence** : Comparez avec `../lab-41-agentic-tools-deep-dive-solution/resources/photo-gallery-fullstack-solution/.gemini/skills/change-impact-analysis/SKILL.md`

### Exercice C5 : Installer une skill depuis un registre public (10 min)

**Objectif** : Rechercher et installer une skill communautaire depuis le registre Tessl

1. **Tâche** : Recherchez la skill `skill-creator` :

```bash
npx -y skills find skill-creator
```

2. Installez-la localement :

```bash
npx -y skills add https://github.com/anthropics/skills --skill skill-creator
```

3. Déplacez la skill installée vers `.gemini/skills/skill-creator/`

4. Vérifiez avec Gemini CLI :

```bash
gemini skills list
```

**Résultat attendu** : Skill communautaire installée et listée par `gemini skills list`

**Note** : Les registres publics comme [tessl.io/registry](https://tessl.io/registry) et [skills.sh](https://skills.sh/) proposent des skills créées par la communauté, compatibles avec toutes les plateformes qui supportent SKILL.md.

### Exercice C6 : Évaluer une agent skill (10 min)

**Objectif** : Utiliser le CLI Tessl combiné à Gemini CLI pour améliorer itérativement la qualité de la skill jusqu'à atteindre un score de 100 %

> **Notes : un compte Tessl est désormais requis pour évaluer des skills. Inscrivez-vous une fois sur https://tessl.io/login?returnPathname=%2Fregistry**

1. **Connectez-vous à Tessl** (une seule fois ; passez cette étape si vous êtes déjà authentifié) :

```bash
npx --yes tessl login
```

Cela ouvre un navigateur pour s'authentifier — c'est nécessaire avant que `tessl review run` fonctionne (vérifiable à tout moment avec `npx --yes tessl whoami`).

2. **Lancez la première revue de skill Tessl** :

```bash
npx --yes tessl review run .gemini/skills/change-impact-analysis/SKILL.md
```

3. **Demandez à Gemini CLI d'améliorer la skill jusqu'à un score de 100 %** :

```
Run `npx --yes tessl review run .gemini/skills/change-impact-analysis/SKILL.md` and analyze the output.
Then improve the SKILL.md file based on the quality score, impact score, and improvement suggestions reported.
Repeat — run the review again, apply further improvements — until the reported score is 100%.
```

4. **Validez le score final** — relancez la revue une dernière fois pour confirmer le score de 100 % :

```bash
npx --yes tessl review run .gemini/skills/change-impact-analysis/SKILL.md
```

**Résultat attendu** : SKILL.md atteint un score de qualité de 100 % d'après le CLI Tessl

**Référence** : https://tessl.io/registry/skills/submit

### Exercice C7 : Configurer des hooks (20 min)

**Objectif** : Mettre en place la validation par hooks avec des scripts shell

1. Créez le répertoire des hooks :

```bash
mkdir -p .gemini/hooks
```

2. **Tâche** : Créez `.gemini/settings.json` :

```json
{
  "enableHooks": true,
  "hooks": {
    "BeforeTool": [
      {
        "matcher": "run_shell_command",
        "hooks": [
          {
            "name": "validate-commit",
            "type": "command",
            "command": ".gemini/hooks/validate-commit.sh",
            "timeout": 15000
          }
        ]
      }
    ],
    "AfterTool": [
      {
        "matcher": "write_file|replace",
        "hooks": [
          {
            "name": "validate-coding-standards",
            "type": "command",
            "command": ".gemini/hooks/validate-coding-standards.sh",
            "timeout": 10000
          }
        ]
      }
    ]
  }
}
```

3. Créez le script de hook `.gemini/hooks/validate-commit.sh` :

```bash
#!/usr/bin/env bash
input=$(cat)
command=$(echo "$input" | jq -r '.tool_input.command // ""')
if [[ ! "$command" =~ git[[:space:]]+commit ]]; then
  exit 0
fi

# Check for violations (console.log, TODO without ticket, etc.)
echo '{"systemMessage":"All commit checks passed"}'
exit 0
```

4. Rendez les scripts exécutables : `chmod +x .gemini/hooks/*.sh`

▶ **Windows (PowerShell) — scripts de hooks Gemini**

Sur Windows, ignorez `chmod +x`. Créez les équivalents PowerShell des scripts de hooks et mettez à jour `.gemini/settings.json` pour qu'il les cible.

**Mettez à jour `.gemini/settings.json`** pour utiliser des commandes PowerShell sur Windows :

```json
{
  "enableHooks": true,
  "hooks": {
    "BeforeTool": [
      {
        "matcher": "run_shell_command",
        "hooks": [
          {
            "name": "validate-commit",
            "type": "command",
            "command": "powershell -File .gemini/hooks/validate-commit.ps1",
            "timeout": 15000
          }
        ]
      }
    ],
    "AfterTool": [
      {
        "matcher": "write_file|replace",
        "hooks": [
          {
            "name": "validate-coding-standards",
            "type": "command",
            "command": "powershell -File .gemini/hooks/validate-coding-standards.ps1",
            "timeout": 10000
          }
        ]
      }
    ]
  }
}
```

**Créez `.gemini/hooks/validate-commit.ps1`** :

```powershell
# Gemini CLI BeforeTool hook: Validate git commit commands

$inputData = [Console]::In.ReadToEnd() | ConvertFrom-Json
$command = $inputData.tool_input.command

# Only process git commit commands
if ($command -notmatch "git\s+commit") {
    exit 0
}

Write-Host "🔍 Running code-reviewer on all modified files..."

$filesToCheck = git diff HEAD --name-only 2>$null
if (-not $filesToCheck) {
    '{"systemMessage":"✅ No modified files to check"}' | Write-Host
    exit 0
}

$violations = @()

foreach ($file in $filesToCheck) {
    if (-not (Test-Path $file)) { continue }
    if ($file -match "\.(ts|tsx|js|jsx)$") {
        $content = Get-Content $file -Raw -ErrorAction SilentlyContinue
        if ($content -match "console\.log") { $violations += "- ${file}: contains console.log statements" }
        if ($content -match ": any") { $violations += "- ${file}: avoid using 'any' type" }
    }
}

if ($violations.Count -gt 0) {
    $reason = "Coding standards violations detected:`n" + ($violations -join "`n")
    @{ decision = "deny"; reason = $reason } | ConvertTo-Json -Compress | Write-Host
    exit 2
}

'{"systemMessage":"✅ Staged files pass coding standards check"}' | Write-Host
exit 0
```

**Créez `.gemini/hooks/validate-coding-standards.ps1`** :

```powershell
# Gemini CLI AfterTool hook: Validate file changes against coding-standards.md

$inputData = [Console]::In.ReadToEnd() | ConvertFrom-Json
$filePath = $inputData.tool_input.file_path
$content = $inputData.tool_input.content

if (-not $filePath) { exit 0 }

# Only check TypeScript/JavaScript files
if ($filePath -notmatch "\.(ts|tsx|js|jsx)$") {
    '{"systemMessage":"⏭️ Skipped: Not a TS/JS file"}' | Write-Host
    exit 0
}

Write-Host "🔍 Validating against coding-standards.md..."

$violations = @()

if ($content -match "console\.log") {
    $violations += "- Remove console.log statements before committing"
}
if ($content -match ": any") {
    $violations += "- Avoid using 'any' type - use proper TypeScript types"
}
if ($content -match "TODO[^:(]") {
    $violations += "- TODO comments should reference a ticket (e.g., TODO(TICKET-123))"
}

if ($violations.Count -gt 0) {
    $violations | ForEach-Object { Write-Host $_ -ForegroundColor Yellow }
    '{"systemMessage":"⚠️ Review coding standards suggestions above"}' | Write-Host
} else {
    '{"systemMessage":"✅ File follows coding standards"}' | Write-Host
}

exit 0
```

> **Alternative** : Si vous avez Git Bash ou WSL, vous pouvez utiliser les scripts `.sh` d'origine sans modification et conserver les chemins bash dans `settings.json`.

**Résultat attendu** : Les scripts de hooks valident les commits et les standards de code

**Référence** : Comparez avec `../lab-41-agentic-tools-deep-dive-solution/resources/photo-gallery-fullstack-solution/.gemini/hooks/validate-commit.sh`

### Exercice C8 : Explorer les extensions (10 min)

**Objectif** : Découvrir et installer une extension Gemini CLI

1. **Tâche** : Parcourez la galerie d'extensions :

   Rendez-vous sur https://geminicli.com/extensions/ pour explorer les extensions disponibles

2. Installez une extension depuis GitHub :

```bash
gemini extensions install https://github.com/gemini-cli-extensions/workspace
```

3. Listez les extensions installées :

```bash
gemini extensions list
```

4. (Optionnel) Créez une nouvelle extension à partir d'un template :

```bash
gemini extensions new my-extension
```

5. Explorez la structure générée :

```
my-extension/
├── gemini-extension.json    # Manifest
├── commands/                # Custom commands (TOML)
├── hooks/                   # Hook definitions
├── skills/                  # Agent skills
├── agents/                  # Sub-agents (*.md)
└── GEMINI.md                # Context file
```

6. (Optionnel) Validez l'extension :

```bash
gemini extensions validate ./my-extension
```

**Résultat attendu** : Comprendre comment les extensions regroupent commandes, hooks, skills et agents dans des paquets distribuables

**Référence des commandes CLI** : `gemini extensions install`, `list`, `new`, `validate`, `update`, `enable`, `disable`, `config`

**Note** : Gemini CLI compte plus de 557 extensions dans sa galerie, dont des intégrations avec Figma, Jira, Stripe et d'autres

### Exercice C9 : Configurer les settings (10 min)

**Objectif** : Compléter la configuration des settings de Gemini CLI

1. **Tâche** : Mettez à jour `.gemini/settings.json` pour activer les hooks et configurer les outils :

```json
{
  "enableHooks": true,
  "hooks": {
    "BeforeTool": [
      {
        "matcher": "run_shell_command",
        "hooks": [
          {
            "name": "validate-commit",
            "type": "command",
            "command": "$GEMINI_PROJECT_DIR/.gemini/hooks/validate-commit.sh",
            "description": "Run code-reviewer on staged files for git commits",
            "timeout": 15000
          }
        ]
      },
      {
        "matcher": "write_file",
        "hooks": [
          {
            "name": "validate-writes",
            "type": "command",
            "command": "$GEMINI_PROJECT_DIR/.gemini/hooks/validate-writes.sh",
            "description": "Validate file write operations for security patterns",
            "timeout": 10000
          }
        ]
      },
      {
        "matcher": "replace",
        "hooks": [
          {
            "name": "validate-writes",
            "type": "command",
            "command": "$GEMINI_PROJECT_DIR/.gemini/hooks/validate-writes.sh",
            "description": "Validate file write operations for security patterns",
            "timeout": 10000
          }
        ]
      }
    ],
    "AfterTool": [
      {
        "matcher": "write_file",
        "hooks": [
          {
            "name": "validate-coding-standards",
            "type": "command",
            "command": "$GEMINI_PROJECT_DIR/.gemini/hooks/validate-coding-standards.sh",
            "description": "Validate against coding-standards.md",
            "timeout": 10000
          }
        ]
      },
      {
        "matcher": "replace",
        "hooks": [
          {
            "name": "validate-coding-standards",
            "type": "command",
            "command": "$GEMINI_PROJECT_DIR/.gemini/hooks/validate-coding-standards.sh",
            "description": "Validate against coding-standards.md",
            "timeout": 10000
          }
        ]
      }
    ]
  }
}
```

**Résultat attendu** : Configuration complète des settings, avec hooks activés

**Référence** : Comparez avec `../lab-41-agentic-tools-deep-dive-solution/resources/photo-gallery-fullstack-solution/.gemini/settings.json`

---

▶ **Section D : exercices Codex CLI**

**Plateforme** : OpenAI Codex CLI
**Configurations de référence** : `../lab-41-agentic-tools-deep-dive-solution/resources/photo-gallery-fullstack-solution/.codex/` et `../lab-41-agentic-tools-deep-dive-solution/resources/photo-gallery-fullstack-solution/AGENTS.md`

### Exercice D1 : Initialiser AGENTS.md (10 min)

**Objectif** : Créer le fichier de contexte projet pour Codex CLI avec `/init`

`AGENTS.md` est chargé automatiquement par Codex CLI au démarrage de la session (dès que le projet est approuvé) — il fournit les instructions propres au projet, les règles d'architecture et les conventions qui s'appliquent globalement à toutes les sessions.

1. Placez-vous dans le projet et approuvez-le :

```bash
cd photo-gallery-fullstack
codex trust .
```

2. Lancez `/init` pour analyser le projet et générer automatiquement un `AGENTS.md` :

Codex CLI parcourt le code et génère un `AGENTS.md` à la racine du projet avec les patterns détectés, les dépendances et les conventions suggérées.

3. Relisez le fichier généré et personnalisez-le. Votre `AGENTS.md` final doit contenir des sections telles que : **Architecture**, **Domain Rules**, **Coding Standards**, etc.

4. Vérifiez que Codex charge bien le fichier en ouvrant une nouvelle session Codex à la racine du projet et en demandant :

```txt
Describe the architecture of this photo gallery application
```

**Résultat attendu** : `AGENTS.md` créé à la racine du projet. Codex référence automatiquement ces règles à chaque session, sans qu'il faille réexpliquer l'architecture du projet.

**Référence** : Comparez avec `../lab-41-agentic-tools-deep-dive-solution/resources/photo-gallery-fullstack-solution/AGENTS.md`

### Exercice D2 : Créer un agent personnalisé (subagent) (15 min)

**Objectif** : Créer un agent de revue spécialisé au format TOML

1. **Tâche** : Créez le répertoire de l'agent :

```bash
mkdir -p .codex/agents
```

▶ **Équivalent Windows (PowerShell)**

```powershell
New-Item -ItemType Directory -Force -Path .codex/agents
```

2. Créez `.codex/agents/architecture-guardian.toml` :

```toml
name = "architecture-guardian"
description = "Validates design decisions against team architectural patterns and ensures alignment with system topology"

developer_instructions = """
You are the Architecture Guardian for the photo-gallery project. Your role is to ensure all code changes align with established architectural patterns, maintain system integrity, and follow documented design principles.

## Core Responsibilities

- Validate Design Decisions: Review proposed architectural changes against architecture.md and ensure alignment with system topology
- Identify Violations: Flag deviations from established patterns, anti-patterns, and architectural debt
- Suggest Refactoring: Recommend improvements that align with team conventions and long-term maintainability
- Maintain Boundaries: Enforce module boundaries and prevent tight coupling between layers
- Review Dependencies: Assess impact of new dependencies and ensure they fit architectural vision

## Context Files

You have access to the following knowledge references:
- architecture.md: System topology, module boundaries, data flow patterns
- coding-standards.md: Team conventions, naming patterns, file organization
- domain-glossary.md: Business terminology and domain model definitions

## Interaction Guidelines

When consulted, you should:
1. Assess Context: Understand the scope and intent of the proposed change
2. Reference Standards: Cite specific sections from architecture.md or coding-standards.md
3. Evaluate Trade-offs: Explain pros/cons of different architectural approaches
4. Provide Specific Recommendations: Give actionable guidance with code examples where applicable
5. Flag Risks: Identify potential scalability, performance, or maintainability concerns

## Example Invocations

- "Should this new feature live in the api module or domain module?"
- "Is it acceptable to add a direct dependency from ui to storage?"
- "What's the recommended pattern for handling cross-cutting concerns?"
- "Validate this component structure against our architecture guidelines"

## Decision Framework

When multiple valid approaches exist, prioritize:
1. Consistency with existing patterns
2. Maintainability and readability
3. Testability and isolation
4. Performance (only when measurable impact exists)
5. Future extensibility

You are an advisor, not a gatekeeper. Provide reasoned guidance but acknowledge when trade-offs are acceptable given project constraints.
"""

model = "gpt-5-codex"
sandbox_mode = "read-only"
model_reasoning_effort = "high"
```

3. Configurez les paramètres de l'agent dans `.codex/config.toml` :

```toml
[agents]
max_threads = 4
max_depth = 1
job_max_runtime_seconds = 300
```

4. **Testez** : Démarrez Codex et posez des questions d'architecture :

```txt
@architecture-guardian Should this photo filter feature live in the api module or domain module?
```

**Résultat attendu** : Les agents personnalisés sont chargés et peuvent recevoir des tâches spécialisées par délégation

**Référence** : Comparez avec `../lab-41-agentic-tools-deep-dive-solution/resources/photo-gallery-fullstack-solution/.codex/agents/`

### Exercice D3 : Créer une agent skill (10 min)

**Objectif** : Créer la skill d'analyse d'impact des changements

1. Créez le répertoire des skills :

```bash
mkdir -p .codex/skills/change-impact-analysis
```

2. **Tâche** : Créez le fichier `.codex/skills/change-impact-analysis/SKILL.md` :

```markdown
---
name: change-impact-analysis
description: Assess the scope and risk of proposed code changes by analyzing affected components, blast radius, and potential side effects. Use when reviewing pull requests, planning large refactorings, assessing deployment readiness, or evaluating rollback complexity.
---

# Change Impact Analysis Skill

## Purpose

Assess the scope and risk of proposed code changes by analyzing affected components, blast radius, and potential side effects. This skill helps teams make informed decisions about change safety.

## Capabilities

### 1. Blast Radius Assessment

- Quantify how many files, modules, and services are affected
- Categorize changes by risk level (low/medium/high/critical)
- Identify cascading effects of a change

### 2. Risk Scoring

- Calculate risk based on change size, complexity, and affected components
- Flag high-risk changes requiring extra review or testing
- Recommend mitigation strategies proportional to risk

### 3. Side Effect Detection

- Identify unintended consequences of changes
- Flag performance implications
- Detect security or compliance impacts

## Usage Context

This skill activates when:

- Reviewing pull requests for approval
- Planning large refactorings or migrations
- Assessing deployment readiness
- Evaluating rollback complexity

## Knowledge Sources

- **testing-guidelines.md**: Test coverage requirements by risk level
- **architecture.md**: Critical paths and high-risk components
- **Git history**: Past incidents correlated with similar changes

## Risk Assessment Framework

### Risk Factors

| Factor             | Weight | Criteria                                                                                  |
| ------------------ | ------ | ----------------------------------------------------------------------------------------- |
| **Lines Changed**  | 20%    | <50 (low) / 50-200 (med) / 200-500 (high) / >500 (critical)                               |
| **Files Affected** | 15%    | <5 (low) / 5-10 (med) / 10-20 (high) / >20 (critical)                                     |
| **Test Coverage**  | 25%    | >80% (low) / 60-80% (med) / 40-60% (high) / <40% (critical)                               |
| **Critical Path**  | 30%    | Not on critical path (low) / Near critical (med) / On critical path (high)                |
| **Rollback Ease**  | 10%    | Easy revert (low) / Config change (med) / DB migration (high) / Data loss risk (critical) |

### Risk Categories

**LOW RISK** (Score: 0-30): Small, isolated changes with high test coverage and easy rollback

**MEDIUM RISK** (Score: 31-60): Moderate scope changes with adequate test coverage

**HIGH RISK** (Score: 61-85): Large scope or critical path changes with test coverage gaps

**CRITICAL RISK** (Score: 86-100): Changes to security/data integrity systems with insufficient testing

## Metrics

Success criteria for impact analysis:

- ✅ Accurately classifies 90%+ of changes by risk
- ✅ Zero high-risk changes deployed without appropriate safeguards
- ✅ Reduces production incidents by 30% through better risk assessment
```

3. **Testez** : Demandez à Codex :

```txt
$change-impact-analysis If I modify the PhotoRepository interface, what is the risk level?
```

**Résultat attendu** : Codex applique la skill pour évaluer le risque du changement

**Référence** : Comparez avec `../lab-41-agentic-tools-deep-dive-solution/resources/photo-gallery-fullstack-solution/.codex/skills/change-impact-analysis/SKILL.md`

### Exercice D4 : Installer une skill depuis un registre public (10 min)

**Objectif** : Rechercher et installer une skill communautaire depuis le registre Tessl

1. **Tâche** : Recherchez la skill `skill-creator` :

```bash
npx tessl search skill-creator
```

2. Installez-la localement :

```bash
npx tessl install anthropics/claude-plugins-official/skill-creator
```

3. Déplacez la skill installée vers `.codex/skills/skill-creator/`

4. **Testez** avec une invocation explicite :

```
$skill-creator "Help me create a skill for API documentation generation"
```

**Résultat attendu** : Skill communautaire installée et invocable via `$skill-creator`

**Référence** : https://tessl.io/registry/skills/github/anthropics/claude-plugins-official/skill-creator

### Exercice D5 : Évaluer une agent skill (10 min)

**Objectif** : Utiliser le CLI Tessl combiné à Codex CLI pour améliorer itérativement la qualité de la skill jusqu'à atteindre un score de 100 %

> **Notes : un compte Tessl est désormais requis pour évaluer des skills. Inscrivez-vous une fois sur https://tessl.io/login?returnPathname=%2Fregistry**

1. **Connectez-vous à Tessl** (une seule fois ; passez cette étape si vous êtes déjà authentifié) :

```bash
npx --yes tessl login
```

Cela ouvre un navigateur pour s'authentifier — c'est nécessaire avant que `tessl review run` fonctionne (vérifiable à tout moment avec `npx --yes tessl whoami`).

2. **Lancez la première revue de skill Tessl** :

```bash
npx --yes tessl review run .codex/skills/change-impact-analysis/SKILL.md
```

3. **Demandez à Codex CLI d'améliorer la skill jusqu'à un score de 100 %** :

```
Run `npx --yes tessl review run .codex/skills/change-impact-analysis/SKILL.md` and analyze the output.
Then improve the SKILL.md file based on the quality score, impact score, and improvement suggestions reported.
Repeat — run the review again, apply further improvements — until the reported score is 100%.
```

4. **Validez le score final** — relancez la revue une dernière fois pour confirmer le score de 100 % :

```bash
npx --yes tessl review run .codex/skills/change-impact-analysis/SKILL.md
```

**Résultat attendu** : SKILL.md atteint un score de qualité de 100 % d'après le CLI Tessl

**Référence** : https://tessl.io/registry/skills/submit

### Exercice D6 : Configurer les Codex Rules (15 min)

**Objectif** : Créer des règles en Starlark pour l'allowlisting de commandes

Codex CLI utilise des Rules (fichiers `.rules` écrits en Starlark) au lieu de hooks pour contrôler les commandes. Les Rules définissent statiquement quelles commandes sont autorisées, nécessitent une approbation ou sont interdites — l'évaluation a lieu au moment de l'invocation de la commande, sans exécuter de script shell.

1. Créez le répertoire des règles :

```bash
mkdir -p .codex/rules
```

2. Créez `.codex/rules/project.rules` :

```python
# Codex CLI Rules — Starlark-based command policy
# Test with: codex execpolicy check --pretty --rules .codex/rules/project.rules -- <command>

def prefix_rule(ctx):
    cmd = ctx.command

    # Allow all npm/npx commands
    if cmd[:4] == "npm " or cmd[:4] == "npx ":
        return rule(
            decision = "allow",
            justification = "npm/npx commands are safe for this project",
        )

    # Allow all read-only git commands
    if cmd in ["git status", "git log", "git diff", "git show"]:
        return rule(
            decision = "allow",
            justification = "read-only git commands always allowed",
        )

    # Require approval for all other git commands
    if cmd[:4] == "git ":
        return rule(
            decision = "prompt",
            justification = "git write operations require review",
        )

    # Forbid destructive operations
    if "rm -rf" in cmd or "drop table" in cmd.lower():
        return rule(
            decision = "forbidden",
            justification = "destructive operations are not allowed",
        )

    return rule(decision = "prompt")
```

3. Testez les règles :

```bash
# Should output: allow
codex execpolicy check --pretty --rules .codex/rules/project.rules -- "npm install"

# Should output: prompt
codex execpolicy check --pretty --rules .codex/rules/project.rules -- "git push"

# Should output: forbidden
codex execpolicy check --pretty --rules .codex/rules/project.rules -- "rm -rf node_modules"
```

4. Référencez les règles dans `.codex/config.toml` :

```toml
[rules]
files = [".codex/rules/project.rules"]
```

**Résultat attendu** : Les Rules appliquent statiquement les politiques de commandes. `npm install` est autorisé immédiatement, `git push` requiert une approbation et `rm -rf` est interdit. Les Rules sont évaluées sans exécuter aucun script shell externe.

**Note** : Les Codex Rules sont l'alternative de Codex CLI aux hooks (utilisés par Claude, Copilot et Gemini). Les Rules s'écrivent en Starlark (un langage proche de Python) et fournissent une frontière de sécurité statique, évaluée au moment de l'invocation de la commande.

**Référence** : Comparez avec `../lab-41-agentic-tools-deep-dive-solution/resources/photo-gallery-fullstack-solution/.codex/rules/project.rules`

### Exercice D7 : Configurer la sandbox et les approbations (10 min)

**Objectif** : Définir les limites de la sandbox

1. **Tâche** : Ajoutez la configuration de sandbox à `.codex/config.toml` :

```toml
[sandbox_workspace_write]
writable_roots = ["apps/", "dist/", ".codex/"]
network_access = false
```

2. Comprenez les politiques d'approbation :

| Politique    | Comportement                            |
| ------------ | --------------------------------------- |
| `untrusted`  | Demande pour chaque action              |
| `on-failure` | Demande seulement si la commande échoue |
| `on-request` | Demande pour les opérations d'écriture  |
| `never`      | Exécute tout                            |

3. **Testez** : Essayez de modifier un fichier hors de writable_roots

**Résultat attendu** : La sandbox restreint les écritures aux répertoires configurés

### Exercice D8 : Configurer des profils (15 min)

**Objectif** : Mettre en place des profils de configuration nommés

1. **Tâche** : Créez `.codex/config.toml` :

```toml
model = "gpt-5-codex"
approval_policy = "on-request"
sandbox_mode = "workspace-write"
model_reasoning_effort = "medium"

[profiles.deep-review]
model = "gpt-5-pro"
model_reasoning_effort = "high"
approval_policy = "on-request"

[profiles.lightweight]
model = "gpt-4.1"
model_reasoning_effort = "low"
approval_policy = "on-failure"

[profiles.testing]
model = "gpt-5-codex"
model_reasoning_effort = "medium"
approval_policy = "on-failure"
```

2. **Testez** : Démarrez Codex avec un profil précis :

```bash
codex --profile deep-review
```

3. Vérifiez la configuration : `/status`

**Résultat attendu** : Les réglages du profil surchargent les valeurs par défaut

**Note** : Les trois profils ci-dessus couvrent les cas d'usage principaux. Le `config.toml` de la solution contient aussi la configuration de sandbox et de rules ajoutée aux exercices D4 et D5.

**Référence** : Comparez avec `../lab-41-agentic-tools-deep-dive-solution/resources/photo-gallery-fullstack-solution/.codex/config.toml`

---

▶ **Section E : exercices OpenCode**

**Plateforme** : OpenCode
**Configurations de référence** : `../lab-41-agentic-tools-deep-dive-solution/resources/photo-gallery-fullstack-solution/.opencode/` et `../lab-41-agentic-tools-deep-dive-solution/resources/photo-gallery-fullstack-solution/AGENTS.md`

### Exercice E1 : Initialiser AGENTS.md (10 min)

**Objectif** : Créer les instructions projet avec `/init`

`AGENTS.md` est chargé automatiquement par OpenCode au démarrage de la session — il fournit les instructions propres au projet, les règles d'architecture et les conventions qui s'appliquent globalement à toutes les sessions.

1. Placez-vous dans le projet et démarrez OpenCode :

```bash
cd photo-gallery-fullstack
opencode
```

2. Lancez `/init` pour analyser le code et générer `AGENTS.md` :

```
/init
```

OpenCode analyse votre projet et crée `AGENTS.md` à la racine du projet avec les étapes de build, les dépendances et les conventions détectées.

**Résultat attendu** : `AGENTS.md` créé à la racine du projet. OpenCode référence automatiquement ces règles à chaque session.

**Référence** : Comparez avec `../lab-41-agentic-tools-deep-dive-solution/resources/photo-gallery-fullstack-solution/AGENTS.md`

### Exercice E2 : Explorer les modes intégrés (10 min)

**Objectif** : Utiliser le mode `plan` intégré pour explorer le code sans risque

OpenCode fournit deux agents principaux intégrés, entre lesquels vous basculez avec `Tab` :

- **build** (par défaut) : Accès complet — lecture de fichiers, écriture, exécution bash
- **plan** : Lecture seule — aucun outil d'édition, sans risque pour l'analyse

1. Basculez en mode plan en appuyant sur `Tab`

2. Demandez à OpenCode d'analyser le code sans rien modifier :

```
Analyze the photo-gallery architecture and identify where I should add a photo tagging feature. List all files that would need to change.
```

3. Relisez l'analyse — aucun fichier n'a été modifié

4. Appuyez à nouveau sur `Tab` pour revenir en mode build

5. Utilisez la sortie du plan pour démarrer l'implémentation :

```
Based on the plan, implement the photo tagging feature in the domain layer
```

**Résultat attendu** : Le mode plan permet une exploration en lecture seule sans risque ; le retour en mode build permet d'implémenter à partir de la sortie du plan.

### Exercice E3 : Créer un agent personnalisé (15 min)

**Objectif** : Créer un agent gardien de l'architecture

1. Créez le répertoire des agents :

```bash
mkdir -p .opencode/agents
```

2. Créez le fichier `.opencode/agents/architecture-guardian.md` :

```markdown
---
description: Validates design decisions against team architectural patterns and ensures alignment with system topology
model: anthropic/claude-sonnet-4-6
---

# Architecture Guardian

You are the **Architecture Guardian** for the photo-gallery project. Your role is to ensure all code changes align with established architectural patterns, maintain system integrity, and follow documented design principles.

## Core Responsibilities

- **Validate Design Decisions**: Review proposed architectural changes against `architecture.md` and ensure alignment with system topology
- **Identify Violations**: Flag deviations from established patterns, anti-patterns, and architectural debt
- **Suggest Refactoring**: Recommend improvements that align with team conventions and long-term maintainability
- **Maintain Boundaries**: Enforce module boundaries and prevent tight coupling between layers
- **Review Dependencies**: Assess impact of new dependencies and ensure they fit architectural vision

## Context Files

You have access to the following knowledge references:

- **architecture.md**: System topology, module boundaries, data flow patterns
- **coding-standards.md**: Team conventions, naming patterns, file organization
- **domain-glossary.md**: Business terminology and domain model definitions

## Interaction Guidelines

When consulted, you should:

1. **Assess Context**: Understand the scope and intent of the proposed change
2. **Reference Standards**: Cite specific sections from architecture.md or coding-standards.md
3. **Evaluate Trade-offs**: Explain pros/cons of different architectural approaches
4. **Provide Specific Recommendations**: Give actionable guidance with code examples where applicable
5. **Flag Risks**: Identify potential scalability, performance, or maintainability concerns

## Decision Framework

When multiple valid approaches exist, prioritize:

1. **Consistency** with existing patterns
2. **Maintainability** and readability
3. **Testability** and isolation
4. **Performance** (only when measurable impact exists)
5. **Future extensibility**

You are an advisor, not a gatekeeper. Provide reasoned guidance but acknowledge when trade-offs are acceptable given project constraints.
```

3. **Testez** : Demandez à OpenCode d'utiliser l'agent :

```
@architecture-guardian I want to add a photo filter feature. Should this go in the API layer or domain layer?
```

**Résultat attendu** : OpenCode active l'agent d'après sa description et fournit des conseils d'architecture

**Référence** : Comparez avec `../lab-41-agentic-tools-deep-dive-solution/resources/photo-gallery-fullstack-solution/.opencode/agents/architecture-guardian.md`

### Exercice E4 : Créer une commande personnalisée (10 min)

**Objectif** : Créer une slash command de revue de code

1. Créez le répertoire des commandes :

```bash
mkdir -p .opencode/commands
```

2. Créez le fichier `.opencode/commands/code-reviewer.md` :

```markdown
---
description: Analyze code changes and generate actionable code review comments aligned with team standards
agent: architecture-guardian
---

# Code Reviewer

Analyze code changes and generate actionable code review comments aligned with team standards.

## Purpose

Assist code reviewers by:

- Identifying potential bugs, security issues, and performance problems
- Flagging violations of team coding standards and architectural patterns
- Suggesting improvements for readability and maintainability
- Highlighting risks that require extra scrutiny

## Instructions

Analyze the current git diff (staged or unstaged changes).

Reference the team standards from the project's coding-standards.md and architecture.md files.

## Output Format

Produce review comments organized by:

1. **Critical Issues**: Bugs, security vulnerabilities, breaking changes (must fix)
2. **Architectural Concerns**: Pattern violations, coupling issues (should fix)
3. **Code Quality**: Readability, maintainability, test coverage (nice to have)
4. **Suggestions**: Performance optimizations, refactoring opportunities (optional)

Each comment includes:

- **File and line reference**
- **Severity**: Critical / High / Medium / Low
- **Category**: Bug / Security / Architecture / Style / Performance
- **Description**: What the issue is and why it matters
- **Recommendation**: Specific action to address the issue
```

3. **Testez** : Faites une petite modification de code, puis lancez :

```
/code-reviewer
```

**Résultat attendu** : OpenCode exécute la commande via l'agent architecture-guardian et produit une sortie de revue structurée

**Référence** : Comparez avec `../lab-41-agentic-tools-deep-dive-solution/resources/photo-gallery-fullstack-solution/.opencode/commands/code-reviewer.md`

### Exercice E5 : Créer une agent skill (10 min)

**Objectif** : Créer une skill d'analyse d'impact des changements

1. Créez le répertoire des skills :

```bash
mkdir -p .opencode/skills/change-impact-analysis
```

2. Créez le fichier `.opencode/skills/change-impact-analysis/SKILL.md` :

```markdown
---
name: change-impact-analysis
description: Assess the scope and risk of proposed code changes by analyzing affected components, blast radius, and potential side effects. Use when reviewing pull requests, planning large refactorings, assessing deployment readiness, or evaluating rollback complexity.
---

# Change Impact Analysis Skill

## Purpose

Assess the scope and risk of proposed code changes by analyzing affected components, blast radius, and potential side effects. This skill helps teams make informed decisions about change safety.

## Capabilities

### 1. Blast Radius Assessment

- Quantify how many files, modules, and services are affected
- Categorize changes by risk level (low/medium/high/critical)
- Identify cascading effects of a change

### 2. Risk Scoring

- Calculate risk based on change size, complexity, and affected components
- Flag high-risk changes requiring extra review or testing
- Recommend mitigation strategies proportional to risk

### 3. Side Effect Detection

- Identify unintended consequences of changes
- Flag performance implications
- Detect security or compliance impacts

## Usage Context

This skill activates when:

- Reviewing pull requests for approval
- Planning large refactorings or migrations
- Assessing deployment readiness
- Evaluating rollback complexity

## Risk Assessment Framework

| Factor             | Weight | Criteria                                                                                  |
| ------------------ | ------ | ----------------------------------------------------------------------------------------- |
| **Lines Changed**  | 20%    | <50 (low) / 50-200 (med) / 200-500 (high) / >500 (critical)                               |
| **Files Affected** | 15%    | <5 (low) / 5-10 (med) / 10-20 (high) / >20 (critical)                                     |
| **Test Coverage**  | 25%    | >80% (low) / 60-80% (med) / 40-60% (high) / <40% (critical)                               |
| **Critical Path**  | 30%    | Not on critical path (low) / Near critical (med) / On critical path (high)                |
| **Rollback Ease**  | 10%    | Easy revert (low) / Config change (med) / DB migration (high) / Data loss risk (critical) |
```

3. **Testez** : Demandez à OpenCode :

```
If I change the PhotoRepository interface, what files will be affected?
```

**Résultat attendu** : OpenCode utilise automatiquement la skill pour fournir une analyse d'impact

**Référence** : Comparez avec `../lab-41-agentic-tools-deep-dive-solution/resources/photo-gallery-fullstack-solution/.opencode/skills/change-impact-analysis/SKILL.md`

### Exercice E6 : Installer une skill depuis un registre public (10 min)

**Objectif** : Rechercher et installer une skill communautaire depuis le registre Tessl

1. Recherchez la skill `skill-creator` :

```bash
npx -y skills find skill-creator
```

2. Installez-la localement :

```bash
npx -y skills add https://github.com/anthropics/skills --skill skill-creator
```

3. Déplacez la skill installée vers `.opencode/skills/skill-creator/`

4. **Testez** : Demandez à OpenCode d'utiliser la skill :

```

Using the skill-creator skill, help me create a new skill for API documentation generation

```

**Résultat attendu** : Skill communautaire installée et disponible pour OpenCode

**Note** : Les registres publics comme [tessl.io/registry](https://tessl.io/registry) et [skills.sh](https://skills.sh/) proposent des skills créées par la communauté, compatibles avec toutes les plateformes qui supportent SKILL.md.

### Exercice E7 : Évaluer une agent skill (10 min)

**Objectif** : Utiliser le CLI Tessl combiné à OpenCode pour améliorer itérativement la qualité de la skill jusqu'à atteindre un score de 100 %

> **Notes : un compte Tessl est désormais requis pour évaluer des skills. Inscrivez-vous une fois sur https://tessl.io/login?returnPathname=%2Fregistry**

1. **Connectez-vous à Tessl** (une seule fois ; passez cette étape si vous êtes déjà authentifié) :

```bash
npx --yes tessl login
```

Cela ouvre un navigateur pour s'authentifier — c'est nécessaire avant que `tessl review run` fonctionne (vérifiable à tout moment avec `npx --yes tessl whoami`).

2. **Lancez la première revue de skill Tessl** :

```bash
npx --yes tessl review run .opencode/skills/change-impact-analysis/SKILL.md
```

3. **Demandez à OpenCode d'améliorer la skill jusqu'à un score de 100 %** :

```
Run `npx --yes tessl review run .opencode/skills/change-impact-analysis/SKILL.md` and analyze the output.
Then improve the SKILL.md file based on the quality score, impact score, and improvement suggestions reported.
Repeat — run the review again, apply further improvements — until the reported score is 100%.
```

4. **Validez le score final** — relancez la revue une dernière fois pour confirmer le score de 100 % :

```bash
npx --yes tessl review run .opencode/skills/change-impact-analysis/SKILL.md
```

**Résultat attendu** : SKILL.md atteint un score de qualité de 100 % d'après le CLI Tessl

**Référence** : https://tessl.io/registry/skills/submit

### Exercice E8 : Créer un plugin (15 min)

**Objectif** : Créer un plugin de pré-validation qui filtre l'exécution des outils via l'événement `"tool.execute.before"`

Les plugins OpenCode sont des fichiers JavaScript ou TypeScript placés dans `.opencode/plugins/`. Chaque plugin exporte une fonction async qui reçoit un objet de contexte et renvoie un objet de hooks indexé par nom d'événement. Contrairement aux hooks JSON de Claude Code dans `settings.json`, les plugins OpenCode sont du vrai code, avec accès à l'API shell de Bun (`$`) et au client du SDK opencode.

1. Créez le répertoire des plugins :

```bash
mkdir -p .opencode/plugins
```

2. Créez le fichier `.opencode/plugins/env-protection.js` :

```js
// .opencode/plugins/env-protection.js
export const EnvProtectionPlugin = async ({ project, client, $, directory, worktree }) => {
  return {
    // Fires before every tool call — can throw to block the action
    'tool.execute.before': async (input, output) => {
      // Block the agent from reading .env files
      if (input.tool === 'read' && output.args.filePath?.includes('.env')) {
        throw new Error('Reading .env files is not allowed — use environment variables instead');
      }
    },
  };
};
```

3. **Testez** : Demandez à OpenCode de lire le fichier `.env` :

```
Read the .env file and show me the contents
```

**Résultat attendu** : La tentative de lecture de `.env` par OpenCode est bloquée par le plugin, avec le message d'erreur. La session continue — seul cet appel d'outil précis est rejeté.

> **Notes** L'agent a-t-il contourné la restriction et réussi à lire le fichier `.env` malgré tout ?
>
> Si oui, consultez https://opencode.ai/docs/tools/#built-in pour comprendre pourquoi 😉 (💡 Indice : `bash`...)
> Vous devrez peut-être améliorer la condition du plugin pour bloquer aussi les commandes `bash` qui tentent de lire des fichiers `.env`, ou tout autre outil permettant d'accéder au contenu du fichier.

4. **Étendez-le** : Ajoutez un second hook pour journaliser chaque commande bash dans la session :

```js
export const EnvProtectionPlugin = async ({ project, client, $, directory, worktree }) => {
  return {
    'tool.execute.before': async (input, output) => {
      if (input.tool === 'read' && output.args.filePath?.includes('.env')) {
        throw new Error('Reading .env files is not allowed — use environment variables instead');
      }
    },

    // Fires after every tool call — use for logging/auditing
    'tool.execute.after': async (input, output) => {
      if (input.tool === 'bash') {
        await client.app.log({
          body: {
            service: 'env-protection',
            level: 'info',
            message: `bash executed: ${output.args?.command}`,
          },
        });
      }
    },
  };
};
```

5. **Testez le journal d'audit** : Lancez une commande bash, par exemple un listing de fichiers :

```
List all TypeScript files in the apps/ directory
```

Consultez ensuite les logs d'OpenCode pour voir l'entrée d'audit.

**Principales différences avec les autres plateformes** :

| Plateforme  | Mécanisme de hook    | Emplacement config           | Langage         |
| ----------- | -------------------- | ---------------------------- | --------------- |
| Claude Code | `settings.json`      | `PreToolUse` / `PostToolUse` | Config JSON     |
| GitHub      | `.github/hooks/`     | `preToolUse` / `postToolUse` | Scripts shell   |
| Gemini CLI  | `settings.json`      | `BeforeTool` / `AfterTool`   | Commandes shell |
| OpenCode    | `.opencode/plugins/` | `tool.execute.before/after`  | Code JS / TS    |

**Note** : Les plugins peuvent aussi charger des paquets npm — ajoutez un `package.json` dans `.opencode/` et importez n'importe quel paquet dans le code de votre plugin.

**Référence** : Comparez avec `../lab-41-agentic-tools-deep-dive-solution/resources/photo-gallery-fullstack-solution/.opencode/plugins/env-protection.js`

### Exercice E9 : Configurer OpenCode (10 min)

**Objectif** : Mettre en place une configuration projet avec les réglages de modèle et de provider

1. Mettez à jour `opencode.json` avec la configuration complète du projet :

```json
{
  "$schema": "https://opencode.ai/config.json",
  "model": "anthropic/claude-sonnet-4-6",
  "instructions": ["./AGENTS.md"],
  "permission": {
    "read": "allow",
    "list": "allow",
    "grep": "allow",
    "glob": "allow",
    "edit": "ask",
    "write": "ask",
    "patch": "ask",
    "bash": "ask"
  }
}
```

3. Vérifiez que la configuration est appliquée :

```txt
/status
```

**Résultat attendu** : OpenCode utilise le modèle indiqué et charge automatiquement les instructions projet depuis AGENTS.md

**Référence** : Comparez avec `../lab-41-agentic-tools-deep-dive-solution/resources/photo-gallery-fullstack-solution/opencode.json`

---

▶ **Section F : exercices Mistral Vibe**

**Plateforme** : Mistral Vibe
**Configurations de référence** : `../lab-41-agentic-tools-deep-dive-solution/resources/photo-gallery-fullstack-solution/.vibe/` et `../lab-41-agentic-tools-deep-dive-solution/resources/photo-gallery-fullstack-solution/AGENTS.md`

> **Installez Mistral Vibe** si ce n'est pas déjà fait :
>
> ```bash
> curl -LsSf https://mistral.ai/vibe/install.sh | bash
> # or: uv tool install mistral-vibe
> ```
>
> Lancez `vibe --setup` une fois pour configurer interactivement votre clé d'API, votre modèle et vos valeurs par défaut.

### Exercice F1 : Initialiser AGENTS.md (10 min)

**Objectif** : Créer le fichier de contexte projet et approuver le workspace

`AGENTS.md` à la racine du projet est chargé automatiquement par Mistral Vibe au démarrage de la session — il fournit les instructions propres au projet, les règles d'architecture et les conventions qui s'appliquent à toutes les sessions.

1. Démarrez Vibe dans le répertoire du projet :

```bash
cd photo-gallery-fullstack
vibe
```

2. Au premier lancement dans un répertoire, Vibe affiche une demande d'**approbation du dossier** (folder-trust) avant de charger la moindre config locale `.vibe/`. Confirmez pour approuver ce workspace.

3. Demandez à Vibe de générer le fichier de contexte :

```
Analyze this project and generate an AGENTS.md at the root describing the architecture, tech stack, build/test commands, and conventions.
```

Relisez le fichier généré et personnalisez-le. Votre `AGENTS.md` final doit contenir des sections telles que **Project Overview**, **Commands**, **Key Architecture Facts** et **Tech Patterns**.

**Résultat attendu** : `AGENTS.md` créé à la racine du projet. Vibe référence automatiquement ces règles dans chaque session approuvée.

**Référence** : Comparez avec `../lab-41-agentic-tools-deep-dive-solution/resources/photo-gallery-fullstack-solution/AGENTS.md`

### Exercice F2 : Explorer les agents intégrés (10 min)

**Objectif** : Utiliser les agents intégrés de Vibe pour contrôler l'autonomie

Mistral Vibe fournit quatre agents intégrés qui correspondent à des comportements de permission :

- **default** : Demande une approbation avant les éditions et les commandes shell
- **plan** : Lecture seule — analyse et planification, aucune modification
- **accept-edits** : Accepte automatiquement les éditions de fichiers, mais filtre encore les commandes shell
- **auto-approve** : Autonomie totale — aucune demande

1. Basculez sur l'agent `plan` et demandez à Vibe d'analyser sans rien modifier :

```
Analyze the photo-gallery architecture and identify where I should add a photo tagging feature. List all files that would need to change.
```

2. Relisez le plan — aucun fichier n'a été modifié.

3. Basculez sur `accept-edits` et implémentez à partir du plan :

```
Based on the plan, implement the photo tagging feature in the domain layer
```

**Résultat attendu** : `plan` permet une exploration en lecture seule sans risque ; `accept-edits` accélère l'implémentation en acceptant automatiquement les éditions tout en continuant à confirmer les commandes shell.

**Note** : Le mode de permission peut aussi être défini durablement via `permission_mode` dans `.vibe/config.toml` (voir l'exercice F9).

### Exercice F3 : Créer un agent personnalisé (15 min)

**Objectif** : Créer un agent gardien de l'architecture

1. Créez le répertoire des agents :

```bash
mkdir -p .vibe/agents
```

2. **Tâche** : Créez le fichier `.vibe/agents/architecture-guardian.md` :

```markdown
---
name: architecture-guardian
description: Validates design decisions against team architectural patterns and ensures alignment with system topology
---

# Architecture Guardian

You are the **Architecture Guardian** for the photo-gallery project. Your role is to ensure all code changes align with established architectural patterns, maintain system integrity, and follow documented design principles.

## Core Responsibilities

- **Validate Design Decisions**: Review proposed architectural changes against `architecture.md` and ensure alignment with system topology
- **Identify Violations**: Flag deviations from established patterns, anti-patterns, and architectural debt
- **Suggest Refactoring**: Recommend improvements that align with team conventions and long-term maintainability
- **Maintain Boundaries**: Enforce module boundaries and prevent tight coupling between layers
- **Review Dependencies**: Assess impact of new dependencies and ensure they fit architectural vision

## Context Files

You have access to the following knowledge references:

- **architecture.md**: System topology, module boundaries, data flow patterns
- **coding-standards.md**: Team conventions, naming patterns, file organization
- **domain-glossary.md**: Business terminology and domain model definitions

## Interaction Guidelines

When consulted, you should:

1. **Assess Context**: Understand the scope and intent of the proposed change
2. **Reference Standards**: Cite specific sections from architecture.md or coding-standards.md
3. **Evaluate Trade-offs**: Explain pros/cons of different architectural approaches
4. **Provide Specific Recommendations**: Give actionable guidance with code examples where applicable
5. **Flag Risks**: Identify potential scalability, performance, or maintainability concerns

## Decision Framework

When multiple valid approaches exist, prioritize:

1. **Consistency** with existing patterns
2. **Maintainability** and readability
3. **Testability** and isolation
4. **Performance** (only when measurable impact exists)
5. **Future extensibility**

You are an advisor, not a gatekeeper. Provide reasoned guidance but acknowledge when trade-offs are acceptable given project constraints.
```

3. **Testez** : Demandez à Vibe de consulter l'agent :

```
@architecture-guardian I want to add a photo filter feature. Should this go in the API layer or domain layer?
```

**Résultat attendu** : Vibe délègue à l'agent, qui analyse l'architecture et fournit une recommandation par couche

**Référence** : Comparez votre fichier avec `../lab-41-agentic-tools-deep-dive-solution/resources/photo-gallery-fullstack-solution/.vibe/agents/architecture-guardian.md`

### Exercice F4 : Créer une commande personnalisée (10 min)

**Objectif** : Créer une slash command de revue de code via le système de skills

Dans Mistral Vibe, les slash commands personnalisées passent par le **système de skills** — une skill dotée d'un `name` devient une commande `/name` invocable.

1. Créez le répertoire de la skill :

```bash
mkdir -p .vibe/skills/code-reviewer
```

2. **Tâche** : Créez le fichier `.vibe/skills/code-reviewer/SKILL.md` :

```markdown
---
name: code-reviewer
description: Analyze code changes (diff) and generate actionable code review comments aligned with team standards. Use when reviewing a pull request, staged changes, or a specific file or branch.
---

# Code Reviewer

Analyze code changes and generate actionable code review comments aligned with team standards.

## Instructions

When invoked, analyze the current git diff (staged or unstaged changes) or the specified file/branch.

Reference these team standards:
@.vibe/references/coding-standards.md
@.vibe/references/architecture.md

## Output Format

Produce review comments organized by:

1. **Critical Issues**: Bugs, security vulnerabilities, breaking changes (must fix)
2. **Architectural Concerns**: Pattern violations, coupling issues (should fix)
3. **Code Quality**: Readability, maintainability, test coverage (nice to have)
4. **Suggestions**: Performance optimizations, refactoring opportunities (optional)

Each comment includes:

- **File and line reference**
- **Severity**: Critical / High / Medium / Low
- **Category**: Bug / Security / Architecture / Style / Performance
- **Description**: What the issue is and why it matters
- **Recommendation**: Specific action to address the issue
```

3. **Testez** : Faites une petite modification de code, puis lancez :

```
/code-reviewer
```

**Résultat attendu** : Vibe exécute la skill en tant que slash command et produit une sortie de revue structurée

**Référence** : Comparez avec `../lab-41-agentic-tools-deep-dive-solution/resources/photo-gallery-fullstack-solution/.vibe/skills/code-reviewer/SKILL.md`

### Exercice F5 : Créer une agent skill (10 min)

**Objectif** : Créer une skill d'analyse d'impact des changements

1. Créez le répertoire des skills :

```bash
mkdir -p .vibe/skills/change-impact-analysis
```

2. **Tâche** : Créez le fichier `.vibe/skills/change-impact-analysis/SKILL.md` :

```markdown
---
name: change-impact-analysis
description: Assess the scope and risk of proposed code changes by analyzing affected components, blast radius, and potential side effects. Use when reviewing pull requests, planning large refactorings, assessing deployment readiness, or evaluating rollback complexity.
---

# Change Impact Analysis Skill

## Purpose

Assess the scope and risk of proposed code changes by analyzing affected components, blast radius, and potential side effects. This skill helps teams make informed decisions about change safety.

## Capabilities

### 1. Blast Radius Assessment

- Quantify how many files, modules, and services are affected
- Categorize changes by risk level (low/medium/high/critical)
- Identify cascading effects of a change

### 2. Risk Scoring

- Calculate risk based on change size, complexity, and affected components
- Flag high-risk changes requiring extra review or testing
- Recommend mitigation strategies proportional to risk

### 3. Side Effect Detection

- Identify unintended consequences of changes
- Flag performance implications
- Detect security or compliance impacts

## Usage Context

This skill activates when:

- Reviewing pull requests for approval
- Planning large refactorings or migrations
- Assessing deployment readiness
- Evaluating rollback complexity

## Risk Assessment Framework

| Factor             | Weight | Criteria                                                                                  |
| ------------------ | ------ | ----------------------------------------------------------------------------------------- |
| **Lines Changed**  | 20%    | <50 (low) / 50-200 (med) / 200-500 (high) / >500 (critical)                               |
| **Files Affected** | 15%    | <5 (low) / 5-10 (med) / 10-20 (high) / >20 (critical)                                     |
| **Test Coverage**  | 25%    | >80% (low) / 60-80% (med) / 40-60% (high) / <40% (critical)                               |
| **Critical Path**  | 30%    | Not on critical path (low) / Near critical (med) / On critical path (high)                |
| **Rollback Ease**  | 10%    | Easy revert (low) / Config change (med) / DB migration (high) / Data loss risk (critical) |
```

3. **Testez** : Demandez à Vibe :

```
If I change the PhotoRepository interface, what files will be affected?
```

**Résultat attendu** : Vibe charge et utilise automatiquement la skill pour fournir une analyse d'impact

**Référence** : Comparez avec `../lab-41-agentic-tools-deep-dive-solution/resources/photo-gallery-fullstack-solution/.vibe/skills/change-impact-analysis/SKILL.md`

### Exercice F6 : Installer une skill depuis un registre public (10 min)

**Objectif** : Rechercher et installer une skill communautaire depuis le registre Tessl

1. Recherchez la skill `skill-creator` :

```bash
npx -y skills find skill-creator
```

2. Installez-la localement :

```bash
npx -y skills add https://github.com/anthropics/skills --skill skill-creator
```

3. Déplacez la skill installée vers `.vibe/skills/skill-creator/`

4. **Testez** : Demandez à Vibe d'utiliser la skill :

```
Using the skill-creator skill, help me create a new skill for API documentation generation
```

**Résultat attendu** : Skill communautaire installée et disponible pour Vibe

**Note** : Les registres publics comme [tessl.io/registry](https://tessl.io/registry) et [skills.sh](https://skills.sh/) proposent des skills créées par la communauté, compatibles avec toutes les plateformes qui supportent SKILL.md.

### Exercice F7 : Configurer des hooks (15 min)

**Objectif** : Mettre en place des hooks pre-tool et post-tool en TOML

Mistral Vibe définit les hooks de cycle de vie de façon déclarative dans `.vibe/hooks.toml`. Les hooks s'exécutent avant/après l'exécution d'un outil et peuvent filtrer ou valider les actions.

1. **Tâche** : Créez le fichier `.vibe/hooks.toml` :

```toml
# Mistral Vibe hooks — lifecycle callbacks defined in TOML.

[[hooks.pre_tool_use]]
matcher = "bash"
type = "prompt"
prompt = "Check if this shell command is a git commit. If so, verify staged files follow coding standards before allowing the commit."

[[hooks.post_tool_use]]
matcher = "write|edit"
type = "prompt"
prompt = "Validate the file changes against coding-standards.md. Check they follow the project's coding standards."
```

2. **Testez** : Faites une modification de code qui viole les standards de code (par ex. ajoutez un `console.log`) et observez le hook post-tool la signaler.

**Résultat attendu** : Le hook post-édition signale la violation des standards de code ; un git commit déclenche la validation pre-tool.

**Référence** : Comparez avec `../lab-41-agentic-tools-deep-dive-solution/resources/photo-gallery-fullstack-solution/.vibe/hooks.toml`

### Exercice F8 : Reprise de session et mode ACP (10 min)

**Objectif** : Reprendre un travail passé et intégrer Vibe comme serveur ACP

1. **Reprenez votre session la plus récente** — repartez exactement d'où vous vous êtes arrêté :

```bash
vibe --continue
```

2. **Reprenez une session passée précise** depuis un sélecteur :

```bash
vibe --resume
```

3. **Lancez le mode ACP** — exécutez Vibe comme serveur Agent Client Protocol (ACP) pour qu'un éditeur ou un client compatible ACP puisse le piloter :

```bash
vibe-acp
```

**Résultat attendu** : `--continue` restaure votre dernière conversation, `--resume` permet d'en choisir une plus ancienne, et `vibe-acp` expose Vibe via ACP pour l'intégration dans un éditeur.

**Note** : Le mode ACP est utile pour brancher Vibe dans des IDE et des clients sur mesure qui parlent l'Agent Client Protocol, en conservant les mêmes agents, skills et config définis dans `.vibe/`.

### Exercice F9 : Configurer Vibe (10 min)

**Objectif** : Mettre en place une configuration projet avec les modes de permission

Vibe lit la configuration projet depuis `.vibe/config.toml` (et les réglages globaux depuis `~/.vibe/config.toml`). La config projet n'est chargée qu'après l'approbation du dossier.

1. **Tâche** : Créez le fichier `.vibe/config.toml` :

```toml
# Default permission mode: default | plan | accept-edits | auto-approve
permission_mode = "default"

# Context file auto-loaded at session start
context_file = "AGENTS.md"

[permissions]
allow = ["Bash(npm:*)", "Bash(npx:*)", "Bash(git:*)"]
deny = ["Bash(rm -rf:*)"]

[env]
NODE_ENV = "development"
```

2. Redémarrez Vibe et confirmez que la demande d'approbation du dossier charge bien la config.

**Résultat attendu** : Vibe autorise les commandes npm/npx/git sans demander, bloque `rm -rf` et démarre dans le mode de permission `default`.

**Note** : Les quatre modes de permission (`default`, `plan`, `accept-edits`, `auto-approve`) peuvent être définis ici pour toutes les sessions ou changés interactivement au cas par cas (exercice F2).

**Référence** : Comparez avec `../lab-41-agentic-tools-deep-dive-solution/resources/photo-gallery-fullstack-solution/.vibe/config.toml`

---

## Évaluation

Après avoir terminé les exercices de votre plateforme, évaluez votre compréhension :

1. **Création de fonctionnalités** : Savez-vous créer le bon type de personnalisation (agent, commande, skill, hook, plugin) pour un scénario donné ?
2. **Conventions de plateforme** : Comprenez-vous les conventions de nommage et les formats de fichiers de la plateforme choisie ?
3. **Vision multiplateforme** : Savez-vous identifier quelles fonctionnalités sont disponibles sur quelles plateformes ?
4. **Cadre de décision** : Savez-vous justifier le choix d'un type de fonctionnalité plutôt qu'un autre pour un cas d'usage précis ?

## Dépannage

- **Agents non reconnus** : Vérifiez les conventions de nommage des fichiers (`.md` pour Claude/Gemini, `.agent.md` pour Copilot, `.toml` pour Codex)
- **Agents Gemini qui ne fonctionnent pas** : Assurez-vous que `"experimental": { "enableAgents": true }` est défini dans `.gemini/settings.json`
- **Commandes qui ne fonctionnent pas** : Vérifiez la syntaxe du frontmatter YAML/TOML et l'emplacement du fichier
- **Hooks qui ne s'exécutent pas** : Vérifiez les permissions de fichiers (`chmod +x *.sh`) et les patterns de matcher (Linux/macOS) ; sur Windows, ignorez `chmod` et utilisez plutôt des scripts `.ps1`
- **Skills non détectées** : Vérifiez que SKILL.md se trouve dans un sous-répertoire nommé (par ex. `skills/my-skill/SKILL.md`)
- **Plugins qui ne se chargent pas** : Pour Claude Code, assurez-vous que `plugin.json` existe dans le sous-répertoire `.claude-plugin/` du dossier du plugin ; pour GitHub Copilot, `plugin.json` se place directement à la racine du plugin (par ex. `.github/plugins/team-workflows/plugin.json`)
- **Plugins Copilot** : Utilisez `copilot plugin list` pour vérifier l'installation
- **Extensions Gemini** : Utilisez `gemini extensions list` pour vérifier l'installation
- **Agents Codex non chargés** : Vérifiez la syntaxe TOML des fichiers `.codex/agents/*.toml` ; vérifiez la section `[agents]` dans config.toml
- **Config Codex non chargée** : Lancez `codex trust .` pour approuver le projet
- **Agents OpenCode non activés** : Vérifiez le champ `description` dans le frontmatter YAML de l'agent — OpenCode s'en sert pour décider quand l'activer
- **Commandes OpenCode introuvables** : Vérifiez que les fichiers `.md` sont bien dans `.opencode/commands/` (et non `.opencode/command/`)
- **Modèle OpenCode qui ne se charge pas** : Vérifiez que la clé d'API du provider est définie dans `~/.config/opencode/opencode.json` ou dans une variable d'environnement
- **Plugins OpenCode qui ne se chargent pas** : Les fichiers de `.opencode/plugins/` doivent exporter une fonction (par ex. `export const MyPlugin = async (ctx) => { return { ... } }`) ; vérifiez l'absence d'erreurs de syntaxe avec `node --input-type=module < .opencode/plugins/env-protection.js`
- **Config Vibe non chargée** : Vibe ne charge la config locale `.vibe/` d'un projet qu'après acceptation de la demande d'approbation du dossier — relancez `vibe` et confirmez l'approbation du répertoire
- **Agents Vibe non activés** : Vérifiez les champs `name` et `description` du frontmatter YAML de l'agent dans `.vibe/agents/*.md` — Vibe se sert de la description pour décider quand déléguer
- **Slash command Vibe introuvable** : Les slash commands personnalisées viennent du système de skills — assurez-vous que le répertoire de skill `.vibe/skills/<name>/` contient un `SKILL.md` avec un champ `name`
- **Hooks Vibe qui ne se déclenchent pas** : Vérifiez la syntaxe TOML de `.vibe/hooks.toml` et que le `matcher` correspond bien au nom de l'outil (par ex. `bash`, `write|edit`)
- **Vibe non configuré** : Lancez `vibe --setup` pour (re)configurer votre clé d'API, votre modèle et vos valeurs par défaut

## Ressources

- [Slides du module 4](../../docs/markdown/40_module_4_ai_agentic_tools_deepdive/)
- [Solution Photo Gallery Fullstack](../lab-41-agentic-tools-deep-dive-solution/resources/photo-gallery-fullstack-solution/) - Implémentations de référence pour toutes les plateformes
- [AGENTS.md - Référence multiplateforme](../lab-41-agentic-tools-deep-dive-solution/resources/photo-gallery-fullstack-solution/AGENTS.md)
