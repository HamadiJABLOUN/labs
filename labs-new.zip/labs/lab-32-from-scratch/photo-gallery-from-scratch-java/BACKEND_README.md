# Photo Gallery API - Backend

## Overview

This is the Spring Boot backend implementation for the Photo Gallery application. It provides RESTful endpoints for uploading, managing, tagging, browsing, filtering, and deleting photos.

## Features

- **Photo Upload**: Upload photos with optional tags (JPEG, PNG, GIF, WebP)
- **Photo Management**: Get, update, and delete photos
- **Tag Management**: Add, remove, replace tags on photos
- **Browsing**: Paginated list of all photos
- **Filtering**: Filter photos by tags with AND/OR logic
- **Validation**: Comprehensive validation for files, tags, and requests
- **Error Handling**: Proper error responses with meaningful messages

## API Documentation

### Swagger/OpenAPI

The API documentation is available at:
- **OpenAPI JSON**: `http://localhost:8080/api/v3/api-docs`
- **Swagger UI**: `http://localhost:8080/api/swagger-ui.html`

### Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/photos` | Upload a new photo with optional tags |
| GET | `/api/photos` | Get all photos with pagination and filtering |
| GET | `/api/photos/{id}` | Get a specific photo by ID |
| DELETE | `/api/photos/{id}` | Delete a photo by ID |
| GET | `/api/photos/{id}/tags` | Get all tags for a photo |
| PUT | `/api/photos/{id}/tags` | Replace all tags on a photo |
| POST | `/api/photos/{id}/tags` | Add tags to a photo |
| DELETE | `/api/photos/{id}/tags/{tag}` | Remove a specific tag from a photo |

### Request/Response Examples

#### Upload Photo (POST /api/photos)

**Request:**
```bash
curl -X POST -F "file=@/path/to/photo.jpg" -F "tags=nature,landscape" http://localhost:8080/api/photos
```

**Response:**
```json
{
  "success": true,
  "message": "Photo uploaded successfully",
  "data": {
    "id": "abc123",
    "filename": "photo.jpg",
    "originalFilename": "photo.jpg",
    "contentType": "image/jpeg",
    "fileSize": 12345,
    "width": 1920,
    "height": 1080,
    "uploadDate": "2024-01-15T10:30:00",
    "filePath": "/uploads/abc123_photo.jpg",
    "tags": ["nature", "landscape"]
  },
  "timestamp": "2024-01-15T10:30:00.123"
}
```

#### Get All Photos (GET /api/photos)

**Request:**
```bash
curl -X GET "http://localhost:8080/api/photos?page=0&size=10&tags=nature&mode=AND"
```

**Response:**
```json
{
  "success": true,
  "message": "Photos retrieved successfully",
  "data": {
    "content": [
      {
        "id": "abc123",
        "filename": "photo1.jpg",
        "originalFilename": "photo1.jpg",
        "contentType": "image/jpeg",
        "fileSize": 12345,
        "width": 1920,
        "height": 1080,
        "uploadDate": "2024-01-15T10:30:00",
        "filePath": "/uploads/abc123_photo1.jpg",
        "tags": ["nature", "landscape"]
      }
    ],
    "page": 0,
    "size": 10,
    "totalElements": 1,
    "totalPages": 1,
    "last": true,
    "first": true
  },
  "timestamp": "2024-01-15T10:30:01.234"
}
```

## Technology Stack

- **Java**: 17
- **Spring Boot**: 4.0.0
- **Spring Data JPA**: For database operations
- **H2 Database**: In-memory database for development
- **Lombok**: For reducing boilerplate code
- **ModelMapper**: For DTO mapping
- **SpringDoc OpenAPI**: For API documentation
- **Maven**: Build tool

## Validation Rules

### File Upload
- **Maximum Size**: 10MB
- **Allowed Types**: JPEG, PNG, GIF, WebP
- **Required**: File must be provided

### Tags
- **Format**: Only lowercase alphanumeric characters, hyphens, and underscores (`[a-z0-9_-]+`)
- **Maximum Length**: 50 characters per tag
- **Maximum Count**: 20 tags per photo
- **Case**: Tags are stored in lowercase (case-insensitive)

### Pagination
- **Default Page**: 0 (0-based)
- **Default Size**: 20
- **Maximum Size**: 100

## Project Structure

```
photo-gallery-api/
├── src/
│   ├── main/
│   │   ├── java/
│   │   │   └── com/sfeir/photo_gallery_api/
│   │   │       ├── config/          # Spring configuration
│   │   │       ├── controller/      # REST controllers
│   │   │       ├── dto/            # Data Transfer Objects
│   │   │       ├── exception/      # Custom exceptions
│   │   │       ├── model/          # JPA entities
│   │   │       ├── repository/     # JPA repositories
│   │   │       ├── service/        # Business logic services
│   │   │       └── util/           # Utility classes
│   │   └── resources/
│   │       └── application.properties
│   └── test/
│       └── java/
│           └── com/sfeir/photo_gallery_api/
│               ├── controller/     # Controller tests
│               ├── service/       # Service tests
│               └── ...
└── pom.xml
```

## Configuration

### application.properties

```properties
# Server
server.port=8080
server.servlet.context-path=/api

# Database (H2)
spring.datasource.url=jdbc:h2:mem:photogallery
spring.datasource.driver-class-name=org.h2.Driver
spring.datasource.username=sa
spring.datasource.password=

# JPA
spring.jpa.show-sql=true
spring.jpa.hibernate.ddl-auto=update

# File Upload
spring.servlet.multipart.max-file-size=10MB
spring.servlet.multipart.max-request-size=10MB
app.upload.dir=uploads

# CORS
app.cors.allowed-origins=*
app.cors.allowed-methods=GET,POST,PUT,DELETE,OPTIONS
```

## Running the Application

### Development

```bash
# Start the application
./mvnw spring-boot:run

# Or with Maven
mvn spring-boot:run

# The application will be available at:
# http://localhost:8080/api
# Swagger UI: http://localhost:8080/api/swagger-ui.html
```

### Testing

```bash
# Run all tests
./mvnw test

# Or with Maven
mvn test
```

### Building

```bash
# Build the project
./mvnw clean package

# Or with Maven
mvn clean package

# The JAR file will be in the target/ directory
```

## Error Handling

The API returns consistent error responses:

```json
{
  "success": false,
  "message": "Error message",
  "timestamp": "2024-01-15T10:30:00.123"
}
```

### Common Error Responses

| Status Code | Error | Description |
|-------------|-------|-------------|
| 400 | Bad Request | Invalid request parameters or validation failed |
| 404 | Not Found | Requested resource not found |
| 413 | Payload Too Large | File exceeds maximum size (10MB) |
| 415 | Unsupported Media Type | File type not supported |
| 500 | Internal Server Error | Unexpected server error |

## Future Improvements

- [ ] Add database migration support (Flyway/Liquibase)
- [ ] Add authentication and authorization
- [ ] Add rate limiting
- [ ] Add file compression/optimization
- [ ] Add thumbnail generation
- [ ] Add EXIF metadata extraction
- [ ] Add support for cloud storage (S3, Azure Blob, etc.)
- [ ] Add caching for better performance
- [ ] Add metrics and monitoring

## License

MIT License
