# Photo Gallery API - Feature Specification

## Overview

The Photo Gallery API is a backend service that enables users to upload, manage, tag, browse, and delete photos through a RESTful interface. This specification defines the complete feature set for the initial version of the application.

---

## 1. User Stories

### US-001: Upload a Photo
**As a** user  
**I want to** upload a photo from my device  
**So that** I can store it in my gallery for later viewing and sharing.

### US-002: Add Tags to a Photo
**As a** user  
**I want to** add descriptive tags to my uploaded photos  
**So that** I can categorize and organize them effectively.

### US-003: Browse All Photos
**As a** user  
**I want to** view a paginated list of all photos in my gallery  
**So that** I can see what photos I have uploaded.

### US-004: Filter Photos by Tag
**As a** user  
**I want to** filter photos by one or more tags  
**So that** I can quickly find photos that match specific criteria.

### US-005: View Photo Details
**As a** user  
**I want to** view detailed information about a specific photo including its metadata and tags  
**So that** I can see all information associated with that photo.

### US-006: Delete a Photo
**As a** user  
**I want to** delete a photo from my gallery  
**So that** I can remove photos I no longer want to keep.

---

## 2. Functional Requirements

### 2.1 Photo Upload
- **FR-001:** The system must accept photo uploads via HTTP POST request
- **FR-002:** The system must support common image formats: JPEG, PNG, GIF, WebP
- **FR-003:** The system must validate that uploaded files are valid images
- **FR-004:** The system must generate a unique identifier for each uploaded photo
- **FR-005:** The system must store the photo file on the server filesystem
- **FR-006:** The system must store photo metadata in a database
- **FR-007:** The system must return the photo ID and metadata in the response
- **FR-008:** The system must limit maximum file size to 10MB per photo

### 2.2 Photo Tagging
- **FR-010:** The system must allow adding one or more tags to a photo at upload time
- **FR-011:** The system must allow adding tags to an existing photo
- **FR-012:** The system must allow removing tags from a photo
- **FR-013:** The system must allow replacing all tags on a photo
- **FR-014:** Tags must be case-insensitive (stored in lowercase)
- **FR-015:** Tags must be alphanumeric with hyphens and underscores allowed (regex: `[a-z0-9_-]+`)
- **FR-016:** Individual tags must not exceed 50 characters
- **FR-017:** A photo can have a maximum of 20 tags

### 2.3 Photo Browsing
- **FR-020:** The system must provide an endpoint to retrieve all photos
- **FR-021:** The system must support pagination with `page` and `size` parameters
- **FR-022:** The system must return paginated results with metadata (total pages, total items, current page)
- **FR-023:** Default pagination must be page 0 with size 20
- **FR-024:** Maximum page size must be limited to 100 items
- **FR-025:** The system must support sorting by upload date (ascending and descending)

### 2.4 Photo Filtering
- **FR-030:** The system must support filtering photos by one or more tags
- **FR-031:** The system must support AND logic for multiple tag filters (photo must have ALL specified tags)
- **FR-032:** The system must support OR logic for multiple tag filters via query parameter
- **FR-033:** The system must combine filtering with pagination

### 2.5 Photo Details
- **FR-040:** The system must provide an endpoint to retrieve a single photo by ID
- **FR-041:** The system must return photo metadata: ID, filename, upload date, file size, dimensions, content type
- **FR-042:** The system must return all tags associated with the photo
- **FR-043:** The system must return the photo file URL for download/viewing
- **FR-044:** The system must return HTTP 404 if photo ID does not exist

### 2.6 Photo Deletion
- **FR-050:** The system must provide an endpoint to delete a photo by ID
- **FR-051:** The system must delete the photo file from the filesystem
- **FR-052:** The system must delete the photo record and all associated tags from the database
- **FR-053:** The system must return HTTP 204 No Content on successful deletion
- **FR-054:** The system must return HTTP 404 if photo ID does not exist
- **FR-055:** The system must be idempotent (multiple delete requests on same ID return 404 after first deletion)

---

## 3. Acceptance Criteria

### 3.1 Photo Upload
- **AC-001:** Given a valid JPEG image, when POST /api/photos with the image, then the system returns HTTP 201 Created with photo metadata
- **AC-002:** Given a valid PNG image with tags "nature", "landscape", when POST /api/photos with the image and tags, then the system stores the photo with the specified tags
- **AC-003:** Given a file larger than 10MB, when POST /api/photos, then the system returns HTTP 400 Bad Request with error message
- **AC-004:** Given a non-image file (e.g., PDF), when POST /api/photos, then the system returns HTTP 415 Unsupported Media Type
- **AC-005:** Given no file provided, when POST /api/photos, then the system returns HTTP 400 Bad Request

### 3.2 Photo Tagging
- **AC-010:** Given an existing photo ID and tags "vacation", "summer", when PUT /api/photos/{id}/tags, then the photo has exactly those two tags
- **AC-011:** Given an existing photo with tags "nature", when POST /api/photos/{id}/tags with tag "landscape", then the photo has tags "nature" and "landscape"
- **AC-012:** Given an existing photo with tags "nature", "landscape", when DELETE /api/photos/{id}/tags/nature, then the photo has only tag "landscape"
- **AC-013:** Given tag "Vacation", when adding to a photo, then the tag is stored as "vacation"
- **AC-014:** Given a tag with special characters "nature!@#", when adding to a photo, then the system returns HTTP 400 Bad Request with validation error

### 3.3 Photo Browsing
- **AC-020:** Given 25 photos exist, when GET /api/photos?page=0&size=10, then the system returns 10 photos with totalPages=3
- **AC-021:** Given 25 photos exist, when GET /api/photos?page=2&size=10, then the system returns the last 5 photos
- **AC-022:** Given photos exist, when GET /api/photos?sort=uploadDate,asc, then photos are returned in chronological order
- **AC-023:** Given photos exist, when GET /api/photos?sort=uploadDate,desc, then photos are returned in reverse chronological order

### 3.4 Photo Filtering
- **AC-030:** Given photos with tags: photo1="nature,landscape", photo2="nature,portrait", photo3="city", when GET /api/photos?tags=nature, then the system returns photo1 and photo2
- **AC-031:** Given photos with tags: photo1="nature,landscape", photo2="nature,portrait", photo3="landscape,city", when GET /api/photos?tags=nature&tags=landscape, then the system returns only photo1
- **AC-032:** Given photos with tags: photo1="nature,landscape", photo2="nature,portrait", photo3="landscape,city", when GET /api/photos?tags=nature,landscape&mode=OR, then the system returns photo1, photo2, and photo3
- **AC-033:** Given 100 photos with tag "nature", when GET /api/photos?tags=nature&page=0&size=10, then the system returns first 10 photos with tag "nature"

### 3.5 Photo Details
- **AC-040:** Given photo with ID "abc123" exists, when GET /api/photos/abc123, then the system returns HTTP 200 with complete photo metadata
- **AC-041:** Given photo with ID "abc123" exists with tags "nature", "landscape", when GET /api/photos/abc123, then the response includes the tags array
- **AC-042:** Given photo with ID "nonexistent" does not exist, when GET /api/photos/nonexistent, then the system returns HTTP 404 Not Found

### 3.6 Photo Deletion
- **AC-050:** Given photo with ID "abc123" exists, when DELETE /api/photos/abc123, then the system returns HTTP 204 No Content
- **AC-051:** Given photo with ID "abc123" exists, when DELETE /api/photos/abc123 and then GET /api/photos/abc123, then the system returns HTTP 404 Not Found
- **AC-052:** Given photo with ID "abc123" has been deleted, when DELETE /api/photos/abc123 again, then the system returns HTTP 404 Not Found
- **AC-053:** Given photo with ID "nonexistent" does not exist, when DELETE /api/photos/nonexistent, then the system returns HTTP 404 Not Found

---

## 4. Success Criteria

| Metric | Target | Measurement Method |
|--------|--------|-------------------|
| **SC-001** | All acceptance criteria pass | Automated integration tests |
| **SC-002** | API response time < 200ms for browse endpoints | Performance testing with 100 photos |
| **SC-003** | API response time < 500ms for upload endpoints | Performance testing with 5MB images |
| **SC-004** | 100% test coverage for all endpoints | Code coverage reports |
| **SC-005** | Zero critical bugs in production | Manual and automated testing |
| **SC-006** | Support concurrent uploads from 10 users | Load testing |
| **SC-007** | Database schema allows for 10,000+ photos | Capacity testing |

---

## 5. Out of Scope

### 5.1 Features Not Included in This Version
- **OS-001:** User authentication and authorization (all endpoints are public)
- **OS-002:** User accounts and multi-user support (single shared gallery)
- **OS-003:** Photo editing capabilities (cropping, filters, etc.)
- **OS-004:** Photo sharing or social features
- **OS-005:** Photo comments or ratings
- **OS-006:** Photo albums or collections
- **OS-007:** Search by photo content (computer vision, object detection)
- **OS-008:** Image processing (thumbnail generation, resizing)
- **OS-009:** Cloud storage integration (all files stored on local filesystem)
- **OS-010:** Database backup and restore functionality
- **OS-011:** Rate limiting or API key management
- **OS-012:** WebSocket or real-time notifications
- **OS-013:** Frontend UI or web application
- **OS-014:** Mobile app integration
- **OS-015:** Geotagging or location-based features

### 5.2 Technical Constraints
- **OS-020:** No support for video files
- **OS-021:** No support for animated GIFs (treated as static images)
- **OS-022:** No support for SVG or vector images
- **OS-023:** No support for HEIC/HEIF formats
- **OS-024:** No support for EXIF metadata extraction beyond basic image dimensions

---

## Appendix A: API Endpoint Summary

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/photos` | POST | Upload a new photo with optional tags |
| `/api/photos` | GET | Browse all photos with pagination and filtering |
| `/api/photos/{id}` | GET | Get detailed information for a specific photo |
| `/api/photos/{id}` | DELETE | Delete a photo by ID |
| `/api/photos/{id}/tags` | GET | Get all tags for a photo |
| `/api/photos/{id}/tags` | PUT | Replace all tags for a photo |
| `/api/photos/{id}/tags` | POST | Add one or more tags to a photo |
| `/api/photos/{id}/tags/{tag}` | DELETE | Remove a specific tag from a photo |

---

## Appendix B: Data Model Summary

### Photo Entity
```
- id: String (UUID) - Primary Key
- filename: String - Original filename
- originalFilename: String - Original filename before sanitization
- contentType: String - MIME type (e.g., image/jpeg)
- fileSize: Long - Size in bytes
- width: Integer - Image width in pixels
- height: Integer - Image height in pixels
- uploadDate: LocalDateTime - When the photo was uploaded
- filePath: String - Path to stored file on filesystem
```

### Tag Entity
```
- id: Long - Primary Key
- name: String - Tag name (lowercase, normalized)
- photos: Many-to-Many relationship with Photo
```

---

*Document Version: 1.0.0*  
*Last Updated: 2026-10-07*  
*Author: Photo Gallery API Team*
