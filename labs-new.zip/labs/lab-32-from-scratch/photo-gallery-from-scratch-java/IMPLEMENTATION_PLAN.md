# Photo Gallery Frontend - Implementation Plan

## Overview

This document outlines the implementation plan for the **Angular 21.x frontend** of the Photo Gallery application. The frontend will consume the Spring Boot API defined in `SPECIFICATION.md` and provide a reactive, signal-based user interface with local caching.

---

## 1. Architecture

### 1.1 High-Level Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                        Angular Application                     │
├─────────────────────────────────────────────────────────────┤
│                                                               │
│  ┌─────────────────┐    ┌─────────────────┐    ┌─────────┐ │
│  │   UI Layer      │    │   Service Layer  │    │  Model   │ │
│  │   (Components)  │◄───►│   (Services)    │◄───►│ Layer    │ │
│  └─────────────────┘    └─────────────────┘    └─────────┘ │
│                       ▲                                      │
│                       │                                      │
│                    ┌──┴──┐                                  │
│                    │HTTP │                                  │
│                    └──┬──┘                                  │
│                       ▼                                      │
│  ┌─────────────────────────────────────────────────────────┐│
│  │               Spring Boot API (Backend)                   ││
│  └─────────────────────────────────────────────────────────┘│
│                                                               │
└─────────────────────────────────────────────────────────────┘
```

### 1.2 Component Structure (Standalone)

All components are **standalone** (no NgModule), enabling tree-shakable dependencies and reducing bundle size.

```
Photo Gallery App
├── AppComponent (Root)
│   ├── HeaderComponent
│   ├── MainLayoutComponent
│   │   ├── PhotoUploadComponent
│   │   ├── PhotoGalleryComponent
│   │   │   ├── PhotoCardComponent (for each photo)
│   │   │   └── TagFilterComponent
│   │   ├── PhotoDetailModalComponent
│   │   └── DeleteConfirmationModalComponent
│   └── FooterComponent
```

### 1.3 Data Flow

**Unidirectional Data Flow with Signals:**

```
User Action (e.g., upload photo)
        ↓
Component (PhotoUploadComponent)
        ↓ (calls service method)
Service (PhotoService)
        ↓ (updates signal)
Store (photoList signal in PhotoStore)
        ↓ (computed from signal)
Component (PhotoGalleryComponent) - subscribes via signal
        ↓
UI Updates
```

- **No RxJS Observables** for component state (Angular 21 signals are preferred)
- **RxJS limited to HTTP calls** in services only
- **Signals** propagate state changes reactively
- **Computed signals** derive state (e.g., filtered photos, tag counts)

### 1.4 State Management

**Reactive State Management with Angular Signals:**

```typescript
// Pattern: Centralized Store with Signals
@Injectable({ providedIn: 'root' })
class PhotoStore {
  // State signals
  private _photos = signal<Photo[]>([]);
  private _loading = signal<boolean>(false);
  private _error = signal<string | null>(null);
  private _selectedTags = signal<string[]>([]);
  
  // Public readonly signals
  readonly photos = this._photos.asReadonly();
  readonly loading = this._loading.asReadonly();
  readonly error = this._error.asReadonly();
  readonly selectedTags = this._selectedTags.asReadonly();
  
  // Computed signals
  readonly filteredPhotos = computed(() => {
    const photos = this._photos();
    const tags = this._selectedTags();
    return photos.filter(photo => 
      tags.length === 0 || tags.every(tag => photo.tags.includes(tag))
    );
  });
  
  readonly tagStats = computed(() => {
    const photos = this._photos();
    const counts = new Map<string, number>();
    photos.forEach(p => p.tags.forEach(t => counts.set(t, (counts.get(t) || 0) + 1)));
    return Array.from(counts.entries()).map(([name, count]) => ({ name, count }));
  });
  
  // Actions
  uploadPhoto(file: File, tags: string[]): void { ... }
  deletePhoto(id: string): void { ... }
  selectTag(tag: string): void { ... }
  clearFilters(): void { ... }
}
```

**Why Signals:**
- Angular 21's signals provide fine-grained reactivity without RxJS overhead
- Automatic dependency tracking eliminates manual subscription management
- Better performance than Observables for most use cases
- Seamless integration with Angular's change detection
- Simpler mental model for component state

### 1.5 LocalStorage Integration

**Persistence Strategy:**
- All photo data cached in LocalStorage for offline access
- API calls sync with backend, LocalStorage acts as fallback
- On app load: try API first, fall back to LocalStorage
- On changes: update both API and LocalStorage atomically

```typescript
// PhotoService - Storage Adapter
@Injectable({ providedIn: 'root' })
class PhotoStorageService {
  private readonly STORAGE_KEY = 'photo-gallery-photos';
  
  savePhotos(photos: Photo[]): void {
    localStorage.setItem(this.STORAGE_KEY, JSON.stringify(photos));
  }
  
  loadPhotos(): Photo[] {
    const data = localStorage.getItem(this.STORAGE_KEY);
    return data ? JSON.parse(data) : [];
  }
  
  clearPhotos(): void {
    localStorage.removeItem(this.STORAGE_KEY);
  }
}
```

---

## 2. Data Model

### 2.1 Core Entities

```typescript
// ========== Photo Entity ==========
export interface Photo {
  id: string;                    // UUID v4 generated client-side
  filename: string;              // Original filename (sanitized)
  originalFilename: string;      // Exact original filename
  dataUrl: string;               // Base64 data URL for immediate display
  file?: File;                   // Browser File object (not persisted)
  contentType: string;           // MIME type (e.g., 'image/jpeg')
  size: number;                  // File size in bytes
  width: number;                 // Image width in pixels
  height: number;                // Image height in pixels
  uploadedAt: Date;              // When photo was uploaded
  tags: string[];                // Array of tag strings
  isSynced: boolean;             // Whether photo is synced with backend
  syncError?: string;            // Error message if sync failed
}

// ========== Tag Statistics ==========
export interface TagStats {
  name: string;                  // Tag name (lowercase)
  count: number;                // Number of photos with this tag
}

// ========== Upload Progress ==========
export interface UploadProgress {
  photoId: string;
  progress: number;              // 0-100
  status: 'pending' | 'uploading' | 'complete' | 'error';
  error?: string;
}

// ========== Filter State ==========
export interface PhotoFilter {
  tags: string[];                // Active tag filters
  sortBy: 'uploadedAt' | 'filename' | 'size';
  sortDirection: 'asc' | 'desc';
  page: number;                  // 0-based page index
  pageSize: number;             // Items per page
}

// ========== API DTOs ==========
export interface ApiPhoto {
  id: string;
  filename: string;
  originalFilename: string;
  contentType: string;
  fileSize: number;
  width: number;
  height: number;
  uploadDate: string;            // ISO 8601 date string
  tags: string[];
  filePath: string;              // Server file path
}

// DTO for API requests
export interface UploadPhotoRequest {
  file: File;
  tags?: string[];
}
```

### 2.2 Validation Rules

```typescript
// Tag validation (mirrors backend requirements)
export const TAG_REGEX = /^[a-z0-9_-]+$/;
export const MAX_TAG_LENGTH = 50;
export const MAX_TAGS_PER_PHOTO = 20;

// Photo validation
export const MAX_FILE_SIZE = 10 * 1024 * 1024; // 10MB
export const ALLOWED_CONTENT_TYPES = [
  'image/jpeg',
  'image/png', 
  'image/gif',
  'image/webp'
];

// Pagination
export const DEFAULT_PAGE_SIZE = 20;
export const MAX_PAGE_SIZE = 100;
```

### 2.3 Type Guards

```typescript
// Runtime validation for API responses
export function isApiPhoto(obj: unknown): obj is ApiPhoto {
  return typeof obj === 'object' && obj !== null &&
    'id' in obj && typeof obj.id === 'string' &&
    'filename' in obj && typeof obj.filename === 'string' &&
    'contentType' in obj && typeof obj.contentType === 'string' &&
    'fileSize' in obj && typeof obj.fileSize === 'number' &&
    'uploadDate' in obj && typeof obj.uploadDate === 'string';
}

export function isPhoto(obj: unknown): obj is Photo {
  return typeof obj === 'object' && obj !== null &&
    'id' in obj && typeof obj.id === 'string' &&
    'filename' in obj && typeof obj.filename === 'string' &&
    'dataUrl' in obj && typeof obj.dataUrl === 'string' &&
    'contentType' in obj && typeof obj.contentType === 'string' &&
    'size' in obj && typeof obj.size === 'number' &&
    'uploadedAt' in obj && obj.uploadedAt instanceof Date &&
    'tags' in obj && Array.isArray(obj.tags);
}
```

---

## 3. File Structure

```
photo-gallery-frontend/
├── src/
│   ├── app/
│   │   ├── core/
│   │   │   ├── guards/
│   │   │   │   └── unsaved-changes.guard.ts
│   │   │   ├── interceptors/
│   │   │   │   └── http-error.interceptor.ts
│   │   │   └── constants/
│   │   │       ├── app.constants.ts
│   │   │       └── api.constants.ts
│   │   │
│   │   ├── shared/
│   │   │   ├── components/
│   │   │   │   ├── modal/
│   │   │   │   │   ├── modal.component.ts
│   │   │   │   │   └── modal.component.html
│   │   │   │   ├── loading-spinner/
│   │   │   │   │   ├── loading-spinner.component.ts
│   │   │   │   │   └── loading-spinner.component.html
│   │   │   │   ├── tag-badge/
│   │   │   │   │   ├── tag-badge.component.ts
│   │   │   │   │   └── tag-badge.component.html
│   │   │   │   └── confirm-dialog/
│   │   │   │       ├── confirm-dialog.component.ts
│   │   │   │       └── confirm-dialog.component.html
│   │   │   │
│   │   │   ├── directives/
│   │   │   │   ├── click-outside.directive.ts
│   │   │   │   └── drag-drop.directive.ts
│   │   │   │
│   │   │   ├── pipes/
│   │   │   │   ├── file-size.pipe.ts
│   │   │   │   ├── date-format.pipe.ts
│   │   │   │   └── truncate.pipe.ts
│   │   │   │
│   │   │   └── utils/
│   │   │       ├── image.utils.ts
│   │   │       ├── validation.utils.ts
│   │   │       └── storage.utils.ts
│   │   │
│   │   ├── stores/
│   │   │   ├── photo.store.ts
│   │   │   └── ui.store.ts
│   │   │
│   │   ├── services/
│   │   │   ├── api/
│   │   │   │   ├── photo-api.service.ts
│   │   │   │   └── tag-api.service.ts
│   │   │   ├── photo.service.ts
│   │   │   ├── storage.service.ts
│   │   │   ├── tag.service.ts
│   │   │   └── image.service.ts
│   │   │
│   │   ├── models/
│   │   │   ├── photo.model.ts
│   │   │   ├── tag.model.ts
│   │   │   └── index.ts
│   │   │
│   │   ├── features/
│   │   │   ├── upload/
│   │   │   │   ├── photo-upload.component.ts
│   │   │   │   ├── photo-upload.component.html
│   │   │   │   └── photo-upload.component.css
│   │   │   │
│   │   │   ├── gallery/
│   │   │   │   ├── photo-gallery.component.ts
│   │   │   │   ├── photo-gallery.component.html
│   │   │   │   └── photo-gallery.component.css
│   │   │   │
│   │   │   ├── card/
│   │   │   │   ├── photo-card.component.ts
│   │   │   │   ├── photo-card.component.html
│   │   │   │   └── photo-card.component.css
│   │   │   │
│   │   │   ├── detail/
│   │   │   │   ├── photo-detail-modal.component.ts
│   │   │   │   ├── photo-detail-modal.component.html
│   │   │   │   └── photo-detail-modal.component.css
│   │   │   │
│   │   │   ├── filter/
│   │   │   │   ├── tag-filter.component.ts
│   │   │   │   ├── tag-filter.component.html
│   │   │   │   └── tag-filter.component.css
│   │   │   │
│   │   │   └── delete/
│   │   │       ├── delete-confirmation-modal.component.ts
│   │   │       ├── delete-confirmation-modal.component.html
│   │   │       └── delete-confirmation-modal.component.css
│   │   │
│   │   ├── layout/
│   │   │   ├── header/
│   │   │   │   ├── header.component.ts
│   │   │   │   ├── header.component.html
│   │   │   │   └── header.component.css
│   │   │   ├── footer/
│   │   │   │   ├── footer.component.ts
│   │   │   │   ├── footer.component.html
│   │   │   │   └── footer.component.css
│   │   │   └── main-layout/
│   │   │       ├── main-layout.component.ts
│   │   │       ├── main-layout.component.html
│   │   │       └── main-layout.component.css
│   │   │
│   │   ├── app.component.ts
│   │   ├── app.component.html
│   │   ├── app.component.css
│   │   ├── app.config.ts
│   │   └── app.routes.ts
│   │
│   ├── assets/
│   │   └── images/
│   │       └── placeholder.png
│   │
│   ├── styles/
│   │   ├── _variables.scss
│   │   ├── _mixins.scss
│   │   └── global.scss
│   │
│   └── index.html
│   └── main.ts
│   └── styles.css
│
├── project.json
├── tsconfig.json
├── tsconfig.app.json
├── tsconfig.spec.json
├── vite.config.ts
├── vitest.config.ts
└── package.json
```

### 3.1 File Naming Conventions

- **Components:** `feature-name.component.ts` (kebab-case for feature, camelCase for class)
- **Services:** `feature-name.service.ts`
- **Stores:** `feature-name.store.ts`
- **Models:** `feature-name.model.ts`
- **Utils:** `feature-name.utils.ts`
- **Directives:** `directive-name.directive.ts`
- **Pipes:** `pipe-name.pipe.ts`

---

## 4. Technical Decisions

### 4.1 Angular 21 with Standalone Components

**Decision:** Use Angular 21 with standalone components and signals.

**Rationale:**
- **Standalone Components:** Eliminates NgModule boilerplate, reduces bundle size through tree-shaking, and simplifies the module system
- **Signals:** Native Angular reactivity replaces RxJS for most state management, reducing complexity and improving performance
- **Modern Syntax:** Aligns with Angular's future direction (RxJS will become optional)
- **Type Safety:** Signals provide better TypeScript inference than Observables
- **Learning Curve:** Simpler mental model for new developers joining the project

**Trade-offs:**
- Some RxJS knowledge still needed for HTTP operations
- Ecosystem tooling (like NgRx) may need adaptation
- Migration from older Angular versions requires effort

### 4.2 esbuild (via Nx Angular Default)

**Decision:** Use esbuild as the build tool through Nx Angular's default configuration.

**Rationale:**
- **Speed:** esbuild is significantly faster than Webpack for development builds
- **Nx Integration:** Nx provides first-class Angular support with esbuild
- **Production Ready:** esbuild produces optimized production bundles
- **Incremental Builds:** Nx's computation caching makes rebuilds nearly instantaneous
- **Monorepo Support:** Nx enables easy addition of multiple apps/libraries in the future

**Trade-offs:**
- Less customizable than Webpack (fewer plugins available)
- Nx adds complexity for simple projects
- esbuild doesn't support all Webpack features (e.g., custom loaders)

**Alternative Considered:** Vite - rejected because Nx provides better Angular-specific tooling and we want consistency with the Spring Boot backend (both managed by Nx).

### 4.3 Vitest for Testing

**Decision:** Use Vitest instead of Jasmine/Karma.

**Rationale:**
- **Speed:** Vitest runs tests 10-100x faster than Jest/Jasmine
- **ESM Native:** Full ES Modules support without configuration
- **TypeScript First:** Seamless TypeScript integration
- **Watch Mode:** Instant feedback during development
- **Jest Compatible:** Same API as Jest, easy migration
- **Component Testing:** Built-in support for testing Angular components

**Test Structure:**
```
┌── src/
│   ├── app/
│   │   ├── features/upload/
│   │   │   ├── photo-upload.component.spec.ts
│   │   │   └── photo-upload.service.spec.ts
│   │   └── stores/
│   │       └── photo.store.spec.ts
```

**Test Types:**
- **Unit Tests:** Test individual functions and methods
- **Component Tests:** Test components with `@angular/core/testing`
- **Integration Tests:** Test component interactions
- **E2E Tests:** Consider Cypress/Playwright for future (not in initial scope)

### 4.4 LocalStorage for Client-Side Persistence

**Decision:** Use LocalStorage for caching photo data.

**Rationale:**
- **Offline Support:** Users can browse their photos without internet connection
- **Performance:** Reduces API calls for already-fetched data
- **User Experience:** Immediate feedback - photos appear instantly from cache
- **No Backend Dependency:** Frontend can work independently for development
- **Simple API:** LocalStorage provides a simple key-value store

**Implementation Strategy:**
- **Cache-First:** Load from LocalStorage immediately, sync with API in background
- **Write-Through:** Update both API and LocalStorage on changes
- **Conflict Resolution:** API is source of truth; LocalStorage is a cache
- **Storage Limits:** Handle `QuotaExceededError` gracefully with user notification

**Limitations & Mitigations:**
| Limitation | Mitigation |
|------------|------------|
| 5MB storage limit per domain | Compress photo data, implement LRU eviction |
| Synchronous API blocks UI | Use `queueMicrotask` for async writes |
| Only stores strings | JSON.stringify/parse all data |
| No automatic expiration | Implement TTL on cached items |
| Shared across tabs | Use `storage` event to sync tabs |

### 4.5 Signals for State Management

**Decision:** Use Angular signals instead of NgRx or other state management libraries.

**Rationale:**
- **Built-in:** Signals are part of Angular core (no external dependencies)
- **Fine-Grained:** Only components using a signal re-render when it changes
- **Composable:** Signals can be combined with `computed` for derived state
- **Simple:** No reducers, actions, selectors, or store setup needed
- **Integration:** Native support in Angular 21's new control flow and effects

**Pattern Implementation:**

```typescript
// Central store (single source of truth)
@Injectable({ providedIn: 'root' })
class PhotoStore {
  // Private mutable state
  private _photos = signal<Photo[]>([], { equal: shallowArrayEqual });
  private _loading = signal(false);
  private _error = signal<string | null>(null);
  
  // Public readonly access
  readonly photos = this._photos.asReadonly();
  readonly loading = this._loading.asReadonly();
  
  // Computed state
  readonly photoCount = computed(() => this._photos().length);
  readonly hasPhotos = computed(() => this._photos().length > 0);
  
  // Actions (mutate private state)
  addPhoto(photo: Photo): void {
    this._photos.update(photos => [...photos, photo]);
  }
  
  removePhoto(id: string): void {
    this._photos.update(photos => photos.filter(p => p.id !== id));
  }
  
  // Async actions
  async loadPhotos(): Promise<void> {
    this._loading.set(true);
    this._error.set(null);
    try {
      const photos = await this.photoService.getAll();
      this._photos.set(photos);
    } catch (error) {
      this._error.set('Failed to load photos');
    } finally {
      this._loading.set(false);
    }
  }
}
```

**Why Not NgRx:**
- Overkill for this application size
- Signals provide 80% of functionality with 20% of complexity
- No need for time-travel debugging in this project
- Team prefers simpler mental model

**Why Not RxJS Only:**
- Signals have better Angular integration
- RxJS is still used for HTTP but not for component state
- Signals are more intuitive for most developers

### 4.6 Image Handling

**Decision:** Store images as base64 data URLs in LocalStorage for cached photos.

**Rationale:**
- **Self-Contained:** Each photo object has everything needed for display
- **No Separate Requests:** No additional HTTP requests for cached images
- **Simple Implementation:** Easy to serialize/deserialize

**Trade-offs & Mitigations:**
- **Size:** Base64 increases file size by ~33%; LocalStorage has 5MB limit
  - Mitigation: Implement compression or store only metadata in LocalStorage, fetch images from API
- **Performance:** Large base64 strings in LocalStorage can slow down the browser
  - Mitigation: Limit number of cached images; implement LRU cache

**Alternative Approach (Recommended for Production):**
```typescript
// Store only metadata, fetch images from API
export interface CachedPhoto {
  id: string;
  filename: string;
  contentType: string;
  size: number;
  width: number;
  height: number;
  uploadedAt: Date;
  tags: string[];
  // No dataUrl - fetched from API when needed
}
```

### 4.7 Error Handling

**Decision:** Centralized error handling with user notifications.

**Implementation:**
```typescript
// In PhotoStore
private _errors = signal<AppError[]>([]);
readonly errors = this._errors.asReadonly();

// Error model
export interface AppError {
  id: string;
  message: string;
  type: 'network' | 'validation' | 'storage' | 'unknown';
  timestamp: Date;
  severity: 'info' | 'warning' | 'error';
}

// HTTP Interceptor catches errors
@Injectable()
export class HttpErrorInterceptor implements HttpInterceptor {
  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    return next.handle(req).pipe(
      catchError((error: HttpErrorResponse) => {
        this.errorService.report(error);
        return throwError(() => error);
      })
    );
  }
}

// ErrorService displays notifications
@Injectable({ providedIn: 'root' })
export class ErrorService {
  private _errors = this.store.errors; // From PhotoStore
  
  constructor(private store: PhotoStore) {}
  
  report(error: HttpErrorResponse | Error): void {
    const appError = this.normalizeError(error);
    this.store.addError(appError);
  }
}
```

### 4.8 Routing Strategy

**Decision:** Single-page application with client-side routing.

**Routes:**
```typescript
// app.routes.ts
const routes: Route[] = [
  { path: '', redirectTo: '/gallery', pathMatch: 'full' },
  { 
    path: 'gallery', 
    component: MainLayoutComponent,
    children: [
      { path: '', component: PhotoGalleryComponent },
      { path: 'upload', component: PhotoUploadComponent },
      { path: ':id', component: PhotoDetailModalComponent }
    ]
  },
  { path: '**', redirectTo: '/gallery' }
];
```

**Why Client-Side Routing:**
- Seamless navigation without page reloads
- Better user experience
- Easy to add more pages in the future
- Works with LocalStorage caching

---

## 5. Implementation Phases

### Phase 1: Foundation (1-2 days)
- [ ] Set up Nx workspace with Angular 21
- [ ] Configure esbuild and Vitest
- [ ] Create base project structure
- [ ] Set up shared utilities and constants

### Phase 2: Models & Services (2-3 days)
- [ ] Define all TypeScript interfaces
- [ ] Create type guards and validation
- [ ] Implement LocalStorage service
- [ ] Implement API client services
- [ ] Implement PhotoStore with signals

### Phase 3: Core Components (3-4 days)
- [ ] Create Header and Footer components
- [ ] Create MainLayout component
- [ ] Create shared components (Modal, Spinner, etc.)

### Phase 4: Photo Upload Feature (2-3 days)
- [ ] Create PhotoUpload component
- [ ] Implement drag-and-drop directive
- [ ] Add image validation
- [ ] Implement upload with progress

### Phase 5: Photo Gallery Feature (3-4 days)
- [ ] Create PhotoGallery component
- [ ] Create PhotoCard component
- [ ] Implement pagination
- [ ] Implement sorting

### Phase 6: Tag Filtering (1-2 days)
- [ ] Create TagFilter component
- [ ] Create TagBadge component
- [ ] Implement tag statistics

### Phase 7: Photo Details & Delete (2-3 days)
- [ ] Create PhotoDetailModal component
- [ ] Create DeleteConfirmationModal component
- [ ] Implement delete functionality

### Phase 8: Testing & Polish (2-3 days)
- [ ] Write unit tests for all services
- [ ] Write component tests
- [ ] Add error handling and edge cases
- [ ] Performance optimization
- [ ] Accessibility audit

---

## 6. Dependencies

```json
{
  "dependencies": {
    "@angular/animations": "^21.0.0",
    "@angular/common": "^21.0.0",
    "@angular/compiler": "^21.0.0",
    "@angular/core": "^21.0.0",
    "@angular/forms": "^21.0.0",
    "@angular/platform-browser": "^21.0.0",
    "@angular/platform-browser-dynamic": "^21.0.0",
    "@angular/router": "^21.0.0",
    "rxjs": "~7.8.0",
    "tslib": "^2.6.0",
    "zone.js": "~0.15.0"
  },
  "devDependencies": {
    "@angular-devkit/build-angular": "^21.0.0",
    "@angular/cli": "^21.0.0",
    "@angular/compiler-cli": "^21.0.0",
    "@nx/angular": "^21.0.0",
    "@types/jasmine": "~5.1.0",
    "@types/node": "^22.0.0",
    "jasmine-core": "~5.4.0",
    "nx": "^21.0.0",
    "typescript": "~5.6.0",
    "vitest": "^2.1.0"
  }
}
```

---

## 7. Risk Mitigation

| Risk | Probability | Impact | Mitigation |
|------|-------------|--------|------------|
| Angular 21 signals not stable | Low | Medium | Verify compatibility with Nx, have RxJS fallback |
| LocalStorage size exceeded | Medium | Medium | Implement LRU cache, compress data, user notification |
| Browser compatibility issues | Medium | High | Test on target browsers, use polyfills if needed |
| API changes from backend | Medium | Medium | Version API endpoints, maintain backward compatibility |
| Performance with many photos | Medium | High | Implement virtual scrolling, lazy loading |

---

*Document Version: 1.0.0*  
*Last Updated: 2026-10-07*  
*Author: Photo Gallery Frontend Team*
