package com.sfeir.photo_gallery_api.repository;

import com.sfeir.photo_gallery_api.model.Tag;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * Repository for Tag entity operations.
 */
@Repository
public interface TagRepository extends JpaRepository<Tag, Long> {

    /**
     * Finds a tag by its name (case-insensitive).
     */
    Optional<Tag> findByNameIgnoreCase(String name);

    /**
     * Finds all tags whose names contain the given string (case-insensitive).
     */
    List<Tag> findByNameContainingIgnoreCase(String name);

    /**
     * Finds all tags by their names in a list (case-insensitive).
     */
    List<Tag> findByNameInIgnoreCase(List<String> names);

    /**
     * Checks if a tag with the given name exists (case-insensitive).
     */
    boolean existsByNameIgnoreCase(String name);

    /**
     * Deletes a tag by its name (case-insensitive).
     */
    void deleteByNameIgnoreCase(String name);
}
