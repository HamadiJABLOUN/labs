/**
 * Utility Classes for the Photo Gallery API.
 * <p>
 * This package contains utility classes and constants.
 * </p>
 */
package com.sfeir.photo_gallery_api.util;
