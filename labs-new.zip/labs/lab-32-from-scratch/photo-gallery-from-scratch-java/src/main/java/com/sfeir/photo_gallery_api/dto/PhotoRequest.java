package com.sfeir.photo_gallery_api.dto;

import jakarta.validation.constraints.*;

import java.util.Set;

/**
 * Request DTO for photo operations (updating tags, etc.).
 */
public class PhotoRequest {

    @Size(max = 20, message = "Maximum 20 tags allowed")
    private Set<String> tags = Set.of();

    public PhotoRequest() {
    }

    public PhotoRequest(Set<String> tags) {
        this.tags = tags;
    }

    // Getters and Setters

    public Set<String> getTags() {
        return tags;
    }

    public void setTags(Set<String> tags) {
        this.tags = tags;
    }
}
