package com.sfeir.photo_gallery_api.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.nio.file.Path;
import java.nio.file.Paths;

/**
 * Configuration for file storage operations.
 */
@Configuration
public class FileStorageConfig {

    @Value("${app.upload.dir:uploads}")
    private String uploadDir;

    /**
     * Creates the upload directory path.
     */
    @Bean
    public Path uploadPath() {
        return Paths.get(uploadDir).toAbsolutePath().normalize();
    }

    public String getUploadDir() {
        return uploadDir;
    }

    /**
     * Gets the full path for a photo file.
     */
    public Path getPhotoPath(String photoId, String filename) {
        return uploadPath().resolve(photoId + "_" + filename);
    }
}
