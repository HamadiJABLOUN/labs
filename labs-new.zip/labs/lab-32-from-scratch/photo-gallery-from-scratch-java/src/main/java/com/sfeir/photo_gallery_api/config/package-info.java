/**
 * Configuration for the Photo Gallery API.
 * <p>
 * This package contains Spring configuration classes.
 * </p>
 */
package com.sfeir.photo_gallery_api.config;
