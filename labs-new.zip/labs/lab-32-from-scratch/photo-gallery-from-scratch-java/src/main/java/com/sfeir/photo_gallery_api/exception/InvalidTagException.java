package com.sfeir.photo_gallery_api.exception;

import java.util.Set;

/**
 * Exception thrown when tag validation fails.
 */
public class InvalidTagException extends RuntimeException {

    private final Set<String> invalidTags;
    private final String reason;

    public InvalidTagException(String message, Set<String> invalidTags, String reason) {
        super(message);
        this.invalidTags = invalidTags;
        this.reason = reason;
    }

    public InvalidTagException(String message) {
        super(message);
        this.invalidTags = Set.of();
        this.reason = "invalid_format";
    }

    public static InvalidTagException forInvalidCharacters(Set<String> tags) {
        return new InvalidTagException(
                "Tags contain invalid characters. Only [a-z0-9_-] are allowed.",
                tags,
                "invalid_characters"
        );
    }

    public static InvalidTagException forLength(Set<String> tags) {
        return new InvalidTagException(
                "Tags exceed maximum length of 50 characters.",
                tags,
                "max_length_exceeded"
        );
    }

    public static InvalidTagException forCount() {
        return new InvalidTagException(
                "Maximum 20 tags allowed per photo.",
                Set.of(),
                "max_count_exceeded"
        );
    }

    public static InvalidTagException forEmpty() {
        return new InvalidTagException(
                "Tag name cannot be empty.",
                Set.of(),
                "empty_tag"
        );
    }

    public Set<String> getInvalidTags() {
        return invalidTags;
    }

    public String getReason() {
        return reason;
    }
}
