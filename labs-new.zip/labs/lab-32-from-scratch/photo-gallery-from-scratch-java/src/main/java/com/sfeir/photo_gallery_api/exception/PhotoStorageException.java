package com.sfeir.photo_gallery_api.exception;

/**
 * Exception thrown when there is an error with photo storage operations.
 */
public class PhotoStorageException extends RuntimeException {

    private final String errorType;

    public PhotoStorageException(String message) {
        super(message);
        this.errorType = "storage_error";
    }

    public PhotoStorageException(String message, Throwable cause) {
        super(message, cause);
        this.errorType = "storage_error";
    }

    public PhotoStorageException(String message, String errorType) {
        super(message);
        this.errorType = errorType;
    }

    public PhotoStorageException(String message, String errorType, Throwable cause) {
        super(message, cause);
        this.errorType = errorType;
    }

    public String getErrorType() {
        return errorType;
    }
}
