package com.sfeir.photo_gallery_api.dto;

import jakarta.validation.constraints.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.Set;

/**
 * Request DTO for uploading a new photo.
 */
public class UploadPhotoRequest {

    @NotNull(message = "File is required")
    private MultipartFile file;

    @Size(max = 20, message = "Maximum 20 tags allowed")
    private Set<String> tags = Set.of();

    public UploadPhotoRequest() {
    }

    public UploadPhotoRequest(MultipartFile file, Set<String> tags) {
        this.file = file;
        this.tags = tags;
    }

    // Getters and Setters

    public MultipartFile getFile() {
        return file;
    }

    public void setFile(MultipartFile file) {
        this.file = file;
    }

    public Set<String> getTags() {
        return tags;
    }

    public void setTags(Set<String> tags) {
        this.tags = tags;
    }
}
