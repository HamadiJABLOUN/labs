/**
 * Exception Handling for the Photo Gallery API.
 * <p>
 * This package contains custom exceptions and the global exception handler.
 * </p>
 */
package com.sfeir.photo_gallery_api.exception;
