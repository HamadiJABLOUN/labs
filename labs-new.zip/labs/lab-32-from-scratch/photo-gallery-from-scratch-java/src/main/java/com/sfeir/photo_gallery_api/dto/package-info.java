/**
 * Data Transfer Objects for the Photo Gallery API.
 * <p>
 * This package contains the DTO classes used for request and response payloads.
 * </p>
 */
package com.sfeir.photo_gallery_api.dto;
