package com.sfeir.photo_gallery_api.repository;

import com.sfeir.photo_gallery_api.model.Photo;
import com.sfeir.photo_gallery_api.model.Tag;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * Repository for Photo entity operations.
 */
@Repository
public interface PhotoRepository extends JpaRepository<Photo, String>, JpaSpecificationExecutor<Photo> {

    /**
     * Finds a photo by its ID.
     */
    Optional<Photo> findById(String id);

    /**
     * Finds all photos, paginated.
     */
    Page<Photo> findAll(Pageable pageable);

    /**
     * Finds all photos that have a specific tag.
     */
    @Query("SELECT DISTINCT p FROM Photo p JOIN p.tags t WHERE LOWER(t.name) = LOWER(:tagName)")
    Page<Photo> findByTagName(String tagName, Pageable pageable);

    /**
     * Finds all photos that have ALL the specified tags (AND logic).
     */
    @Query("SELECT DISTINCT p FROM Photo p JOIN p.tags t WHERE LOWER(t.name) IN :tagNames " +
           "GROUP BY p HAVING COUNT(DISTINCT t) = :tagCount")
    Page<Photo> findByAllTagNames(List<String> tagNames, long tagCount, Pageable pageable);

    /**
     * Finds all photos that have ANY of the specified tags (OR logic).
     */
    @Query("SELECT DISTINCT p FROM Photo p JOIN p.tags t WHERE LOWER(t.name) IN :tagNames")
    Page<Photo> findByAnyTagName(List<String> tagNames, Pageable pageable);

    /**
     * Finds photos by filename containing a string (case-insensitive).
     */
    Page<Photo> findByFilenameContainingIgnoreCase(String filename, Pageable pageable);

    /**
     * Counts all photos.
     */
    long count();

    /**
     * Checks if a photo with the given ID exists.
     */
    boolean existsById(String id);

    /**
     * Deletes a photo by its ID.
     */
    void deleteById(String id);
}
