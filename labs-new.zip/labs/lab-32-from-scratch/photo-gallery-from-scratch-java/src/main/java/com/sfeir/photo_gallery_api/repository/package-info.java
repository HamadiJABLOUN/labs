/**
 * Data Access Layer for the Photo Gallery API.
 * <p>
 * This package contains the JPA repository interfaces for database operations.
 * </p>
 */
package com.sfeir.photo_gallery_api.repository;
