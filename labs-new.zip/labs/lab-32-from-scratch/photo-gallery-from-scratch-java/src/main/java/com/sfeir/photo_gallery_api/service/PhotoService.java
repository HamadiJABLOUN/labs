package com.sfeir.photo_gallery_api.service;

import com.sfeir.photo_gallery_api.dto.PhotoDto;
import com.sfeir.photo_gallery_api.dto.PageResponse;
import com.sfeir.photo_gallery_api.exception.FileUploadException;
import com.sfeir.photo_gallery_api.exception.InvalidTagException;
import com.sfeir.photo_gallery_api.exception.ResourceNotFoundException;
import com.sfeir.photo_gallery_api.model.Photo;
import com.sfeir.photo_gallery_api.model.Tag;
import com.sfeir.photo_gallery_api.repository.PhotoRepository;
import com.sfeir.photo_gallery_api.util.Constants;
import com.sfeir.photo_gallery_api.util.TagValidator;
import org.modelmapper.ModelMapper;
import org.springframework.data.domain.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Service for managing photos.
 */
@Service
public class PhotoService {

    private static final long MAX_FILE_SIZE = 10 * 1024 * 1024; // 10MB
    private static final Set<String> ALLOWED_CONTENT_TYPES = Set.of(
            "image/jpeg",
            "image/png",
            "image/gif",
            "image/webp"
    );

    private final PhotoRepository photoRepository;
    private final TagService tagService;
    private final FileStorageService fileStorageService;
    private final ModelMapper modelMapper;

    public PhotoService(PhotoRepository photoRepository, TagService tagService,
                      FileStorageService fileStorageService, ModelMapper modelMapper) {
        this.photoRepository = photoRepository;
        this.tagService = tagService;
        this.fileStorageService = fileStorageService;
        this.modelMapper = modelMapper;
    }

    /**
     * Uploads a new photo.
     */
    @Transactional
    public PhotoDto uploadPhoto(MultipartFile file, Set<String> tagNames) {
        // Validate file
        validateFile(file);
        
        // Validate tags
        tagService.validateTags(tagNames);
        
        // Generate photo ID
        String photoId = fileStorageService.generatePhotoId();
        
        // Store file
        String sanitizedFilename = fileStorageService.sanitizeFilename(
                file.getOriginalFilename()
        );
        String filePath = fileStorageService.storeFile(file, photoId);
        
        // Get or create tags
        Set<Tag> tags = tagService.getOrCreateTags(tagNames);
        
        // Get image dimensions
        int[] dimensions = fileStorageService.getImageDimensions(file);
        
        // Create photo entity
        Photo photo = new Photo();
        photo.setId(photoId);
        photo.setFilename(sanitizedFilename);
        photo.setOriginalFilename(file.getOriginalFilename());
        photo.setContentType(file.getContentType());
        photo.setFileSize(file.getSize());
        photo.setWidth(dimensions[0]);
        photo.setHeight(dimensions[1]);
        photo.setUploadDate(LocalDateTime.now());
        photo.setFilePath(filePath);
        photo.setTags(tags);
        
        // Save photo
        Photo savedPhoto = photoRepository.save(photo);
        
        return convertToDto(savedPhoto);
    }

    /**
     * Validates an uploaded file.
     */
    private void validateFile(MultipartFile file) {
        if (file == null || file.isEmpty()) {
            throw FileUploadException.forEmptyFile();
        }
        
        if (file.getSize() > MAX_FILE_SIZE) {
            throw FileUploadException.forFileTooLarge(file.getSize(), MAX_FILE_SIZE);
        }
        
        if (!ALLOWED_CONTENT_TYPES.contains(file.getContentType())) {
            throw FileUploadException.forInvalidType(file.getContentType());
        }
        
        if (!fileStorageService.isImageFile(file)) {
            throw FileUploadException.forInvalidImage();
        }
    }

    /**
     * Gets a photo by ID.
     */
    @Transactional(readOnly = true)
    public PhotoDto getPhotoById(String id) {
        Photo photo = photoRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Photo", id));
        return convertToDto(photo);
    }

    /**
     * Gets all photos with pagination.
     */
    @Transactional(readOnly = true)
    public PageResponse<PhotoDto> getAllPhotos(
            int page, 
            int size, 
            String sortBy, 
            String sortDirection) {
        
        // Validate pagination parameters
        if (page < 0) {
            page = 0;
        }
        if (size < 1 || size > Constants.MAX_PAGE_SIZE) {
            size = Constants.DEFAULT_PAGE_SIZE;
        }
        
        // Create sort
        Sort.Direction direction = sortDirection != null && sortDirection.equalsIgnoreCase("desc")
                ? Sort.Direction.DESC : Sort.Direction.ASC;
        Sort sort = Sort.by(direction, sortBy != null ? sortBy : "uploadDate");
        
        // Create pageable
        Pageable pageable = PageRequest.of(page, size, sort);
        
        // Get page
        Page<Photo> photoPage = photoRepository.findAll(pageable);
        
        // Convert to DTOs
        List<PhotoDto> photoDtos = photoPage.getContent().stream()
                .map(this::convertToDto)
                .toList();
        
        // Create response
        return new PageResponse<>(
                photoDtos,
                photoPage.getNumber(),
                photoPage.getSize(),
                photoPage.getTotalElements(),
                photoPage.getTotalPages(),
                photoPage.isLast(),
                photoPage.isFirst()
        );
    }

    /**
     * Gets photos filtered by tags.
     */
    @Transactional(readOnly = true)
    public PageResponse<PhotoDto> getPhotosByTags(
            Set<String> tagNames,
            String filterMode,
            int page,
            int size,
            String sortBy,
            String sortDirection) {
        
        // Validate pagination parameters
        if (page < 0) {
            page = 0;
        }
        if (size < 1 || size > Constants.MAX_PAGE_SIZE) {
            size = Constants.DEFAULT_PAGE_SIZE;
        }
        
        // Create sort
        Sort.Direction direction = sortDirection != null && sortDirection.equalsIgnoreCase("desc")
                ? Sort.Direction.DESC : Sort.Direction.ASC;
        Sort sort = Sort.by(direction, sortBy != null ? sortBy : "uploadDate");
        
        // Create pageable
        Pageable pageable = PageRequest.of(page, size, sort);
        
        Page<Photo> photoPage;
        
        if (tagNames == null || tagNames.isEmpty()) {
            // No tags specified, return all photos
            photoPage = photoRepository.findAll(pageable);
        } else {
            // Normalize tag names
            Set<String> normalizedTags = tagService.normalizeTags(tagNames);
            List<String> tagList = new ArrayList<>(normalizedTags);
            
            if (filterMode != null && filterMode.equalsIgnoreCase("OR")) {
                // OR logic: photo must have ANY of the tags
                photoPage = photoRepository.findByAnyTagName(tagList, pageable);
            } else {
                // AND logic (default): photo must have ALL of the tags
                photoPage = photoRepository.findByAllTagNames(
                        tagList, 
                        tagList.size(), 
                        pageable
                );
            }
        }
        
        // Convert to DTOs
        List<PhotoDto> photoDtos = photoPage.getContent().stream()
                .map(this::convertToDto)
                .toList();
        
        // Create response
        return new PageResponse<>(
                photoDtos,
                photoPage.getNumber(),
                photoPage.getSize(),
                photoPage.getTotalElements(),
                photoPage.getTotalPages(),
                photoPage.isLast(),
                photoPage.isFirst()
        );
    }

    /**
     * Adds tags to a photo.
     */
    @Transactional
    public PhotoDto addTagsToPhoto(String photoId, Set<String> tagNames) {
        Photo photo = photoRepository.findById(photoId)
                .orElseThrow(() -> new ResourceNotFoundException("Photo", photoId));
        
        tagService.validateTags(tagNames);
        
        // Check if adding tags would exceed the limit
        if (photo.getTags().size() + tagNames.size() > Constants.MAX_TAGS_PER_PHOTO) {
            throw InvalidTagException.forCount();
        }
        
        // Get or create tags
        Set<Tag> tags = tagService.getOrCreateTags(tagNames);
        
        // Add tags to photo
        for (Tag tag : tags) {
            if (!photo.hasTag(tag.getName())) {
                photo.addTag(tag);
            }
        }
        
        Photo savedPhoto = photoRepository.save(photo);
        return convertToDto(savedPhoto);
    }

    /**
     * Removes a tag from a photo.
     */
    @Transactional
    public PhotoDto removeTagFromPhoto(String photoId, String tagName) {
        Photo photo = photoRepository.findById(photoId)
                .orElseThrow(() -> new ResourceNotFoundException("Photo", photoId));
        
        String normalizedTagName = tagService.normalizeTag(tagName);
        
        // Find and remove the tag
        photo.getTags().removeIf(tag -> tag.getName().equals(normalizedTagName));
        
        Photo savedPhoto = photoRepository.save(photo);
        return convertToDto(savedPhoto);
    }

    /**
     * Replaces all tags on a photo.
     */
    @Transactional
    public PhotoDto replaceTagsOnPhoto(String photoId, Set<String> tagNames) {
        Photo photo = photoRepository.findById(photoId)
                .orElseThrow(() -> new ResourceNotFoundException("Photo", photoId));
        
        tagService.validateTags(tagNames);
        
        // Clear existing tags
        photo.clearTags();
        
        // Add new tags
        Set<Tag> tags = tagService.getOrCreateTags(tagNames);
        for (Tag tag : tags) {
            photo.addTag(tag);
        }
        
        Photo savedPhoto = photoRepository.save(photo);
        return convertToDto(savedPhoto);
    }

    /**
     * Gets all tags for a photo.
     */
    @Transactional(readOnly = true)
    public Set<String> getTagsForPhoto(String photoId) {
        Photo photo = photoRepository.findById(photoId)
                .orElseThrow(() -> new ResourceNotFoundException("Photo", photoId));
        
        return photo.getTags().stream()
                .map(Tag::getName)
                .collect(Collectors.toSet());
    }

    /**
     * Deletes a photo by ID.
     */
    @Transactional
    public void deletePhoto(String photoId) {
        Photo photo = photoRepository.findById(photoId)
                .orElseThrow(() -> new ResourceNotFoundException("Photo", photoId));
        
        // Delete the file from filesystem
        try {
            fileStorageService.deleteFile(photo.getFilePath());
        } catch (Exception e) {
            // Log warning but don't fail the operation
        }
        
        // Delete the photo from database
        photoRepository.delete(photo);
    }

    /**
     * Checks if a photo exists.
     */
    @Transactional(readOnly = true)
    public boolean photoExists(String photoId) {
        return photoRepository.existsById(photoId);
    }

    /**
     * Gets the count of all photos.
     */
    @Transactional(readOnly = true)
    public long getPhotoCount() {
        return photoRepository.count();
    }

    /**
     * Converts a Photo entity to PhotoDto.
     */
    private PhotoDto convertToDto(Photo photo) {
        PhotoDto dto = modelMapper.map(photo, PhotoDto.class);
        // Convert tags to tag names
        if (photo.getTags() != null) {
            Set<String> tagNames = photo.getTags().stream()
                    .map(Tag::getName)
                    .collect(Collectors.toSet());
            dto.setTags(tagNames);
        }
        return dto;
    }
}
