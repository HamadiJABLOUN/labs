package com.sfeir.photo_gallery_api.exception;

/**
 * Exception thrown when file upload validation fails.
 */
public class FileUploadException extends RuntimeException {

    private final String errorType;
    private final long fileSize;
    private final String contentType;

    public FileUploadException(String message, String errorType, long fileSize, String contentType) {
        super(message);
        this.errorType = errorType;
        this.fileSize = fileSize;
        this.contentType = contentType;
    }

    public FileUploadException(String message, String errorType) {
        super(message);
        this.errorType = errorType;
        this.fileSize = 0;
        this.contentType = null;
    }

    public static FileUploadException forFileTooLarge(long fileSize, long maxSize) {
        return new FileUploadException(
                String.format("File size %d bytes exceeds maximum allowed size of %d bytes", fileSize, maxSize),
                "file_too_large",
                fileSize,
                null
        );
    }

    public static FileUploadException forInvalidType(String contentType) {
        return new FileUploadException(
                String.format("File type %s is not supported. Allowed types: JPEG, PNG, GIF, WebP", contentType),
                "invalid_file_type",
                0,
                contentType
        );
    }

    public static FileUploadException forEmptyFile() {
        return new FileUploadException(
                "No file provided for upload",
                "empty_file",
                0,
                null
        );
    }

    public static FileUploadException forInvalidImage() {
        return new FileUploadException(
                "Uploaded file is not a valid image",
                "invalid_image"
        );
    }

    public String getErrorType() {
        return errorType;
    }

    public long getFileSize() {
        return fileSize;
    }

    public String getContentType() {
        return contentType;
    }
}
