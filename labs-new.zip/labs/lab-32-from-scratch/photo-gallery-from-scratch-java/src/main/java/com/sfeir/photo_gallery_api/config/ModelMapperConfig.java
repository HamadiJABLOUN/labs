package com.sfeir.photo_gallery_api.config;

import com.sfeir.photo_gallery_api.model.Photo;
import com.sfeir.photo_gallery_api.model.Tag;
import com.sfeir.photo_gallery_api.dto.PhotoDto;
import org.modelmapper.Converter;
import org.modelmapper.ModelMapper;
import org.modelmapper.convention.MatchingStrategies;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.HashSet;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * Configuration for ModelMapper bean.
 */
@Configuration
public class ModelMapperConfig {

    /**
     * Creates and configures ModelMapper bean.
     */
    @Bean
    public ModelMapper modelMapper() {
        ModelMapper modelMapper = new ModelMapper();
        modelMapper.getConfiguration()
                .setMatchingStrategy(MatchingStrategies.STANDARD)
                .setSkipNullEnabled(true);

        // Configure custom mappings
        modelMapper.typeMap(Photo.class, PhotoDto.class).addMappings(mapper -> {
            mapper.using((Converter<Set<Tag>, Set<String>>) ctx ->
                            ctx.getSource() == null
                                    ? new HashSet<>()
                                    : ctx.getSource().stream()
                                            .map(Tag::getName)
                                            .collect(Collectors.toSet()))
                    .map(Photo::getTags, PhotoDto::setTags);
        });

        return modelMapper;
    }
}
