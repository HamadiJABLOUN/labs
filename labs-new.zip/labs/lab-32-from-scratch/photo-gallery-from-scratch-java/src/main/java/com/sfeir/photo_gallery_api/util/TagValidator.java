package com.sfeir.photo_gallery_api.util;

import com.sfeir.photo_gallery_api.exception.InvalidTagException;

import java.util.*;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

/**
 * Utility class for tag validation.
 */
public final class TagValidator {

    private static final Pattern TAG_PATTERN = Pattern.compile(Constants.TAG_REGEX);

    private TagValidator() {
        // Prevent instantiation
    }

    /**
     * Validates a single tag.
     * 
     * @param tag the tag to validate
     * @throws InvalidTagException if the tag is invalid
     */
    public static void validate(String tag) {
        if (tag == null || tag.trim().isEmpty()) {
            throw InvalidTagException.forEmpty();
        }
        
        String normalizedTag = tag.toLowerCase().trim();
        
        if (normalizedTag.length() > Constants.MAX_TAG_LENGTH) {
            throw InvalidTagException.forLength(Set.of(tag));
        }
        
        if (!TAG_PATTERN.matcher(normalizedTag).matches()) {
            throw InvalidTagException.forInvalidCharacters(Set.of(tag));
        }
    }

    /**
     * Validates a collection of tags.
     * 
     * @param tags the tags to validate
     * @throws InvalidTagException if any tag is invalid
     */
    public static void validate(Collection<String> tags) {
        if (tags == null) {
            return;
        }
        
        if (tags.size() > Constants.MAX_TAGS_PER_PHOTO) {
            throw InvalidTagException.forCount();
        }
        
        for (String tag : tags) {
            validate(tag);
        }
    }

    /**
     * Normalizes a tag name (lowercase, trim).
     * 
     * @param tag the tag to normalize
     * @return the normalized tag name
     */
    public static String normalize(String tag) {
        if (tag == null) {
            return null;
        }
        return tag.toLowerCase().trim();
    }

    /**
     * Normalizes a collection of tag names.
     * 
     * @param tags the tags to normalize
     * @return a set of normalized tag names
     */
    public static Set<String> normalize(Collection<String> tags) {
        if (tags == null) {
            return Set.of();
        }
        return tags.stream()
                .map(TagValidator::normalize)
                .collect(Collectors.toSet());
    }

    /**
     * Checks if a tag name is valid.
     * 
     * @param tag the tag to check
     * @return true if the tag is valid
     */
    public static boolean isValid(String tag) {
        if (tag == null || tag.trim().isEmpty()) {
            return false;
        }
        
        String normalizedTag = tag.toLowerCase().trim();
        
        if (normalizedTag.length() > Constants.MAX_TAG_LENGTH) {
            return false;
        }
        
        return TAG_PATTERN.matcher(normalizedTag).matches();
    }

    /**
     * Filters valid tags from a collection.
     * 
     * @param tags the tags to filter
     * @return a set of valid tags
     */
    public static Set<String> filterValid(Collection<String> tags) {
        if (tags == null) {
            return Set.of();
        }
        return tags.stream()
                .filter(TagValidator::isValid)
                .collect(Collectors.toSet());
    }
}
