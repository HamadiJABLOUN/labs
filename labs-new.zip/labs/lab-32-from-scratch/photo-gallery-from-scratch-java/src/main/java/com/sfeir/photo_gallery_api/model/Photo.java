package com.sfeir.photo_gallery_api.model;

import jakarta.persistence.*;

import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Set;

/**
 * Entity representing a photo in the gallery.
 * Contains metadata about the photo and its associated tags.
 */
@Entity
@Table(name = "photos")
public class Photo {

    @Id
    @Column(length = 36)
    private String id;

    @Column(nullable = false, length = 255)
    private String filename;

    @Column(name = "original_filename", length = 255)
    private String originalFilename;

    @Column(name = "content_type", nullable = false, length = 100)
    private String contentType;

    @Column(name = "file_size", nullable = false)
    private Long fileSize;

    @Column(nullable = false)
    private Integer width;

    @Column(nullable = false)
    private Integer height;

    @Column(name = "upload_date", nullable = false)
    private LocalDateTime uploadDate;

    @Column(name = "file_path", nullable = false, length = 500)
    private String filePath;

    @ManyToMany(fetch = FetchType.LAZY)
    @JoinTable(
            name = "photo_tags",
            joinColumns = @JoinColumn(name = "photo_id"),
            inverseJoinColumns = @JoinColumn(name = "tag_id")
    )
    private Set<Tag> tags = new HashSet<>();

    public Photo() {
    }

    public Photo(String id, String filename, String originalFilename, String contentType,
                Long fileSize, Integer width, Integer height, LocalDateTime uploadDate,
                String filePath, Set<Tag> tags) {
        this.id = id;
        this.filename = filename;
        this.originalFilename = originalFilename;
        this.contentType = contentType;
        this.fileSize = fileSize;
        this.width = width;
        this.height = height;
        this.uploadDate = uploadDate;
        this.filePath = filePath;
        this.tags = tags;
    }

    /**
     * Adds a tag to this photo.
     */
    public void addTag(Tag tag) {
        this.tags.add(tag);
        tag.getPhotos().add(this);
    }

    /**
     * Removes a tag from this photo.
     */
    public void removeTag(Tag tag) {
        this.tags.remove(tag);
        tag.getPhotos().remove(this);
    }

    /**
     * Removes all tags from this photo.
     */
    public void clearTags() {
        this.tags.forEach(tag -> tag.getPhotos().remove(this));
        this.tags.clear();
    }

    /**
     * Checks if this photo has a specific tag (case-insensitive).
     */
    public boolean hasTag(String tagName) {
        return this.tags.stream()
                .anyMatch(tag -> tag.getName().equalsIgnoreCase(tagName));
    }

    /**
     * Checks if this photo has all the specified tags.
     */
    public boolean hasAllTags(Set<String> tagNames) {
        return tagNames.stream()
                .allMatch(this::hasTag);
    }

    @PrePersist
    protected void onCreate() {
        if (this.uploadDate == null) {
            this.uploadDate = LocalDateTime.now();
        }
    }

    // Getters and Setters

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getFilename() {
        return filename;
    }

    public void setFilename(String filename) {
        this.filename = filename;
    }

    public String getOriginalFilename() {
        return originalFilename;
    }

    public void setOriginalFilename(String originalFilename) {
        this.originalFilename = originalFilename;
    }

    public String getContentType() {
        return contentType;
    }

    public void setContentType(String contentType) {
        this.contentType = contentType;
    }

    public Long getFileSize() {
        return fileSize;
    }

    public void setFileSize(Long fileSize) {
        this.fileSize = fileSize;
    }

    public Integer getWidth() {
        return width;
    }

    public void setWidth(Integer width) {
        this.width = width;
    }

    public Integer getHeight() {
        return height;
    }

    public void setHeight(Integer height) {
        this.height = height;
    }

    public LocalDateTime getUploadDate() {
        return uploadDate;
    }

    public void setUploadDate(LocalDateTime uploadDate) {
        this.uploadDate = uploadDate;
    }

    public String getFilePath() {
        return filePath;
    }

    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }

    public Set<Tag> getTags() {
        return tags;
    }

    public void setTags(Set<Tag> tags) {
        this.tags = tags;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Photo photo = (Photo) o;
        return id != null && id.equals(photo.id);
    }

    @Override
    public int hashCode() {
        return id != null ? id.hashCode() : 0;
    }

    @Override
    public String toString() {
        return "Photo{" +
                "id='" + id + '\'' +
                ", filename='" + filename + '\'' +
                ", originalFilename='" + originalFilename + '\'' +
                ", contentType='" + contentType + '\'' +
                ", fileSize=" + fileSize +
                ", width=" + width +
                ", height=" + height +
                ", uploadDate=" + uploadDate +
                ", filePath='" + filePath + '\'' +
                '}';
    }
}
