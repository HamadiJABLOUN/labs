package com.sfeir.photo_gallery_api.model;

import jakarta.persistence.*;

import java.util.HashSet;
import java.util.Set;

/**
 * Entity representing a tag that can be associated with photos.
 * Tags are case-insensitive and stored in lowercase.
 */
@Entity
@Table(name = "tags")
public class Tag {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true, length = 50)
    private String name;

    @ManyToMany(mappedBy = "tags", fetch = FetchType.LAZY)
    private Set<Photo> photos = new HashSet<>();

    public Tag() {
    }

    public Tag(Long id, String name, Set<Photo> photos) {
        this.id = id;
        this.name = name;
        this.photos = photos;
    }

    /**
     * Constructor with name only.
     */
    public Tag(String name) {
        this.name = name.toLowerCase();
    }

    /**
     * Adds a photo to this tag.
     */
    public void addPhoto(Photo photo) {
        this.photos.add(photo);
        if (photo != null) {
            photo.getTags().add(this);
        }
    }

    /**
     * Removes a photo from this tag.
     */
    public void removePhoto(Photo photo) {
        this.photos.remove(photo);
        if (photo != null) {
            photo.getTags().remove(this);
        }
    }

    // Getters and Setters

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Set<Photo> getPhotos() {
        return photos;
    }

    public void setPhotos(Set<Photo> photos) {
        this.photos = photos;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Tag tag = (Tag) o;
        return name != null && name.equals(tag.name);
    }

    @Override
    public int hashCode() {
        return name != null ? name.hashCode() : 0;
    }

    @Override
    public String toString() {
        return "Tag{" +
                "id=" + id +
                ", name='" + name + '\'' +
                '}';
    }
}
