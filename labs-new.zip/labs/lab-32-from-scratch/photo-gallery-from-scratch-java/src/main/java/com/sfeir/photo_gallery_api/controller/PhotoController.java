package com.sfeir.photo_gallery_api.controller;

import com.sfeir.photo_gallery_api.dto.ApiResponse;
import com.sfeir.photo_gallery_api.dto.PageResponse;
import com.sfeir.photo_gallery_api.dto.PhotoDto;
import com.sfeir.photo_gallery_api.dto.PhotoRequest;
import com.sfeir.photo_gallery_api.service.PhotoService;
import jakarta.validation.Valid;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.Set;

/**
 * REST Controller for photo operations.
 * Implements all endpoints defined in SPECIFICATION.md
 */
@RestController
@RequestMapping("/photos")
public class PhotoController {

    private final PhotoService photoService;

    public PhotoController(PhotoService photoService) {
        this.photoService = photoService;
    }

    /**
     * Uploads a new photo.
     * 
     * Endpoint: POST /api/photos
     * FR-001, FR-002, FR-003, FR-004, FR-005, FR-006, FR-007, FR-008
     * AC-001, AC-002, AC-003, AC-004, AC-005
     */
    @PostMapping
    public ResponseEntity<ApiResponse<PhotoDto>> uploadPhoto(
            @RequestParam("file") MultipartFile file,
            @RequestParam(required = false) Set<String> tags) {
        
        PhotoDto photoDto = photoService.uploadPhoto(file, tags);
        
        ApiResponse<PhotoDto> response = ApiResponse.success(
                photoDto,
                "Photo uploaded successfully"
        );
        
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }

    /**
     * Gets all photos with pagination and filtering.
     * 
     * Endpoint: GET /api/photos
     * FR-020, FR-021, FR-022, FR-023, FR-024, FR-025
     * FR-030, FR-031, FR-032, FR-033
     * AC-020, AC-021, AC-022, AC-023
     * AC-030, AC-031, AC-032, AC-033
     */
    @GetMapping
    public ResponseEntity<ApiResponse<PageResponse<PhotoDto>>> getAllPhotos(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size,
            @RequestParam(required = false) Set<String> tags,
            @RequestParam(defaultValue = "AND") String mode,
            @RequestParam(defaultValue = "uploadDate") String sort,
            @RequestParam(defaultValue = "desc") String direction) {
        
        PageResponse<PhotoDto> photoPage;
        
        if (tags != null && !tags.isEmpty()) {
            photoPage = photoService.getPhotosByTags(
                    tags, mode, page, size, sort, direction
            );
        } else {
            photoPage = photoService.getAllPhotos(
                    page, size, sort, direction
            );
        }
        
        ApiResponse<PageResponse<PhotoDto>> response = ApiResponse.success(
                photoPage,
                "Photos retrieved successfully"
        );
        
        return ResponseEntity.ok(response);
    }

    /**
     * Gets a specific photo by ID.
     * 
     * Endpoint: GET /api/photos/{id}
     * FR-040, FR-041, FR-042, FR-043, FR-044
     * AC-040, AC-041, AC-042
     */
    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<PhotoDto>> getPhotoById(@PathVariable String id) {
        PhotoDto photoDto = photoService.getPhotoById(id);
        
        ApiResponse<PhotoDto> response = ApiResponse.success(
                photoDto,
                "Photo retrieved successfully"
        );
        
        return ResponseEntity.ok(response);
    }

    /**
     * Deletes a photo by ID.
     * 
     * Endpoint: DELETE /api/photos/{id}
     * FR-050, FR-051, FR-052, FR-053, FR-054, FR-055
     * AC-050, AC-051, AC-052, AC-053
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletePhoto(@PathVariable String id) {
        photoService.deletePhoto(id);
        return ResponseEntity.noContent().build();
    }

    /**
     * Gets all tags for a specific photo.
     * 
     * Endpoint: GET /api/photos/{id}/tags
     * FR-010, FR-011, FR-012, FR-013, FR-014, FR-015, FR-016, FR-017
     */
    @GetMapping("/{id}/tags")
    public ResponseEntity<ApiResponse<Set<String>>> getPhotoTags(@PathVariable String id) {
        Set<String> tags = photoService.getTagsForPhoto(id);
        
        ApiResponse<Set<String>> response = ApiResponse.success(
                tags,
                "Tags retrieved successfully"
        );
        
        return ResponseEntity.ok(response);
    }

    /**
     * Replaces all tags on a photo.
     * 
     * Endpoint: PUT /api/photos/{id}/tags
     * FR-010, FR-013
     * AC-010
     */
    @PutMapping("/{id}/tags")
    public ResponseEntity<ApiResponse<PhotoDto>> replacePhotoTags(
            @PathVariable String id,
            @Valid @RequestBody PhotoRequest request) {
        
        PhotoDto photoDto = photoService.replaceTagsOnPhoto(id, request.getTags());
        
        ApiResponse<PhotoDto> response = ApiResponse.success(
                photoDto,
                "Tags replaced successfully"
        );
        
        return ResponseEntity.ok(response);
    }

    /**
     * Adds tags to a photo.
     * 
     * Endpoint: POST /api/photos/{id}/tags
     * FR-011
     * AC-011
     */
    @PostMapping("/{id}/tags")
    public ResponseEntity<ApiResponse<PhotoDto>> addPhotoTags(
            @PathVariable String id,
            @Valid @RequestBody PhotoRequest request) {
        
        PhotoDto photoDto = photoService.addTagsToPhoto(id, request.getTags());
        
        ApiResponse<PhotoDto> response = ApiResponse.success(
                photoDto,
                "Tags added successfully"
        );
        
        return ResponseEntity.ok(response);
    }

    /**
     * Removes a specific tag from a photo.
     * 
     * Endpoint: DELETE /api/photos/{id}/tags/{tag}
     * FR-012
     * AC-012
     */
    @DeleteMapping("/{id}/tags/{tag}")
    public ResponseEntity<ApiResponse<PhotoDto>> removePhotoTag(
            @PathVariable String id,
            @PathVariable String tag) {
        
        PhotoDto photoDto = photoService.removeTagFromPhoto(id, tag);
        
        ApiResponse<PhotoDto> response = ApiResponse.success(
                photoDto,
                "Tag removed successfully"
        );
        
        return ResponseEntity.ok(response);
    }
}
