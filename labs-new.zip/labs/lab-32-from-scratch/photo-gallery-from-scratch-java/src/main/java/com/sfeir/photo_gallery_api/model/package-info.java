/**
 * Domain Model for the Photo Gallery API.
 * <p>
 * This package contains the JPA entity classes that represent the data model.
 * </p>
 */
package com.sfeir.photo_gallery_api.model;
