package com.sfeir.photo_gallery_api.util;

/**
 * Application constants.
 */
public final class Constants {

    // Pagination constants
    public static final int DEFAULT_PAGE = 0;
    public static final int DEFAULT_PAGE_SIZE = 20;
    public static final int MAX_PAGE_SIZE = 100;

    // Tag constants
    public static final int MAX_TAG_LENGTH = 50;
    public static final int MAX_TAGS_PER_PHOTO = 20;
    public static final String TAG_REGEX = "^[a-z0-9_-]+$";

    // File upload constants
    public static final long MAX_FILE_SIZE = 10 * 1024 * 1024; // 10MB
    public static final String[] ALLOWED_CONTENT_TYPES = {
            "image/jpeg",
            "image/png",
            "image/gif",
            "image/webp"
    };

    // Sort constants
    public static final String[] ALLOWED_SORT_FIELDS = {
            "uploadDate",
            "filename",
            "fileSize"
    };

    // Filter mode constants
    public static final String FILTER_MODE_AND = "AND";
    public static final String FILTER_MODE_OR = "OR";

    private Constants() {
        // Prevent instantiation
    }
}
