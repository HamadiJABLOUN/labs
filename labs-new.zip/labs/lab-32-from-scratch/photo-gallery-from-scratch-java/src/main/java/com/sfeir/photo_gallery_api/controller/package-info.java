/**
 * REST Controllers for the Photo Gallery API.
 * <p>
 * This package contains the controller classes that handle HTTP requests
 * and delegate to the appropriate services.
 * </p>
 */
package com.sfeir.photo_gallery_api.controller;
