package com.sfeir.photo_gallery_api.service;

import com.sfeir.photo_gallery_api.config.FileStorageConfig;
import com.sfeir.photo_gallery_api.exception.PhotoStorageException;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.*;
import java.util.UUID;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Service for handling file storage operations.
 */
@Service
public class FileStorageService {

    private static final Logger logger = Logger.getLogger(FileStorageService.class.getName());

    private final FileStorageConfig fileStorageConfig;

    public FileStorageService(FileStorageConfig fileStorageConfig) {
        this.fileStorageConfig = fileStorageConfig;
    }

    /**
     * Stores a file on the filesystem.
     */
    public String storeFile(MultipartFile file, String photoId) {
        try {
            // Create upload directory if it doesn't exist
            Path uploadPath = fileStorageConfig.uploadPath();
            if (!Files.exists(uploadPath)) {
                Files.createDirectories(uploadPath);
            }

            // Generate unique filename
            String originalFilename = sanitizeFilename(file.getOriginalFilename());
            String filename = photoId + "_" + originalFilename;
            Path targetPath = uploadPath.resolve(filename);

            // Save file
            file.transferTo(targetPath);

            logger.info("File stored successfully: " + targetPath);
            return targetPath.toString();

        } catch (IOException e) {
            logger.log(Level.SEVERE, "Failed to store file: " + e.getMessage(), e);
            throw new PhotoStorageException(
                    "Failed to store file: " + e.getMessage(),
                    "storage_failed",
                    e
            );
        }
    }

    /**
     * Deletes a file from the filesystem.
     */
    public void deleteFile(String filePath) {
        try {
            Path path = Paths.get(filePath);
            if (Files.exists(path)) {
                Files.delete(path);
                logger.info("File deleted successfully: " + filePath);
            }
        } catch (IOException e) {
            logger.log(Level.SEVERE, "Failed to delete file: " + e.getMessage(), e);
            throw new PhotoStorageException(
                    "Failed to delete file: " + e.getMessage(),
                    "deletion_failed",
                    e
            );
        }
    }

    /**
     * Generates a unique ID for a photo.
     */
    public String generatePhotoId() {
        return UUID.randomUUID().toString();
    }

    /**
     * Sanitizes a filename to prevent path traversal attacks.
     */
    public String sanitizeFilename(String filename) {
        if (filename == null) {
            return "unknown";
        }
        // Replace any path separators with underscore
        return filename.replaceAll("[/\\\\]", "_");
    }

    /**
     * Gets the file extension from a filename.
     */
    public String getFileExtension(String filename) {
        if (filename == null) {
            return "";
        }
        int lastDotIndex = filename.lastIndexOf('.');
        return lastDotIndex > 0 ? filename.substring(lastDotIndex + 1).toLowerCase() : "";
    }

    /**
     * Validates that a file is an image.
     */
    public boolean isImageFile(MultipartFile file) {
        String contentType = file.getContentType();
        if (contentType == null) {
            return false;
        }
        return contentType.startsWith("image/") && 
               (contentType.equals("image/jpeg") ||
                contentType.equals("image/png") ||
                contentType.equals("image/gif") ||
                contentType.equals("image/webp"));
    }

    /**
     * Gets the image dimensions from a file.
     */
    public int[] getImageDimensions(MultipartFile file) {
        try {
            // Simple approach: read the file and try to get dimensions
            // For a real implementation, you might use ImageIO or similar
            // This is a simplified version
            byte[] bytes = file.getBytes();
            if (bytes.length > 0) {
                // Placeholder: return dummy dimensions
                // In a real app, parse the image file
                return new int[]{0, 0};
            }
            return new int[]{0, 0};
        } catch (IOException e) {
            logger.log(Level.WARNING, "Could not determine image dimensions: " + e.getMessage(), e);
            return new int[]{0, 0};
        }
    }
}
