package com.sfeir.photo_gallery_api.service;

import com.sfeir.photo_gallery_api.exception.InvalidTagException;
import com.sfeir.photo_gallery_api.exception.ResourceNotFoundException;
import com.sfeir.photo_gallery_api.model.Tag;
import com.sfeir.photo_gallery_api.repository.TagRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

/**
 * Service for managing tags.
 */
@Service
public class TagService {

    private static final Pattern TAG_PATTERN = Pattern.compile("^[a-z0-9_-]+$");
    private static final int MAX_TAG_LENGTH = 50;
    private static final int MAX_TAGS_PER_PHOTO = 20;

    private final TagRepository tagRepository;

    public TagService(TagRepository tagRepository) {
        this.tagRepository = tagRepository;
    }

    /**
     * Validates a tag name.
     */
    public void validateTag(String tag) {
        if (tag == null || tag.trim().isEmpty()) {
            throw InvalidTagException.forEmpty();
        }
        
        String normalizedTag = tag.toLowerCase().trim();
        
        if (normalizedTag.length() > MAX_TAG_LENGTH) {
            throw InvalidTagException.forLength(Set.of(tag));
        }
        
        if (!TAG_PATTERN.matcher(normalizedTag).matches()) {
            throw InvalidTagException.forInvalidCharacters(Set.of(tag));
        }
    }

    /**
     * Validates a collection of tags.
     */
    public void validateTags(Collection<String> tags) {
        if (tags == null) {
            return;
        }
        
        if (tags.size() > MAX_TAGS_PER_PHOTO) {
            throw InvalidTagException.forCount();
        }
        
        for (String tag : tags) {
            validateTag(tag);
        }
    }

    /**
     * Normalizes a tag name (lowercase, trim).
     */
    public String normalizeTag(String tag) {
        if (tag == null) {
            return null;
        }
        return tag.toLowerCase().trim();
    }

    /**
     * Normalizes a collection of tag names.
     */
    public Set<String> normalizeTags(Collection<String> tags) {
        if (tags == null) {
            return Set.of();
        }
        return tags.stream()
                .map(this::normalizeTag)
                .collect(Collectors.toSet());
    }

    /**
     * Gets or creates a tag by name.
     */
    @Transactional
    public Tag getOrCreateTag(String tagName) {
        String normalizedName = normalizeTag(tagName);
        validateTag(tagName);
        
        return tagRepository.findByNameIgnoreCase(normalizedName)
                .orElseGet(() -> {
                    Tag tag = new Tag(normalizedName);
                    return tagRepository.save(tag);
                });
    }

    /**
     * Gets or creates multiple tags by name.
     */
    @Transactional
    public Set<Tag> getOrCreateTags(Collection<String> tagNames) {
        if (tagNames == null || tagNames.isEmpty()) {
            return Set.of();
        }
        
        validateTags(tagNames);
        Set<String> normalizedNames = normalizeTags(tagNames);
        
        // Find existing tags
        List<Tag> existingTags = tagRepository.findByNameInIgnoreCase(
                new ArrayList<>(normalizedNames)
        );
        
        Set<String> existingNames = existingTags.stream()
                .map(Tag::getName)
                .collect(Collectors.toSet());
        
        // Find tags that need to be created
        Set<String> tagsToCreate = normalizedNames.stream()
                .filter(name -> !existingNames.contains(name))
                .collect(Collectors.toSet());
        
        // Create new tags
        List<Tag> newTags = tagsToCreate.stream()
                .map(Tag::new)
                .toList();
        
        if (!newTags.isEmpty()) {
            tagRepository.saveAll(newTags);
        }
        
        // Combine existing and new tags
        Set<Tag> allTags = new HashSet<>(existingTags);
        allTags.addAll(newTags);
        
        return allTags;
    }

    /**
     * Gets all tags.
     */
    @Transactional(readOnly = true)
    public List<Tag> getAllTags() {
        return tagRepository.findAll();
    }

    /**
     * Gets a tag by name.
     */
    @Transactional(readOnly = true)
    public Optional<Tag> getTagByName(String name) {
        return tagRepository.findByNameIgnoreCase(normalizeTag(name));
    }

    /**
     * Gets a tag by ID.
     */
    @Transactional(readOnly = true)
    public Tag getTagById(Long id) {
        return tagRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Tag", String.valueOf(id)));
    }

    /**
     * Gets tag statistics (count of photos per tag).
     */
    @Transactional(readOnly = true)
    public Map<String, Long> getTagStatistics() {
        List<Tag> tags = tagRepository.findAll();
        return tags.stream()
                .collect(Collectors.toMap(
                        Tag::getName,
                        tag -> (long) tag.getPhotos().size()
                ));
    }

    /**
     * Deletes a tag by name.
     */
    @Transactional
    public void deleteTag(String name) {
        tagRepository.deleteByNameIgnoreCase(normalizeTag(name));
    }

    /**
     * Deletes a tag by ID.
     */
    @Transactional
    public void deleteTag(Long id) {
        tagRepository.deleteById(id);
    }
}
