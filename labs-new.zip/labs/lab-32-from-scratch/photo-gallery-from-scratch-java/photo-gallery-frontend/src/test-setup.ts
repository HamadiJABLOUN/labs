// Test setup file for Vitest with Angular
import 'zone.js/dist/zone';
import 'zone.js/dist/zone-testing';
import { getTestBed } from '@angular/core/testing';
import { BrowserDynamicTestingModule, platformBrowserDynamicTesting } from '@angular/platform-browser-dynamic/testing';

// Initialize Angular testing platform
BrowserDynamicTestingModule;
getTestBed().initTestEnvironment(
  BrowserDynamicTestingModule,
  platformBrowserDynamicTesting()
);

// Mock localStorage
class MockLocalStorage implements Storage {
  private store: Record<string, string> = {};

  clear(): void {
    this.store = {};
  }

  getItem(key: string): string | null {
    return this.store[key] || null;
  }

  key(index: number): string | null {
    const keys = Object.keys(this.store);
    return index < keys.length ? keys[index] : null;
  }

  get length(): number {
    return Object.keys(this.store).length;
  }

  removeItem(key: string): void {
    delete this.store[key];
  }

  setItem(key: string, value: string): void {
    this.store[key] = value;
  }
}

// Replace global localStorage with mock
const mockLocalStorage = new MockLocalStorage();
Object.defineProperty(window, 'localStorage', { value: mockLocalStorage });

// Mock URL.createObjectURL and URL.revokeObjectURL
if (!URL.createObjectURL) {
  URL.createObjectURL = () => 'blob:mock-url';
}

if (!URL.revokeObjectURL) {
  URL.revokeObjectURL = () => {};
}

// Mock FileReader
class MockFileReader {
  onload: ((this: FileReader, ev: ProgressEvent<FileReader>) => any) | null = null;
  onerror: ((this: FileReader, ev: ProgressEvent<FileReader>) => any) | null = null;

  readAsDataURL(file: Blob): void {
    // Simulate async read
    setTimeout(() => {
      if (this.onload) {
        this.onload({ target: this, loaded: 100, total: 100 } as any);
      }
    }, 10);
  }
}

Object.defineProperty(window, 'FileReader', { value: MockFileReader });

// Mock Image for testing image utilities
class MockImage {
  width = 0;
  height = 0;
  onload: (() => any) | null = null;
  onerror: (() => any) | null = null;
  src = '';

  constructor() {
    setTimeout(() => {
      this.width = 100;
      this.height = 100;
      if (this.onload) this.onload({} as any);
    }, 10);
  }
}

Object.defineProperty(window, 'Image', { value: MockImage });