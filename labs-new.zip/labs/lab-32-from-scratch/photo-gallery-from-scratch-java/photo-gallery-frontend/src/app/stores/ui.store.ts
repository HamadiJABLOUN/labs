// UI store for managing UI state like modals, notifications, etc.
import { Injectable, signal, computed } from '@angular/core';
import { ANIMATION_DURATIONS } from '../core/constants/app.constants';

export interface AppError {
  id: string;
  message: string;
  type: 'network' | 'validation' | 'storage' | 'unknown';
  timestamp: Date;
  severity: 'info' | 'warning' | 'error';
}

export interface Notification {
  id: string;
  message: string;
  type: 'success' | 'error' | 'warning' | 'info';
  timestamp: Date;
  duration?: number; // Auto-dismiss duration in ms
}

@Injectable({
  providedIn: 'root'
})
export class UiStore {
  // ========== Private State Signals ==========
  
  // Modal visibility
  private _isUploadModalOpen = signal<boolean>(false);
  private _isDetailModalOpen = signal<boolean>(false);
  private _isDeleteModalOpen = signal<boolean>(false);
  private _isTagFilterOpen = signal<boolean>(false);
  
  // Notifications
  private _notifications = signal<Notification[]>([]);
  private _errors = signal<AppError[]>([]);
  
  // Loading indicators
  private _isLoading = signal<boolean>(false);
  private _loadingMessages = signal<string[]>([]);
  
  // Theme and layout
  private _theme = signal<'light' | 'dark'>('light');
  private _sidebarOpen = signal<boolean>(true);
  
  // ========== Public Readonly Signals ==========
  
  // Modal states
  readonly isUploadModalOpen = this._isUploadModalOpen.asReadonly();
  readonly isDetailModalOpen = this._isDetailModalOpen.asReadonly();
  readonly isDeleteModalOpen = this._isDeleteModalOpen.asReadonly();
  readonly isTagFilterOpen = this._isTagFilterOpen.asReadonly();
  
  // Notifications and errors
  readonly notifications = this._notifications.asReadonly();
  readonly errors = this._errors.asReadonly();
  
  // Loading states
  readonly isLoading = this._isLoading.asReadonly();
  readonly loadingMessages = this._loadingMessages.asReadonly();
  
  // Theme and layout
  readonly theme = this._theme.asReadonly();
  readonly sidebarOpen = this._sidebarOpen.asReadonly();
  
  // ========== Computed Signals ==========
  
  // Active notifications count
  readonly notificationCount = computed(() => this._notifications().length);
  
  // Active errors count
  readonly errorCount = computed(() => this._errors().length);
  
  // Check if any modals are open
  readonly hasOpenModal = computed(() => 
    this._isUploadModalOpen() || 
    this._isDetailModalOpen() || 
    this._isDeleteModalOpen() ||
    this._isTagFilterOpen()
  );
  
  // Current loading message (first one)
  readonly currentLoadingMessage = computed(() => 
    this._loadingMessages().length > 0 ? this._loadingMessages()[0] : ''
  );
  
  // Check if dark mode is active
  readonly isDarkMode = computed(() => this._theme() === 'dark');
  
  // ========== Modal Methods ==========
  
  // Open upload modal
  openUploadModal(): void {
    this._isUploadModalOpen.set(true);
  }
  
  // Close upload modal
  closeUploadModal(): void {
    this._isUploadModalOpen.set(false);
  }
  
  // Toggle upload modal
  toggleUploadModal(): void {
    this._isUploadModalOpen.update(open => !open);
  }
  
  // Open detail modal
  openDetailModal(): void {
    this._isDetailModalOpen.set(true);
  }
  
  // Close detail modal
  closeDetailModal(): void {
    this._isDetailModalOpen.set(false);
  }
  
  // Open delete modal
  openDeleteModal(): void {
    this._isDeleteModalOpen.set(true);
  }
  
  // Close delete modal
  closeDeleteModal(): void {
    this._isDeleteModalOpen.set(false);
  }
  
  // Open tag filter
  openTagFilter(): void {
    this._isTagFilterOpen.set(true);
  }
  
  // Close tag filter
  closeTagFilter(): void {
    this._isTagFilterOpen.set(false);
  }
  
  // Close all modals
  closeAllModals(): void {
    this._isUploadModalOpen.set(false);
    this._isDetailModalOpen.set(false);
    this._isDeleteModalOpen.set(false);
    this._isTagFilterOpen.set(false);
  }
  
  // ========== Notification Methods ==========
  
  // Add a notification
  addNotification(message: string, type: Notification['type'] = 'info', duration?: number): Notification {
    const notification: Notification = {
      id: `notification-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`,
      message,
      type,
      timestamp: new Date(),
      duration
    };
    
    this._notifications.update(notifications => [...notifications, notification]);
    
    // Auto-dismiss if duration is provided
    if (duration) {
      setTimeout(() => {
        this.removeNotification(notification.id);
      }, duration);
    }
    
    return notification;
  }
  
  // Add success notification
  addSuccessNotification(message: string, duration: number = 3000): Notification {
    return this.addNotification(message, 'success', duration);
  }
  
  // Add error notification
  addErrorNotification(message: string, duration: number = 5000): Notification {
    return this.addNotification(message, 'error', duration);
  }
  
  // Add warning notification
  addWarningNotification(message: string, duration: number = 4000): Notification {
    return this.addNotification(message, 'warning', duration);
  }
  
  // Remove a notification by ID
  removeNotification(id: string): boolean {
    const initialLength = this._notifications().length;
    this._notifications.update(notifications => 
      notifications.filter(n => n.id !== id)
    );
    return this._notifications().length < initialLength;
  }
  
  // Clear all notifications
  clearNotifications(): void {
    this._notifications.set([]);
  }
  
  // Add an error
  addError(error: AppError): AppError {
    this._errors.update(errors => [...errors, error]);
    return error;
  }
  
  // Add a simple error (creates AppError from message)
  addSimpleError(message: string, type: AppError['type'] = 'unknown'): AppError {
    const error: AppError = {
      id: `error-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`,
      message,
      type,
      timestamp: new Date(),
      severity: 'error'
    };
    return this.addError(error);
  }
  
  // Remove an error by ID
  removeError(id: string): boolean {
    const initialLength = this._errors().length;
    this._errors.update(errors => errors.filter(e => e.id !== id));
    return this._errors().length < initialLength;
  }
  
  // Clear all errors
  clearErrors(): void {
    this._errors.set([]);
  }
  
  // ========== Loading Methods ==========
  
  // Set loading state
  setLoading(loading: boolean, message?: string): void {
    this._isLoading.set(loading);
    
    if (message) {
      this._loadingMessages.update(messages => [...messages, message]);
    } else {
      this._loadingMessages.set([]);
    }
  }
  
  // Add a loading message
  addLoadingMessage(message: string): void {
    this._loadingMessages.update(messages => [...messages, message]);
  }
  
  // Remove a loading message
  removeLoadingMessage(message: string): void {
    this._loadingMessages.update(messages => 
      messages.filter(m => m !== message)
    );
  }
  
  // Clear loading messages
  clearLoadingMessages(): void {
    this._loadingMessages.set([]);
  }
  
  // ========== Theme Methods ==========
  
  // Set theme
  setTheme(theme: 'light' | 'dark'): void {
    this._theme.set(theme);
    // Could also save to LocalStorage here
    localStorage.setItem('photo-gallery-theme', theme);
  }
  
  // Toggle theme
  toggleTheme(): void {
    this._theme.update(theme => theme === 'light' ? 'dark' : 'light');
    localStorage.setItem('photo-gallery-theme', this._theme());
  }
  
  // Initialize theme from LocalStorage
  initializeTheme(): void {
    const savedTheme = localStorage.getItem('photo-gallery-theme');
    if (savedTheme === 'light' || savedTheme === 'dark') {
      this._theme.set(savedTheme);
    }
  }
  
  // ========== Layout Methods ==========
  
  // Toggle sidebar
  toggleSidebar(): void {
    this._sidebarOpen.update(open => !open);
  }
  
  // Set sidebar state
  setSidebarOpen(open: boolean): void {
    this._sidebarOpen.set(open);
  }
  
  // Close sidebar
  closeSidebar(): void {
    this._sidebarOpen.set(false);
  }
  
  // Open sidebar
  openSidebar(): void {
    this._sidebarOpen.set(true);
  }
}