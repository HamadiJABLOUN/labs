// Photo store using Angular signals for state management
import { Injectable, inject, signal, computed } from '@angular/core';
import { Photo, PhotoFilter, TagStats, DEFAULT_PAGE_SIZE } from '../models';
import { PhotoService } from '../services/photo.service';
import { StorageService } from '../services/storage.service';

@Injectable({
  providedIn: 'root'
})
export class PhotoStore {
  private readonly photoService = inject(PhotoService);
  private readonly storageService = inject(StorageService);
  
  // ========== Private State Signals ==========
  
  // Core photo data
  private _photos = signal<Photo[]>([]);
  
  // Loading and error states
  private _loading = signal<boolean>(false);
  private _error = signal<string | null>(null);
  
  // Filter and pagination state
  private _filter = signal<PhotoFilter>({
    tags: [],
    sortBy: 'uploadedAt',
    sortDirection: 'desc',
    page: 0,
    pageSize: DEFAULT_PAGE_SIZE
  });
  
  // Selected photo for detail view
  private _selectedPhoto = signal<Photo | null>(null);
  
  // Photo to delete (for confirmation)
  private _photoToDelete = signal<Photo | null>(null);
  
  // Upload state
  private _uploading = signal<boolean>(false);
  private _uploadError = signal<string | null>(null);
  
  // ========== Public Readonly Signals ==========
  
  // Core data
  readonly photos = this._photos.asReadonly();
  readonly loading = this._loading.asReadonly();
  readonly error = this._error.asReadonly();
  
  // Filter and pagination
  readonly filter = this._filter.asReadonly();
  readonly selectedPhoto = this._selectedPhoto.asReadonly();
  readonly photoToDelete = this._photoToDelete.asReadonly();
  
  // Upload state
  readonly uploading = this._uploading.asReadonly();
  readonly uploadError = this._uploadError.asReadonly();
  
  // ========== Computed Signals ==========
  
  // Filtered and sorted photos
  readonly filteredPhotos = computed(() => {
    const photos = this._photos();
    const filter = this._filter();
    
    let filtered = [...photos];
    
    // Apply tag filtering (AND logic)
    if (filter.tags.length > 0) {
      filtered = filtered.filter(photo => 
        filter.tags.every(tag => 
          photo.tags.some(photoTag => photoTag.toLowerCase() === tag.toLowerCase())
        )
      );
    }
    
    // Apply sorting
    filtered = this.sortPhotos(filtered, filter.sortBy, filter.sortDirection);
    
    // Apply pagination
    const startIndex = filter.page * filter.pageSize;
    const endIndex = startIndex + filter.pageSize;
    
    return filtered.slice(startIndex, endIndex);
  });
  
  // Total number of photos (after filtering)
  readonly totalPhotos = computed(() => {
    const photos = this._photos();
    const filter = this._filter();
    
    if (filter.tags.length === 0) {
      return photos.length;
    }
    
    // Count photos that match all tags
    return photos.filter(photo => 
      filter.tags.every(tag => 
        photo.tags.some(photoTag => photoTag.toLowerCase() === tag.toLowerCase())
      )
    ).length;
  });
  
  // Number of photos in the store
  readonly photoCount = computed(() => this._photos().length);
  
  // Total pages
  readonly totalPages = computed(() => {
    const total = this.totalPhotos();
    const pageSize = this._filter().pageSize;
    return Math.ceil(total / pageSize);
  });
  
  // Current page info
  readonly currentPage = computed(() => this._filter().page);
  readonly pageSize = computed(() => this._filter().pageSize);
  
  // Check if there are photos
  readonly hasPhotos = computed(() => this._photos().length > 0);
  
  // Check if we're on the first page
  readonly isFirstPage = computed(() => this._filter().page === 0);
  
  // Check if we're on the last page
  readonly isLastPage = computed(() => {
    const filter = this._filter();
    return filter.page >= this.totalPages() - 1;
  });
  
  // Tag statistics
  readonly tagStats = computed(() => {
    const photos = this._photos();
    const counts = new Map<string, number>();
    
    photos.forEach(photo => {
      photo.tags.forEach(tag => {
        const normalizedTag = tag.toLowerCase();
        counts.set(normalizedTag, (counts.get(normalizedTag) || 0) + 1);
      });
    });
    
    const stats: TagStats[] = Array.from(counts.entries()).map(([name, count]) => ({
      name,
      count
    }));
    
    // Sort by count (descending), then by name (ascending)
    return stats.sort((a, b) => b.count - a.count || a.name.localeCompare(b.name));
  });
  
  // Active tag filters (from current filter)
  readonly activeTags = computed(() => this._filter().tags);
  
  // Check if any filters are active
  readonly hasActiveFilters = computed(() => this._filter().tags.length > 0);
  
  // ========== Public Methods ==========
  
  // Initialize store (load from service)
  async initialize(): Promise<void> {
    try {
      this._loading.set(true);
      this._error.set(null);
      
      // Load photos from service (which handles API + LocalStorage fallback)
      const photos = await this.photoService.loadPhotos();
      this._photos.set(photos);
      
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Failed to initialize photo store';
      this._error.set(errorMessage);
    } finally {
      this._loading.set(false);
    }
  }
  
  // Load photos (force = reload from API)
  async loadPhotos(force = false): Promise<void> {
    if (force) {
      await this.refreshPhotos();
    } else {
      await this.initialize();
    }
  }
  
  // Refresh photos (force load from API)
  async refreshPhotos(): Promise<void> {
    try {
      this._loading.set(true);
      this._error.set(null);
      
      const photos = await this.photoService.loadPhotos(true);
      this._photos.set(photos);
      this.resetPagination();
      
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Failed to refresh photos';
      this._error.set(errorMessage);
    } finally {
      this._loading.set(false);
    }
  }
  
  // Upload a photo
  async uploadPhoto(file: File, tags: string[] = []): Promise<Photo | undefined> {
    this._uploading.set(true);
    this._uploadError.set(null);
    
    try {
      const photo = await this.photoService.uploadPhoto(file, tags);
      
      // Update our photos (the service should have already updated its state)
      const currentPhotos = this._photos();
      if (!currentPhotos.some(p => p.id === photo.id)) {
        this._photos.update(photos => [photo, ...photos]);
      }
      
      // Reset to first page to show the new photo
      this.resetPagination();
      
      return photo;
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Upload failed';
      this._uploadError.set(errorMessage);
      throw error;
    } finally {
      this._uploading.set(false);
    }
  }
  
  // Delete a photo
  async deletePhoto(photoId: string): Promise<void> {
    try {
      await this.photoService.deletePhoto(photoId);
      
      // Remove from our state
      this._photos.update(photos => photos.filter(p => p.id !== photoId));
      
      // Reset pagination if needed
      this.adjustPaginationAfterDeletion();
      
      // Clear any references to the deleted photo
      if (this._selectedPhoto()?.id === photoId) {
        this._selectedPhoto.set(null);
      }
      if (this._photoToDelete()?.id === photoId) {
        this._photoToDelete.set(null);
      }
      
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Delete failed';
      this._error.set(errorMessage);
      throw error;
    }
  }
  
  // Add tags to a photo
  async addTagsToPhoto(photoId: string, tags: string[]): Promise<void> {
    try {
      const updatedPhoto = await this.photoService.addTagsToPhoto(photoId, tags);
      if (updatedPhoto) {
        this.updatePhotoInStore(updatedPhoto);
      }
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Failed to add tags';
      this._error.set(errorMessage);
      throw error;
    }
  }
  
  // Remove a tag from a photo
  async removeTagFromPhoto(photoId: string, tag: string): Promise<void> {
    try {
      const updatedPhoto = await this.photoService.removeTagFromPhoto(photoId, tag);
      if (updatedPhoto) {
        this.updatePhotoInStore(updatedPhoto);
      }
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Failed to remove tag';
      this._error.set(errorMessage);
      throw error;
    }
  }
  
  // Replace all tags on a photo
  async replaceTagsOnPhoto(photoId: string, tags: string[]): Promise<void> {
    try {
      const updatedPhoto = await this.photoService.replaceTagsOnPhoto(photoId, tags);
      if (updatedPhoto) {
        this.updatePhotoInStore(updatedPhoto);
      }
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Failed to replace tags';
      this._error.set(errorMessage);
      throw error;
    }
  }
  
  // Set selected photo for detail view
  setSelectedPhoto(photo: Photo | null): void {
    this._selectedPhoto.set(photo);
  }
  
  // Set photo to delete (for confirmation)
  setPhotoToDelete(photo: Photo | null): void {
    this._photoToDelete.set(photo);
  }
  
  // ========== Filter and Pagination Methods ==========
  
  // Set filter
  setFilter(filter: Partial<PhotoFilter>): void {
    this._filter.update(currentFilter => ({
      ...currentFilter,
      ...filter
    }));
  }
  
  // Add a tag to filter
  addTagFilter(tag: string): void {
    const normalizedTag = tag.toLowerCase().trim();
    this._filter.update(currentFilter => {
      const existingTags = currentFilter.tags.filter(t => t !== normalizedTag);
      return {
        ...currentFilter,
        tags: [...existingTags, normalizedTag],
        page: 0 // Reset to first page when filter changes
      };
    });
  }
  
  // Remove a tag from filter
  removeTagFilter(tag: string): void {
    const normalizedTag = tag.toLowerCase().trim();
    this._filter.update(currentFilter => {
      const updatedTags = currentFilter.tags.filter(t => t !== normalizedTag);
      return {
        ...currentFilter,
        tags: updatedTags,
        page: 0 // Reset to first page when filter changes
      };
    });
  }
  
  // Clear all tag filters
  clearTagFilters(): void {
    this._filter.update(currentFilter => ({
      ...currentFilter,
      tags: []
    }));
  }
  
  // Set page
  setPage(page: number): void {
    this._filter.update(currentFilter => ({
      ...currentFilter,
      page: Math.max(0, page)
    }));
  }
  
  // Next page
  goToNextPage(): void {
    this.setPage(this._filter().page + 1);
  }
  
  // Previous page
  goToPreviousPage(): void {
    this.setPage(this._filter().page - 1);
  }
  
  // Reset pagination to first page
  resetPagination(): void {
    this._filter.update(currentFilter => ({
      ...currentFilter,
      page: 0
    }));
  }
  
  // Set page size
  setPageSize(size: number): void {
    this._filter.update(currentFilter => ({
      ...currentFilter,
      pageSize: size,
      page: 0 // Reset to first page when page size changes
    }));
  }
  
  // Sort photos
  setSortBy(sortBy: 'uploadedAt' | 'filename' | 'size'): void {
    this._filter.update(currentFilter => ({
      ...currentFilter,
      sortBy,
      sortDirection: currentFilter.sortDirection
    }));
  }
  
  // Toggle sort direction
  toggleSortDirection(): void {
    this._filter.update(currentFilter => ({
      ...currentFilter,
      sortDirection: currentFilter.sortDirection === 'asc' ? 'desc' : 'asc'
    }));
  }
  
  // ========== Helper Methods ==========
  
  private sortPhotos(photos: Photo[], sortBy: string, sortDirection: 'asc' | 'desc'): Photo[] {
    const sorted = [...photos];
    
    sorted.sort((a, b) => {
      let comparison = 0;
      
      switch (sortBy) {
        case 'uploadedAt':
          comparison = a.uploadedAt.getTime() - b.uploadedAt.getTime();
          break;
        case 'filename':
          comparison = a.filename.localeCompare(b.filename);
          break;
        case 'size':
          comparison = a.size - b.size;
          break;
        default:
          comparison = 0;
      }
      
      return sortDirection === 'asc' ? comparison : -comparison;
    });
    
    return sorted;
  }
  
  private updatePhotoInStore(updatedPhoto: Photo): void {
    this._photos.update(photos => 
      photos.map(p => p.id === updatedPhoto.id ? updatedPhoto : p)
    );
  }
  
  private adjustPaginationAfterDeletion(): void {
    const totalPages = this.totalPages();
    const currentPage = this._filter().page;
    
    // If we're on a page that no longer exists, go to the last page
    if (currentPage >= totalPages && totalPages > 0) {
      this.setPage(totalPages - 1);
    }
    
    // If there are no pages left, go to page 0
    if (totalPages === 0) {
      this.resetPagination();
    }
  }
  
  // Get a photo by ID from the store
  getPhotoById(photoId: string): Photo | undefined {
    return this._photos().find(p => p.id === photoId);
  }
}