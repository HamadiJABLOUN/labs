// Footer component
import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { APP_NAME, APP_VERSION } from '../../core/constants/app.constants';

@Component({
  selector: 'app-footer',
  standalone: true,
  imports: [CommonModule],
  template: `
    <footer class="footer">
      <div class="footer-content">
        <div class="footer-left">
          <span class="footer-text">{{ appName }} v{{ appVersion }}</span>
        </div>
        <div class="footer-right">
          <span class="footer-text">Built with Angular 21</span>
        </div>
      </div>
    </footer>
  `,
  styles: [`
    .footer {
      background-color: var(--footer-bg, #f8f9fa);
      border-top: 1px solid var(--border-color, #e9ecef);
      padding: 20px;
    }
    
    .footer-content {
      display: flex;
      justify-content: space-between;
      align-items: center;
      max-width: 1200px;
      margin: 0 auto;
      font-size: 14px;
    }
    
    .footer-text {
      color: var(--text-secondary, #666);
    }
    
    .footer-left {
      display: flex;
      align-items: center;
      gap: 8px;
    }
    
    .footer-right {
      display: flex;
      align-items: center;
      gap: 8px;
    }
    
    @media (max-width: 768px) {
      .footer-content {
        flex-direction: column;
        gap: 12px;
        text-align: center;
      }
    }
  `]
})
export class FooterComponent {
  readonly appName = APP_NAME;
  readonly appVersion = APP_VERSION;
}