// Main layout component
import { Component, inject, effect, Signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterOutlet } from '@angular/router';
import { HeaderComponent } from '../header/header.component';
import { FooterComponent } from '../footer/footer.component';
import { UiStore } from '../../stores/ui.store';

@Component({
  selector: 'app-main-layout',
  standalone: true,
  imports: [CommonModule, RouterOutlet, HeaderComponent, FooterComponent],
  template: `
    <div class="main-layout" [class.dark-mode]="isDarkMode()">
      <app-header></app-header>
      
      <main class="main-content">
        <router-outlet></router-outlet>
      </main>
      
      <app-footer></app-footer>
    </div>
  `,
  styles: [`
    .main-layout {
      display: flex;
      flex-direction: column;
      min-height: 100vh;
      background-color: var(--bg-color, #ffffff);
      color: var(--text-primary, #333);
    }
    
    .main-layout.dark-mode {
      --bg-color: #1a1a2e;
      --text-primary: #eaeaea;
      --text-secondary: #a0a0a0;
      --border-color: #2d2d44;
      --header-bg: #16213e;
      --header-shadow: 0 1px 3px rgba(0,0,0,0.3);
      --footer-bg: #16213e;
      --hover-bg: #2d2d44;
      background-color: var(--bg-color);
      color: var(--text-primary);
    }
    
    .main-content {
      flex: 1;
      max-width: 1200px;
      width: 100%;
      margin: 0 auto;
      padding: 20px;
      min-height: calc(100vh - 120px);
    }
    
    @media (max-width: 768px) {
      .main-content {
        padding: 16px;
      }
    }
  `]
})
export class MainLayoutComponent {
  private readonly uiStore = inject(UiStore);
  isDarkMode = this.uiStore.isDarkMode;
  
  constructor() {
    // Apply dark mode class to document when theme changes
    effect(() => {
      const isDark = this.isDarkMode();
      if (isDark) {
        document.documentElement.classList.add('dark-mode');
      } else {
        document.documentElement.classList.remove('dark-mode');
      }
    });
  }
}