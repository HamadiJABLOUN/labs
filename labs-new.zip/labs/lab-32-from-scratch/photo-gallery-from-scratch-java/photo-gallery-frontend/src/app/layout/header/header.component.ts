// Header component
import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterLink, RouterLinkActive } from '@angular/router';
import { UiStore } from '../../stores/ui.store';
import { PhotoStore } from '../../stores/photo.store';
import { APP_NAME } from '../../core/constants/app.constants';

@Component({
  selector: 'app-header',
  standalone: true,
  imports: [CommonModule, RouterLink, RouterLinkActive],
  template: `
    <header class="header">
      <div class="header-content">
        <div class="header-left">
          <a routerLink="/" class="app-logo">
            <span class="logo-text">{{ appName }}</span>
          </a>
        </div>
        
        <nav class="header-nav">
          <a 
            routerLink="/gallery" 
            routerLinkActive="active"
            class="nav-link"
          >
            Gallery
          </a>
          <a 
            routerLink="/gallery/upload" 
            routerLinkActive="active"
            class="nav-link"
          >
            Upload
          </a>
        </nav>
        
        <div class="header-right">
          <div class="photo-count">
            {{ photoCount() }} photos
          </div>
          <button 
            class="theme-toggle" 
            (click)="toggleTheme()"
            [attr.aria-label]="isDarkMode() ? 'Switch to light mode' : 'Switch to dark mode'"
          >
            @if (isDarkMode()) {
              <span>&#9728;</span> <!-- Moon icon -->
            } @else {
              <span>&#9728;</span> <!-- Sun icon -->
            }
          </button>
        </div>
      </div>
    </header>
  `,
  styles: [`
    .header {
      background-color: var(--header-bg, #ffffff);
      border-bottom: 1px solid var(--border-color, #e9ecef);
      position: sticky;
      top: 0;
      z-index: 100;
      box-shadow: var(--header-shadow, 0 1px 3px rgba(0,0,0,0.1));
    }
    
    .header-content {
      display: flex;
      align-items: center;
      justify-content: space-between;
      max-width: 1200px;
      margin: 0 auto;
      padding: 0 20px;
      height: 60px;
    }
    
    .header-left {
      display: flex;
      align-items: center;
    }
    
    .app-logo {
      text-decoration: none;
      color: var(--text-primary, #333);
    }
    
    .logo-text {
      font-size: 18px;
      font-weight: 600;
      color: #3498db;
    }
    
    .header-nav {
      display: flex;
      gap: 24px;
    }
    
    .nav-link {
      text-decoration: none;
      color: var(--text-secondary, #666);
      font-weight: 500;
      padding: 8px 0;
      position: relative;
      transition: color 0.2s ease;
    }
    
    .nav-link:hover {
      color: var(--text-primary, #333);
    }
    
    .nav-link.active {
      color: #3498db;
    }
    
    .nav-link.active::after {
      content: '';
      position: absolute;
      bottom: 0;
      left: 0;
      right: 0;
      height: 2px;
      background-color: #3498db;
    }
    
    .header-right {
      display: flex;
      align-items: center;
      gap: 16px;
    }
    
    .photo-count {
      color: var(--text-secondary, #666);
      font-size: 14px;
      font-weight: 500;
    }
    
    .theme-toggle {
      background: none;
      border: none;
      font-size: 18px;
      cursor: pointer;
      color: var(--text-secondary, #666);
      padding: 4px;
      border-radius: 4px;
      transition: background-color 0.2s ease, color 0.2s ease;
    }
    
    .theme-toggle:hover {
      background-color: var(--hover-bg, #f8f9fa);
      color: var(--text-primary, #333);
    }
    
    .theme-toggle:focus {
      outline: 2px solid #3498db;
      outline-offset: 2px;
    }
    
    @media (max-width: 768px) {
      .header-content {
        padding: 0 16px;
      }
      
      .header-nav {
        gap: 16px;
      }
      
      .nav-link {
        font-size: 14px;
      }
      
      .photo-count {
        font-size: 12px;
      }
    }
  `]
})
export class HeaderComponent {
  readonly appName = APP_NAME;
  readonly uiStore = inject(UiStore);
  readonly photoStore = inject(PhotoStore);
  readonly Router = Router;
  
  // Signals from stores
  isDarkMode = this.uiStore.isDarkMode;
  photoCount = this.photoStore.photoCount;
  
  constructor() {
    // Initialize theme
    this.uiStore.initializeTheme();
  }
  
  toggleTheme(): void {
    this.uiStore.toggleTheme();
  }
}