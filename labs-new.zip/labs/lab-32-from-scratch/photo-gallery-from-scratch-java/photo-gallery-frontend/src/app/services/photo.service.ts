// Main photo service that coordinates between API and LocalStorage
import { Injectable, inject, signal, computed } from '@angular/core';
import { Observable, of, throwError, from, switchMap, catchError, forkJoin } from 'rxjs';
import { PhotoApiService } from './api/photo-api.service';
import { StorageService } from './storage.service';
import { 
  Photo, 
  PhotoFilter,
  UploadProgress,
  createPhotoFromFile,
  validateFileType,
  validateFileSize,
  DEFAULT_PAGE_SIZE
} from '../models';
import { apiPhotoToPhoto, ApiPhoto, PhotoPageResponse } from '../models/api.models';
import { fileToDataUrl, getImageDimensionsFromFile } from '../shared/utils/image.utils';
import { generateClientPhotoId, normalizeTagList } from '../shared/utils/validation.utils';

@Injectable({
  providedIn: 'root'
})
export class PhotoService {
  private readonly apiService = inject(PhotoApiService);
  private readonly storageService = inject(StorageService);
  
  // State signals
  private _photos = signal<Photo[]>([]);
  private _loading = signal<boolean>(false);
  private _error = signal<string | null>(null);
  private _uploadProgress = signal<Record<string, UploadProgress>>({});
  
  // Public readonly signals
  readonly photos = this._photos.asReadonly();
  readonly loading = this._loading.asReadonly();
  readonly error = this._error.asReadonly();
  readonly uploadProgress = this._uploadProgress.asReadonly();
  
  // Computed signals
  readonly photoCount = computed(() => this._photos().length);
  readonly hasPhotos = computed(() => this._photos().length > 0);
  readonly isLoading = computed(() => this._loading());
  
  constructor() {
    // Load initial data from storage
    this.loadFromStorage();
  }
  
  // ========== Public Methods ==========
  
  // Load all photos from API (with fallback to LocalStorage)
  async loadPhotos(forceRefresh: boolean = false): Promise<Photo[]> {
    this._loading.set(true);
    this._error.set(null);
    
    try {
      if (forceRefresh) {
        // Always try API first
        const apiPhotos = await this.fetchPhotosFromApi();
        this._photos.set(apiPhotos);
        this.storageService.savePhotos(apiPhotos);
      } else {
        // Try API first, fall back to LocalStorage
        try {
          const apiPhotos = await this.fetchPhotosFromApi();
          this._photos.set(apiPhotos);
          this.storageService.savePhotos(apiPhotos);
        } catch (apiError) {
          // Fall back to LocalStorage
          const storedPhotos = this.storageService.loadPhotos();
          this._photos.set(storedPhotos);
        }
      }
    } catch (error) {
      this._error.set('Failed to load photos');
      console.error('Error loading photos:', error);
    } finally {
      this._loading.set(false);
    }
    
    return this._photos();
  }
  
  // Load photos with pagination and filtering
  async loadPhotosPaginated(filter: PhotoFilter): Promise<void> {
    this._loading.set(true);
    this._error.set(null);
    
    try {
      const apiPhotos = await this.fetchPhotosPaginatedFromApi(filter);
      this._photos.set(apiPhotos);
      this.storageService.savePhotos(apiPhotos);
    } catch (error) {
      this._error.set('Failed to load photos with filters');
      console.error('Error loading paginated photos:', error);
    } finally {
      this._loading.set(false);
    }
  }
  
  // Upload a new photo
  async uploadPhoto(file: File, tags: string[] = []): Promise<Photo> {
    this._error.set(null);
    
    // Validate the file
    const validation = this.validatePhotoFile(file, tags);
    if (!validation.valid) {
      throw new Error(validation.errors.join(', '));
    }
    
    // Create a client-side photo immediately for optimistic UI
    const clientPhotoId = generateClientPhotoId();
    const clientPhoto = {
      ...createPhotoFromFile(file, tags),
      id: clientPhotoId,
      dataUrl: await fileToDataUrl(file),
      isSynced: false,
      ...await this.getImageDimensions(file)
    } as Photo;
    
    // Add to local state optimistically
    this._photos.update(photos => [clientPhoto, ...photos]);
    
    // Update upload progress
    this._uploadProgress.update(progress => ({
      ...progress,
      [clientPhotoId]: {
        photoId: clientPhotoId,
        progress: 0,
        status: 'uploading',
        error: undefined
      }
    }));
    
    try {
      // Try to upload to API
      const apiPhoto = await this.apiService.uploadPhotoWithConversion(file, tags);
      
      // Replace client photo with synced photo
      const syncedPhoto: Photo = {
        ...clientPhoto,
        id: apiPhoto.id,
        filename: apiPhoto.filename,
        uploadedAt: apiPhoto.uploadedAt,
        isSynced: true,
        syncError: undefined
      };
      
      this._photos.update(photos => 
        photos.map(p => p.id === clientPhotoId ? syncedPhoto : p)
      );
      
      // Update progress
      this._uploadProgress.update(progress => ({
        ...progress,
        [clientPhotoId]: {
          photoId: clientPhotoId,
          progress: 100,
          status: 'complete'
        }
      }));
      
      // Save to LocalStorage
      this.storageService.savePhotos(this._photos());
      
      return syncedPhoto;
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Upload failed';
      
      // Update client photo with error
      this._photos.update(photos => 
        photos.map(p => p.id === clientPhotoId ? {
          ...p,
          syncError: errorMessage,
          isSynced: false
        } : p)
      );
      
      // Update progress
      this._uploadProgress.update(progress => ({
        ...progress,
        [clientPhotoId]: {
          photoId: clientPhotoId,
          progress: 0,
          status: 'error',
          error: errorMessage
        }
      }));
      
      this._error.set(errorMessage);
      throw error;
    }
  }
  
  // Delete a photo by ID
  async deletePhoto(photoId: string): Promise<void> {
    this._error.set(null);
    this._loading.set(true);
    
    try {
      // Find the photo to delete
      const photoToDelete = this._photos().find(p => p.id === photoId);
      
      if (!photoToDelete) {
        throw new Error(`Photo with ID ${photoId} not found`);
      }
      
      // Optimistic removal from UI
      this._photos.update(photos => photos.filter(p => p.id !== photoId));
      this.storageService.removePhoto(photoId);
      
      // Try to delete from API
      try {
        await this.apiService.deletePhoto(photoId).toPromise();
      } catch (apiError) {
        // If API delete fails, but the photo wasn't synced anyway, that's fine
        if (!photoToDelete.isSynced) {
          console.log(`Photo ${photoId} wasn't synced, so API delete failure is acceptable`);
        } else {
          // For synced photos, re-add to UI with error state
          this._photos.update(photos => [photoToDelete, ...photos]);
          throw apiError;
        }
      }
      
      // Update storage
      this.storageService.savePhotos(this._photos());
      
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Delete failed';
      this._error.set(errorMessage);
      throw error;
    } finally {
      this._loading.set(false);
    }
  }
  
  // Get photo by ID
  getPhotoById(photoId: string): Photo | undefined {
    return this._photos().find(p => p.id === photoId);
  }
  
  // Add tags to a photo
  async addTagsToPhoto(photoId: string, tags: string[]): Promise<Photo | undefined> {
    const photo = this.getPhotoById(photoId);
    if (!photo) return undefined;
    
    const normalizedTags = normalizeTagList(tags);
    const existingTags = new Set(photo.tags);
    const newTags = [...existingTags, ...normalizedTags];
    
    // Optimistic update
    const updatedPhoto: Photo = {
      ...photo,
      tags: Array.from(new Set(newTags)) // Ensure uniqueness
    };
    
    this.updatePhotoLocally(updatedPhoto);
    
    try {
      // Try to update on API if photo is synced
      if (photo.isSynced) {
        await this.apiService.addTags(photoId, normalizedTags).toPromise();
      }
      
      return updatedPhoto;
    } catch (error) {
      // Revert on error
      this.updatePhotoLocally(photo);
      throw error;
    }
  }
  
  // Remove tag from a photo
  async removeTagFromPhoto(photoId: string, tag: string): Promise<Photo | undefined> {
    const photo = this.getPhotoById(photoId);
    if (!photo) return undefined;
    
    const normalizedTag = tag.toLowerCase().trim();
    const updatedTags = photo.tags.filter(t => t !== normalizedTag);
    
    const updatedPhoto: Photo = {
      ...photo,
      tags: updatedTags
    };
    
    this.updatePhotoLocally(updatedPhoto);
    
    try {
      // Try to update on API if photo is synced
      if (photo.isSynced) {
        await this.apiService.removeTag(photoId, normalizedTag).toPromise();
      }
      
      return updatedPhoto;
    } catch (error) {
      // Revert on error
      this.updatePhotoLocally(photo);
      throw error;
    }
  }
  
  // Replace all tags on a photo
  async replaceTagsOnPhoto(photoId: string, tags: string[]): Promise<Photo | undefined> {
    const photo = this.getPhotoById(photoId);
    if (!photo) return undefined;
    
    const normalizedTags = normalizeTagList(tags);
    const updatedPhoto: Photo = {
      ...photo,
      tags: normalizedTags
    };
    
    this.updatePhotoLocally(updatedPhoto);
    
    try {
      // Try to update on API if photo is synced
      if (photo.isSynced) {
        await this.apiService.replaceTags(photoId, normalizedTags).toPromise();
      }
      
      return updatedPhoto;
    } catch (error) {
      // Revert on error
      this.updatePhotoLocally(photo);
      throw error;
    }
  }
  
  // Sync unsynced photos with backend
  async syncUnsyncedPhotos(): Promise<void> {
    const unsyncedPhotos = this._photos().filter(p => !p.isSynced);
    
    for (const photo of unsyncedPhotos) {
      try {
        // For now, unsynced photos from client uploads won't have files
        // This is a limitation - we'd need to store the original File object
        // For this implementation, we'll just mark them as synced if they have an API ID
        if (photo.id && !photo.id.startsWith('client-')) {
          // This is already a server photo
          this._photos.update(photos => 
            photos.map(p => p.id === photo.id ? { ...p, isSynced: true } : p)
          );
        }
      } catch (error) {
        console.error(`Failed to sync photo ${photo.id}:`, error);
        // Mark with sync error
        this._photos.update(photos => 
          photos.map(p => p.id === photo.id ? { 
            ...p, 
            syncError: 'Failed to sync with server' 
          } : p)
        );
      }
    }
  }
  
  // ========== Private Methods ==========
  
  private loadFromStorage(): void {
    const storedPhotos = this.storageService.loadPhotos();
    if (storedPhotos.length > 0) {
      this._photos.set(storedPhotos);
    }
  }
  
  private async fetchPhotosFromApi(): Promise<Photo[]> {
    return new Promise((resolve, reject) => {
      this.apiService.getPhotos().subscribe({
        next: (response: PhotoPageResponse) => {
          const photos = response.content.map(apiPhoto => {
            // For server photos, we need to create data URLs
            // Since we can't get the actual image data from the API easily,
            // we'll create placeholder photos that will load from server
            return apiPhotoToPhoto(apiPhoto);
          });
          resolve(photos);
        },
        error: (error) => {
          reject(error);
        }
      });
    });
  }
  
  private async fetchPhotosPaginatedFromApi(filter: PhotoFilter): Promise<Photo[]> {
    return new Promise((resolve, reject) => {
      this.apiService.getPhotos(
        filter.page,
        filter.pageSize,
        filter.tags,
        `${filter.sortBy},${filter.sortDirection}`
      ).subscribe({
        next: (response: PhotoPageResponse) => {
          const photos = response.content.map(apiPhoto => apiPhotoToPhoto(apiPhoto));
          resolve(photos);
        },
        error: (error) => {
          reject(error);
        }
      });
    });
  }
  
  private async getImageDimensions(file: File): Promise<{ width: number; height: number }> {
    try {
      return await getImageDimensionsFromFile(file);
    } catch (error) {
      console.warn('Could not get image dimensions:', error);
      return { width: 0, height: 0 };
    }
  }
  
  private updatePhotoLocally(updatedPhoto: Photo): void {
    this._photos.update(photos => 
      photos.map(p => p.id === updatedPhoto.id ? updatedPhoto : p)
    );
    this.storageService.savePhotos(this._photos());
  }
  
  private validatePhotoFile(file: File, tags: string[]): { valid: boolean; errors: string[] } {
    const errors: string[] = [];
    
    if (!file) {
      errors.push('No file provided');
      return { valid: false, errors };
    }
    
    if (!validateFileType(file)) {
      errors.push(`File type "${file.type}" is not supported`);
    }
    
    if (!validateFileSize(file)) {
      errors.push(`File is too large (max ${DEFAULT_PAGE_SIZE / (1024 * 1024)}MB)`);
    }
    
    // Import validation for tags
    if (tags.length > 0) {
      const tagValidation = this.validateTags(tags);
      if (!tagValidation.valid) {
        errors.push(...tagValidation.errors);
      }
    }
    
    return {
      valid: errors.length === 0,
      errors
    };
  }
  
  private validateTags(tags: string[]): { valid: boolean; errors: string[] } {
    const errors: string[] = [];
    const seenTags = new Set<string>();
    
    for (const tag of tags) {
      const normalizedTag = tag.toLowerCase().trim();
      
      if (normalizedTag.length === 0) {
        errors.push('Tag cannot be empty');
        continue;
      }
      
      if (normalizedTag.length > 50) {
        errors.push(`Tag "${tag}" is too long (max 50 characters)`);
      }
      
      if (!/^[a-z0-9_-]+$/.test(normalizedTag)) {
        errors.push(`Tag "${tag}" contains invalid characters (only a-z, 0-9, _, - allowed)`);
      }
      
      if (seenTags.has(normalizedTag)) {
        errors.push(`Duplicate tag: "${tag}"`);
      }
      seenTags.add(normalizedTag);
    }
    
    if (tags.length > 20) {
      errors.push('Maximum of 20 tags allowed');
    }
    
    return {
      valid: errors.length === 0,
      errors
    };
  }
}