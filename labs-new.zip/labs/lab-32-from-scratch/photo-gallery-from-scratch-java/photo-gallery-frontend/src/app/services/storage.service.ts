// Storage service for LocalStorage operations
import { Injectable } from '@angular/core';
import { Photo } from '../models';
import { STORAGE_KEYS } from '../core/constants/app.constants';
import { photoStorage, setStoredPhotos, getStoredPhotos } from '../shared/utils/storage.utils';

@Injectable({
  providedIn: 'root'
})
export class StorageService {
  private readonly PHOTO_STORAGE_KEY = STORAGE_KEYS.PHOTOS;
  
  constructor() {}
  
  // Save photos to LocalStorage
  savePhotos(photos: Photo[]): boolean {
    return photoStorage.set(photos);
  }
  
  // Load photos from LocalStorage
  loadPhotos(): Photo[] {
    return photoStorage.get<Photo[]>() || [];
  }
  
  // Add a single photo to LocalStorage
  addPhoto(photo: Photo): Photo[] {
    const photos = this.loadPhotos();
    photos.push(photo);
    this.savePhotos(photos);
    return photos;
  }
  
  // Update a photo in LocalStorage
  updatePhoto(updatedPhoto: Photo): Photo[] {
    const photos = this.loadPhotos();
    const index = photos.findIndex(p => p.id === updatedPhoto.id);
    
    if (index !== -1) {
      photos[index] = updatedPhoto;
      this.savePhotos(photos);
    }
    
    return photos;
  }
  
  // Remove a photo from LocalStorage
  removePhoto(photoId: string): Photo[] {
    const photos = this.loadPhotos();
    const filteredPhotos = photos.filter(p => p.id !== photoId);
    this.savePhotos(filteredPhotos);
    return filteredPhotos;
  }
  
  // Clear all photos from LocalStorage
  clearPhotos(): boolean {
    return photoStorage.remove();
  }
  
  // Check if LocalStorage is available
  isAvailable(): boolean {
    try {
      const testKey = '__photo_gallery_test__';
      localStorage.setItem(testKey, testKey);
      localStorage.removeItem(testKey);
      return true;
    } catch (error) {
      return false;
    }
  }
  
  // Get storage usage information
  getStorageInfo(): { used: number; max: number; percentage: number } {
    let used = 0;
    let max = 5 * 1024 * 1024; // Default 5MB
    
    try {
      for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i);
        if (key) {
          used += localStorage.getItem(key)?.length || 0;
        }
      }
      
      // Try to detect actual quota (if available)
      const quota = (localStorage as unknown as { quota?: number }).quota;
      if (typeof quota === 'number') {
        max = quota;
      }
    } catch (error) {
      // Use defaults if we can't access storage
    }
    
    const percentage = (used / max) * 100;
    
    return { used, max, percentage };
  }
  
  // Check if there's enough space for additional data
  hasEnoughSpace(additionalSize: number): boolean {
    const info = this.getStorageInfo();
    return (info.used + additionalSize) < (info.max * 0.9); // Keep 10% buffer
  }
  
  // Sync LocalStorage with provided photos (for when API sync happens)
  syncWithApi(photos: Photo[]): void {
    this.savePhotos(photos);
  }
}