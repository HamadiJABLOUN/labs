// Photo API service for HTTP calls to the backend
import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpHeaders, HttpErrorResponse, HttpParams } from '@angular/common/http';
import { catchError, map, throwError, Observable } from 'rxjs';
import { API_ENDPOINTS, API_BASE_URL } from '../../core/constants/app.constants';
import { 
  ApiPhoto, 
  PhotoPageResponse, 
  UploadPhotoRequest,
  isApiPhoto,
  apiPhotoToPhoto
} from '../../models';
import { Photo } from '../../models/photo.model';

@Injectable({
  providedIn: 'root'
})
export class PhotoApiService {
  private readonly http = inject(HttpClient);
  
  constructor() {}
  
  // GET /api/photos - Get all photos with pagination and filtering
  getPhotos(page: number = 0, size: number = 20, tags: string[] = [], sort: string = 'uploadDate,desc'): Observable<PhotoPageResponse> {
    // Backend expects separate 'sort' (property) and 'direction' params
    const [sortField, sortDirection = 'desc'] = sort.split(',');
    let params = new HttpParams()
      .set('page', page.toString())
      .set('size', size.toString())
      .set('sort', sortField)
      .set('direction', sortDirection);
    
    // Add tag filters
    tags.forEach(tag => {
      params = params.append('tags', tag);
    });
    
    return this.http.get<PhotoPageResponse>(API_ENDPOINTS.PHOTOS, { params }).pipe(
      catchError(this.handleError)
    );
  }
  
  // GET /api/photos/{id} - Get a specific photo by ID
  getPhotoById(id: string): Observable<ApiPhoto> {
    return this.http.get<ApiPhoto>(API_ENDPOINTS.PHOTO_BY_ID(id)).pipe(
      catchError(this.handleError)
    );
  }
  
  // POST /api/photos - Upload a new photo
  uploadPhoto(file: File, tags: string[] = []): Observable<ApiPhoto> {
    const formData = new FormData();
    formData.append('file', file, file.name);
    
    // Add tags if provided
    if (tags.length > 0) {
      formData.append('tags', tags.join(','));
    }
    
    // Don't set Content-Type header - let browser set it automatically with boundary
    const headers = new HttpHeaders();
    // Remove Content-Type to let browser handle multipart form data
    
    return this.http.post<ApiPhoto>(API_ENDPOINTS.PHOTOS, formData, { 
      headers,
      reportProgress: true,
      observe: 'response' 
    }).pipe(
      // Map to just the body for consistency
      map(response => response.body as ApiPhoto),
      catchError(this.handleError)
    );
  }
  
  // DELETE /api/photos/{id} - Delete a photo by ID
  deletePhoto(id: string): Observable<void> {
    return this.http.delete<void>(API_ENDPOINTS.PHOTO_BY_ID(id)).pipe(
      catchError(this.handleError)
    );
  }
  
  // GET /api/photos/{id}/tags - Get all tags for a photo
  getTagsForPhoto(id: string): Observable<string[]> {
    return this.http.get<string[]>(API_ENDPOINTS.PHOTO_TAGS(id)).pipe(
      catchError(this.handleError)
    );
  }
  
  // PUT /api/photos/{id}/tags - Replace all tags for a photo
  replaceTags(id: string, tags: string[]): Observable<string[]> {
    return this.http.put<string[]>(API_ENDPOINTS.PHOTO_TAGS(id), tags).pipe(
      catchError(this.handleError)
    );
  }
  
  // POST /api/photos/{id}/tags - Add one or more tags to a photo
  addTags(id: string, tags: string[]): Observable<string[]> {
    return this.http.post<string[]>(API_ENDPOINTS.PHOTO_TAGS(id), tags).pipe(
      catchError(this.handleError)
    );
  }
  
  // DELETE /api/photos/{id}/tags/{tag} - Remove a specific tag from a photo
  removeTag(id: string, tag: string): Observable<void> {
    return this.http.delete<void>(API_ENDPOINTS.PHOTO_TAG(id, tag)).pipe(
      catchError(this.handleError)
    );
  }
  
  // Helper method to upload and convert to Photo model
  async uploadPhotoWithConversion(file: File, tags: string[] = []): Promise<Photo> {
    return new Promise((resolve, reject) => {
      this.uploadPhoto(file, tags).subscribe({
        next: (apiPhoto) => {
          if (isApiPhoto(apiPhoto)) {
            const photo = apiPhotoToPhoto(apiPhoto);
            resolve(photo);
          } else {
            reject(new Error('Invalid API response format'));
          }
        },
        error: (error) => {
          reject(error);
        }
      });
    });
  }
  
  // Helper method to handle multipart upload with progress
  uploadPhotoWithProgress(file: File, tags: string[] = []): Observable<{ photo: ApiPhoto; progress: number }> {
    const formData = new FormData();
    formData.append('file', file, file.name);
    
    if (tags.length > 0) {
      formData.append('tags', tags.join(','));
    }
    
    return new Observable<{ photo: ApiPhoto; progress: number }>(subscriber => {
      const headers = new HttpHeaders();
      
      this.http.post<ApiPhoto>(API_ENDPOINTS.PHOTOS, formData, {
        headers,
        reportProgress: true,
        observe: 'events'
      }).subscribe({
        next: (event) => {
          if (event.type === 1 && event.loaded && event.total) {
            // Upload progress event
            const progress = Math.round((event.loaded / event.total) * 100);
            // Don't emit progress updates too frequently
            if (progress % 10 === 0 || progress === 100) {
              // We can't resolve the photo yet, so this approach needs adjustment
            }
          } else if (event.type === 4) {
            // HTTP response
            subscriber.next({ photo: event.body!, progress: 100 });
            subscriber.complete();
          }
        },
        error: (error) => {
          subscriber.error(error);
        }
      });
    });
  }
  
  // Error handling
  private handleError(error: HttpErrorResponse): Observable<never> {
    let errorMessage = 'An unknown error occurred';
    
    if (error.error instanceof ErrorEvent) {
      // Client-side error
      errorMessage = `Client error: ${error.error.message}`;
    } else {
      // Server-side error
      errorMessage = `Server error: ${error.status} - ${error.message}`;
      
      // Try to get more specific message from error body
      if (error.error?.message) {
        errorMessage = error.error.message;
      } else if (error.error?.error) {
        errorMessage = error.error.error;
      }
    }
    
    return throwError(() => new Error(errorMessage));
  }
  
  // Check if backend is available
  checkBackendHealth(): Observable<boolean> {
    return this.http.get<{ status: string }>(`${API_BASE_URL}/health`).pipe(
      map(() => true),
      catchError(() => throwError(() => new Error('Backend not reachable')))
    );
  }
}