// Application routes
import { Routes } from '@angular/router';
import { MainLayoutComponent } from './layout/main-layout/main-layout.component';
import { PhotoGalleryComponent } from './features/gallery/photo-gallery.component';
import { PhotoUploadComponent } from './features/upload/photo-upload.component';
import { PhotoDetailModalComponent } from './features/detail/photo-detail-modal.component';

export const routes: Routes = [
  {
    path: '',
    redirectTo: '/gallery',
    pathMatch: 'full'
  },
  {
    path: '',
    component: MainLayoutComponent,
    children: [
      {
        path: 'gallery',
        component: PhotoGalleryComponent
      },
      {
        path: 'gallery/upload',
        component: PhotoUploadComponent
      },
      {
        path: 'gallery/:id',
        component: PhotoDetailModalComponent
      },
      {
        path: '',
        redirectTo: 'gallery',
        pathMatch: 'full'
      }
    ]
  },
  {
    path: '**',
    redirectTo: '/gallery'
  }
];