// Main app component
import { Component, inject, effect, signal, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterOutlet, Router } from '@angular/router';
import { UiStore } from './stores/ui.store';
import { PhotoStore } from './stores/photo.store';
import { LoadingSpinnerComponent } from './shared/components/loading-spinner/loading-spinner.component';
import { HeaderComponent } from './layout/header/header.component';
import { FooterComponent } from './layout/footer/footer.component';
import { MainLayoutComponent } from './layout/main-layout/main-layout.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [
    CommonModule,
    RouterOutlet,
    LoadingSpinnerComponent,
    HeaderComponent,
    FooterComponent,
    MainLayoutComponent
  ],
  template: `
    <div class="app-root">
      @if (loading()) {
        <app-loading-spinner [large]="true" message="Loading photo gallery..."></app-loading-spinner>
      } @else {
        <router-outlet></router-outlet>
      }
    </div>
  `,
  styles: [`
    .app-root {
      min-height: 100vh;
      display: flex;
      flex-direction: column;
    }
    
    :host {
      display: flex;
      flex-direction: column;
      min-height: 100vh;
    }
  `]
})
export class AppComponent implements OnInit {
  private readonly uiStore = inject(UiStore);
  private readonly photoStore = inject(PhotoStore);
  private readonly router = inject(Router);
  
  // State
  loading = signal<boolean>(true);
  
  constructor() {
    // Initialize theme from saved preference
    this.uiStore.initializeTheme();
  }
  
  async ngOnInit(): Promise<void> {
    try {
      // Load photos on app initialization
      await this.photoStore.initialize();
      
      // Navigate to gallery if we're at root
      if (this.router.url === '/') {
        this.router.navigate(['/gallery']);
      }
    } catch (error) {
      console.error('Failed to initialize app:', error);
    } finally {
      this.loading.set(false);
    }
  }
}