// Delete confirmation modal component
import { Component, inject, signal, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PhotoStore } from '../../stores/photo.store';
import { UiStore } from '../../stores/ui.store';
import { ModalComponent } from '../../shared/components/modal/modal.component';
import { LoadingSpinnerComponent } from '../../shared/components/loading-spinner/loading-spinner.component';
import { Photo } from '../../models';

@Component({
  selector: 'app-delete-confirmation-modal',
  standalone: true,
  imports: [CommonModule, ModalComponent, LoadingSpinnerComponent],
  template: `
    <app-modal 
      [isOpen]="isOpen()"
      title="Confirm Delete"
      (closed)="close()"
    >
      @if (photo()) {
        <div class="confirmation-content">
          <p class="confirmation-message">
            Are you sure you want to permanently delete this photo?
          </p>
          
          <div class="photo-preview">
            @if (photo()!.dataUrl) {
              <img [src]="photo()!.dataUrl" alt="Preview" class="preview-image" />
            } @else {
              <div class="preview-placeholder">
                <span class="placeholder-icon">&#128247;</span>
              </div>
            }
            <div class="preview-info">
              <strong>{{ photo()!.filename }}</strong>
              <span class="preview-size">{{ photo()!.size | fileSize }}</span>
            </div>
          </div>
          
          <p class="confirmation-warning">
            This action cannot be undone. The photo will be permanently removed from your gallery.
          </p>
        </div>
        
        <div class="confirmation-actions">
          <button 
            class="action-button secondary" 
            (click)="close()"
            [disabled]="deleting()"
          >
            Cancel
          </button>
          
          <button 
            class="action-button danger" 
            (click)="confirmDelete()"
            [disabled]="deleting()"
          >
            @if (deleting()) {
              <app-loading-spinner [small]="true"></app-loading-spinner>
              Deleting...
            } @else {
              Delete Photo
            }
          </button>
        </div>
      }
    </app-modal>
  `,
  styles: [`
    .confirmation-content {
      display: flex;
      flex-direction: column;
      gap: 20px;
    }
    
    .confirmation-message {
      font-size: 16px;
      color: var(--text-primary);
      line-height: 1.5;
      margin: 0;
    }
    
    .photo-preview {
      display: flex;
      align-items: center;
      gap: 16px;
      padding: 16px;
      background-color: var(--hover-bg);
      border-radius: var(--radius-md);
    }
    
    .preview-image {
      width: 80px;
      height: 80px;
      object-fit: cover;
      border-radius: var(--radius-sm);
    }
    
    .preview-placeholder {
      width: 80px;
      height: 80px;
      background-color: var(--border-color);
      border-radius: var(--radius-sm);
      display: flex;
      align-items: center;
      justify-content: center;
    }
    
    .placeholder-icon {
      font-size: 24px;
      opacity: 0.7;
    }
    
    .preview-info {
      display: flex;
      flex-direction: column;
      gap: 4px;
    }
    
    .preview-info strong {
      font-size: 14px;
      color: var(--text-primary);
    }
    
    .preview-size {
      font-size: 12px;
      color: var(--text-secondary);
    }
    
    .confirmation-warning {
      color: var(--warning-color);
      font-size: 14px;
      line-height: 1.5;
      margin: 0;
      padding: 12px;
      background-color: rgba(243, 156, 18, 0.1);
      border-radius: var(--radius-sm);
    }
    
    .confirmation-actions {
      display: flex;
      justify-content: flex-end;
      gap: 12px;
      border-top: 1px solid var(--border-color);
      padding-top: 16px;
      margin-top: auto;
    }
    
    .action-button {
      padding: 8px 16px;
      border-radius: var(--radius-sm);
      font-size: 14px;
      font-weight: 500;
      cursor: pointer;
      transition: all var(--transition-fast);
      display: inline-flex;
      align-items: center;
      gap: 8px;
    }
    
    .action-button.secondary {
      background-color: var(--bg-color);
      color: var(--text-primary);
      border: 1px solid var(--border-color);
    }
    
    .action-button.secondary:hover:not(:disabled) {
      background-color: var(--hover-bg);
    }
    
    .action-button.danger {
      background-color: var(--danger-color);
      color: white;
    }
    
    .action-button.danger:hover:not(:disabled) {
      background-color: #c0392b;
    }
    
    .action-button:disabled {
      opacity: 0.6;
      cursor: not-allowed;
    }
    
    @media (max-width: 768px) {
      .photo-preview {
        flex-direction: column;
        text-align: center;
      }
      
      .confirmation-actions {
        justify-content: stretch;
      }
      
      .action-button {
        width: 100%;
        justify-content: center;
      }
    }
  `]
})
export class DeleteConfirmationModalComponent implements OnInit {
  private readonly photoStore = inject(PhotoStore);
  private readonly uiStore = inject(UiStore);
  
  // State
  isOpen = signal<boolean>(false);
  photo = signal<Photo | null>(null);
  deleting = signal<boolean>(false);
  
  constructor() {}
  
  ngOnInit(): void {
    // Watch for photo to delete changes in the store
    this.photoStore.photoToDelete.subscribe(photo => {
      this.photo.set(photo);
      if (photo) {
        this.isOpen.set(true);
      } else {
        this.isOpen.set(false);
      }
    });
  }
  
  close(): void {
    this.isOpen.set(false);
    this.photoStore.setPhotoToDelete(null);
  }
  
  async confirmDelete(): Promise<void> {
    const photo = this.photo();
    if (!photo) return;
    
    this.deleting.set(true);
    
    try {
      await this.photoStore.deletePhoto(photo.id);
      this.uiStore.addSuccessNotification('Photo deleted successfully');
      this.close();
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to delete photo';
      this.uiStore.addErrorNotification(errorMessage);
    } finally {
      this.deleting.set(false);
    }
  }
}