// Photo detail component for viewing and editing photo details
import { Component, inject, signal, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { PhotoStore } from '../../stores/photo.store';
import { UiStore } from '../../stores/ui.store';
import { TagBadgeComponent } from '../../shared/components/tag-badge/tag-badge.component';
import { LoadingSpinnerComponent } from '../../shared/components/loading-spinner/loading-spinner.component';
import { ConfirmDialogComponent } from '../../shared/components/confirm-dialog/confirm-dialog.component';
import { ModalComponent } from '../../shared/components/modal/modal.component';
import { FileSizePipe } from '../../shared/pipes/file-size.pipe';
import { DateFormatPipe } from '../../shared/pipes/date-format.pipe';
import { Photo } from '../../models';
import { 
  MAX_TAGS_PER_PHOTO,
  validateTag 
} from '../../models';
import { normalizeTagList } from '../../shared/utils/validation.utils';

@Component({
  selector: 'app-photo-detail-modal',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    RouterLink,
    TagBadgeComponent,
    LoadingSpinnerComponent,
    ConfirmDialogComponent,
    ModalComponent,
    FileSizePipe,
    DateFormatPipe
  ],
  template: `
    <app-modal 
      [isOpen]="isModalOpen()"
      [title]="photo() ? photo()!.filename : 'Photo Details'"
      [large]="true"
      (closed)="closeModal()"
    >
      @if (loading()) {
        <app-loading-spinner [large]="true" message="Loading photo details..."></app-loading-spinner>
      } @else if (error()) {
        <div class="error-container">
          <p class="error-message">{{ error() }}</p>
          <button class="retry-button" (click)="loadPhoto()">Retry</button>
        </div>
      } @else if (photo()) {
        <div class="detail-container">
          <div class="detail-main">
            <div class="detail-image-section">
              @if (photo()!.dataUrl) {
                <img 
                  [src]="photo()!.dataUrl" 
                  [alt]="photo()!.filename" 
                  class="detail-image"
                />
              } @else {
                <div class="detail-image-placeholder">
                  <span class="placeholder-icon">&#128247;</span>
                  <span class="placeholder-text">Image not available</span>
                </div>
              }
              
              <div class="image-actions">
                <button 
                  class="image-action" 
                  (click)="downloadPhoto()"
                  [disabled]="!photo()?.dataUrl"
                >
                  <span>&#8681; Download</span>
                </button>
              </div>
            </div>
            
            <div class="detail-info-section">
              <div class="info-header">
                <h2 class="info-title">{{ photo()!.filename }}</h2>
                
                @if (photo()!.isSynced === false) {
                  <span class="sync-status unsynced">Not synced</span>
                } @else {
                  <span class="sync-status synced">Synced</span>
                }
              </div>
              
              <div class="info-grid">
                <div class="info-item">
                  <span class="info-label">Uploaded</span>
                  <span class="info-value">{{ photo()!.uploadedAt | dateFormat:'long' }}</span>
                </div>
                
                <div class="info-item">
                  <span class="info-label">File Size</span>
                  <span class="info-value">{{ photo()!.size | fileSize }}</span>
                </div>
                
                @if (photo()!.width > 0 && photo()!.height > 0) {
                  <div class="info-item">
                    <span class="info-label">Dimensions</span>
                    <span class="info-value">{{ photo()!.width }} × {{ photo()!.height }} px</span>
                  </div>
                }
                
                <div class="info-item">
                  <span class="info-label">Type</span>
                  <span class="info-value">{{ photo()!.contentType }}</span>
                </div>
              </div>
              
              <div class="tags-section">
                <div class="tags-header">
                  <h3>Tags</h3>
                  @if (isEditingTags()) {
                    <button class="edit-done" (click)="toggleTagEditing()">Done</button>
                  } @else {
                    <button class="edit-button" (click)="toggleTagEditing()">
                      <span>&#9998;</span> Edit
                    </button>
                  }
                </div>
                
                @if (isEditingTags()) {
                  <div class="tags-editor">
                    <div class="tag-input-container">
                      <input 
                        type="text" 
                        class="tag-input" 
                        placeholder="Add a tag..."
                        [ngModel]="newTag"
                        (ngModelChange)="onNewTagChange($event)"
                        (keydown.enter)="addNewTag()"
                        (keydown.escape)="cancelTagEdit()"
                      />
                      
                      @if (tagsError()) {
                        <p class="tags-error">{{ tagsError() }}</p>
                      }
                    </div>
                    
                    <div class="edit-tags-list">
                      @for (tag of editableTags(); track tag) {
                        <app-tag-badge 
                          [tag]="tag"
                          [removable]="true"
                          (remove)="removeTag(tag)"
                        ></app-tag-badge>
                      }
                      @if (editableTags().length === 0) {
                        <span class="no-tags">No tags</span>
                      }
                    </div>
                    
                    <p class="tags-hint">
                      {{ editableTags().length }} / {{ MAX_TAGS_PER_PHOTO }} tags
                    </p>
                  </div>
                } @else {
                  @if (photo()!.tags.length > 0) {
                    <div class="tags-list">
                      @for (tag of photo()!.tags; track tag) {
                        <app-tag-badge 
                          [tag]="tag" 
                          [clickable]="true"
                          (click)="filterByTag(tag)"
                        ></app-tag-badge>
                      }
                    </div>
                  } @else {
                    <p class="no-tags">No tags</p>
                  }
                }
              </div>
              
              @if (photo()!.syncError) {
                <div class="sync-error">
                  <span class="error-icon">&#10006;</span>
                  <span class="error-message">{{ photo()!.syncError }}</span>
                </div>
              }
            </div>
          </div>
          
          @if (photo()!.originalFilename !== photo()!.filename) {
            <div class="original-filename">
              Original filename: {{ photo()!.originalFilename }}
            </div>
          }
        </div>
        
        <div class="detail-actions">
          <button class="action-button secondary" (click)="closeModal()">
            Close
          </button>
          
          @if (isEditingTags()) {
            <button 
              class="action-button primary" 
              (click)="saveTags()"
              [disabled]="!canSaveTags() || savingTags()"
            >
              @if (savingTags()) {
                <app-loading-spinner [small]="true"></app-loading-spinner>
                Saving...
              } @else {
                Save Tags
              }
            </button>
          } @else {
            <button 
              class="action-button danger" 
              (click)="confirmDelete()"
              [disabled]="deleting()"
            >
              @if (deleting()) {
                <app-loading-spinner [small]="true"></app-loading-spinner>
                Deleting...
              } @else {
                Delete Photo
              }
            </button>
          }
        </div>
      }
    </app-modal>
    
    @if (showDeleteConfirmation()) {
      <app-confirm-dialog
        title="Delete Photo"
        message="Are you sure you want to permanently delete this photo?"
        [details]="'This action cannot be undone.'"
        confirmText="Delete"
        [danger]="true"
        (confirmed)="deletePhotoConfirmed()"
        (cancelled)="cancelDelete()"
      ></app-confirm-dialog>
    }
  `,
  styles: [`
    .detail-container {
      display: flex;
      flex-direction: column;
      gap: 24px;
      max-height: 80vh;
      overflow-y: auto;
    }
    
    .detail-main {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 24px;
    }
    
    .detail-image-section {
      position: relative;
    }
    
    .detail-image {
      width: 100%;
      max-height: 500px;
      object-fit: contain;
      background-color: var(--hover-bg);
      border-radius: var(--radius-md);
    }
    
    .detail-image-placeholder {
      width: 100%;
      height: 400px;
      background-color: var(--hover-bg);
      border-radius: var(--radius-md);
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      color: var(--text-muted);
    }
    
    .placeholder-icon {
      font-size: 48px;
      margin-bottom: 8px;
    }
    
    .image-actions {
      display: flex;
      gap: 8px;
      margin-top: 12px;
    }
    
    .image-action {
      padding: 8px 16px;
      background-color: var(--bg-color);
      color: var(--text-primary);
      border: 1px solid var(--border-color);
      border-radius: var(--radius-sm);
      font-size: 13px;
      cursor: pointer;
      transition: all var(--transition-fast);
    }
    
    .image-action:hover:not(:disabled) {
      background-color: var(--hover-bg);
    }
    
    .image-action:disabled {
      opacity: 0.6;
      cursor: not-allowed;
    }
    
    .detail-info-section {
      display: flex;
      flex-direction: column;
      gap: 20px;
    }
    
    .info-header {
      display: flex;
      align-items: center;
      gap: 12px;
    }
    
    .info-title {
      font-size: 18px;
      font-weight: 600;
      color: var(--text-primary);
      margin: 0;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }
    
    .sync-status {
      padding: 4px 8px;
      border-radius: 12px;
      font-size: 12px;
      font-weight: 500;
    }
    
    .sync-status.synced {
      background-color: #d4edda;
      color: #155724;
    }
    
    .sync-status.unsynced {
      background-color: #fff3cd;
      color: #856404;
    }
    
    .info-grid {
      display: grid;
      grid-template-columns: repeat(2, 1fr);
      gap: 8px;
    }
    
    .info-item {
      display: flex;
      flex-direction: column;
    }
    
    .info-label {
      color: var(--text-secondary);
      font-size: 12px;
      font-weight: 500;
      text-transform: uppercase;
      letter-spacing: 0.5px;
    }
    
    .info-value {
      color: var(--text-primary);
      font-size: 14px;
      font-weight: 500;
    }
    
    .tags-section {
      border-top: 1px solid var(--border-color);
      padding-top: 16px;
    }
    
    .tags-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 12px;
    }
    
    .tags-header h3 {
      font-size: 16px;
      font-weight: 600;
      color: var(--text-primary);
      margin: 0;
    }
    
    .edit-button,
    .edit-done {
      background: none;
      border: none;
      color: var(--text-secondary);
      cursor: pointer;
      font-size: 13px;
      transition: color var(--transition-fast);
    }
    
    .edit-button:hover,
    .edit-done:hover {
      color: var(--primary-color);
    }
    
    .tags-editor {
      display: flex;
      flex-direction: column;
      gap: 12px;
    }
    
    .tag-input-container {
      position: relative;
    }
    
    .tag-input {
      width: 100%;
      padding: 8px 12px;
      border: 1px solid var(--border-color);
      border-radius: var(--radius-sm);
      font-size: 13px;
      background-color: var(--bg-color);
      color: var(--text-primary);
    }
    
    .tag-input:focus {
      outline: none;
      border-color: var(--primary-color);
      box-shadow: 0 0 0 2px rgba(52, 152, 219, 0.2);
    }
    
    .tags-hint {
      color: var(--text-secondary);
      font-size: 12px;
      margin: 0;
    }
    
    .tags-error {
      color: var(--danger-color);
      font-size: 12px;
      margin: 4px 0 0 0;
    }
    
    .edit-tags-list,
    .tags-list {
      display: flex;
      flex-wrap: wrap;
      gap: 6px;
    }
    
    .no-tags {
      color: var(--text-muted);
      font-size: 13px;
    }
    
    .sync-error {
      display: flex;
      align-items: center;
      gap: 8px;
      padding: 12px;
      background-color: #f8d7da;
      color: #721c24;
      border-radius: var(--radius-sm);
      margin-top: auto;
    }
    
    .error-icon {
      font-size: 16px;
    }
    
    .error-message {
      font-size: 14px;
    }
    
    .original-filename {
      font-size: 12px;
      color: var(--text-muted);
      font-style: italic;
    }
    
    .detail-actions {
      display: flex;
      justify-content: flex-end;
      gap: 12px;
      border-top: 1px solid var(--border-color);
      padding-top: 16px;
      margin-top: auto;
    }
    
    .action-button {
      padding: 8px 16px;
      border-radius: var(--radius-sm);
      font-size: 14px;
      font-weight: 500;
      cursor: pointer;
      transition: all var(--transition-fast);
      display: inline-flex;
      align-items: center;
      gap: 8px;
    }
    
    .action-button.secondary {
      background-color: var(--bg-color);
      color: var(--text-primary);
      border: 1px solid var(--border-color);
    }
    
    .action-button.secondary:hover:not(:disabled) {
      background-color: var(--hover-bg);
    }
    
    .action-button.primary {
      background-color: var(--primary-color);
      color: white;
    }
    
    .action-button.primary:hover:not(:disabled) {
      background-color: var(--primary-hover);
    }
    
    .action-button.danger {
      background-color: var(--danger-color);
      color: white;
    }
    
    .action-button.danger:hover:not(:disabled) {
      background-color: #c0392b;
    }
    
    .action-button:disabled {
      opacity: 0.6;
      cursor: not-allowed;
    }
    
    .error-container {
      text-align: center;
      padding: 20px;
    }
    
    .error-message {
      color: var(--danger-color);
      font-size: 16px;
    }
    
    .retry-button {
      margin-top: 12px;
      padding: 8px 16px;
      background-color: var(--primary-color);
      color: white;
      border: none;
      border-radius: var(--radius-sm);
      cursor: pointer;
    }
    
    @media (max-width: 1024px) {
      .detail-main {
        grid-template-columns: 1fr;
      }
      
      .detail-image-section {
        order: -1;
      }
      
      .detail-image {
        max-height: 400px;
      }
      
      .detail-image-placeholder {
        height: 300px;
      }
    }
    
    @media (max-width: 768px) {
      .detail-container {
        max-height: 90vh;
      }
      
      .info-grid {
        grid-template-columns: 1fr;
      }
      
      .detail-actions {
        justify-content: stretch;
      }
      
      .action-button {
        width: 100%;
        justify-content: center;
      }
    }
    
    @media (max-width: 480px) {
      .info-header {
        flex-direction: column;
        align-items: flex-start;
      }
      
      .info-title {
        font-size: 16px;
      }
    }
  `]
})
export class PhotoDetailModalComponent implements OnInit, OnDestroy {
  private readonly photoStore = inject(PhotoStore);
  private readonly uiStore = inject(UiStore);
  private readonly route = inject(ActivatedRoute);
  private readonly router = inject(Router);
  
  // State
  photo = signal<Photo | null>(null);
  loading = signal<boolean>(true);
  error = signal<string>('');
  isModalOpen = signal<boolean>(true);
  isEditingTags = signal<boolean>(false);
  editableTags = signal<string[]>([]);
  newTag = '';
  tagsError = signal<string>('');
  savingTags = signal<boolean>(false);
  deleting = signal<boolean>(false);
  showDeleteConfirmation = signal<boolean>(false);
  
  // Constants
  MAX_TAGS_PER_PHOTO = MAX_TAGS_PER_PHOTO;
  
  constructor() {}
  
  async ngOnInit(): Promise<void> {
    await this.loadPhoto();
  }
  
  ngOnDestroy(): void {
    this.closeModal();
  }
  
  async loadPhoto(): Promise<void> {
    this.loading.set(true);
    this.error.set('');
    
    try {
      const photoId = this.route.snapshot.paramMap.get('id');
      if (!photoId) {
        throw new Error('Photo ID not found');
      }
      
      const photo = this.photoStore.getPhotoById(photoId);
      if (!photo) {
        // Try to load photos first
        await this.photoStore.loadPhotos(true);
        const updatedPhoto = this.photoStore.getPhotoById(photoId);
        if (!updatedPhoto) {
          throw new Error('Photo not found');
        }
        this.photo.set(updatedPhoto);
      } else {
        this.photo.set(photo);
      }
      
      // Initialize editable tags
      this.editableTags.set([...(this.photo()?.tags ?? [])]);
      
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to load photo';
      this.error.set(errorMessage);
    } finally {
      this.loading.set(false);
    }
  }
  
  closeModal(): void {
    this.isModalOpen.set(false);
    // Navigate back to gallery after a small delay
    setTimeout(() => {
      this.router.navigate(['/gallery']);
    }, 200);
  }
  
  // Tag editing
  toggleTagEditing(): void {
    this.isEditingTags.update(editing => !editing);
    if (!this.isEditingTags()) {
      // Reset to original tags when canceling edit
      this.editableTags.set([...this.photo()!.tags]);
      this.newTag = '';
      this.tagsError.set('');
    }
  }
  
  cancelTagEdit(): void {
    this.toggleTagEditing();
  }
  
  onNewTagChange(tag: string): void {
    this.newTag = tag;
    this.clearTagsError();
  }
  
  addNewTag(): void {
    const tag = this.newTag.trim().toLowerCase();
    if (!tag || tag.length === 0) return;
    
    if (!validateTag(tag)) {
      this.tagsError.set('Invalid tag format. Only a-z, 0-9, _, - allowed');
      return;
    }
    
    const currentTags = this.editableTags();
    if (currentTags.includes(tag)) {
      this.tagsError.set('This tag is already added');
      return;
    }
    
    if (currentTags.length >= MAX_TAGS_PER_PHOTO) {
      this.tagsError.set(`Maximum of ${MAX_TAGS_PER_PHOTO} tags allowed`);
      return;
    }
    
    this.editableTags.update(tags => [...tags, tag]);
    this.newTag = '';
    this.clearTagsError();
  }
  
  removeTag(tag: string): void {
    this.editableTags.update(tags => tags.filter(t => t !== tag));
    this.clearTagsError();
  }
  
  canSaveTags(): boolean {
    const originalTags = this.photo()?.tags || [];
    const currentTags = this.editableTags();
    
    if (originalTags.length === currentTags.length) {
      return originalTags.every(tag => currentTags.includes(tag));
    }
    
    return true;
  }
  
  async saveTags(): Promise<void> {
    const photo = this.photo();
    if (!photo) return;
    
    const originalTags = [...photo.tags];
    const newTags = normalizeTagList(this.editableTags());
    
    if (originalTags.length === newTags.length && 
        originalTags.every(tag => newTags.includes(tag))) {
      this.toggleTagEditing();
      return;
    }
    
    this.savingTags.set(true);
    
    try {
      await this.photoStore.replaceTagsOnPhoto(photo.id, newTags);
      
      // Update photo in store
      this.photo.set({ ...photo, tags: newTags });
      this.editableTags.set([...newTags]);
      this.toggleTagEditing();
      
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to save tags';
      this.tagsError.set(errorMessage);
    } finally {
      this.savingTags.set(false);
    }
  }
  
  clearTagsError(): void {
    this.tagsError.set('');
  }
  
  filterByTag(tag: string): void {
    this.photoStore.addTagFilter(tag);
    this.closeModal();
  }
  
  // Delete photo
  confirmDelete(): void {
    this.showDeleteConfirmation.set(true);
  }
  
  cancelDelete(): void {
    this.showDeleteConfirmation.set(false);
  }
  
  async deletePhotoConfirmed(): Promise<void> {
    this.showDeleteConfirmation.set(false);
    const photo = this.photo();
    if (!photo) return;
    
    this.deleting.set(true);
    
    try {
      await this.photoStore.deletePhoto(photo.id);
      this.uiStore.addSuccessNotification('Photo deleted successfully');
      this.closeModal();
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to delete photo';
      this.error.set(errorMessage);
    } finally {
      this.deleting.set(false);
    }
  }
  
  // Download photo
  downloadPhoto(): void {
    const photo = this.photo();
    if (!photo || !photo.dataUrl) return;
    
    const link = document.createElement('a');
    link.href = photo.dataUrl;
    link.download = photo.filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }
}