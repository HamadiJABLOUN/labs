// Photo gallery component for displaying photo grid
import { Component, inject, signal, OnInit, effect } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { PhotoStore } from '../../stores/photo.store';
import { UiStore } from '../../stores/ui.store';
import { PhotoCardComponent } from '../card/photo-card.component';
import { TagFilterComponent } from '../filter/tag-filter.component';
import { LoadingSpinnerComponent } from '../../shared/components/loading-spinner/loading-spinner.component';
import { Photo } from '../../models';
import { TagBadgeComponent } from '../../shared/components/tag-badge/tag-badge.component';

@Component({
  selector: 'app-photo-gallery',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    RouterLink,
    PhotoCardComponent,
    TagFilterComponent,
    LoadingSpinnerComponent,
    TagBadgeComponent
  ],
  template: `
    <div class="gallery-container">
      <div class="gallery-header">
        <div class="gallery-title-section">
          <h1 class="gallery-title">Photo Gallery</h1>
          <p class="gallery-subtitle">
            @if (photoCount() === 0) {
              No photos yet. 
              <a routerLink="/gallery/upload">Upload your first photo!</a>
            } @else {
              {{ photoCount() }} photos
              @if (hasActiveFilters()) {
                <span class="filter-indicator">
                  filtered by {{ activeTags().length }} tag(s)
                </span>
              }
            }
          </p>
        </div>
        
        <div class="gallery-actions">
          <button 
            class="action-button primary" 
            [routerLink]="['/gallery/upload']"
          >
            <span class="button-icon">+</span> Upload Photo
          </button>
          
          <button 
            class="action-button" 
            (click)="refreshPhotos()"
            [disabled]="loading()"
          >
            <span class="button-icon">&#8635;</span> Refresh
          </button>
        </div>
      </div>
      
      <div class="gallery-main">
        <aside class="gallery-sidebar">
          <app-tag-filter></app-tag-filter>
        </aside>
        
        <main class="gallery-content">
          @if (loading()) {
            <div class="loading-container">
              <app-loading-spinner [large]="true" message="Loading photos..."></app-loading-spinner>
            </div>
          } @else if (error()) {
            <div class="error-container">
              <p class="error-message">{{ error() }}</p>
              <button class="retry-button" (click)="refreshPhotos()">Retry</button>
            </div>
          } @else if (filteredPhotos().length === 0) {
            <div class="empty-state">
              <div class="empty-icon">&#128247;</div>
              <h2>No photos found</h2>
              @if (hasActiveFilters()) {
                <p>Try removing some filters to see more photos.</p>
                <button class="empty-action" (click)="clearFilters()">Clear Filters</button>
              } @else {
                <p>Start by uploading your first photo.</p>
                <button class="empty-action" [routerLink]="['/gallery/upload']">Upload Photo</button>
              }
            </div>
          } @else {
            <div class="photos-grid">
              @for (photo of filteredPhotos(); track photo.id) {
                <app-photo-card 
                  [photo]="photo"
                  (cardClick)="onPhotoClick(photo)"
                  (detailClick)="onDetailClick(photo)"
                  (deleteClick)="onDeleteClick(photo)"
                  (tagClick)="onTagClick($event)"
                ></app-photo-card>
              }
            </div>
            
            <div class="pagination">
              <div class="pagination-info">
                Showing {{ currentPage() + 1 }} of {{ totalPages() || 1 }} pages
                ({{ totalPhotos() }} photos total)
              </div>
              
              <div class="pagination-controls">
                <button 
                  class="pagination-button" 
                  (click)="goToPreviousPage()"
                  [disabled]="isFirstPage() || loading()"
                >
                  Previous
                </button>
                
                <div class="page-numbers">
                  @for (page of getPageNumbers(); track page) {
                    @if (page === '...') {
                      <span class="page-ellipsis">...</span>
                    } @else {
                      <button 
                        class="pagination-button page-number"
                        [class.active]="page === currentPage() + 1"
                        (click)="goToPage($any(page) - 1)"
                      >
                        {{ page }}
                      </button>
                    }
                  }
                </div>
                
                <button 
                  class="pagination-button" 
                  (click)="goToNextPage()"
                  [disabled]="isLastPage() || loading()"
                >
                  Next
                </button>
              </div>
              
              <div class="page-size-selector">
                <label class="page-size-label">Photos per page:</label>
                <select 
                  class="page-size-select" 
                  [ngModel]="pageSize()"
                  (ngModelChange)="setPageSize($event)"
                >
                  <option value="10">10</option>
                  <option value="20">20</option>
                  <option value="50">50</option>
                  <option value="100">100</option>
                </select>
              </div>
            </div>
          }
        </main>
      </div>
    </div>
  `,
  styles: [`
    .gallery-container {
      display: flex;
      flex-direction: column;
      min-height: 100%;
    }
    
    .gallery-header {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      margin-bottom: 24px;
      gap: 16px;
    }
    
    .gallery-title-section {
      flex: 1;
    }
    
    .gallery-title {
      font-size: 24px;
      font-weight: 700;
      color: var(--text-primary);
      margin: 0 0 4px 0;
    }
    
    .gallery-subtitle {
      color: var(--text-secondary);
      font-size: 14px;
      margin: 0;
    }
    
    .gallery-subtitle a {
      color: var(--primary-color);
      font-weight: 500;
    }
    
    .gallery-subtitle a:hover {
      text-decoration: underline;
    }
    
    .filter-indicator {
      background-color: var(--primary-color);
      color: white;
      padding: 2px 8px;
      border-radius: 12px;
      font-size: 12px;
      margin-left: 8px;
    }
    
    .gallery-actions {
      display: flex;
      gap: 12px;
    }
    
    .action-button {
      display: inline-flex;
      align-items: center;
      gap: 6px;
      padding: 8px 16px;
      border-radius: var(--radius-sm);
      font-size: 14px;
      font-weight: 500;
      cursor: pointer;
      border: none;
      transition: all var(--transition-fast);
    }
    
    .action-button.primary {
      background-color: var(--primary-color);
      color: white;
    }
    
    .action-button.primary:hover:not(:disabled) {
      background-color: var(--primary-hover);
    }
    
    .action-button:not(.primary) {
      background-color: var(--bg-color);
      color: var(--text-primary);
      border: 1px solid var(--border-color);
    }
    
    .action-button:not(.primary):hover:not(:disabled) {
      background-color: var(--hover-bg);
    }
    
    .action-button:disabled {
      opacity: 0.6;
      cursor: not-allowed;
    }
    
    .button-icon {
      font-size: 16px;
      font-weight: bold;
    }
    
    .gallery-main {
      display: grid;
      grid-template-columns: 250px 1fr;
      gap: 24px;
      flex: 1;
    }
    
    .gallery-sidebar {
      position: sticky;
      top: 20px;
      align-self: start;
    }
    
    .gallery-content {
      display: flex;
      flex-direction: column;
      gap: 24px;
    }
    
    .photos-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
      gap: 20px;
    }
    
    .loading-container,
    .error-container,
    .empty-state {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      min-height: 400px;
      text-align: center;
      padding: 40px;
    }
    
    .error-message {
      color: var(--danger-color);
      font-size: 16px;
      margin-bottom: 16px;
    }
    
    .retry-button {
      padding: 8px 16px;
      background-color: var(--primary-color);
      color: white;
      border: none;
      border-radius: var(--radius-sm);
      cursor: pointer;
      transition: background-color var(--transition-fast);
    }
    
    .retry-button:hover {
      background-color: var(--primary-hover);
    }
    
    .empty-state {
      gap: 16px;
    }
    
    .empty-icon {
      font-size: 64px;
      opacity: 0.7;
    }
    
    .empty-state h2 {
      font-size: 18px;
      font-weight: 600;
      color: var(--text-primary);
    }
    
    .empty-state p {
      color: var(--text-secondary);
      font-size: 14px;
    }
    
    .empty-action {
      padding: 10px 20px;
      background-color: var(--primary-color);
      color: white;
      border: none;
      border-radius: var(--radius-sm);
      font-size: 14px;
      font-weight: 500;
      cursor: pointer;
      transition: background-color var(--transition-fast);
    }
    
    .empty-action:hover {
      background-color: var(--primary-hover);
    }
    
    .pagination {
      display: flex;
      justify-content: space-between;
      align-items: center;
      gap: 16px;
      margin-top: auto;
    }
    
    .pagination-info {
      color: var(--text-secondary);
      font-size: 13px;
    }
    
    .pagination-controls {
      display: flex;
      align-items: center;
      gap: 8px;
    }
    
    .pagination-button {
      padding: 6px 12px;
      border: 1px solid var(--border-color);
      background-color: var(--bg-color);
      color: var(--text-primary);
      border-radius: var(--radius-sm);
      cursor: pointer;
      transition: all var(--transition-fast);
    }
    
    .pagination-button:hover:not(:disabled) {
      background-color: var(--hover-bg);
      border-color: var(--primary-color);
    }
    
    .pagination-button:disabled {
      opacity: 0.6;
      cursor: not-allowed;
    }
    
    .pagination-button.page-number.active {
      background-color: var(--primary-color);
      color: white;
      border-color: var(--primary-color);
    }
    
    .page-numbers {
      display: flex;
      gap: 4px;
    }
    
    .page-ellipsis {
      padding: 6px 8px;
      color: var(--text-muted);
      cursor: default;
    }
    
    .page-size-selector {
      display: flex;
      align-items: center;
      gap: 8px;
    }
    
    .page-size-label {
      color: var(--text-secondary);
      font-size: 13px;
      white-space: nowrap;
    }
    
    .page-size-select {
      padding: 6px 8px;
      border: 1px solid var(--border-color);
      background-color: var(--bg-color);
      color: var(--text-primary);
      border-radius: var(--radius-sm);
      font-size: 13px;
      cursor: pointer;
    }
    
    .page-size-select:focus {
      outline: none;
      border-color: var(--primary-color);
    }
    
    @media (max-width: 1024px) {
      .gallery-main {
        grid-template-columns: 1fr;
      }
      
      .gallery-sidebar {
        position: static;
        margin-bottom: 24px;
      }
      
      .gallery-header {
        flex-direction: column;
        align-items: stretch;
      }
      
      .gallery-actions {
        justify-content: flex-start;
      }
    }
    
    @media (max-width: 768px) {
      .photos-grid {
        grid-template-columns: repeat(2, 1fr);
      }
      
      .pagination {
        flex-direction: column;
        gap: 12px;
        text-align: center;
      }
      
      .pagination-info {
        order: 2;
      }
      
      .pagination-controls {
        order: 3;
        flex-wrap: wrap;
        justify-content: center;
      }
      
      .page-size-selector {
        order: 1;
        justify-content: center;
      }
    }
    
    @media (max-width: 480px) {
      .photos-grid {
        grid-template-columns: 1fr;
      }
      
      .gallery-actions {
        flex-direction: column;
      }
      
      .action-button {
        width: 100%;
        justify-content: center;
      }
    }
  `]
})
export class PhotoGalleryComponent implements OnInit {
  private readonly photoStore = inject(PhotoStore);
  private readonly uiStore = inject(UiStore);
  private readonly router = inject(Router);
  
  // Get data from store
  photos = this.photoStore.photos;
  filteredPhotos = this.photoStore.filteredPhotos;
  loading = this.photoStore.loading;
  error = this.photoStore.error;
  photoCount = this.photoStore.photoCount;
  hasPhotos = this.photoStore.hasPhotos;
  
  // Pagination data
  currentPage = this.photoStore.currentPage;
  totalPages = this.photoStore.totalPages;
  totalPhotos = this.photoStore.totalPhotos;
  pageSize = this.photoStore.pageSize;
  isFirstPage = this.photoStore.isFirstPage;
  isLastPage = this.photoStore.isLastPage;
  
  // Filter data
  hasActiveFilters = this.photoStore.hasActiveFilters;
  activeTags = this.photoStore.activeTags;
  
  constructor() {
    // Load photos on component initialization
    this.loadPhotos();
  }
  
  async ngOnInit(): Promise<void> {
    // Load photos if not already loaded
    if (this.photos().length === 0) {
      await this.loadPhotos();
    }
  }
  
  async loadPhotos(): Promise<void> {
    try {
      await this.photoStore.loadPhotos();
    } catch (error) {
      console.error('Failed to load photos:', error);
    }
  }
  
  async refreshPhotos(): Promise<void> {
    await this.photoStore.refreshPhotos();
  }
  
  clearFilters(): void {
    this.photoStore.clearTagFilters();
  }
  
  // Navigation methods
  onPhotoClick(photo: Photo): void {
    this.router.navigate(['/gallery', photo.id]);
  }
  
  onDetailClick(photo: Photo): void {
    this.router.navigate(['/gallery', photo.id]);
  }
  
  onDeleteClick(photo: Photo): void {
    this.photoStore.setPhotoToDelete(photo);
    this.uiStore.openDeleteModal();
  }
  
  onTagClick(tag: string): void {
    this.photoStore.addTagFilter(tag);
  }
  
  // Pagination methods
  goToPreviousPage(): void {
    if (!this.isFirstPage()) {
      this.photoStore.goToPreviousPage();
    }
  }
  
  goToNextPage(): void {
    if (!this.isLastPage()) {
      this.photoStore.goToNextPage();
    }
  }
  
  goToPage(page: number): void {
    this.photoStore.setPage(page);
  }
  
  setPageSize(size: number): void {
    this.photoStore.setPageSize(Number(size));
  }
  
  // Generate page numbers with ellipsis
  getPageNumbers(): (number | string)[] {
    const current = this.currentPage();
    const total = this.totalPages();
    const maxVisible = 7;
    
    if (total <= maxVisible) {
      return Array.from({ length: total }, (_, i) => i + 1);
    }
    
    const pages: (number | string)[] = [];
    const ellipsis = '...';
    
    // Always show first page
    pages.push(1);
    
    // Show pages around current
    const start = Math.max(2, current - 2);
    const end = Math.min(total - 1, current + 2);
    
    if (start > 2) {
      pages.push(ellipsis);
    }
    
    for (let i = start; i <= end; i++) {
      pages.push(i);
    }
    
    if (end < total - 1) {
      pages.push(ellipsis);
    }
    
    // Always show last page
    if (total > 1) {
      pages.push(total);
    }
    
    return pages;
  }
}