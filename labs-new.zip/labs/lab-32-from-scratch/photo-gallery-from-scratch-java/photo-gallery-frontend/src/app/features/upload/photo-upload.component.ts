// Photo upload component
import { Component, inject, signal, ElementRef, ViewChild, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { PhotoStore } from '../../stores/photo.store';
import { UiStore } from '../../stores/ui.store';
import { DragDropDirective } from '../../shared/directives/drag-drop.directive';
import { LoadingSpinnerComponent } from '../../shared/components/loading-spinner/loading-spinner.component';
import { TagBadgeComponent } from '../../shared/components/tag-badge/tag-badge.component';
import { FileSizePipe } from '../../shared/pipes/file-size.pipe';
import { 
  MAX_FILE_SIZE, 
  ALLOWED_CONTENT_TYPES,
  validateTag,
  MAX_TAGS_PER_PHOTO
} from '../../models';
import { fileToDataUrl, getImageDimensionsFromFile } from '../../shared/utils/image.utils';
import { normalizeTagList } from '../../shared/utils/validation.utils';

@Component({
  selector: 'app-photo-upload',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    RouterLink,
    DragDropDirective,
    LoadingSpinnerComponent,
    TagBadgeComponent,
    FileSizePipe
  ],
  template: `
    <div class="upload-container">
      <div class="upload-header">
        <h1 class="upload-title">Upload Photos</h1>
        <p class="upload-subtitle">
          Drag & drop photos here or click the button below to browse files
        </p>
      </div>
      
      <div 
        class="drop-zone"
        [class.dragging]="isDragging()"
        [class.disabled]="uploading() || processing()"
        appDragDrop
        (filesDropped)="handleFilesDropped($event)"
        (fileHover)="onDragHover($event)"
        [disabled]="uploading() || processing()"
      >
        <div class="drop-zone-content">
          @if (previewUrl()) {
            <div class="image-preview">
              <img [src]="previewUrl()" alt="Preview" class="preview-image" />
              <div class="preview-overlay">
                <span class="preview-info">
                  {{ selectedFile()?.name || 'Selected Image' }}
                </span>
                <span class="preview-size">
                  {{ selectedFile()?.size | fileSize }}
                </span>
              </div>
            </div>
          } @else {
            <div class="drop-zone-icon">
              <span>&#128247;</span>
            </div>
            <p class="drop-zone-text">
              Drop your photo here or 
              <button 
                class="browse-button" 
                (click)="onBrowseClick()"
                [disabled]="uploading() || processing()"
              >
                Browse Files
              </button>
            </p>
          }
          
          <input 
            #fileInput 
            type="file" 
            class="file-input" 
            accept="image/jpeg,image/png,image/gif,image/webp"
            (change)="handleFileSelect($event)"
            [disabled]="uploading() || processing()"
          />
        </div>
      </div>
      
      @if (selectedFile()) {
        <div class="upload-details">
          <div class="file-info">
            <h3>File Information</h3>
            <table class="info-table">
              <tr>
                <th>Filename:</th>
                <td>{{ selectedFile()?.name }}</td>
              </tr>
              <tr>
                <th>Type:</th>
                <td>{{ selectedFile()?.type || 'Unknown' }}</td>
              </tr>
              <tr>
                <th>Size:</th>
                <td>{{ selectedFile()?.size | fileSize }}</td>
              </tr>
              @if (imageDimensions().width > 0 && imageDimensions().height > 0) {
                <tr>
                  <th>Dimensions:</th>
                  <td>{{ imageDimensions().width }} × {{ imageDimensions().height }}</td>
                </tr>
              }
            </table>
          </div>
          
          <div class="tags-section">
            <h3>Tags</h3>
            <p class="tags-hint">
              Add descriptive tags to categorize your photo (separate with commas or spaces)
            </p>
            <div class="tags-input-container">
              <input 
                type="text" 
                class="tags-input" 
                placeholder="e.g., nature, landscape, summer..."
                [ngModel]="tagsInput"
                (ngModelChange)="onTagsInputChange($event)"
                (keydown.enter)="onTagsKeyDown($event)"
                [disabled]="uploading() || processing()"
              />
              
              @if (suggestedTags().length > 0) {
                <div class="tags-suggestions">
                  @for (tag of suggestedTags(); track tag) {
                    <button 
                      class="suggestion-tag" 
                      (click)="addSuggestedTag(tag)"
                    >
                      {{ tag }}
                    </button>
                  }
                </div>
              }
            </div>
            
            <div class="selected-tags">
              @for (tag of normalizedTags(); track tag) {
                <app-tag-badge 
                  [tag]="tag"
                  [removable]="true"
                  (remove)="removeTag(tag)"
                ></app-tag-badge>
              }
              @if (normalizedTags().length === 0) {
                <span class="no-tags">No tags added</span>
              }
            </div>
            
            @if (tagsError()) {
              <p class="tags-error">{{ tagsError() }}</p>
            }
            
            @if (normalizedTags().length > 0) {
              <p class="tags-char-count">
                {{ normalizedTags().length }} / {{ MAX_TAGS_PER_PHOTO }} tags
              </p>
            }
          </div>
        </div>
      }
      
      <div class="upload-actions">
        <button 
          class="upload-button secondary" 
          [routerLink]="['/gallery']"
          [disabled]="uploading() || processing()"
        >
          Cancel
        </button>
        
        <button 
          class="upload-button primary" 
          (click)="uploadPhoto()"
          [disabled]="!canUpload() || uploading() || processing()"
        >
          @if (uploading() || processing()) {
            <app-loading-spinner [small]="true"></app-loading-spinner>
            Processing...
          } @else {
            Upload Photo
          }
        </button>
      </div>
      
      @if (error()) {
        <div class="upload-error">
          <span class="error-icon">&#10006;</span>
          <span class="error-message">{{ error() }}</span>
          <button class="error-close" (click)="clearError()">×</button>
        </div>
      }
      
      @if (success()) {
        <div class="upload-success">
          <span class="success-icon">✓</span>
          <span class="success-message">{{ success() }}</span>
          <button class="success-close" (click)="clearSuccess()">×</button>
        </div>
      }
      
      <div class="upload-requirements">
        <h4>Requirements:</h4>
        <ul class="requirements-list">
          <li>File types: JPEG, PNG, GIF, WebP</li>
          <li>Maximum size: {{ MAX_FILE_SIZE / (1024 * 1024) }}MB</li>
          <li>Maximum tags: {{ MAX_TAGS_PER_PHOTO }}</li>
          <li>Tags: lowercase letters, numbers, hyphens, underscores</li>
        </ul>
      </div>
    </div>
  `,
  styles: [`
    .upload-container {
      display: flex;
      flex-direction: column;
      gap: 24px;
      max-width: 800px;
      margin: 0 auto;
    }
    
    .upload-header {
      text-align: center;
    }
    
    .upload-title {
      font-size: 24px;
      font-weight: 700;
      color: var(--text-primary);
      margin: 0 0 8px 0;
    }
    
    .upload-subtitle {
      color: var(--text-secondary);
      font-size: 14px;
      margin: 0;
    }
    
    .drop-zone {
      border: 2px dashed var(--border-color);
      border-radius: var(--radius-lg);
      padding: 40px;
      text-align: center;
      cursor: pointer;
      transition: all var(--transition-normal);
      min-height: 300px;
      display: flex;
      align-items: center;
      justify-content: center;
      background-color: var(--bg-color);
    }
    
    .drop-zone:hover:not(.disabled) {
      border-color: var(--primary-color);
      background-color: var(--hover-bg);
    }
    
    .drop-zone.dragging:not(.disabled) {
      border-color: var(--primary-color);
      background-color: rgba(52, 152, 219, 0.05);
      border-style: solid;
    }
    
    .drop-zone.disabled {
      opacity: 0.6;
      cursor: not-allowed;
    }
    
    .drop-zone-content {
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 16px;
      width: 100%;
    }
    
    .image-preview {
      position: relative;
      width: 200px;
      height: 200px;
      border-radius: var(--radius-md);
      overflow: hidden;
      box-shadow: var(--shadow-md);
    }
    
    .preview-image {
      width: 100%;
      height: 100%;
      object-fit: cover;
    }
    
    .preview-overlay {
      position: absolute;
      bottom: 0;
      left: 0;
      right: 0;
      background: linear-gradient(transparent, rgba(0, 0, 0, 0.7));
      color: white;
      padding: 12px;
      font-size: 12px;
      display: flex;
      justify-content: space-between;
    }
    
    .drop-zone-icon {
      font-size: 64px;
      color: var(--text-muted);
      opacity: 0.7;
    }
    
    .drop-zone-text {
      color: var(--text-secondary);
      font-size: 16px;
    }
    
    .browse-button {
      background-color: var(--primary-color);
      color: white;
      border: none;
      padding: 8px 16px;
      border-radius: var(--radius-sm);
      font-size: 14px;
      font-weight: 500;
      cursor: pointer;
      transition: background-color var(--transition-fast);
      margin-left: 4px;
    }
    
    .browse-button:hover:not(:disabled) {
      background-color: var(--primary-hover);
    }
    
    .browse-button:disabled {
      opacity: 0.6;
      cursor: not-allowed;
    }
    
    .file-input {
      display: none;
    }
    
    .upload-details {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 24px;
    }
    
    .file-info h3,
    .tags-section h3 {
      font-size: 16px;
      font-weight: 600;
      color: var(--text-primary);
      margin: 0 0 12px 0;
    }
    
    .info-table {
      width: 100%;
      border-collapse: collapse;
    }
    
    .info-table th,
    .info-table td {
      padding: 6px 0;
      text-align: left;
      border-bottom: 1px solid var(--border-color);
    }
    
    .info-table th {
      color: var(--text-secondary);
      font-weight: 500;
      white-space: nowrap;
    }
    
    .info-table td {
      color: var(--text-primary);
    }
    
    .tags-hint {
      color: var(--text-secondary);
      font-size: 13px;
      margin: 0 0 8px 0;
    }
    
    .tags-input-container {
      position: relative;
      margin-bottom: 8px;
    }
    
    .tags-input {
      width: 100%;
      padding: 8px 12px;
      border: 1px solid var(--border-color);
      border-radius: var(--radius-sm);
      font-size: 14px;
      background-color: var(--bg-color);
      color: var(--text-primary);
    }
    
    .tags-input:focus {
      outline: none;
      border-color: var(--primary-color);
      box-shadow: 0 0 0 2px rgba(52, 152, 219, 0.2);
    }
    
    .tags-input:disabled {
      opacity: 0.6;
      cursor: not-allowed;
    }
    
    .tags-suggestions {
      display: flex;
      flex-wrap: wrap;
      gap: 6px;
      margin-top: 8px;
    }
    
    .suggestion-tag {
      background-color: var(--hover-bg);
      color: var(--text-primary);
      border: 1px solid var(--border-color);
      padding: 4px 8px;
      border-radius: var(--radius-sm);
      font-size: 12px;
      cursor: pointer;
      transition: all var(--transition-fast);
    }
    
    .suggestion-tag:hover {
      background-color: var(--primary-color);
      color: white;
      border-color: var(--primary-color);
    }
    
    .selected-tags {
      display: flex;
      flex-wrap: wrap;
      gap: 6px;
      margin-bottom: 8px;
    }
    
    .no-tags {
      color: var(--text-muted);
      font-size: 12px;
    }
    
    .tags-error {
      color: var(--danger-color);
      font-size: 13px;
      margin: 0;
    }
    
    .tags-char-count {
      color: var(--text-secondary);
      font-size: 12px;
      margin: 0;
    }
    
    .upload-actions {
      display: flex;
      justify-content: flex-end;
      gap: 12px;
    }
    
    .upload-button {
      padding: 10px 20px;
      border-radius: var(--radius-sm);
      font-size: 14px;
      font-weight: 500;
      cursor: pointer;
      transition: all var(--transition-fast);
      display: inline-flex;
      align-items: center;
      gap: 8px;
    }
    
    .upload-button.secondary {
      background-color: var(--bg-color);
      color: var(--text-primary);
      border: 1px solid var(--border-color);
    }
    
    .upload-button.secondary:hover:not(:disabled) {
      background-color: var(--hover-bg);
    }
    
    .upload-button.primary {
      background-color: var(--primary-color);
      color: white;
    }
    
    .upload-button.primary:hover:not(:disabled) {
      background-color: var(--primary-hover);
    }
    
    .upload-button:disabled {
      opacity: 0.6;
      cursor: not-allowed;
    }
    
    .upload-error,
    .upload-success {
      display: flex;
      align-items: center;
      gap: 8px;
      padding: 12px 16px;
      border-radius: var(--radius-sm);
      margin-top: 16px;
    }
    
    .upload-error {
      background-color: #f8d7da;
      color: #721c24;
      border: 1px solid #f5c6cb;
    }
    
    .upload-success {
      background-color: #d4edda;
      color: #155724;
      border: 1px solid #c3e6cb;
    }
    
    .error-icon,
    .success-icon {
      font-size: 16px;
      font-weight: bold;
    }
    
    .error-message,
    .success-message {
      flex: 1;
      font-size: 14px;
    }
    
    .error-close,
    .success-close {
      background: none;
      border: none;
      font-size: 18px;
      cursor: pointer;
      color: inherit;
      opacity: 0.7;
      transition: opacity var(--transition-fast);
    }
    
    .error-close:hover,
    .success-close:hover {
      opacity: 1;
    }
    
    .upload-requirements {
      background-color: var(--bg-color);
      border: 1px solid var(--border-color);
      border-radius: var(--radius-sm);
      padding: 16px;
    }
    
    .upload-requirements h4 {
      font-size: 14px;
      font-weight: 600;
      color: var(--text-primary);
      margin: 0 0 8px 0;
    }
    
    .requirements-list {
      margin: 0;
      padding-left: 20px;
      color: var(--text-secondary);
      font-size: 13px;
      line-height: 1.6;
    }
    
    .requirements-list li {
      margin-bottom: 4px;
    }
    
    @media (max-width: 768px) {
      .upload-details {
        grid-template-columns: 1fr;
      }
      
      .drop-zone {
        padding: 30px 20px;
      }
      
      .upload-actions {
        justify-content: stretch;
      }
      
      .upload-button {
        width: 100%;
        justify-content: center;
      }
    }
    
    @media (max-width: 480px) {
      .upload-container {
        padding: 0 10px;
      }
      
      .upload-title {
        font-size: 20px;
      }
      
      .image-preview {
        width: 150px;
        height: 150px;
      }
      
      .drop-zone-icon {
        font-size: 48px;
      }
      
      .drop-zone-text {
        font-size: 14px;
      }
    }
  `]
})
export class PhotoUploadComponent implements OnDestroy {
  private readonly photoStore = inject(PhotoStore);
  private readonly uiStore = inject(UiStore);
  private readonly router = inject(Router);
  
  @ViewChild('fileInput') fileInput!: ElementRef<HTMLInputElement>;
  
  // State
  selectedFile = signal<File | null>(null);
  previewUrl = signal<string>('');
  tagsInput = '';
  normalizedTags = signal<string[]>([]);
  isDragging = signal<boolean>(false);
  uploading = signal<boolean>(false);
  processing = signal<boolean>(false);
  error = signal<string>('');
  success = signal<string>('');
  imageDimensions = signal<{ width: number; height: number }>({ width: 0, height: 0 });
  tagsError = signal<string>('');
  
  // Computed
  canUpload = signal<boolean>(false);
  
  // Constants
  MAX_TAGS_PER_PHOTO = MAX_TAGS_PER_PHOTO;
  MAX_FILE_SIZE = MAX_FILE_SIZE;
  
  constructor() {
    // Update canUpload whenever relevant data changes
    this.updateCanUpload();
  }
  
  ngOnDestroy(): void {
    this.clearFileSelection();
  }
  
  // Handle file selection from input
  handleFileSelect(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files.length > 0) {
      this.handleFiles(Array.from(input.files));
    }
  }
  
  // Handle files dropped on the drop zone
  handleFilesDropped(files: File[]): void {
    this.handleFiles(files);
  }
  
  // Handle drag hover
  onDragHover(isHovering: boolean): void {
    this.isDragging.set(isHovering);
  }
  
  // Trigger file input click
  onBrowseClick(): void {
    this.fileInput.nativeElement.click();
  }
  
  // Handle tags input changes
  onTagsInputChange(tags: string): void {
    this.tagsInput = tags;
    this.updateNormalizedTags();
  }
  
  // Handle Enter key in tags input
  onTagsKeyDown(event: Event): void {
    event.preventDefault();
    this.addTagsFromInput();
  }
  
  // Add suggested tag
  addSuggestedTag(tag: string): void {
    this.tagsInput = ''; // Clear input when adding from suggestion
    this.normalizedTags.update(tags => [...new Set([...tags, tag])]);
    this.clearTagsError();
  }
  
  // Remove tag
  removeTag(tag: string): void {
    this.normalizedTags.update(tags => tags.filter(t => t !== tag));
    this.updateTagsInput();
    this.clearTagsError();
  }
  
  // Update normalized tags from input
  private updateNormalizedTags(): void {
    const tags = this.tagsInput
      .split(/[,\s]+/) // Split by commas or spaces
      .filter(tag => tag.trim().length > 0)
      .map(tag => tag.trim().toLowerCase())
      .filter(tag => validateTag(tag));
    
    this.normalizedTags.set([...new Set(tags)]);
    this.clearTagsError();
    this.updateCanUpload();
  }
  
  // Update tags input from normalized tags
  private updateTagsInput(): void {
    this.tagsInput = this.normalizedTags().join(', ');
  }
  
  // Add tags from input (called on Enter key)
  private addTagsFromInput(): void {
    const newTags = this.tagsInput
      .split(/[,\s]+/)
      .filter(tag => tag.trim().length > 0)
      .map(tag => tag.trim().toLowerCase())
      .filter(tag => validateTag(tag));
    
    if (newTags.length > 0) {
      this.normalizedTags.update(tags => [...new Set([...tags, ...newTags])]);
      this.tagsInput = '';
      this.clearTagsError();
    }
  }
  
  // Handle files
  private handleFiles(files: File[]): void {
    // Only accept the first file for now
    const file = files[0];
    
    if (!file) return;
    
    // Validate file type
    if (!ALLOWED_CONTENT_TYPES.includes(file.type)) {
      this.error.set(`File type not supported. Please upload: ${ALLOWED_CONTENT_TYPES.join(', ')}`);
      return;
    }
    
    // Validate file size
    if (file.size > MAX_FILE_SIZE) {
      this.error.set(`File is too large. Maximum size is ${MAX_FILE_SIZE / (1024 * 1024)}MB`);
      return;
    }
    
    this.selectedFile.set(file);
    this.clearError();
    this.clearSuccess();
    
    // Create preview
    this.createPreview(file);
    
    // Get image dimensions
    this.getDimensions(file);
    
    this.updateCanUpload();
  }
  
  // Create preview from file
  private async createPreview(file: File): Promise<void> {
    this.processing.set(true);
    
    try {
      const url = await fileToDataUrl(file);
      this.previewUrl.set(url);
    } catch (err) {
      this.error.set('Failed to create image preview');
      console.error('Error creating preview:', err);
    } finally {
      this.processing.set(false);
    }
  }
  
  // Get image dimensions
  private async getDimensions(file: File): Promise<void> {
    try {
      const dimensions = await getImageDimensionsFromFile(file);
      this.imageDimensions.set(dimensions);
    } catch (err) {
      console.warn('Could not get image dimensions:', err);
    }
  }
  
  // Update canUpload state
  private updateCanUpload(): void {
    const hasFile = this.selectedFile() !== null;
    const tagsValid = this.validateTags();
    
    this.canUpload.set(hasFile && tagsValid);
  }
  
  // Validate tags
  private validateTags(): boolean {
    const tags = this.normalizedTags();
    
    if (tags.length > MAX_TAGS_PER_PHOTO) {
      this.tagsError.set(`Maximum of ${MAX_TAGS_PER_PHOTO} tags allowed`);
      return false;
    }
    
    // All tags are already validated in updateNormalizedTags
    this.clearTagsError();
    return true;
  }
  
  // Upload photo
  async uploadPhoto(): Promise<void> {
    const file = this.selectedFile();
    if (!file) return;
    
    const tags = this.normalizedTags();
    
    // Final validation
    if (!this.canUpload()) {
      this.error.set('Please fix the errors before uploading');
      return;
    }
    
    this.uploading.set(true);
    this.error.set('');
    this.success.set('');
    
    try {
      await this.photoStore.uploadPhoto(file, tags);
      
      this.success.set('Photo uploaded successfully!');
      
      // Clear selection after successful upload
      this.clearFileSelection();
      
      // Navigate back to gallery after a delay
      setTimeout(() => {
        this.router.navigate(['/gallery']);
      }, 1500);
      
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Upload failed';
      this.error.set(errorMessage);
    } finally {
      this.uploading.set(false);
    }
  }
  
  // Clear file selection
  clearFileSelection(): void {
    this.selectedFile.set(null);
    this.previewUrl.set('');
    this.tagsInput = '';
    this.normalizedTags.set([]);
    this.imageDimensions.set({ width: 0, height: 0 });
    this.clearError();
    this.clearSuccess();
    this.clearTagsError();
    this.updateCanUpload();
    
    // Reset file input
    if (this.fileInput) {
      this.fileInput.nativeElement.value = '';
    }
  }
  
  // Clear error
  clearError(): void {
    this.error.set('');
  }
  
  // Clear success
  clearSuccess(): void {
    this.success.set('');
  }
  
  // Clear tags error
  clearTagsError(): void {
    this.tagsError.set('');
  }
  
  // Get suggested tags based on file
  suggestedTags(): string[] {
    if (!this.selectedFile()) return [];
    
    const filename = this.selectedFile()!.name.toLowerCase();
    const tags = this.normalizedTags();
    
    // Extract potential tags from filename
    const filenameTags = filename
      .replace(/\.[^.]+$/, '') // Remove extension
      .split(/[\s_\-]+/) // Split by spaces, underscores, hyphens
      .filter(word => word.length > 2 && word.length <= 15)
      .filter(word => /^[a-z0-9]+$/.test(word)) // Only alphanumeric
      .filter(word => !tags.includes(word)) // Exclude already added tags
      .slice(0, 3); // Limit to 3 suggestions
    
    return filenameTags;
  }
}