// Tag filter component for filtering photos by tags
import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { PhotoStore } from '../../stores/photo.store';
import { TagBadgeComponent } from '../../shared/components/tag-badge/tag-badge.component';
import { TagStats } from '../../models';

@Component({
  selector: 'app-tag-filter',
  standalone: true,
  imports: [CommonModule, FormsModule, TagBadgeComponent],
  template: `
    <div class="tag-filter">
      <div class="filter-header">
        <h3 class="filter-title">
          @if (hasActiveFilters()) {
            Active Filters ({{ activeTags().length }})
          } @else {
            Filter by Tags
          }
        </h3>
        
        @if (hasActiveFilters()) {
          <button class="clear-filters" (click)="clearFilters()">
            Clear All
          </button>
        }
      </div>
      
      <div class="tag-input-container">
        <input 
          type="text" 
          class="tag-input" 
          placeholder="Search or add tags..."
          [ngModel]="tagSearch"
          (ngModelChange)="onTagSearchChange($event)"
          (keydown.enter)="addNewTag($event)"
        />
        
        @if (tagSuggestions().length > 0) {
          <div class="tag-suggestions">
            @for (tag of tagSuggestions(); track tag.name) {
              <button 
                class="suggestion-item" 
                (click)="addTagFromSuggestion(tag.name)"
              >
                {{ tag.name }} <span class="suggestion-count">({{ tag.count }})</span>
              </button>
            }
          </div>
        }
      </div>
      
      @if (popularTags().length > 0) {
        <div class="popular-tags">
          <h4 class="section-title">Popular Tags</h4>
          <div class="tags-grid">
            @for (tag of popularTags(); track tag.name) {
              <app-tag-badge 
                [tag]="tag.name"
                [active]="isActive(tag.name)"
                [clickable]="true"
                (click)="toggleTag(tag.name)"
              ></app-tag-badge>
            }
          </div>
        </div>
      }
      
      <div class="active-tags">
        <h4 class="section-title">
          @if (hasActiveFilters()) {
            Active Filters
          } @else {
            All Photos
          }
        </h4>
        
        @if (hasActiveFilters()) {
          <div class="active-tags-list">
            @for (tag of activeTags(); track tag) {
              <app-tag-badge 
                [tag]="tag"
                [active]="true"
                [removable]="true"
                (remove)="removeTag(tag)"
              ></app-tag-badge>
            }
          </div>
        } @else {
          <p class="no-filters">Showing all photos</p>
        }
      </div>
    </div>
  `,
  styles: [`
    .tag-filter {
      background-color: var(--bg-color);
      border: 1px solid var(--border-color);
      border-radius: var(--radius-md);
      padding: 16px;
      max-width: 300px;
    }
    
    .filter-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 12px;
    }
    
    .filter-title {
      font-size: 14px;
      font-weight: 600;
      color: var(--text-primary);
      margin: 0;
    }
    
    .clear-filters {
      background: none;
      border: none;
      color: var(--primary-color);
      font-size: 12px;
      cursor: pointer;
      padding: 4px;
      transition: color var(--transition-fast);
    }
    
    .clear-filters:hover {
      color: var(--primary-hover);
      text-decoration: underline;
    }
    
    .tag-input-container {
      position: relative;
      margin-bottom: 16px;
    }
    
    .tag-input {
      width: 100%;
      padding: 8px 12px;
      border: 1px solid var(--border-color);
      border-radius: var(--radius-sm);
      font-size: 14px;
      background-color: var(--bg-color);
      color: var(--text-primary);
      transition: border-color var(--transition-fast), box-shadow var(--transition-fast);
    }
    
    .tag-input:focus {
      outline: none;
      border-color: var(--primary-color);
      box-shadow: 0 0 0 2px rgba(52, 152, 219, 0.2);
    }
    
    .tag-input::placeholder {
      color: var(--text-muted);
    }
    
    .tag-suggestions {
      position: absolute;
      top: 100%;
      left: 0;
      right: 0;
      background-color: var(--bg-color);
      border: 1px solid var(--border-color);
      border-top: none;
      border-radius: 0 0 var(--radius-sm) var(--radius-sm);
      max-height: 200px;
      overflow-y: auto;
      z-index: 100;
      margin-top: -1px;
    }
    
    .suggestion-item {
      display: block;
      width: 100%;
      padding: 8px 12px;
      text-align: left;
      background: none;
      border: none;
      font-size: 13px;
      color: var(--text-primary);
      cursor: pointer;
      transition: background-color var(--transition-fast);
    }
    
    .suggestion-item:hover {
      background-color: var(--hover-bg);
    }
    
    .suggestion-count {
      color: var(--text-secondary);
      font-size: 12px;
      margin-left: 8px;
    }
    
    .popular-tags,
    .active-tags {
      margin-bottom: 16px;
    }
    
    .section-title {
      font-size: 12px;
      font-weight: 600;
      color: var(--text-secondary);
      margin-bottom: 8px;
      text-transform: uppercase;
      letter-spacing: 0.5px;
    }
    
    .tags-grid {
      display: flex;
      flex-wrap: wrap;
      gap: 6px;
    }
    
    .active-tags-list {
      display: flex;
      flex-wrap: wrap;
      gap: 6px;
    }
    
    .no-filters {
      color: var(--text-muted);
      font-size: 13px;
      margin: 0;
    }
    
    /* Dark mode adjustments */
    .dark-mode .tag-filter {
      background-color: var(--bg-color);
      border-color: var(--border-color);
    }
    
    .dark-mode .tag-input {
      background-color: var(--bg-color);
      border-color: var(--border-color);
      color: var(--text-primary);
    }
    
    .dark-mode .tag-input:focus {
      border-color: var(--primary-color);
      box-shadow: 0 0 0 2px rgba(52, 152, 219, 0.3);
    }
    
    .dark-mode .tag-suggestions {
      background-color: var(--bg-color);
      border-color: var(--border-color);
    }
    
    @media (max-width: 768px) {
      .tag-filter {
        max-width: 100%;
      }
    }
  `]
})
export class TagFilterComponent {
  private readonly photoStore = inject(PhotoStore);
  
  // Search term
  tagSearch = '';
  
  // Get data from store
  tagStats = this.photoStore.tagStats;
  activeTags = this.photoStore.activeTags;
  hasActiveFilters = this.photoStore.hasActiveFilters;
  
  // Check if tag is active
  isActive(tagName: string): boolean {
    return this.activeTags().includes(tagName);
  }
  
  // Add a tag to filter
  toggleTag(tag: string): void {
    if (this.isActive(tag)) {
      this.photoStore.removeTagFilter(tag);
    } else {
      this.photoStore.addTagFilter(tag);
    }
    this.tagSearch = '';
  }
  
  // Remove a tag from filter
  removeTag(tag: string): void {
    this.photoStore.removeTagFilter(tag);
  }
  
  // Clear all filters
  clearFilters(): void {
    this.photoStore.clearTagFilters();
  }
  
  // Handle tag search input
  onTagSearchChange(search: string): void {
    this.tagSearch = search;
  }
  
  // Add a new tag from input
  addNewTag(event: Event): void {
    event.preventDefault();
    const tag = this.tagSearch.trim().toLowerCase();
    if (tag && !this.isActive(tag)) {
      this.toggleTag(tag);
    }
    this.tagSearch = '';
  }
  
  // Add tag from suggestion
  addTagFromSuggestion(tagName: string): void {
    this.toggleTag(tagName);
    this.tagSearch = '';
  }
  
  // Get tag suggestions based on current search
  tagSuggestions(): TagStats[] {
    const search = this.tagSearch.trim().toLowerCase();
    if (!search) return [];
    
    const stats = this.tagStats();
    const matchingTags = stats.filter(tag => 
      tag.name.includes(search)
    );
    
    // Sort by count (descending) and limit to 5
    return matchingTags
      .sort((a, b) => b.count - a.count)
      .slice(0, 5);
  }
  
  // Show only top 10 popular tags
  popularTags(): TagStats[] {
    return this.tagStats().slice(0, 10);
  }
}