// Photo card component for displaying individual photos
import { Component, Input, Output, EventEmitter, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { Photo } from '../../models';
import { TagBadgeComponent } from '../../shared/components/tag-badge/tag-badge.component';
import { FileSizePipe } from '../../shared/pipes/file-size.pipe';
import { TruncatePipe } from '../../shared/pipes/truncate.pipe';
import { DateFormatPipe } from '../../shared/pipes/date-format.pipe';
import { UiStore } from '../../stores/ui.store';
import { PhotoStore } from '../../stores/photo.store';

@Component({
  selector: 'app-photo-card',
  standalone: true,
  imports: [CommonModule, RouterLink, TagBadgeComponent, FileSizePipe, DateFormatPipe, TruncatePipe],
  template: `
    <article class="photo-card" [class.selected]="selected" [class.hoverable]="hoverable">
      <div class="card-image-container">
        @if (photo.dataUrl) {
          <img 
            [src]="photo.dataUrl" 
            [alt]="photo.filename"
            class="card-image"
            (click)="onCardClick()"
          />
        } @else {
          <div class="card-image-placeholder" (click)="onCardClick()">
            <span class="placeholder-icon">&#128247;</span>
            <span class="placeholder-text">Loading...</span>
          </div>
        }
        
        @if (photo.isSynced === false) {
          <div class="card-sync-status unsynced">
            <span class="status-icon">&#9888;</span>
            <span class="status-tooltip">Not synced</span>
          </div>
        }
        
        @if (photo.syncError) {
          <div class="card-sync-status error">
            <span class="status-icon">&#10006;</span>
            <span class="status-tooltip">{{ photo.syncError }}</span>
          </div>
        }
        
        <div class="card-actions">
          <button 
            class="card-action-button detail" 
            (click)="onDetailClick($event)"
            [attr.aria-label]="'View details for ' + photo.filename"
          >
            <span class="action-icon">&#128065;</span>
          </button>
          
          <button 
            class="card-action-button delete" 
            (click)="onDeleteClick($event)"
            [attr.aria-label]="'Delete ' + photo.filename"
          >
            <span class="action-icon">&#128465;</span>
          </button>
        </div>
      </div>
      
      <div class="card-content">
        <h3 class="card-title">
          <a [routerLink]="['/gallery', photo.id]" (click)="$event.stopPropagation()">
            {{ photo.filename | truncate:20 }}
          </a>
        </h3>
        
        <div class="card-meta">
          <span class="meta-item">{{ photo.uploadedAt | dateFormat:'relative' }}</span>
          <span class="meta-separator">|</span>
          <span class="meta-item">{{ photo.size | fileSize }}</span>
          @if (photo.width > 0 && photo.height > 0) {
            <span class="meta-separator">|</span>
            <span class="meta-item">{{ photo.width }}x{{ photo.height }}</span>
          }
        </div>
        
        @if (photo.tags && photo.tags.length > 0) {
          <div class="card-tags">
            @for (tag of photo.tags.slice(0, 3); track tag) {
              <app-tag-badge 
                [tag]="tag" 
                [small]="true"
                [clickable]="true"
                (click)="onTagClick(tag)"
              ></app-tag-badge>
            }
            @if (photo.tags.length > 3) {
              <app-tag-badge 
                [tag]="'+' + (photo.tags.length - 3)" 
                [small]="true"
              ></app-tag-badge>
            }
          </div>
        }
      </div>
    </article>
  `,
  styles: [`
    .photo-card {
      background-color: var(--bg-color);
      border: 1px solid var(--border-color);
      border-radius: var(--radius-md);
      overflow: hidden;
      transition: all var(--transition-normal);
      cursor: default;
      display: flex;
      flex-direction: column;
    }
    
    .photo-card.hoverable:hover {
      transform: translateY(-4px);
      box-shadow: var(--shadow-lg);
      border-color: var(--primary-color);
    }
    
    .photo-card.selected {
      border-color: var(--primary-color);
      box-shadow: 0 0 0 2px var(--primary-color);
    }
    
    .card-image-container {
      position: relative;
      width: 100%;
      aspect-ratio: 1 / 1;
      background-color: var(--hover-bg);
      overflow: hidden;
    }
    
    .card-image {
      width: 100%;
      height: 100%;
      object-fit: cover;
      transition: transform var(--transition-normal);
    }
    
    .photo-card.hoverable:hover .card-image {
      transform: scale(1.05);
    }
    
    .card-image-placeholder {
      width: 100%;
      height: 100%;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      background-color: var(--hover-bg);
      color: var(--text-muted);
    }
    
    .placeholder-icon {
      font-size: 48px;
      margin-bottom: 8px;
      opacity: 0.7;
    }
    
    .placeholder-text {
      font-size: 12px;
      opacity: 0.8;
    }
    
    .card-sync-status {
      position: absolute;
      top: 8px;
      right: 8px;
      background-color: white;
      padding: 4px 8px;
      border-radius: 12px;
      font-size: 12px;
      box-shadow: var(--shadow-sm);
      display: flex;
      align-items: center;
      gap: 4px;
    }
    
    .card-sync-status.unsynced {
      background-color: #fff3cd;
      color: #856404;
    }
    
    .card-sync-status.error {
      background-color: #f8d7da;
      color: #721c24;
    }
    
    .status-icon {
      font-size: 14px;
    }
    
    .status-tooltip {
      display: none;
    }
    
    .card-sync-status:hover .status-tooltip {
      display: inline;
    }
    
    .card-actions {
      position: absolute;
      bottom: 8px;
      right: 8px;
      display: flex;
      gap: 4px;
      opacity: 0;
      transition: opacity var(--transition-normal);
    }
    
    .photo-card:hover .card-actions {
      opacity: 1;
    }
    
    .card-action-button {
      width: 32px;
      height: 32px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: pointer;
      border: none;
      transition: all var(--transition-fast);
      box-shadow: var(--shadow-sm);
    }
    
    .card-action-button.detail {
      background-color: rgba(255, 255, 255, 0.9);
      color: var(--text-primary);
    }
    
    .card-action-button.detail:hover {
      background-color: white;
      transform: scale(1.1);
    }
    
    .card-action-button.delete {
      background-color: rgba(231, 76, 60, 0.9);
      color: white;
    }
    
    .card-action-button.delete:hover {
      background-color: var(--danger-color);
      transform: scale(1.1);
    }
    
    .action-icon {
      font-size: 14px;
    }
    
    .card-content {
      padding: 12px;
      flex: 1;
    }
    
    .card-title {
      font-size: 14px;
      font-weight: 600;
      margin: 0 0 6px 0;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }
    
    .card-title a {
      color: var(--text-primary);
      text-decoration: none;
    }
    
    .card-title a:hover {
      color: var(--primary-color);
      text-decoration: underline;
    }
    
    .card-meta {
      display: flex;
      align-items: center;
      gap: 4px;
      font-size: 12px;
      color: var(--text-secondary);
      margin-bottom: 8px;
    }
    
    .meta-item {
      display: inline-block;
    }
    
    .meta-separator {
      color: var(--border-color);
    }
    
    .card-tags {
      display: flex;
      flex-wrap: wrap;
      gap: 4px;
    }
    
    @media (max-width: 768px) {
      .card-actions {
        opacity: 1;
      }
      
      .card-image-container {
        aspect-ratio: 4 / 3;
      }
    }
  `]
})
export class PhotoCardComponent {
  private readonly uiStore = inject(UiStore);
  private readonly photoStore = inject(PhotoStore);
  
  @Input() photo!: Photo;
  @Input() selected: boolean = false;
  @Input() hoverable: boolean = true;
  
  @Output() cardClick = new EventEmitter<Photo>();
  @Output() detailClick = new EventEmitter<Photo>();
  @Output() deleteClick = new EventEmitter<Photo>();
  @Output() tagClick = new EventEmitter<string>();
  
  onCardClick(): void {
    this.cardClick.emit(this.photo);
  }
  
  onDetailClick(event: Event): void {
    event.stopPropagation();
    this.detailClick.emit(this.photo);
  }
  
  onDeleteClick(event: Event): void {
    event.stopPropagation();
    this.deleteClick.emit(this.photo);
  }
  
  onTagClick(tag: string): void {
    this.tagClick.emit(tag);
  }
}