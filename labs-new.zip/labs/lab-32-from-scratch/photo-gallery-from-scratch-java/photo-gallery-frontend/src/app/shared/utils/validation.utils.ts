// Validation utility functions
import { 
  TAG_REGEX, 
  MAX_TAG_LENGTH, 
  MAX_TAGS_PER_PHOTO, 
  MAX_FILE_SIZE, 
  ALLOWED_CONTENT_TYPES 
} from '../../models';

// Tag validation
export function isValidTagFormat(tag: string): boolean {
  return TAG_REGEX.test(tag);
}

export function isValidTagLength(tag: string): boolean {
  return tag.length <= MAX_TAG_LENGTH && tag.length > 0;
}

export function isValidTag(tag: string): boolean {
  const normalizedTag = tag.toLowerCase().trim();
  return isValidTagFormat(normalizedTag) && isValidTagLength(normalizedTag);
}

export function validateTagList(tags: string[]): { valid: boolean; errors: string[] } {
  const errors: string[] = [];
  
  if (tags.length > MAX_TAGS_PER_PHOTO) {
    errors.push(`Maximum of ${MAX_TAGS_PER_PHOTO} tags allowed`);
  }
  
  const seenTags = new Set<string>();
  tags.forEach(tag => {
    const normalizedTag = tag.toLowerCase().trim();
    
    if (!isValidTagFormat(normalizedTag)) {
      errors.push(`Tag "${tag}" has invalid format. Only [a-z0-9_-] characters are allowed.`);
    }
    
    if (!isValidTagLength(normalizedTag)) {
      errors.push(`Tag "${tag}" exceeds maximum length of ${MAX_TAG_LENGTH} characters.`);
    }
    
    if (seenTags.has(normalizedTag)) {
      errors.push(`Duplicate tag: "${tag}"`);
    }
    seenTags.add(normalizedTag);
  });
  
  return {
    valid: errors.length === 0,
    errors
  };
}

// File validation
export function isValidFileType(file: File): boolean {
  return ALLOWED_CONTENT_TYPES.includes(file.type);
}

export function isValidFileSize(file: File): boolean {
  return file.size <= MAX_FILE_SIZE;
}

export function validateFile(file: File): { valid: boolean; errors: string[] } {
  const errors: string[] = [];
  
  if (!file) {
    errors.push('No file provided');
    return { valid: false, errors };
  }
  
  if (!isValidFileType(file)) {
    errors.push(`File type "${file.type}" is not supported. Supported types: ${ALLOWED_CONTENT_TYPES.join(', ')}`);
  }
  
  if (!isValidFileSize(file)) {
    errors.push(`File size (${formatFileSize(file.size)}) exceeds maximum limit of ${formatFileSize(MAX_FILE_SIZE)}`);
  }
  
  return {
    valid: errors.length === 0,
    errors
  };
}

// Format utilities
export function formatFileSize(bytes: number): string {
  if (bytes === 0) return '0 Bytes';
  
  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

// Normalize tag for backend compatibility
export function normalizeTag(tag: string): string {
  return tag.toLowerCase().trim();
}

// Normalize tag list
export function normalizeTagList(tags: string[]): string[] {
  return [...new Set(tags.map(normalizeTag).filter(tag => tag.length > 0))];
}

// Check if two tag lists are equal (order-independent)
export function areTagListsEqual(a: string[], b: string[]): boolean {
  if (a.length !== b.length) return false;
  
  const normalizedA = normalizeTagList(a);
  const normalizedB = normalizeTagList(b);
  
  return normalizedA.every(tag => normalizedB.includes(tag));
}

// Generate unique ID for client-side photos
export function generateClientPhotoId(): string {
  return `client-${Date.now()}-${Math.random().toString(36).substring(2, 11)}`;
}