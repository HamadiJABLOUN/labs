// Generic modal component
import { Component, Input, Output, EventEmitter, inject, ElementRef, AfterViewInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LoadingSpinnerComponent } from '../loading-spinner/loading-spinner.component';

@Component({
  selector: 'app-modal',
  standalone: true,
  imports: [CommonModule, LoadingSpinnerComponent],
  template: `
    <div class="modal-overlay" [class.open]="isOpen" (click)="onBackdropClick()">
      <div 
        class="modal"
        [class.open]="isOpen"
        [class.large]="large"
        [class.fullscreen]="fullscreen"
        (click)="$event.stopPropagation()"
        role="dialog"
        [attr.aria-modal]="isOpen ? 'true' : 'false'"
        [attr.aria-labelledby]="title ? 'modal-title' : null"
      >
        <div class="modal-header">
          <h2 id="modal-title" class="modal-title">{{ title }}</h2>
          <button 
            class="modal-close" 
            (click)="onClose()"
            [attr.aria-label]="'Close ' + (title || 'modal')"
          >
            &times;
          </button>
        </div>
        
        <div class="modal-content">
          @if (loading) {
            <app-loading-spinner [message]="loadingMessage"></app-loading-spinner>
          } @else {
            <ng-content></ng-content>
          }
        </div>
        
        @if (showFooter) {
          <div class="modal-footer">
            @if (showCancel) {
              <button 
                class="modal-button cancel" 
                (click)="onCancel()"
              >
                {{ cancelText }}
              </button>
            }
            @if (showConfirm) {
              <button 
                class="modal-button confirm" 
                [class.danger]="confirmDanger"
                (click)="onConfirm()"
                [disabled]="confirmDisabled"
              >
                {{ confirmText }}
              </button>
            }
          </div>
        }
      </div>
    </div>
  `,
  styles: [`
    .modal-overlay {
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background-color: rgba(0, 0, 0, 0.5);
      display: flex;
      align-items: center;
      justify-content: center;
      z-index: 1000;
      opacity: 0;
      visibility: hidden;
      transition: all 0.2s ease-out;
      padding: 20px;
    }
    
    .modal-overlay.open {
      opacity: 1;
      visibility: visible;
    }
    
    .modal {
      background-color: white;
      border-radius: 8px;
      box-shadow: 0 4px 20px rgba(0, 0, 0, 0.2);
      max-width: 500px;
      width: 100%;
      max-height: 90vh;
      display: flex;
      flex-direction: column;
      transform: translateY(10px);
      transition: transform 0.2s ease-out, opacity 0.2s ease-out;
      overflow: hidden;
    }
    
    .modal.open {
      transform: translateY(0);
    }
    
    .modal.large {
      max-width: 800px;
    }
    
    .modal.fullscreen {
      max-width: none;
      max-height: none;
      height: 100vh;
      width: 100vw;
      border-radius: 0;
    }
    
    .modal-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 16px 20px;
      border-bottom: 1px solid #e9ecef;
    }
    
    .modal-title {
      margin: 0;
      color: #333;
      font-size: 18px;
      font-weight: 600;
    }
    
    .modal-close {
      background: none;
      border: none;
      font-size: 24px;
      color: #666;
      cursor: pointer;
      padding: 4px 8px;
      line-height: 1;
      transition: color 0.2s ease;
    }
    
    .modal-close:hover {
      color: #333;
    }
    
    .modal-close:focus {
      outline: 2px solid #3498db;
      outline-offset: 2px;
      border-radius: 2px;
    }
    
    .modal-content {
      flex: 1;
      overflow-y: auto;
      padding: 20px;
      display: flex;
      flex-direction: column;
      gap: 16px;
    }
    
    .modal-content::-webkit-scrollbar {
      width: 8px;
    }
    
    .modal-content::-webkit-scrollbar-track {
      background: #f1f1f1;
    }
    
    .modal-content::-webkit-scrollbar-thumb {
      background: #ccc;
      border-radius: 4px;
    }
    
    .modal-content::-webkit-scrollbar-thumb:hover {
      background: #aaa;
    }
    
    .modal-footer {
      display: flex;
      justify-content: flex-end;
      gap: 12px;
      padding: 16px 20px;
      border-top: 1px solid #e9ecef;
    }
    
    .modal-button {
      padding: 8px 16px;
      border-radius: 4px;
      font-size: 14px;
      font-weight: 500;
      cursor: pointer;
      border: none;
      transition: all 0.2s ease;
    }
    
    .modal-button.cancel {
      background-color: #f8f9fa;
      color: #666;
      border: 1px solid #ddd;
    }
    
    .modal-button.cancel:hover {
      background-color: #e9ecef;
    }
    
    .modal-button.confirm {
      background-color: #3498db;
      color: white;
    }
    
    .modal-button.confirm:hover:not(:disabled) {
      background-color: #2980b9;
    }
    
    .modal-button.confirm.danger {
      background-color: #e74c3c;
    }
    
    .modal-button.confirm.danger:hover:not(:disabled) {
      background-color: #c0392b;
    }
    
    .modal-button:disabled {
      opacity: 0.6;
      cursor: not-allowed;
    }
    
    .modal-button:focus:not(:disabled) {
      outline: 2px solid #3498db;
      outline-offset: 2px;
    }
    
    @media (max-width: 768px) {
      .modal {
        margin: 10px;
        max-height: calc(100vh - 40px);
      }
      
      .modal.large {
        max-width: calc(100vw - 20px);
      }
      
      .modal-footer {
        flex-direction: column-reverse;
      }
      
      .modal-button {
        width: 100%;
      }
    }
  `]
})
export class ModalComponent implements AfterViewInit, OnDestroy {
  private readonly elementRef = inject(ElementRef);
  
  @Input() isOpen: boolean = false;
  @Input() title: string = '';
  @Input() large: boolean = false;
  @Input() fullscreen: boolean = false;
  @Input() loading: boolean = false;
  @Input() loadingMessage: string = 'Loading...';
  @Input() showFooter: boolean = true;
  @Input() showCancel: boolean = true;
  @Input() showConfirm: boolean = true;
  @Input() confirmText: string = 'Confirm';
  @Input() cancelText: string = 'Cancel';
  @Input() confirmDanger: boolean = false;
  @Input() confirmDisabled: boolean = false;
  
  @Output() closed = new EventEmitter<void>();
  @Output() confirmed = new EventEmitter<void>();
  @Output() cancelled = new EventEmitter<void>();
  
  ngAfterViewInit(): void {
    this.setupFocusTrap();
  }
  
  ngOnDestroy(): void {
    this.cleanupFocusTrap();
  }
  
  onClose(): void {
    this.isOpen = false;
    this.closed.emit();
    this.restoreFocus();
  }
  
  onConfirm(): void {
    this.confirmed.emit();
  }
  
  onCancel(): void {
    this.cancelled.emit();
    this.onClose();
  }
  
  onBackdropClick(): void {
    if (this.isOpen) {
      this.onClose();
    }
  }
  
  // ========== Focus Management ==========
  
  private previousActiveElement: HTMLElement | null = null;
  private focusTrapInterval: number | null = null;
  
  private setupFocusTrap(): void {
    if (!this.isOpen) return;
    
    // Store the currently focused element
    this.previousActiveElement = document.activeElement as HTMLElement;
    
    // Focus the modal when opened
    const modalElement = (this.elementRef.nativeElement as HTMLElement).querySelector<HTMLElement>('.modal');
    if (modalElement) {
      modalElement.focus();
    }
    
    // Set up focus trap
    this.focusTrapInterval = window.setInterval(() => {
      this.trapFocus();
    }, 50);
  }
  
  private trapFocus(): void {
    if (!this.isOpen) return;
    
    const modalElement = (this.elementRef.nativeElement as HTMLElement).querySelector<HTMLElement>('.modal');
    if (!modalElement) return;
    
    const focusableElements = modalElement.querySelectorAll<HTMLElement>(
      'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])'
    );
    
    const firstElement = focusableElements[0];
    const lastElement = focusableElements[focusableElements.length - 1];
    
    const activeElement = document.activeElement as HTMLElement;
    
    // If modal doesn't contain focus, focus the first element
    if (!modalElement.contains(activeElement)) {
      firstElement?.focus();
      return;
    }
    
    // If we're at the first element and pressing Shift+Tab, wrap to last
    if (activeElement === firstElement && document.activeElement === firstElement) {
      // This check is a bit redundant but ensures we're handling it correctly
    }
  }
  
  private restoreFocus(): void {
    if (this.previousActiveElement) {
      this.previousActiveElement.focus();
      this.previousActiveElement = null;
    }
  }
  
  private cleanupFocusTrap(): void {
    if (this.focusTrapInterval) {
      clearInterval(this.focusTrapInterval);
      this.focusTrapInterval = null;
    }
    this.restoreFocus();
  }
}