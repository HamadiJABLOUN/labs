// Loading spinner component
import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-loading-spinner',
  standalone: true,
  template: `
    <div class="spinner-container" [class.small]="small" [class.large]="large">
      <div class="spinner" [class.small]="small" [class.large]="large"></div>
      @if (message) {
        <span class="spinner-message">{{ message }}</span>
      }
    </div>
  `,
  styles: [`
    .spinner-container {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      gap: 8px;
    }
    
    .spinner {
      border: 4px solid rgba(0, 0, 0, 0.1);
      border-radius: 50%;
      border-top-color: #3498db;
      animation: spin 1s ease-in-out infinite;
    }
    
    .spinner.small {
      width: 20px;
      height: 20px;
      border-width: 2px;
    }
    
    .spinner.large {
      width: 60px;
      height: 60px;
      border-width: 6px;
    }
    
    .spinner:not(.small):not(.large) {
      width: 40px;
      height: 40px;
    }
    
    .spinner-message {
      font-size: 14px;
      color: #666;
      font-weight: 500;
    }
    
    @keyframes spin {
      to { transform: rotate(360deg); }
    }
  `]
})
export class LoadingSpinnerComponent {
  @Input() small: boolean = false;
  @Input() large: boolean = false;
  @Input() message: string = '';
}