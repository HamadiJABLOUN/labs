// Tag badge component for displaying photo tags
import { Component, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-tag-badge',
  standalone: true,
  template: `
    <span 
      class="tag-badge"
      [class.clickable]="clickable"
      [class.active]="active"
      [class.small]="small"
      [class.large]="large"
      (click)="onClick()"
      [attr.aria-label]="tag + (clickable ? ', click to filter' : '')"
      tabindex="0"
      (keydown.enter)="onClick()"
      (keydown.space)="onClick()"
    >
      {{ tag }}
      @if (removable) {
        <button 
          class="remove-button" 
          (click)="onRemove($event)"
          [attr.aria-label]="'Remove ' + tag + ' tag'"
        >
          &times;
        </button>
      }
    </span>
  `,
  styles: [`
    .tag-badge {
      display: inline-flex;
      align-items: center;
      gap: 4px;
      padding: 4px 8px;
      background-color: #e0f2fe;
      color: #0369a1;
      border-radius: 12px;
      font-size: 12px;
      font-weight: 500;
      line-height: 1;
      white-space: nowrap;
      cursor: default;
      transition: all 0.2s ease;
    }
    
    .tag-badge.clickable {
      cursor: pointer;
    }
    
    .tag-badge.clickable:hover {
      background-color: #bae6fd;
      transform: translateY(-1px);
    }
    
    .tag-badge.active {
      background-color: #0369a1;
      color: white;
    }
    
    .tag-badge.small {
      padding: 2px 6px;
      font-size: 10px;
    }
    
    .tag-badge.large {
      padding: 6px 12px;
      font-size: 14px;
    }
    
    .remove-button {
      background: none;
      border: none;
      color: inherit;
      font-size: 14px;
      cursor: pointer;
      padding: 0 0 0 4px;
      margin-left: 2px;
      line-height: 1;
      opacity: 0.7;
      transition: opacity 0.2s ease;
    }
    
    .remove-button:hover {
      opacity: 1;
    }
    
    .remove-button:focus {
      outline: 2px solid currentColor;
      outline-offset: 1px;
      border-radius: 2px;
    }
  `]
})
export class TagBadgeComponent {
  @Input() tag: string = '';
  @Input() active: boolean = false;
  @Input() clickable: boolean = false;
  @Input() removable: boolean = false;
  @Input() small: boolean = false;
  @Input() large: boolean = false;
  
  @Output() click = new EventEmitter<string>();
  @Output() remove = new EventEmitter<string>();
  
  onClick(): void {
    if (this.clickable) {
      this.click.emit(this.tag);
    }
  }
  
  onRemove(event: Event): void {
    event.stopPropagation();
    this.remove.emit(this.tag);
  }
}