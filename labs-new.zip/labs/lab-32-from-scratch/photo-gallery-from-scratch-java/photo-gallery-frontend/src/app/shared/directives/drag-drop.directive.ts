// Directive for drag and drop file upload functionality
import { 
  Directive, 
  HostListener, 
  Output, 
  EventEmitter, 
  HostBinding,
  Input
} from '@angular/core';

@Directive({
  selector: '[appDragDrop]',
  standalone: true
})
export class DragDropDirective {
  @Input() disabled: boolean = false;
  @Output() filesDropped = new EventEmitter<File[]>();
  @Output() fileHover = new EventEmitter<boolean>();
  
  private isDragging: boolean = false;
  
  @HostBinding('class.drag-over') get dragOverClass(): boolean {
    return this.isDragging && !this.disabled;
  }
  
  constructor() {}
  
  @HostListener('dragover', ['$event'])
  onDragOver(event: DragEvent): void {
    if (this.disabled) return;
    
    event.preventDefault();
    event.stopPropagation();
    
    if (event.dataTransfer) {
      event.dataTransfer.dropEffect = 'copy';
    }
    
    if (!this.isDragging) {
      this.isDragging = true;
      this.fileHover.emit(true);
    }
  }
  
  @HostListener('dragleave', ['$event'])
  onDragLeave(event: DragEvent): void {
    if (this.disabled) return;
    
    event.preventDefault();
    event.stopPropagation();
    
    this.isDragging = false;
    this.fileHover.emit(false);
  }
  
  @HostListener('drop', ['$event'])
  onDrop(event: DragEvent): void {
    if (this.disabled) return;
    
    event.preventDefault();
    event.stopPropagation();
    
    this.isDragging = false;
    this.fileHover.emit(false);
    
    if (event.dataTransfer) {
      const files = this.getValidFiles(event.dataTransfer.files);
      if (files.length > 0) {
        this.filesDropped.emit(files);
      }
    }
  }
  
  @HostListener('dragend', ['$event'])
  onDragEnd(event: DragEvent): void {
    if (this.disabled) return;
    
    event.preventDefault();
    event.stopPropagation();
    
    this.isDragging = false;
    this.fileHover.emit(false);
  }
  
  private getValidFiles(fileList: FileList): File[] {
    const validFiles: File[] = [];
    const validTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
    
    for (let i = 0; i < fileList.length; i++) {
      const file = fileList[i];
      if (validTypes.includes(file.type)) {
        validFiles.push(file);
      }
    }
    
    return validFiles;
  }
}