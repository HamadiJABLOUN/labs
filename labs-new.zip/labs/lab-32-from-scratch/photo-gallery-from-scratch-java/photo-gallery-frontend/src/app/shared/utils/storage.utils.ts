// LocalStorage utility functions
import { STORAGE_KEYS } from '../../core/constants/app.constants';

// Base LocalStorage wrapper with error handling
export class StorageWrapper {
  private readonly key: string;
  
  constructor(key: string) {
    this.key = key;
  }
  
  get<T>(): T | null {
    try {
      const data = localStorage.getItem(this.key);
      return data ? JSON.parse(data) : null;
    } catch (error) {
      console.error(`Failed to read from LocalStorage key "${this.key}":`, error);
      return null;
    }
  }
  
  set<T>(value: T): boolean {
    try {
      localStorage.setItem(this.key, JSON.stringify(value));
      return true;
    } catch (error) {
      console.error(`Failed to write to LocalStorage key "${this.key}":`, error);
      return false;
    }
  }
  
  remove(): boolean {
    try {
      localStorage.removeItem(this.key);
      return true;
    } catch (error) {
      console.error(`Failed to remove LocalStorage key "${this.key}":`, error);
      return false;
    }
  }
  
  clear(): boolean {
    return this.remove();
  }
}

// Photo storage utilities
export const photoStorage = new StorageWrapper(STORAGE_KEYS.PHOTOS);
export const lastSyncStorage = new StorageWrapper(STORAGE_KEYS.LAST_SYNC);
export const preferencesStorage = new StorageWrapper(STORAGE_KEYS.USER_PREFERENCES);
export const filterStateStorage = new StorageWrapper(STORAGE_KEYS.FILTER_STATE);

// Type-safe storage access
export function getStoredPhotos(): any[] {
  return photoStorage.get<any[]>() || [];
}

export function setStoredPhotos(photos: any[]): boolean {
  return photoStorage.set(photos);
}

export function getLastSyncTimestamp(): number | null {
  return lastSyncStorage.get<number>() || null;
}

export function setLastSyncTimestamp(timestamp: number): boolean {
  return lastSyncStorage.set(timestamp);
}

// Check if LocalStorage is available
export function isLocalStorageAvailable(): boolean {
  try {
    const testKey = '__test__';
    localStorage.setItem(testKey, testKey);
    localStorage.removeItem(testKey);
    return true;
  } catch (error) {
    return false;
  }
}

// Check storage usage
export function getStorageUsage(): { used: number; max: number; percentage: number } {
  if (!isLocalStorageAvailable()) {
    return { used: 0, max: 0, percentage: 0 };
  }
  
  let used = 0;
  
  for (let i = 0; i < localStorage.length; i++) {
    const key = localStorage.key(i);
    if (key) {
      used += localStorage.getItem(key)?.length || 0;
    }
  }
  
  // Estimate max storage (typically 5MB)
  const max = 5 * 1024 * 1024;
  const percentage = (used / max) * 100;
  
  return { used, max, percentage };
}

// Storage limit warnings
export function checkStorageLimit(data: string): boolean {
  const storage = getStorageUsage();
  const additionalSize = data.length;
  const totalUsage = storage.used + additionalSize;
  
  // Warn if usage would exceed 80% of max
  return totalUsage < (storage.max * 0.8);
}

// LRU cache implementation for photos
export interface LRUCacheItem<T> {
  data: T;
  timestamp: number;
}

export class LRUCache<T> {
  private readonly maxSize: number;
  private cache = new Map<string, LRUCacheItem<T>>();
  
  constructor(maxSize: number = 100) {
    this.maxSize = maxSize;
  }
  
  get(key: string): T | undefined {
    const item = this.cache.get(key);
    if (!item) return undefined;
    
    // Update access time
    this.cache.delete(key);
    this.cache.set(key, { ...item, timestamp: Date.now() });
    
    return item.data;
  }
  
  set(key: string, data: T): void {
    // If key exists, delete it first
    if (this.cache.has(key)) {
      this.cache.delete(key);
    } else if (this.cache.size >= this.maxSize) {
      // Remove least recently used item
      const oldestKey = this.getOldestKey();
      if (oldestKey) {
        this.cache.delete(oldestKey);
      }
    }
    
    this.cache.set(key, { data, timestamp: Date.now() });
  }
  
  delete(key: string): boolean {
    return this.cache.delete(key);
  }
  
  clear(): void {
    this.cache.clear();
  }
  
  size(): number {
    return this.cache.size;
  }
  
  private getOldestKey(): string | undefined {
    let oldestKey: string | undefined;
    let oldestTimestamp = Infinity;
    
    for (const [key, item] of this.cache.entries()) {
      if (item.timestamp < oldestTimestamp) {
        oldestTimestamp = item.timestamp;
        oldestKey = key;
      }
    }
    
    return oldestKey;
  }
}

// Shared LRU cache for photo thumbnails
export const thumbnailCache = new LRUCache<string>(50);