// Image utility functions

export function fileToDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    
    reader.onload = () => {
      const result = reader.result as string;
      resolve(result);
    };
    
    reader.onerror = () => {
      reject(new Error('Failed to read file as data URL'));
    };
    
    reader.readAsDataURL(file);
  });
}

export function getImageDimensions(dataUrl: string): Promise<{ width: number; height: number }> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    
    img.onload = () => {
      resolve({
        width: img.width,
        height: img.height
      });
    };
    
    img.onerror = () => {
      reject(new Error('Failed to load image for dimension measurement'));
    };
    
    img.src = dataUrl;
  });
}

export async function getImageDimensionsFromFile(file: File): Promise<{ width: number; height: number }> {
  const dataUrl = await fileToDataUrl(file);
  return getImageDimensions(dataUrl);
}

export function isImageFile(file: File): boolean {
  return file.type.startsWith('image/');
}

export function getFileExtension(filename: string): string {
  return filename.slice((filename.lastIndexOf('.') + 1)).toLowerCase();
}

export function isValidImageExtension(extension: string): boolean {
  const validExtensions = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
  return validExtensions.includes(extension.toLowerCase());
}

export function compressImage(dataUrl: string, maxWidth: number, maxHeight: number, quality: number = 0.8): Promise<string> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    
    img.onload = () => {
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      
      if (!ctx) {
        reject(new Error('Failed to create canvas context'));
        return;
      }
      
      // Calculate scaled dimensions
      let width = img.width;
      let height = img.height;
      
      if (width > maxWidth || height > maxHeight) {
        const ratio = Math.min(maxWidth / width, maxHeight / height);
        width = Math.floor(width * ratio);
        height = Math.floor(height * ratio);
      }
      
      canvas.width = width;
      canvas.height = height;
      
      ctx.drawImage(img, 0, 0, width, height);
      
      try {
        const compressedDataUrl = canvas.toDataURL('image/jpeg', quality);
        resolve(compressedDataUrl);
      } catch (error) {
        reject(new Error('Failed to compress image'));
      }
    };
    
    img.onerror = () => {
      reject(new Error('Failed to load image for compression'));
    };
    
    img.src = dataUrl;
  });
}

export function createObjectUrl(file: File): string {
  return URL.createObjectURL(file);
}

export function revokeObjectUrl(url: string): void {
  URL.revokeObjectURL(url);
}

// Generate a thumbnail from a data URL
export async function createThumbnail(dataUrl: string, maxWidth: number = 200, maxHeight: number = 200): Promise<string> {
  return compressImage(dataUrl, maxWidth, maxHeight, 0.7);
}