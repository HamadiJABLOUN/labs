// Confirm dialog component for deletion and other confirmations
import { Component, Input, Output, EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-confirm-dialog',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="confirm-dialog-overlay" (click)="onCancel()">
      <div class="confirm-dialog" (click)="$event.stopPropagation()">
        <h3 class="confirm-title">{{ title }}</h3>
        <div class="confirm-message">{{ message }}</div>
        
        @if (details) {
          <div class="confirm-details">{{ details }}</div>
        }
        
        <div class="confirm-actions">
          <button 
            class="confirm-button cancel" 
            (click)="onCancel()"
          >
            {{ cancelText }}
          </button>
          <button 
            class="confirm-button confirm" 
            [class.danger]="danger"
            (click)="onConfirm()"
          >
            {{ confirmText }}
          </button>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .confirm-dialog-overlay {
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background-color: rgba(0, 0, 0, 0.5);
      display: flex;
      align-items: center;
      justify-content: center;
      z-index: 1000;
      padding: 20px;
    }
    
    .confirm-dialog {
      background-color: white;
      border-radius: 8px;
      box-shadow: 0 4px 20px rgba(0, 0, 0, 0.2);
      padding: 24px;
      max-width: 400px;
      width: 100%;
      animation: fadeIn 0.2s ease-out;
    }
    
    .confirm-title {
      margin: 0 0 12px 0;
      color: #333;
      font-size: 18px;
      font-weight: 600;
    }
    
    .confirm-message {
      margin: 0 0 16px 0;
      color: #666;
      font-size: 14px;
      line-height: 1.5;
    }
    
    .confirm-details {
      margin: 0 0 16px 0;
      padding: 12px;
      background-color: #f8f9fa;
      border-radius: 4px;
      font-size: 13px;
      color: #555;
      border-left: 3px solid #3498db;
    }
    
    .confirm-actions {
      display: flex;
      gap: 12px;
      justify-content: flex-end;
    }
    
    .confirm-button {
      padding: 8px 16px;
      border-radius: 4px;
      font-size: 14px;
      font-weight: 500;
      cursor: pointer;
      border: none;
      transition: all 0.2s ease;
    }
    
    .confirm-button.cancel {
      background-color: #f8f9fa;
      color: #666;
      border: 1px solid #ddd;
    }
    
    .confirm-button.cancel:hover {
      background-color: #e9ecef;
    }
    
    .confirm-button.confirm {
      background-color: #3498db;
      color: white;
    }
    
    .confirm-button.confirm:hover {
      background-color: #2980b9;
    }
    
    .confirm-button.confirm.danger {
      background-color: #e74c3c;
    }
    
    .confirm-button.confirm.danger:hover {
      background-color: #c0392b;
    }
    
    .confirm-button:focus {
      outline: 2px solid #3498db;
      outline-offset: 2px;
    }
    
    @keyframes fadeIn {
      from {
        opacity: 0;
        transform: translateY(-10px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }
    
    @media (max-width: 480px) {
      .confirm-dialog {
        margin: 10px;
        padding: 20px;
      }
      
      .confirm-actions {
        flex-direction: column-reverse;
      }
      
      .confirm-button {
        width: 100%;
      }
    }
  `]
})
export class ConfirmDialogComponent {
  @Input() title: string = 'Confirm';
  @Input() message: string = 'Are you sure you want to perform this action?';
  @Input() details: string = '';
  @Input() confirmText: string = 'Confirm';
  @Input() cancelText: string = 'Cancel';
  @Input() danger: boolean = false;
  
  @Output() confirmed = new EventEmitter<void>();
  @Output() cancelled = new EventEmitter<void>();
  
  onConfirm(): void {
    this.confirmed.emit();
  }
  
  onCancel(): void {
    this.cancelled.emit();
  }
}