import { isDevMode } from '@angular/core';

// Application constants
export const APP_NAME = 'Photo Gallery';
export const APP_VERSION = '1.0.0';
export const APP_DESCRIPTION = 'A simple photo gallery application for uploading, tagging, and managing photos';

// Development settings
export const IS_DEVELOPMENT = isDevMode();
export const IS_PRODUCTION = !isDevMode();

// LocalStorage keys
export const STORAGE_KEYS = {
  PHOTOS: 'photo-gallery-photos',
  LAST_SYNC: 'photo-gallery-last-sync',
  USER_PREFERENCES: 'photo-gallery-preferences',
  FILTER_STATE: 'photo-gallery-filter-state'
} as const;

// API configuration
export const API_BASE_URL = '/api';
export const API_TIMEOUT = 30000; // 30 seconds

export const API_ENDPOINTS = {
  PHOTOS: '/api/photos',
  PHOTO_BY_ID: (id: string) => `/api/photos/${id}`,
  PHOTO_TAGS: (id: string) => `/api/photos/${id}/tags`,
  PHOTO_TAG: (id: string, tag: string) => `/api/photos/${id}/tags/${tag}`
} as const;

// UI configuration
export const UI_CONFIG = {
  MAX_PHOTOS_PER_PAGE: 20,
  MAX_TAG_BADGES_VISIBLE: 5,
  DEFAULT_SORT_BY: 'uploadedAt' as const,
  DEFAULT_SORT_DIRECTION: 'desc' as const
};

// Animation durations
export const ANIMATION_DURATIONS = {
  FADE: 200,
  SLIDE: 300,
  MODAL: 200
};

// File upload configuration
export const UPLOAD_CONFIG = {
  CHUNK_SIZE: 5 * 1024 * 1024, // 5MB chunks
  MAX_CONCURRENT_UPLOADS: 3,
  RETRY_ATTEMPTS: 3
};