// Guard to prevent navigation when there are unsaved changes
import { Injectable, inject } from '@angular/core';
import { CanDeactivateFn } from '@angular/router';
import { Observable, of } from 'rxjs';

export interface HasUnsavedChanges {
  hasUnsavedChanges: () => boolean;
}

export const unsavedChangesGuard: CanDeactivateFn<HasUnsavedChanges> = (
  component: HasUnsavedChanges
) => {
  // Check if there are unsaved changes
  if (component.hasUnsavedChanges && component.hasUnsavedChanges()) {
    // Return observable that resolves to true if user confirms, false otherwise
    const confirm = window.confirm(
      'You have unsaved changes. Are you sure you want to leave?'
    );
    return of(confirm);
  }
  
  // No unsaved changes, allow navigation
  return of(true);
};