// HTTP error interceptor for centralized error handling
import { 
  Injectable, 
  inject 
} from '@angular/core';
import { 
  HttpInterceptorFn, 
  HttpErrorResponse,
  HttpRequest,
  HttpHandlerFn
} from '@angular/common/http';
import { throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { UiStore } from '../../stores/ui.store';

export const httpErrorInterceptor: HttpInterceptorFn = (req: HttpRequest<any>, next: HttpHandlerFn) => {
  const uiStore = inject(UiStore);
  
  return next(req).pipe(
    catchError((error: HttpErrorResponse) => {
      // Handle the error
      handleHttpError(error, uiStore);
      return throwError(() => error);
    })
  );
};

function handleHttpError(error: HttpErrorResponse, uiStore: UiStore): void {
  let errorMessage = 'An unknown error occurred';
  let errorType: 'network' | 'validation' | 'storage' | 'unknown' = 'unknown';
  
  if (error.error instanceof ErrorEvent) {
    // Client-side error
    errorMessage = `Network error: ${error.error.message}`;
    errorType = 'network';
  } else {
    // Server-side error
    switch (error.status) {
      case 0:
        errorMessage = 'Network connection failed. Please check your internet connection.';
        errorType = 'network';
        break;
      case 400:
        errorMessage = getValidationErrorMessage(error);
        errorType = 'validation';
        break;
      case 401:
        errorMessage = 'Unauthorized. Please login.';
        break;
      case 403:
        errorMessage = 'Forbidden. You do not have permission.';
        break;
      case 404:
        errorMessage = 'Resource not found.';
        break;
      case 409:
        errorMessage = 'Conflict. The resource already exists.';
        break;
      case 413:
        errorMessage = 'File too large. Maximum size exceeded.';
        errorType = 'validation';
        break;
      case 415:
        errorMessage = 'Unsupported media type. Please upload a valid image file.';
        errorType = 'validation';
        break;
      case 422:
        errorMessage = getValidationErrorMessage(error);
        errorType = 'validation';
        break;
      case 429:
        errorMessage = 'Too many requests. Please wait before trying again.';
        break;
      case 500:
        errorMessage = 'Internal server error. Please try again later.';
        break;
      case 502:
        errorMessage = 'Bad gateway. The server is temporarily unavailable.';
        break;
      case 503:
        errorMessage = 'Service unavailable. Please try again later.';
        break;
      default:
        errorMessage = error.message || 'An unexpected error occurred';
    }
  }
  
  // Add error to UI store
  uiStore.addSimpleError(errorMessage, errorType);
  
  // Also show a notification for critical errors
  if (error.status >= 500 || error.status === 0) {
    uiStore.addErrorNotification(errorMessage, 5000);
  }
}

function getValidationErrorMessage(error: HttpErrorResponse): string {
  // Try to extract validation errors from response
  if (error.error && typeof error.error === 'object') {
    if ('message' in error.error) {
      return String(error.error.message);
    }
    if ('error' in error.error) {
      return String(error.error.error);
    }
    if ('messages' in error.error) {
      const messages = (error.error as any).messages;
      if (Array.isArray(messages)) {
        return messages.join(', ');
      }
      return String(messages);
    }
  }
  
  // Fallback to status text
  return error.statusText || 'Validation failed';
}