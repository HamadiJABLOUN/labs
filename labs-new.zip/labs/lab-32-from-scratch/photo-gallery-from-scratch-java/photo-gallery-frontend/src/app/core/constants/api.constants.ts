// API-specific constants that mirror backend limits from SPECIFICATION.md
import { MAX_FILE_SIZE, ALLOWED_CONTENT_TYPES, MAX_TAG_LENGTH, MAX_TAGS_PER_PHOTO } from '../../models';

// Validation messages
export const VALIDATION_MESSAGES = {
  FILE_TOO_LARGE: `File size exceeds maximum limit of ${MAX_FILE_SIZE / (1024 * 1024)}MB`,
  INVALID_FILE_TYPE: `File type must be one of: ${ALLOWED_CONTENT_TYPES.join(', ')}`,
  NO_FILE_PROVIDED: 'Please select a file to upload',
  INVALID_TAG_FORMAT: `Tag must match pattern [a-z0-9_-]+ and be ${MAX_TAG_LENGTH} characters or less`,
  TOO_MANY_TAGS: `Maximum of ${MAX_TAGS_PER_PHOTO} tags allowed`,
  DUPLICATE_TAG: 'This tag is already added',
  EMPTY_TAG: 'Tag cannot be empty'
};

// HTTP status codes
export const HTTP_STATUS = {
  SUCCESS: 200,
  CREATED: 201,
  NO_CONTENT: 204,
  BAD_REQUEST: 400,
  UNAUTHORIZED: 401,
  FORBIDDEN: 403,
  NOT_FOUND: 404,
  UNSUPPORTED_MEDIA_TYPE: 415,
  INTERNAL_SERVER_ERROR: 500,
  SERVICE_UNAVAILABLE: 503
};

// HTTP status messages
export const HTTP_STATUS_MESSAGES: Record<number, string> = {
  [HTTP_STATUS.SUCCESS]: 'Success',
  [HTTP_STATUS.CREATED]: 'Created successfully',
  [HTTP_STATUS.NO_CONTENT]: 'Deleted successfully',
  [HTTP_STATUS.BAD_REQUEST]: 'Bad request',
  [HTTP_STATUS.UNAUTHORIZED]: 'Unauthorized',
  [HTTP_STATUS.FORBIDDEN]: 'Forbidden',
  [HTTP_STATUS.NOT_FOUND]: 'Resource not found',
  [HTTP_STATUS.UNSUPPORTED_MEDIA_TYPE]: 'Unsupported media type',
  [HTTP_STATUS.INTERNAL_SERVER_ERROR]: 'Internal server error',
  [HTTP_STATUS.SERVICE_UNAVAILABLE]: 'Service unavailable'
};

// Error types
export type ApiErrorType = 
  | 'network'
  | 'validation'
  | 'not_found'
  | 'unsupported_media'
  | 'file_too_large'
  | 'storage_error'
  | 'unknown';

// Network error messages
export const NETWORK_ERRORS = {
  NETWORK_ERROR: 'Network connection failed. Please check your internet connection.',
  TIMEOUT: 'Request timed out. Please try again.',
  SERVER_ERROR: 'Server error. Please try again later.',
  UNKNOWN_ERROR: 'An unknown error occurred. Please try again.'
};