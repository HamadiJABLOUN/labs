// Unwraps the backend ApiResponse envelope ({ success, message, data, timestamp })
import { HttpInterceptorFn, HttpResponse } from '@angular/common/http';
import { map } from 'rxjs/operators';

export const apiResponseInterceptor: HttpInterceptorFn = (req, next) =>
  next(req).pipe(
    map(event => {
      if (event instanceof HttpResponse) {
        const body = event.body as { success?: unknown; data?: unknown } | null;
        if (body && typeof body === 'object' && 'success' in body && 'data' in body) {
          return event.clone({ body: body.data });
        }
      }
      return event;
    })
  );
