// ========== API DTOs ==========
// These interfaces match the backend API responses from SPECIFICATION.md

export interface ApiPhoto {
  id: string;
  filename: string;
  originalFilename: string;
  contentType: string;
  fileSize: number;
  width: number;
  height: number;
  uploadDate: string;            // ISO 8601 date string
  tags: string[];
  filePath: string;             // Server file path
}

// DTO for API requests
export interface UploadPhotoRequest {
  file: File;
  tags?: string[];
}

// Pagination response
export interface PageResponse<T> {
  content: T[];
  totalElements: number;
  totalPages: number;
  last: boolean;
  first: boolean;
  size: number;
  number: number;
  empty: boolean;
}

// Photo page response
export interface PhotoPageResponse {
  content: ApiPhoto[];
  totalElements: number;
  totalPages: number;
  last: boolean;
  first: boolean;
  size: number;
  number: number;
  empty: boolean;
}

// Tag operations
export interface UpdateTagsRequest {
  tags: string[];
}

// Error response
export interface ApiError {
  timestamp: string;
  status: number;
  error: string;
  message: string;
  path: string;
}

// ========== Type Guards ==========
export function isApiPhoto(obj: unknown): obj is ApiPhoto {
  return typeof obj === 'object' && obj !== null &&
    'id' in obj && typeof obj.id === 'string' &&
    'filename' in obj && typeof obj.filename === 'string' &&
    'contentType' in obj && typeof obj.contentType === 'string' &&
    'fileSize' in obj && typeof obj.fileSize === 'number' &&
    'uploadDate' in obj && typeof obj.uploadDate === 'string' &&
    'tags' in obj && Array.isArray(obj.tags);
}

export function isPageResponse<T>(obj: unknown): obj is PageResponse<T> {
  return typeof obj === 'object' && obj !== null &&
    'content' in obj && Array.isArray(obj.content) &&
    'totalElements' in obj && typeof obj.totalElements === 'number' &&
    'totalPages' in obj && typeof obj.totalPages === 'number' &&
    'size' in obj && typeof obj.size === 'number' &&
    'number' in obj && typeof obj.number === 'number';
}

export function isApiError(obj: unknown): obj is ApiError {
  return typeof obj === 'object' && obj !== null &&
    'status' in obj && typeof obj.status === 'number' &&
    'error' in obj && typeof obj.error === 'string' &&
    'message' in obj && typeof obj.message === 'string';
}

// ========== Conversion Functions ==========
// Convert API photo to frontend Photo model
import { Photo } from './photo.model';

export function apiPhotoToPhoto(apiPhoto: ApiPhoto): Photo {
  return {
    id: apiPhoto.id,
    filename: apiPhoto.filename,
    originalFilename: apiPhoto.originalFilename,
    dataUrl: '', // Will be populated separately
    contentType: apiPhoto.contentType,
    size: apiPhoto.fileSize,
    width: apiPhoto.width,
    height: apiPhoto.height,
    uploadedAt: new Date(apiPhoto.uploadDate),
    tags: apiPhoto.tags,
    isSynced: true
  };
}

// Convert frontend Photo to API upload request (for creating new photos)
export function photoToUploadRequest(photo: Partial<Photo>, file: File): UploadPhotoRequest {
  return {
    file: file,
    tags: photo.tags
  };
}