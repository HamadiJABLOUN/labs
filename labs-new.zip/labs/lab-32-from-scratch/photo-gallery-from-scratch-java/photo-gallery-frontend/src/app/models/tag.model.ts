// ========== Tag Entity ==========
export interface Tag {
  id: number;                   // Primary Key (from backend)
  name: string;                 // Tag name (lowercase, normalized)
}

// ========== Tag Statistics ==========
export interface TagStats {
  name: string;                 // Tag name (lowercase)
  count: number;               // Number of photos with this tag
}

// ========== Tag Filter ==========
export interface TagFilter {
  name: string;
  isActive: boolean;
}

// ========== Type Guards ==========
export function isTag(obj: unknown): obj is Tag {
  return typeof obj === 'object' && obj !== null &&
    'id' in obj && typeof obj.id === 'number' &&
    'name' in obj && typeof obj.name === 'string';
}

export function isTagStats(obj: unknown): obj is TagStats {
  return typeof obj === 'object' && obj !== null &&
    'name' in obj && typeof obj.name === 'string' &&
    'count' in obj && typeof obj.count === 'number';
}

// ========== Helper Functions ==========
export function normalizeTag(tag: string): string {
  return tag.toLowerCase().trim();
}

export function createTag(name: string): Tag {
  return {
    id: Date.now(), // Temporary ID, will be replaced by backend
    name: normalizeTag(name)
  };
}

export function sortTagsByName(tags: TagStats[]): TagStats[] {
  return [...tags].sort((a, b) => a.name.localeCompare(b.name));
}

export function sortTagsByCount(tags: TagStats[]): TagStats[] {
  return [...tags].sort((a, b) => b.count - a.count);
}