// ========== Photo Entity ==========
export interface Photo {
  id: string;                    // UUID v4 generated client-side
  filename: string;              // Original filename (sanitized)
  originalFilename: string;      // Exact original filename
  dataUrl: string;               // Base64 data URL for immediate display
  contentType: string;           // MIME type (e.g., 'image/jpeg')
  size: number;                  // File size in bytes
  width: number;                 // Image width in pixels
  height: number;                // Image height in pixels
  uploadedAt: Date;              // When photo was uploaded
  tags: string[];                // Array of tag strings
  isSynced: boolean;             // Whether photo is synced with backend
  syncError?: string;            // Error message if sync failed
}

// ========== Upload Progress ==========
export interface UploadProgress {
  photoId: string;
  progress: number;              // 0-100
  status: 'pending' | 'uploading' | 'complete' | 'error';
  error?: string;
}

// ========== Filter State ==========
export interface PhotoFilter {
  tags: string[];                // Active tag filters
  sortBy: 'uploadedAt' | 'filename' | 'size';
  sortDirection: 'asc' | 'desc';
  page: number;                  // 0-based page index
  pageSize: number;             // Items per page
}

// ========== Validation Rules ==========
export const TAG_REGEX = /^[a-z0-9_-]+$/;
export const MAX_TAG_LENGTH = 50;
export const MAX_TAGS_PER_PHOTO = 20;
export const MAX_FILE_SIZE = 10 * 1024 * 1024; // 10MB
export const ALLOWED_CONTENT_TYPES = [
  'image/jpeg',
  'image/png', 
  'image/gif',
  'image/webp'
];
export const DEFAULT_PAGE_SIZE = 20;
export const MAX_PAGE_SIZE = 100;

// ========== Type Guards ==========
export function isPhoto(obj: unknown): obj is Photo {
  return typeof obj === 'object' && obj !== null &&
    'id' in obj && typeof obj.id === 'string' &&
    'filename' in obj && typeof obj.filename === 'string' &&
    'dataUrl' in obj && typeof obj.dataUrl === 'string' &&
    'contentType' in obj && typeof obj.contentType === 'string' &&
    'size' in obj && typeof obj.size === 'number' &&
    'uploadedAt' in obj && obj.uploadedAt instanceof Date &&
    'tags' in obj && Array.isArray(obj.tags);
}

// ========== Helper Functions ==========
export function createPhotoFromFile(file: File, tags: string[] = []): Partial<Photo> {
  return {
    filename: sanitizeFilename(file.name),
    originalFilename: file.name,
    contentType: file.type,
    size: file.size,
    uploadedAt: new Date(),
    tags: tags.map(tag => tag.toLowerCase()),
    isSynced: false
  };
}

export function sanitizeFilename(filename: string): string {
  // Remove path information and special characters
  return filename.replace(/[^a-zA-Z0-9._-]/g, '_');
}

export function validateTag(tag: string): boolean {
  return TAG_REGEX.test(tag) && 
         tag.length <= MAX_TAG_LENGTH && 
         tag.length > 0;
}

export function validateTags(tags: string[]): boolean {
  return tags.length <= MAX_TAGS_PER_PHOTO && 
         tags.every(validateTag);
}

export function validateFileType(file: File): boolean {
  return ALLOWED_CONTENT_TYPES.includes(file.type);
}

export function validateFileSize(file: File): boolean {
  return file.size <= MAX_FILE_SIZE;
}