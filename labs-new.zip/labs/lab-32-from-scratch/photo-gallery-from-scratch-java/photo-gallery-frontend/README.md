# Photo Gallery Frontend

A modern Angular 21 frontend application for the Photo Gallery app that consumes the Spring Boot backend API.

## Features

- **Photo Upload**: Drag & drop or browse files with real-time preview
- **Gallery View**: Responsive grid layout with photo cards
- **Photo Details**: Modal with full photo information and tag management
- **Tag Filtering**: Filter photos by one or more tags with tag statistics
- **Photo Deletion**: Confirmation dialog with safe delete functionality
- **LocalStorage Cache**: Offline-first experience with client-side caching
- **Dark/Light Mode**: Theme switching with user preference persistence
- **Pagination**: Photo browsing with page navigation
- **Responsive Design**: Mobile-first, works on all device sizes

## Technology Stack

- **Angular 21** with Standalone Components
- **Signals** for reactive state management
- **Vite** for fast development server and builds
- **Vitest** for testing
- **TypeScript 5.6**
- **RxJS 7.8** (limited to HTTP operations)

## Project Structure

```
photo-gallery-frontend/
├── src/
│   ├── app/
│   │   ├── core/                    # Core utilities and services
│   │   │   ├── constants/           # Application and API constants
│   │   │   ├── guards/             # Route guards
│   │   │   └── interceptors/        # HTTP interceptors
│   │   │
│   │   ├── shared/                 # Shared components and utilities
│   │   │   ├── components/         # Reusable components (modal, spinner, etc.)
│   │   │   ├── directives/         # Custom directives
│   │   │   ├── pipes/              # Custom pipes
│   │   │   └── utils/              # Utility functions
│   │   │
│   │   ├── stores/                 # State management with Signals
│   │   │   ├── photo.store.ts      # Photo data and operations
│   │   │   └── ui.store.ts         # UI state (modals, theme, etc.)
│   │   │
│   │   ├── services/               # Data services
│   │   │   ├── api/               # API client services
│   │   │   │   └── photo-api.service.ts
│   │   │   ├── photo.service.ts    # Main photo service
│   │   │   └── storage.service.ts # LocalStorage service
│   │   │
│   │   ├── models/                # TypeScript interfaces and types
│   │   │   ├── photo.model.ts      # Photo entity and utilities
│   │   │   ├── tag.model.ts        # Tag entity
│   │   │   ├── api.models.ts       # API DTOs
│   │   │   └── index.ts           # Model exports
│   │   │
│   │   ├── features/              # Feature-specific components
│   │   │   ├── upload/             # Photo upload
│   │   │   ├── gallery/            # Photo gallery
│   │   │   ├── card/               # Photo card
│   │   │   ├── detail/             # Photo detail modal
│   │   │   ├── filter/             # Tag filter
│   │   │   └── delete/             # Delete confirmation
│   │   │
│   │   ├── layout/                # Layout components
│   │   │   ├── header/
│   │   │   ├── footer/
│   │   │   └── main-layout/
│   │   │
│   │   ├── app.component.ts        # Root component
│   │   ├── app.config.ts           # App configuration
│   │   └── app.routes.ts           # Routing configuration
│   │
│   ├── assets/                    # Static assets
│   │   └── images/
│   │       └── placeholder.png
│   │
│   ├── styles.css                 # Global styles
│   ├── index.html                  # HTML entry point
│   └── main.ts                     # Application entry point
│
├── package.json                   # Dependencies
├── angular.json                    # Angular CLI configuration
├── vite.config.ts                  # Vite configuration
├── vitest.config.ts                # Vitest configuration
├── tsconfig.json                   # TypeScript configuration
├── tsconfig.app.json               # App TypeScript config
├── tsconfig.spec.json              # Test TypeScript config
└── .gitignore                      # Git ignore rules
```

## Getting Started

### Prerequisites

- Node.js 20.x or later
- npm 10.x or later
- Angular CLI 21.x

### Installation

```bash
# Navigate to the frontend directory
cd photo-gallery-frontend

# Install dependencies
npm install
```

### Running the Development Server

```bash
# Start the development server
npm start
```

The application will start on `http://localhost:4201` and automatically proxy API requests to the Spring Boot backend at `http://localhost:8080`.

### Building for Production

```bash
# Build the application
npm run build
```

The production build will be output to `dist/photo-gallery-frontend`.

### Running Tests

```bash
# Run all tests
npm test

# Run tests in watch mode
npm run test:watch

# Run tests with coverage
npm run test:coverage
```

## Environment Configuration

The frontend uses the following environment variables:

- `PORT`: Development server port (default: 4201)
- Backend API is configured to proxy to `http://localhost:8080`

## Key Features

### 1. Photo Management

- **Upload**: Supports drag & drop and file browser
- **Validation**: File type, size, and tag validation
- **Preview**: Real-time image preview before upload
- **Progress**: Upload progress indication
- **Sync Status**: Tracks synchronization with backend

### 2. Gallery Experience

- **Grid Layout**: Responsive photo grid
- **Pagination**: Browse through pages of photos
- **Sorting**: Sort by upload date, filename, or size
- **Filtering**: Filter by one or more tags
- **Search**: Find photos by filename or tags

### 3. Tag Management

- **Add Tags**: Add tags to photos during upload or later
- **Remove Tags**: Remove individual tags
- **Replace Tags**: Replace all tags on a photo
- **Tag Statistics**: See most popular tags
- **Tag Suggestions**: Get tag suggestions from filename

### 4. State Management

- **Signals**: Angular 21 signals for reactive state
- **LocalStorage Cache**: Offline-first experience
- **API Sync**: Automatic sync with backend
- **Error Handling**: Centralized error management

## API Integration

The frontend automatically proxies all `/api` requests to the backend at `http://localhost:8080`. The following endpoints are used:

- `GET /api/photos` - Browse photos with pagination and filtering
- `GET /api/photos/{id}` - Get photo details
- `POST /api/photos` - Upload new photo
- `DELETE /api/photos/{id}` - Delete photo
- `GET /api/photos/{id}/tags` - Get photo tags
- `PUT /api/photos/{id}/tags` - Replace photo tags
- `POST /api/photos/{id}/tags` - Add photo tags
- `DELETE /api/photos/{id}/tags/{tag}` - Remove photo tag

## Routing

| Route | Component | Description |
|-------|-----------|-------------|
| `/` | Redirect | Redirects to `/gallery` |
| `/gallery` | PhotoGalleryComponent | Main gallery view |
| `/gallery/upload` | PhotoUploadComponent | Photo upload form |
| `/gallery/:id` | PhotoDetailModalComponent | Photo details modal |

## Browser Support

- Chrome (recommended)
- Firefox
- Safari
- Edge
- Mobile browsers (iOS Safari, Chrome for Android)

## Project Architecture Decisions

### Why Angular 21 with Standalone Components?

- **No NgModule boilerplate**: Reduces code complexity
- **Tree-shakable dependencies**: Smaller bundle sizes
- **Future-proof**: Angular's recommended approach
- **Better performance**: Optimized for modern browsers

### Why Signals for State Management?

- **Built-in**: Part of Angular core (no external dependencies)
- **Fine-grained reactivity**: Only components using signals re-render
- **Simple mental model**: Easier to understand than RxJS
- **Better TypeScript support**: Excellent type inference

### Why Vite over Angular CLI?

- **Speed**: Significantly faster development server
- **Modern**: ES Modules native support
- **Flexible**: Easy to configure
- **Ecosystem**: Growing ecosystem with many plugins

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Run tests (`npm test`)
5. Submit a pull request

## License

This project is part of the Photo Gallery application and follows the same licensing as the main project.