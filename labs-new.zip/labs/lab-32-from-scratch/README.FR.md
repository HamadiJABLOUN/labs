# Lab 32 : Construire à partir de zéro avec le workflow agentique complet

**Durée** : 65-95 minutes  
**Difficulté** : Intermédiaire à avancé  
**Prérequis** : Module 3 et Lab 31 terminés

## Vue d'ensemble

Dans ce lab, vous allez appliquer le **workflow agentique complet** (Specify → Plan → Tasks → Implement → Validate) pour construire à partir de zéro une nouvelle application de galerie photo.

### Objectifs pédagogiques

À la fin de ce lab, vous saurez :

1. Exécuter les 5 phases du workflow agentique de façon autonome
2. Créer des spécifications fonctionnelles complètes avec l'aide de l'IA
3. Concevoir une architecture et prendre des décisions techniques de façon systématique
4. Découper l'implémentation en tâches priorisées
5. Implémenter du code fonctionnel avec tests et documentation
6. Valider que les livrables respectent les spécifications

## Scénario

Votre objectif est d'utiliser le workflow agentique pour construire cette fonctionnalité **de la spécification à l'implémentation fonctionnelle**, avec un haut niveau de qualité.

## Choisissez votre parcours

C'est le workflow qui compte dans ce lab, pas la stack. **Choisissez celle que vous pratiquez au quotidien.**

| Parcours                   | Ce que vous construisez              | Port  |
| -------------------------- | ------------------------------------ | ----- |
| **TypeScript** (Angular)   | une galerie photo dans le navigateur | 42321 |
| **Python** (FastAPI)       | l'**API REST** de la galerie photo   | 42323 |
| **Java** (Spring Boot 3.5) | l'**API REST** de la galerie photo   | 42322 |

Les parcours Python et Java construisent une API plutôt qu'une interface, et partagent un même
contrat HTTP — un stagiaire Python et un stagiaire Java peuvent donc comparer directement leurs
résultats au débriefing. Les cinq phases, les trois artefacts de cadrage et les livrables sont
identiques dans les trois parcours.

## Phase 0 : Mise en place (5 minutes)

### Étape 0 : Initialiser le projet

▶ **TypeScript / Angular**

Générez l'application Nx Angular (exécutez la commande ci-dessous **depuis la racine du workspace**, en veillant à exécuter toute la ligne de commande) :

```bash
npx nx g @nx/angular:application --directory=labs/lab-32-from-scratch/photo-gallery-from-scratch --bundler=esbuild --unitTestRunner=vitest-angular --standalone --routing=false --port=42321 --minimal=true --no-interactive
```

▶ **Python / FastAPI**

```bash
mkdir -p labs/lab-32-from-scratch/photo-gallery-from-scratch-python
cd labs/lab-32-from-scratch/photo-gallery-from-scratch-python

python -m venv .venv
.venv/Scripts/activate        # Windows
# source .venv/bin/activate   # macOS / Linux

pip install fastapi "uvicorn[standard]" python-multipart pytest pytest-cov httpx
pip freeze > requirements.txt
```

▶ **Java / Spring Boot**

Générez le projet depuis [start.spring.io](https://start.spring.io) avec **Spring Web** uniquement
(Java 17, Maven), et décompressez-le dans
`labs/lab-32-from-scratch/photo-gallery-from-scratch-java`. Ou en ligne de commande :

```bash
cd labs/lab-32-from-scratch
curl -G https://start.spring.io/starter.zip \
  -d type=maven-project -d language=java -d javaVersion=17 \
  -d bootVersion=3.5.16 -d dependencies=web \
  -d groupId=com.sfeir -d artifactId=photo-gallery-api \
  -o photo-gallery-from-scratch-java.zip
unzip photo-gallery-from-scratch-java.zip -d photo-gallery-from-scratch-java
```

### Étape 1 : Préparer le workspace

Placez-vous dans le dossier du projet que vous venez de créer, puis ouvrez-le dans votre IDE ou
lancez votre outil agentique dedans.

## Phase 1 : Specify (10-15 minutes)

### Étape 2 : Créer la spécification fonctionnelle

Créez un fichier `SPECIFICATION.md` qui définit :

**Prompt pour l'IA** :

```txt
Help me create a feature specification for a photo gallery application that allows users to:

- Upload photos from their device
- Tag photos with metadata
- Browse and filter photos by tags
- View photo details and delete photos

The specification should include:

1. User Stories: What users need to accomplish
2. Functional Requirements: Specific features and behaviors
3. Acceptance Criteria: How we know each requirement is met
4. Success Criteria: Overall measures of success
5. Out of Scope: What we're NOT building

Save the specification in a `SPECIFICATION.md` file
```

### Étape 3 : Affiner la spécification

Travaillez avec l'IA pour vous assurer que votre spécification :

- ✅ Comporte 3 à 5 user stories claires
- ✅ Liste 10 à 15 exigences fonctionnelles
- ✅ Définit des critères d'acceptation testables
- ✅ Inclut les cas limites et la gestion des erreurs
- ✅ Indique clairement ce qui est hors périmètre

**Validation** : demandez à l'IA de relire votre spécification et d'identifier les ambiguïtés ou les manques.

🔁 Itérez avec l'IA pour affiner la spécification jusqu'à ce qu'elle soit claire, complète et testable.

## Phase 2 : Plan (10-15 minutes)

### Étape 4 : Créer le plan d'implémentation

Créez un fichier `IMPLEMENTATION_PLAN.md` qui définit l'architecture et les décisions techniques de votre galerie photo.

**Prompt pour l'IA** :

```
Based on the `SPECIFICATION.md`, help me create an implementation plan considering:

- Framework: Angular 21.x standalone components with signals
- Build Tool: esbuild (Nx Angular default)
- Testing: Vitest for unit/integration tests
- Storage: LocalStorage for client-side persistence
- State Management: Angular signals (reactive)

The plan should cover:

1. Architecture: Component structure, data flow, state management
2. Data Model: Define entities (e.g., Photo with id, filename, dataUrl,
   uploadedAt, tags, size; TagStats with name, count)
3. File Structure: Directory organization
4. Technical Decisions: Document WHY these approaches were chosen

Save the implementation plan in `IMPLEMENTATION_PLAN.md`
```

> **Parcours Python / Java** : remplacez le bloc de stack ci-dessus par le vôtre, par exemple
> _« Framework: FastAPI with Pydantic v2 / Testing: pytest / Storage: a JSON file »_ ou
> _« Framework: Spring Boot 3.5, Java 17 / Testing: JUnit 5 + MockMvc / Storage: a JSON file »_.
> Demandez à l'IA de justifier chaque choix — c'est le _pourquoi_ qui est le livrable ici, pas le _quoi_.

🔁 Itérez avec l'IA jusqu'à être satisfait du plan proposé.

### Étape 5 : Relire le plan d'implémentation

Travaillez avec l'IA pour vous assurer que votre plan :

- ✅ Définit une architecture de composants basée sur les standalone components Angular
- ✅ Spécifie les interfaces du modèle de données avec tous les champs requis (`Photo`, `TagStats`)
- ✅ Documente l'approche de gestion d'état à base de signals
- ✅ Inclut la justification technique (le pourquoi, pas seulement le quoi)
- ✅ Respecte les conventions de structure de fichiers Angular/Nx

**Validation** : demandez à l'IA de confronter votre plan au SPECIFICATION.md et d'identifier les manques.

## Phase 3 : Tasks (5-10 minutes)

### Étape 6 : Découper en tâches

Créez un fichier `TASKS.md` avec les tâches d'implémentation priorisées :

**Prompt pour l'IA** :

```txt
Based on the `SPECIFICATION.md` and `IMPLEMENTATION_PLAN.md`, create a task breakdown with:

1. Setup tasks (project initialization)
2. Model/interface definitions
3. Service implementation (PhotoService)
4. Component implementation (upload, list)
5. Integration tasks (wire components together)
6. Testing tasks (unit tests for service and components)
7. Documentation tasks

Organize tasks by:
- Dependencies: What must be done first?
- Parallelization: What can be done simultaneously?
- Priority: MVP features vs nice-to-haves

Save the task breakdown in `TASKS.md`
```

🔁 Itérez avec l'IA jusqu'à être satisfait du découpage en tâches proposé.

### Étape 7 : Relire le découpage en tâches

Travaillez avec l'IA pour vous assurer que votre découpage en tâches :

- ✅ Couvre toutes les exigences de `SPECIFICATION.md`
- ✅ Définit un ordre de dépendances clair (ce qui doit être fait en premier)
- ✅ Distingue les tâches MVP des tâches optionnelles
- ✅ Identifie les tâches parallélisables

## Phase 4 : Implement (25-35 minutes)

### Étape 8 : Lancer l'implémentation

Maintenant que vous disposez de vos trois artefacts de préparation (`SPECIFICATION.md`, `IMPLEMENTATION_PLAN.md`, `TASKS.md`), utilisez-les pour piloter l'implémentation. Au lieu de suivre des étapes prescriptives, laissez l'IA dérouler **votre propre découpage en tâches**.

**Prompt pour l'IA** :

```txt
I need you to implement the photo gallery application.
Use the following documents as your guide:
- `SPECIFICATION.md`: defines WHAT we're building
- `IMPLEMENTATION_PLAN.md`: defines HOW we're building it
- `TASKS.md`: defines the execution order

Work through the tasks in `TASKS.md` sequentially, respecting the
dependencies and priorities defined there. Start with the first
task and proceed through each one.
```

> **💡 Astuce** : vous pouvez aussi demander à l'IA de traiter une tâche précise ou un groupe de tâches à la fois, si vous préférez mieux contrôler le rythme :
>
> ```
> Implement the tasks from Phase 2 (Models) in `TASKS.md`,
> following the architecture defined in `IMPLEMENTATION_PLAN.md`.
> ```

### Étape 9 : Relire et itérer

Au fur et à mesure que l'IA termine chaque groupe de tâches :

1. **Relisez la sortie** : le code correspond-il à l'architecture de votre `IMPLEMENTATION_PLAN.md` ?
2. **Testez au fil de l'eau** : lancez l'application après chaque jalon important pour détecter les problèmes tôt
3. **Corrigez la trajectoire** : si quelque chose s'écarte de votre plan, renvoyez l'IA vers l'artefact concerné
4. **Suivez l'avancement** : mettez à jour `TASKS.md` pour tracer les tâches terminées

🔁 Itérez avec l'IA jusqu'à ce que toutes les tâches de votre `TASKS.md` soient terminées.

## Phase 5 : Validate (10-15 minutes)

### Étape 10 : Terminer les tâches restantes

Si votre `TASKS.md` contient des tâches de test ou de documentation encore ouvertes, traitez-les maintenant :

```txt
Complete the remaining validation and documentation tasks
from `TASKS.md`, following the order and dependencies defined there.
```

### Étape 11 : Tester et vérifier par rapport à la spécification

Testez l'application manuellement :

```bash
npx nx serve photo-gallery-from-scratch     # TypeScript
python -m app                               # Python  (ou : uvicorn app.main:app --port 42323)
./mvnw spring-boot:run                      # Java    (mvnw.cmd sous Windows)
```

**Scénarios de test manuel** — via l'interface, ou avec `curl` sur les parcours API :

- [ ] Uploader une photo (taille/type valides)
- [ ] Tenter d'uploader un fichier invalide (trop volumineux, ou un PDF)
- [ ] Ajouter des tags à une photo
- [ ] Filtrer les photos par tag
- [ ] Afficher le détail d'une photo
- [ ] Supprimer une photo
- [ ] Redémarrer l'application (les données persistent)

**Conformité à la spécification** :

- [ ] Toutes les exigences fonctionnelles de `SPECIFICATION.md` sont implémentées
- [ ] Les critères d'acceptation sont respectés
- [ ] Les cas limites sont gérés
- [ ] La gestion des erreurs fournit un retour clair
- [ ] Tous les tests passent (`npx nx test photo-gallery-from-scratch` / `pytest` / `./mvnw test`)

### Étape 12 : Créer la documentation

**Prompt pour l'IA** :

```txt
Add a project `README.md` with:

- Setup instructions
- Usage guide
- Architecture overview
- Development guide (how to run tests, build, etc.)
```

## Livrables

À la fin de ce lab, vous devez avoir :

1. ✅ **`SPECIFICATION.md`** : spécification fonctionnelle complète
2. ✅ **`IMPLEMENTATION_PLAN.md`** : architecture et décisions techniques
3. ✅ **`TASKS.md`** : découpage en tâches priorisées
4. ✅ **Galerie photo fonctionnelle** : application pleinement opérationnelle
5. ✅ **Tests** : tests unitaires du PhotoService avec plus de 80 % de couverture
6. ✅ **Documentation** : `README.md` du projet avec les instructions d'installation et d'usage

## Checklist de validation

### Qualité de la spécification

- [ ] User stories claires avec critères d'acceptation
- [ ] Tous les cas limites identifiés
- [ ] Critères de succès mesurables
- [ ] Hors périmètre clairement défini

### Qualité de l'implémentation

- [ ] L'architecture correspond à `IMPLEMENTATION_PLAN.md`
- [ ] Les règles métier vivent dans un service, pas dans les composants ni les handlers de routes
- [ ] La logique de validation est complète
- [ ] La gestion des erreurs fournit un retour clair
- [ ] Les API publiques sont documentées (JSDoc / docstrings / Javadoc)

### Couverture de tests

- [ ] La couche service dispose de tests unitaires qui tournent sans l'UI ni la couche HTTP
- [ ] Les tests couvrent le cas nominal et les cas d'erreur
- [ ] Tous les tests passent (`npx nx test photo-gallery-from-scratch` / `pytest` / `./mvnw test`)
- [ ] Le rapport de couverture indique plus de 80 %

### Documentation

- [ ] Le README explique comment lancer le projet
- [ ] L'architecture est documentée
- [ ] Chaque composant a un rôle clair
- [ ] L'API est documentée en JSDoc

## Conseils pour réussir

### Collaborer efficacement avec l'IA

**Le contexte compte** : créez un fichier `AGENTS.md` avec :

```markdown
# Photo Gallery Project Context

## Tech Stack

- Angular 21.x standalone components
- Vite build tool
- Vitest testing
- LocalStorage persistence

## Conventions

- Use inject() for dependency injection
- Signal-based state management
- Reactive forms for user input
- Kebab-case for file names
```

### Développement incrémental

1. **Commencez simple** : faites d'abord fonctionner l'upload de base
2. **Ajoutez les fonctionnalités par étapes** : système de tags, filtrage, etc.
3. **Testez au fur et à mesure** : n'attendez pas la fin
4. **Affinez avec l'IA** : itérez sur l'implémentation

### Contrôles qualité

Après chaque composant :

- Demandez à l'IA de vérifier les bonnes pratiques
- Vérifiez la gestion des erreurs
- Ajoutez de la documentation JSDoc
- Écrivez des tests

## Pièges courants

❌ **Sauter la spécification** : passer directement au code
✅ **Commencer au clair** : une spec détaillée fait gagner du temps ensuite

❌ **Aucune validation** : accepter n'importe quel fichier uploadé
✅ **Validation robuste** : contrôler la taille, le type, le format

❌ **Ignorer les tests** : « je testerai à la main »
✅ **Piloté par les tests** : écrire les tests en même temps que l'implémentation

❌ **Mauvaise gestion des erreurs** : l'app plante sur les cas limites
✅ **Échecs maîtrisés** : messages d'erreur clairs pour l'utilisateur

## Gestion du temps

- **Ne restez pas bloqué** : si quelque chose ne fonctionne pas après 10 minutes, demandez de l'aide à l'IA ou passez à la suite
- **MVP d'abord** : faites marcher les fonctionnalités clés, puis ajoutez les extras
- **Surveillez l'horloge** : réservez 15 minutes pour la phase de validation

## Étapes suivantes

Après ce lab :

1. Comparez votre implémentation avec la solution
2. Relisez la documentation du workflow de la solution
3. Notez les différences d'approche et de décisions
4. Identifiez des axes d'amélioration dans votre propre processus

## Ressources

- [Angular Standalone Components](https://angular.dev/guide/components)
- [Angular Signals](https://angular.dev/guide/signals)
- [Documentation Vitest](https://vitest.dev/)
- [Solution du Lab 32](../lab-32-from-scratch-solution/README.md)
