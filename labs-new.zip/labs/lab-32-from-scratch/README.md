# Lab 32: Building from Scratch with Complete Agentic Workflow

**Duration**: 65-95 minutes  
**Difficulty**: Intermediate to Advanced  
**Prerequisites**: Completed Module 3 and Lab 31

## Overview

In this lab, you'll apply the **complete agentic workflow** (Specify → Plan → Tasks → Implement → Validate) to build a new photo gallery application from scratch.

### Learning Objectives

By the end of this lab, you will be able to:

1. Execute all 5 phases of the agentic workflow independently
2. Create comprehensive feature specifications with AI assistance
3. Design architecture and make technical decisions systematically
4. Break down implementation into prioritized tasks
5. Implement working code with tests and documentation
6. Validate that deliverables meet specifications

## Scenario

Your goal is to use the agentic workflow to build this feature **from specification to working implementation** with high quality standards.

## Choose Your Track

The workflow is the point of this lab, not the stack. **Pick the one you work in every day.**

| Track                      | You build                      | Port  |
| -------------------------- | ------------------------------ | ----- |
| **TypeScript** (Angular)   | a browser photo gallery        | 42321 |
| **Python** (FastAPI)       | the photo gallery **REST API** | 42323 |
| **Java** (Spring Boot 3.5) | the photo gallery **REST API** | 42322 |

The Python and Java tracks build an API rather than a UI, and share one HTTP contract — so a Python
trainee and a Java trainee can compare their results directly at the debrief. The five phases, the
three planning artifacts and the deliverables are identical across all three tracks.

## Phase 0: Setup (5 minutes)

### Step 0: Initialize Project

▶ **TypeScript / Angular**

Generate the Nx Angular application (run below command **from root of the workspace**, be sure all the command line is executed):

```bash
npx nx g @nx/angular:application --directory=labs/lab-32-from-scratch/photo-gallery-from-scratch --bundler=esbuild --unitTestRunner=vitest-angular --standalone --routing=false --port=42321 --minimal=true --no-interactive
```

▶ **Python / FastAPI**

```bash
mkdir -p labs/lab-32-from-scratch/photo-gallery-from-scratch-python
cd labs/lab-32-from-scratch/photo-gallery-from-scratch-python

python -m venv .venv
.venv/Scripts/activate        # Windows
# source .venv/bin/activate   # macOS / Linux

pip install fastapi "uvicorn[standard]" python-multipart pytest pytest-cov httpx
pip freeze > requirements.txt
```

▶ **Java / Spring Boot**

Generate the project from [start.spring.io](https://start.spring.io) with **Spring Web** only
(Java 17, Maven), and unpack it into
`labs/lab-32-from-scratch/photo-gallery-from-scratch-java`. Or from the command line:

```bash
cd labs/lab-32-from-scratch
curl -G https://start.spring.io/starter.zip \
  -d type=maven-project -d language=java -d javaVersion=17 \
  -d bootVersion=3.5.16 -d dependencies=web \
  -d groupId=com.sfeir -d artifactId=photo-gallery-api \
  -o photo-gallery-from-scratch-java.zip
unzip photo-gallery-from-scratch-java.zip -d photo-gallery-from-scratch-java
```

### Step 1: Set Up Workspace

Navigate to the project folder you just created, and open it in your IDE or start your agentic tool
inside it.

## Phase 1: Specify (10-15 minutes)

### Step 2: Create Feature Specification

Create a `SPECIFICATION.md` file that defines:

**Prompt for AI**:

```txt
Help me create a feature specification for a photo gallery application that allows users to:

- Upload photos from their device
- Tag photos with metadata
- Browse and filter photos by tags
- View photo details and delete photos

The specification should include:

1. User Stories: What users need to accomplish
2. Functional Requirements: Specific features and behaviors
3. Acceptance Criteria: How we know each requirement is met
4. Success Criteria: Overall measures of success
5. Out of Scope: What we're NOT building

Save the specification in a `SPECIFICATION.md` file
```

### Step 3: Refine Specification

Work with AI to ensure your specification:

- ✅ Has 3-5 clear user stories
- ✅ Lists 10-15 functional requirements
- ✅ Defines testable acceptance criteria
- ✅ Includes edge cases and error handling
- ✅ Clearly states what's out of scope

**Validation**: Ask AI to review your specification and identify any ambiguities or gaps.

🔁 Iterate with AI to refine the specification until it is clear, comprehensive, and testable.

## Phase 2: Plan (10-15 minutes)

### Step 4: Create Implementation Plan

Create an `IMPLEMENTATION_PLAN.md` file that defines the architecture and technical decisions for your photo gallery.

**Prompt for AI**:

```
Based on the `SPECIFICATION.md`, help me create an implementation plan considering:

- Framework: Angular 21.x standalone components with signals
- Build Tool: esbuild (Nx Angular default)
- Testing: Vitest for unit/integration tests
- Storage: LocalStorage for client-side persistence
- State Management: Angular signals (reactive)

The plan should cover:

1. Architecture: Component structure, data flow, state management
2. Data Model: Define entities (e.g., Photo with id, filename, dataUrl,
   uploadedAt, tags, size; TagStats with name, count)
3. File Structure: Directory organization
4. Technical Decisions: Document WHY these approaches were chosen

Save the implementation plan in `IMPLEMENTATION_PLAN.md`
```

> **Python / Java tracks**: replace the stack block above with your own, for example
> _"Framework: FastAPI with Pydantic v2 / Testing: pytest / Storage: a JSON file"_ or
> _"Framework: Spring Boot 3.5, Java 17 / Testing: JUnit 5 + MockMvc / Storage: a JSON file"_.
> Ask the AI to justify each choice — the _why_ is the deliverable here, not the _what_.

🔁 Iterate with AI until you are satisfied with the proposed plan.

### Step 5: Review Implementation Plan

Work with AI to ensure your plan:

- ✅ Defines the layer or component architecture, and what depends on what
- ✅ Specifies the data model with all required fields (`Photo`, `TagStats`)
- ✅ Documents how state is held (Angular signals / a service + repository)
- ✅ Includes technical rationale (why, not just what), including rejected alternatives
- ✅ Follows the conventions of your stack

**Validation**: Ask AI to review your plan against the SPECIFICATION.md and identify any gaps.

## Phase 3: Tasks (5-10 minutes)

### Step 6: Break Down into Tasks

Create a `TASKS.md` file with prioritized implementation tasks:

**Prompt for AI**:

```txt
Based on the `SPECIFICATION.md` and `IMPLEMENTATION_PLAN.md`, create a task breakdown with:

1. Setup tasks (project initialization)
2. Model/interface definitions
3. Service implementation (PhotoService)
4. Component implementation (upload, list)
5. Integration tasks (wire components together)
6. Testing tasks (unit tests for service and components)
7. Documentation tasks

Organize tasks by:
- Dependencies: What must be done first?
- Parallelization: What can be done simultaneously?
- Priority: MVP features vs nice-to-haves

Save the task breakdown in `TASKS.md`
```

🔁 Iterate with AI until you are satisfied with the proposed task breakdown.

### Step 7: Review Task Breakdown

Work with AI to ensure your task breakdown:

- ✅ Covers all requirements from `SPECIFICATION.md`
- ✅ Has clear dependency ordering (what must be done first)
- ✅ Distinguishes MVP tasks from nice-to-haves
- ✅ Identifies tasks that can be parallelized

## Phase 4: Implement (25-35 minutes)

### Step 8: Launch Implementation

Now that you have your three planning artifacts (`SPECIFICATION.md`, `IMPLEMENTATION_PLAN.md`, `TASKS.md`), use them to drive the implementation. Instead of following prescriptive steps, let AI work through **your own task breakdown**.

**Prompt for AI**:

```txt
I need you to implement the photo gallery application.
Use the following documents as your guide:
- `SPECIFICATION.md`: defines WHAT we're building
- `IMPLEMENTATION_PLAN.md`: defines HOW we're building it
- `TASKS.md`: defines the execution order

Work through the tasks in `TASKS.md` sequentially, respecting the
dependencies and priorities defined there. Start with the first
task and proceed through each one.
```

> **💡 Tip**: You can also ask AI to tackle a specific task or group of tasks at a time if you prefer more control over the pace:
>
> ```
> Implement the tasks from Phase 2 (Models) in `TASKS.md`,
> following the architecture defined in `IMPLEMENTATION_PLAN.md`.
> ```

### Step 9: Review and Iterate

As AI completes each task group:

1. **Review the output**: Does the code match your `IMPLEMENTATION_PLAN.md` architecture?
2. **Test incrementally**: Run the app after each major milestone to catch issues early
3. **Course-correct**: If something diverges from your plan, point AI back to the relevant artifact
4. **Mark progress**: Update `TASKS.md` to track completed tasks

🔁 Iterate with AI until all tasks from your `TASKS.md` are completed.

## Phase 5: Validate (10-15 minutes)

### Step 10: Complete Remaining Tasks

If your `TASKS.md` includes testing or documentation tasks that haven't been completed yet, work through them now:

```txt
Complete the remaining validation and documentation tasks
from `TASKS.md`, following the order and dependencies defined there.
```

### Step 11: Test and Verify Against Specification

Test the application manually:

```bash
npx nx serve photo-gallery-from-scratch     # TypeScript
python -m app                               # Python  (or: uvicorn app.main:app --port 42323)
./mvnw spring-boot:run                      # Java    (mvnw.cmd on Windows)
```

**Manual Test Scenarios** — through the UI, or with `curl` on the API tracks:

- [ ] Upload a photo (valid size/type)
- [ ] Try to upload an invalid file (too large, or a PDF)
- [ ] Add tags to a photo
- [ ] Filter photos by tag
- [ ] View photo details
- [ ] Delete a photo
- [ ] Restart the app (data persists)

**Specification Compliance**:

- [ ] All functional requirements from `SPECIFICATION.md` implemented
- [ ] Acceptance criteria met
- [ ] Edge cases handled
- [ ] Error handling provides clear feedback
- [ ] All tests pass (`npx nx test photo-gallery-from-scratch` / `pytest` / `./mvnw test`)

### Step 12: Create Documentation

**Prompt for AI**:

```txt
Add a project `README.md` with:

- Setup instructions
- Usage guide
- Architecture overview
- Development guide (how to run tests, build, etc.)
```

## Deliverables

By the end of this lab, you should have:

1. ✅ **`SPECIFICATION.md`**: Complete feature specification
2. ✅ **`IMPLEMENTATION_PLAN.md`**: Architecture and technical decisions
3. ✅ **`TASKS.md`**: Prioritized task breakdown
4. ✅ **Working Photo Gallery**: Fully functional application
5. ✅ **Tests**: Unit tests for PhotoService with >80% coverage
6. ✅ **Documentation**: Project `README.md` with setup and usage instructions

## Validation Checklist

### Specification Quality

- [ ] Clear user stories with acceptance criteria
- [ ] All edge cases identified
- [ ] Success criteria are measurable
- [ ] Out of scope clearly defined

### Implementation Quality

- [ ] The architecture matches `IMPLEMENTATION_PLAN.md`
- [ ] Business rules live in a service, not in components or route handlers
- [ ] Validation logic is comprehensive
- [ ] Error handling provides clear feedback
- [ ] Public APIs are documented (JSDoc / docstrings / Javadoc)

### Test Coverage

- [ ] The service layer has unit tests that run without the UI or HTTP layer
- [ ] Tests cover happy path and error cases
- [ ] All tests pass (`npx nx test photo-gallery-from-scratch` / `pytest` / `./mvnw test`)
- [ ] Coverage report shows >80% coverage

### Documentation

- [ ] README explains how to run the project
- [ ] Architecture is documented
- [ ] Each component has clear purpose
- [ ] API is documented with JSDoc

## Tips for Success

### Effective AI Collaboration

**Context Matters**: Create an `AGENTS.md` file with:

```markdown
# Photo Gallery Project Context

## Tech Stack

- Angular 21.x standalone components
- Vite build tool
- Vitest testing
- LocalStorage persistence

## Conventions

- Use inject() for dependency injection
- Signal-based state management
- Reactive forms for user input
- Kebab-case for file names
```

### Incremental Development

1. **Start simple**: Get basic upload working first
2. **Add features incrementally**: Tag system, filtering, etc.
3. **Test as you go**: Don't wait until the end
4. **Refine with AI**: Iterate on implementation

### Quality Checks

After each component:

- Ask AI to review for best practices
- Check for error handling
- Add JSDoc documentation
- Write tests

## Common Pitfalls

❌ **Skipping specification**: Jumping straight to code
✅ **Start with clarity**: Detailed spec saves time later

❌ **No validation**: Accepting any file upload
✅ **Robust validation**: Check size, type, format

❌ **Ignoring tests**: "I'll test manually"
✅ **Test-driven**: Write tests alongside implementation

❌ **Poor error handling**: App crashes on edge cases
✅ **Graceful failures**: Clear error messages to users

## Time Management

- **Don't get stuck**: If something isn't working after 10 minutes, ask AI for help or move on
- **MVP first**: Get core features working, then add extras
- **Watch the clock**: Reserve 15 minutes for validation phase

## Next Steps

After completing this lab:

1. Compare your implementation with the solution
2. Review the solution's workflow documentation
3. Note differences in approach and decisions
4. Identify areas for improvement in your process

## Resources

- [Angular Standalone Components](https://angular.dev/guide/components)
- [Angular Signals](https://angular.dev/guide/signals)
- [Vitest Documentation](https://vitest.dev/)
- [Lab 32 Solution](../lab-32-from-scratch-solution/README.md)
