# AGENTS.md - Photo Gallery Legacy Java Project

## Project Context

This is a **Spring Boot 3.5.16** (Java 17) legacy application with intentional technical debt. It's part of a refactoring exercise (Lab 31) from SFEIR Institute. The codebase demonstrates poor practices that need to be identified and fixed.

**Project Type**: Java/Spring Boot Web Application
**Language**: Java 17
**Framework**: Spring Boot 3.5.16
**Build Tool**: Maven

## Primary Goals

1. **Identify** technical debt, code quality issues, security concerns, and maintainability problems
2. **Refactor** the codebase to follow modern Java/Spring best practices
3. **Add tests** to ensure code reliability
4. **Improve security** to address XSS and input validation vulnerabilities

## Code Quality Standards

### Naming Conventions
- **Classes**: PascalCase, descriptive names (NOT `comp1`, `thing`)
- **Methods**: camelCase, action-oriented names
- **Variables**: camelCase, descriptive names
- **Packages**: lowercase, reverse domain notation
- **Constants**: UPPER_SNAKE_CASE

### Type Safety
- ✅ Always use generic types (`List<Photo>`, not raw `List`)
- ✅ Prefer immutable objects (use `final` fields, consider `Record` classes)
- ✅ Never use `Object` as parameter/return type for domain-specific operations
- ✅ Use proper Java types (Instant/LocalDateTime instead of String for dates)

### Architecture
- ✅ Follow **Layered Architecture**: Controller → Service → Repository
- ✅ Use **Dependency Injection** via constructors (NOT field injection)
- ✅ Separate concerns: controllers handle HTTP, services handle business logic
- ✅ Use Spring's `@Service`, `@Repository`, `@Controller` stereotypes appropriately

### Security
- ✅ **ALWAYS** escape user input in HTML output (use Thymeleaf or similar)
- ✅ **ALWAYS** validate file uploads (type, size, content)
- ✅ **NEVER** trust user input - validate and sanitize
- ✅ Implement authentication/authorization for destructive operations
- ✅ Use CSRF protection for state-changing operations

### Error Handling
- ✅ **NEVER** swallow exceptions silently
- ✅ Use `@ControllerAdvice` for global exception handling
- ✅ Log errors appropriately (SLF4J/Logback)
- ✅ Return meaningful error responses to users

### Testing
- ✅ **ALWAYS** create tests in `src/test/java/`
- ✅ Unit tests for services and utilities
- ✅ Integration tests for controllers
- ✅ Use `@SpringBootTest` for integration tests
- ✅ Use Mockito for mocking dependencies

## Specific Rules for This Project

### DO NOT
- ❌ Use field injection (`@Autowired` on fields) - use constructor injection instead
- ❌ Use string concatenation for HTML generation - use Thymeleaf templates
- ❌ Use raw types (`List`, `Map`) - always use generics
- ❌ Swallow exceptions without logging
- ❌ Store user input directly without validation
- ❌ Use public mutable fields - use private fields with getters/setters or immutable objects
- ❌ Hardcode configuration values - use `@Value` or `application.properties`

### DO
- ✅ Rename `comp1.java` to `PhotoUploadController.java`
- ✅ Rename `thing.java` to `PhotoRenderingService.java` or similar
- ✅ Rename `StorageSvc.java` to `PhotoStorageService.java`
- ✅ Use the `Photo` class instead of `Map<String, Object>`
- ✅ Add proper validation for file uploads
- ✅ Implement HTML escaping or use template engine
- ✅ Add Spring Security configuration
- ✅ Create a proper repository layer
- ✅ Add comprehensive logging

## File Structure Guidelines

```
photo-gallery-legacy-java/
├── src/
│   ├── main/
│   │   ├── java/
│   │   │   └── com/sfeir/photogallery/
│   │   │       ├── config/           # Configuration classes
│   │   │       ├── controller/       # HTTP controllers
│   │   │       ├── dto/              # Data Transfer Objects
│   │   │       ├── exception/        # Custom exceptions
│   │   │       ├── model/            # Domain entities (Photo)
│   │   │       ├── repository/       # Data access layer
│   │   │       ├── service/          # Business logic
│   │   │       └── PhotoGalleryLegacyApplication.java
│   │   └── resources/
│   │       ├── static/              # Static assets
│   │       ├── templates/           # Thymeleaf/HTML templates
│   │       └── application.properties
│   └── test/
│       └── java/
│           └── com/sfeir/photogallery/
│               ├── controller/       # Controller tests
│               ├── service/          # Service tests
│               └── PhotoGalleryLegacyApplicationTests.java
├── AGENTS.md                        # This file
├── pom.xml
└── README.md                        # Project documentation
```

## Refactoring Priority Order

1. **Security First** (Critical)
   - Fix XSS vulnerabilities
   - Add input validation
   - Add authentication

2. **Type Safety** (High)
   - Replace raw types with generics
   - Use proper domain classes
   - Remove `Object` parameters

3. **Architecture** (High)
   - Separate controllers, services, repositories
   - Use constructor injection
   - Implement proper layered architecture

4. **Testing** (High)
   - Create test directory
   - Add unit and integration tests

5. **Code Quality** (Medium)
   - Rename classes to follow conventions
   - Add documentation
   - Add logging

6. **Configuration** (Medium)
   - Move hardcoded values to properties
   - Add proper configuration classes

## Tooling & Commands

```bash
# Build the project
mvn clean compile

# Run the application
mvn spring-boot:run

# Run tests (once tests are added)
mvn test

# Check for code quality issues
mvn checkstyle:check
mvn pmd:check

# Run with specific profile
mvn spring-boot:run -Dspring-boot.run.profiles=dev
```

## Dependencies (Current)

- Spring Boot Starter Web
- Spring Boot Starter Test (unused - needs to be utilized)
- Jackson Databind (via Spring Boot)

## Recommended Additional Dependencies

```xml
<!-- Security -->
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-security</artifactId>
</dependency>

<!-- Templating -->
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-thymeleaf</artifactId>
</dependency>

<!-- Validation -->
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-validation</artifactId>
</dependency>

<!-- Logging (already included via Spring Boot) -->
<!-- Use SLF4J with Logback -->

<!-- Lombok (optional, for reducing boilerplate) -->
<dependency>
    <groupId>org.projectlombok</groupId>
    <artifactId>lombok</artifactId>
    <optional>true</optional>
</dependency>

<!-- Testing -->
<dependency>
    <groupId>org.mockito</groupId>
    <artifactId>mockito-core</artifactId>
    <scope>test</scope>
</dependency>
```

## Important Notes

- This is a **legacy refactoring exercise** - the poor code is intentional for educational purposes
- When refactoring, **preserve functionality** while improving quality
- **Small, incremental changes** are preferred over large rewrites
- **Test after each significant change** to ensure nothing breaks
- **Document decisions** in commit messages and PR descriptions

## Git Workflow

```bash
# Create feature branch
git checkout -b refactor/feature-name

# Commit with descriptive message
git commit -m "refactor: improve class naming for controllers"

# Push for review
git push origin refactor/feature-name
```

Use **conventional commits** format:
- `feat:` - New features
- `fix:` - Bug fixes
- `refactor:` - Code refactoring
- `docs:` - Documentation changes
- `test:` - Adding or modifying tests
- `chore:` - Maintenance tasks

## Contact & Resources

- **Lab**: 31 - Legacy Refactoring
- **Organization**: SFEIR Institute
- **Java Version**: 17+
- **Spring Boot Version**: 3.5.16

---

*This AGENTS.md file provides guidance for Mistral Vibe and other AI assistants working on this project.*
