# MIGRATION PLAN - Photo Gallery Legacy Java Refactoring

**Project**: photo-gallery-legacy-java  
**Lab**: 31 - Legacy Refactoring (SFEIR Institute)  
**Version**: 1.0  
**Date**: 2026-10-02  
**Related Documents**: REFACTORING_SPEC.md, AGENTS.md  

---

## 🎯 EXECUTIVE SUMMARY

This migration plan translates the **REFACTORING_SPEC.md** goals into actionable tasks with clear dependencies, effort estimates, and risk assessments. The plan follows a **security-first** approach, addressing critical vulnerabilities before architectural improvements.

**Total Estimated Effort**: ~65-85 hours  
**Recommended Team Size**: 1-2 developers  
**Estimated Duration**: 2-3 weeks (part-time)  

---

## 📊 PRIORITY MATRIX

| Priority | Category | Color | Examples |
|----------|----------|-------|----------|
| **P0 - Critical** | Must fix immediately | 🔴 | Security vulnerabilities, data loss risk |
| **P1 - High** | Required for spec compliance | 🟡 | Architecture, type safety, testing |
| **P2 - Medium** | Important improvements | 🟢 | Code quality, documentation |
| **P3 - Low** | Nice-to-have | 🔵 | Optional enhancements |

---

## 📋 TASK LIST WITH DEPENDENCIES

### Phase 0: Quick Wins (P0 - Critical Security)

#### Task 0.1: Fix XSS Vulnerabilities
| Attribute | Value |
|-----------|-------|
| **ID** | T01 |
| **Title** | Escape user input in HTML output |
| **Description** | Add HTML escaping to all user-provided data in `thing.java` render method |
| **Priority** | P0 (Critical) |
| **Effort** | 2-3 hours |
| **Dependencies** | None |
| **Files Affected** | `thing.java` |
| **Risk** | Low (Isolated change, minimal impact) |
| **Risk Details** | May affect HTML rendering if escaping breaks existing output |
| **Mitigation** | Test HTML output thoroughly, use standard escaping library |
| **Quick Win** | ✅ Yes - Immediate security improvement |

#### Task 0.2: Add File Upload Validation
| Attribute | Value |
|-----------|-------|
| **ID** | T02 |
| **Title** | Validate file uploads in `comp1.java` |
| **Description** | Add type validation (images only), size limits (10MB), and basic sanity checks |
| **Priority** | P0 (Critical) |
| **Effort** | 3-4 hours |
| **Dependencies** | None |
| **Files Affected** | `comp1.java`, `pom.xml` (validation dependency) |
| **Risk** | Low |
| **Risk Details** | May reject previously accepted files |
| **Mitigation** | Document accepted file types, add clear error messages |
| **Quick Win** | ✅ Yes - Immediate security improvement |

#### Task 0.3: Basic Authentication
| Attribute | Value |
|-----------|-------|
| **ID** | T03 |
| **Title** | Add Spring Security with basic authentication |
| **Description** | Implement basic auth for delete endpoints, enable CSRF protection |
| **Priority** | P0 (Critical) |
| **Effort** | 4-6 hours |
| **Dependencies** | None |
| **Files Affected** | `pom.xml`, new `SecurityConfig.java` |
| **Risk** | Medium |
| **Risk Details** | May break existing unauthenticated access |
| **Mitigation** | Configure permit-all for GET endpoints initially, add auth gradually |
| **Quick Win** | ✅ Yes - Immediate security improvement |

**Phase 0 Total**: 9-13 hours, All Quick Wins, Critical Security

---

### Phase 1: Foundation (P1 - High Priority, Dependencies for Other Tasks)

#### Task 1.1: Create Test Directory Structure
| Attribute | Value |
|-----------|-------|
| **ID** | T04 |
| **Title** | Set up test infrastructure |
| **Description** | Create `src/test/java/` structure, add test dependencies, configure test framework |
| **Priority** | P1 (High) |
| **Effort** | 2-3 hours |
| **Dependencies** | None |
| **Files Affected** | `pom.xml`, new test directory |
| **Risk** | Very Low |
| **Risk Details** | Minimal impact on existing code |
| **Mitigation** | Follow Maven conventions |
| **Quick Win** | ✅ Yes |

#### Task 1.2: Create Proper Domain Model
| Attribute | Value |
|-----------|-------|
| **ID** | T05 |
| **Title** | Enhance Photo class with proper types and encapsulation |
| **Description** | Convert Photo to proper domain class with private fields, proper types (Instant for date), and validation |
| **Priority** | P1 (High) |
| **Effort** | 3-4 hours |
| **Dependencies** | None |
| **Files Affected** | `Photo.java` |
| **Risk** | Medium |
| **Risk Details** | Breaking change for code using Photo |
| **Mitigation** | Update all references incrementally |
| **Quick Win** | ❌ No - Requires follow-up changes |

#### Task 1.3: Externalize Configuration
| Attribute | Value |
|-----------|-------|
| **ID** | T06 |
| **Title** | Move hardcoded values to application.properties |
| **Description** | Extract `KEY` from StorageSvc, `title` from PhotoGalleryLegacyApplication, add upload limits |
| **Priority** | P1 (High) |
| **Effort** | 2-3 hours |
| **Dependencies** | None |
| **Files Affected** | `application.properties`, `StorageSvc.java`, `PhotoGalleryLegacyApplication.java` |
| **Risk** | Very Low |
| **Risk Details** | Configuration changes only |
| **Mitigation** | Use sensible defaults |
| **Quick Win** | ✅ Yes |

**Phase 1 Total**: 7-10 hours

---

### Phase 2: Type Safety & Quality (P1 - High Priority)

#### Task 2.1: Eliminate Raw Types
| Attribute | Value |
|-----------|-------|
| **ID** | T07 |
| **Title** | Replace all raw List/Map usage with generics |
| **Description** | Add type parameters to all collections, replace Object parameters |
| **Priority** | P1 (High) |
| **Effort** | 4-6 hours |
| **Dependencies** | T05 (Photo class) |
| **Files Affected** | All Java files |
| **Risk** | Medium |
| **Risk Details** | May expose type-related bugs that were hidden |
| **Mitigation** | Fix issues as they're discovered, compile frequently |
| **Quick Win** | ❌ No - Requires careful changes |

#### Task 2.2: Constructor Injection
| Attribute | Value |
|-----------|-------|
| **ID** | T08 |
| **Title** | Replace field injection with constructor injection |
| **Description** | Convert all `@Autowired` fields to constructor parameters, add `@RequiredArgsConstructor` or manual constructors |
| **Priority** | P1 (High) |
| **Effort** | 3-4 hours |
| **Dependencies** | T04 (tests may need updates) |
| **Files Affected** | All controller and service classes |
| **Risk** | Low |
| **Risk Details** | Behavioral change is minimal |
| **Mitigation** | Verify injection still works, update tests |
| **Quick Win** | ⚠️ Medium - Best practice, but requires multiple file changes |

#### Task 2.3: Proper Exception Handling
| Attribute | Value |
|-----------|-------|
| **ID** | T09 |
| **Title** | Add logging and proper error handling |
| **Description** | Replace swallowed exceptions with logging, add proper error responses |
| **Priority** | P1 (High) |
| **Effort** | 3-5 hours |
| **Dependencies** | T04 (tests), T06 (logging config) |
| **Files Affected** | `StorageSvc.java`, all controllers |
| **Risk** | Low |
| **Risk Details** | May expose previously hidden errors |
| **Mitigation** | Handle exceptions gracefully, don't break user flows |
| **Quick Win** | ⚠️ Medium - Important but requires setup |

**Phase 2 Total**: 10-15 hours

---

### Phase 3: Architecture (P1 - High Priority)

#### Task 3.1: Create Repository Layer
| Attribute | Value |
|-----------|-------|
| **ID** | T10 |
| **Title** | Implement repository abstraction for photo storage |
| **Description** | Create `PhotoRepository` interface, implement `JsonPhotoRepository` using existing StorageSvc logic |
| **Priority** | P1 (High) |
| **Effort** | 4-6 hours |
| **Dependencies** | T05 (Photo class), T06 (configuration) |
| **Files Affected** | New `repository/` package files |
| **Risk** | Medium |
| **Risk Details** | Major refactoring of data access |
| **Mitigation** | Keep existing StorageSvc as backup, test thoroughly |
| **Quick Win** | ❌ No - Foundation for future improvements |

#### Task 3.2: Create Service Layer
| Attribute | Value |
|-----------|-------|
| **ID** | T11 |
| **Title** | Implement proper service layer |
| **Description** | Create `PhotoService` to handle business logic, separate from controllers |
| **Priority** | P1 (High) |
| **Effort** | 4-6 hours |
| **Dependencies** | T05 (Photo class), T07 (types), T10 (repository) |
| **Files Affected** | New `service/` package files |
| **Risk** | Medium |
| **Risk Details** | Business logic relocation |
| **Mitigation** | Move logic incrementally, test at each step |
| **Quick Win** | ❌ No - Foundation work |

#### Task 3.3: Refactor Controllers
| Attribute | Value |
|-----------|-------|
| **ID** | T12 |
| **Title** | Rename and refactor controller classes |
| **Description** | Rename `comp1.java` → `PhotoUploadController.java`, `thing.java` → `PhotoDisplayController.java`, separate HTML rendering |
| **Priority** | P1 (High) |
| **Effort** | 3-5 hours |
| **Dependencies** | T08 (constructor injection), T11 (service layer) |
| **Files Affected** | `comp1.java`, `thing.java`, `PhotoGalleryLegacyApplication.java` |
| **Risk** | Medium |
| **Risk Details** | Renaming affects all references |
| **Mitigation** | Use IDE refactoring tools, test thoroughly |
| **Quick Win** | ⚠️ Medium - Improves maintainability significantly |

**Phase 3 Total**: 11-17 hours

---

### Phase 4: Testing (P1 - High Priority)

#### Task 4.1: Unit Tests for Services
| Attribute | Value |
|-----------|-------|
| **ID** | T13 |
| **Title** | Add unit tests for service classes |
| **Description** | Create unit tests for PhotoService, repository implementations |
| **Priority** | P1 (High) |
| **Effort** | 4-6 hours |
| **Dependencies** | T04 (test infrastructure), T10 (repository), T11 (service) |
| **Files Affected** | New test files in `service/` package |
| **Risk** | Low |
| **Risk Details** | Tests may fail if implementation changes |
| **Mitigation** | Update tests as implementation evolves |
| **Quick Win** | ❌ No - Requires service layer first |

#### Task 4.2: Integration Tests for Controllers
| Attribute | Value |
|-----------|-------|
| **ID** | T14 |
| **Title** | Add integration tests for all controllers |
| **Description** | Create `@SpringBootTest` integration tests for upload, delete, and index endpoints |
| **Priority** | P1 (High) |
| **Effort** | 4-6 hours |
| **Dependencies** | T04 (test infrastructure), T12 (controllers) |
| **Files Affected** | New test files in `controller/` package |
| **Risk** | Medium |
| **Risk Details** | Integration tests are slower and more fragile |
| **Mitigation** | Use test profiles, mock external dependencies |
| **Quick Win** | ❌ No - Requires working controllers |

#### Task 4.3: Achieve 80% Coverage
| Attribute | Value |
|-----------|-------|
| **ID** | T15 |
| **Title** | Add additional tests to reach 80% coverage |
| **Description** | Identify uncovered code, add tests for edge cases and error paths |
| **Priority** | P1 (High) |
| **Effort** | 3-4 hours |
| **Dependencies** | T04, T13, T14 |
| **Files Affected** | Additional test files |
| **Risk** | Low |
| **Risk Details** | Coverage gaps may reveal untested edge cases |
| **Mitigation** | Focus on critical paths first |
| **Quick Win** | ❌ No - Depends on test infrastructure |

**Phase 4 Total**: 11-16 hours

---

### Phase 5: Code Quality (P2 - Medium Priority)

#### Task 5.1: Add JavaDoc Documentation
| Attribute | Value |
|-----------|-------|
| **ID** | T16 |
| **Title** | Add JavaDoc to all public classes and methods |
| **Description** | Document all public APIs with proper JavaDoc comments |
| **Priority** | P2 (Medium) |
| **Effort** | 3-4 hours |
| **Dependencies** | All refactoring tasks (document final state) |
| **Files Affected** | All Java files |
| **Risk** | Very Low |
| **Risk Details** | Documentation only, no functional changes |
| **Mitigation** | None needed |
| **Quick Win** | ✅ Yes - Standalone task |

#### Task 5.2: Implement Logging
| Attribute | Value |
|-----------|-------|
| **ID** | T17 |
| **Title** | Add SLF4J logging throughout |
| **Description** | Add logger to all classes, log important events and errors |
| **Priority** | P2 (Medium) |
| **Effort** | 2-3 hours |
| **Dependencies** | T09 (exception handling) |
| **Files Affected** | All Java files |
| **Risk** | Very Low |
| **Risk Details** | Logging only, no functional changes |
| **Mitigation** | Use consistent log levels and formats |
| **Quick Win** | ✅ Yes - Standalone task |

#### Task 5.3: Thymeleaf Templates
| Attribute | Value |
|-----------|-------|
| **ID** | T18 |
| **Title** | Replace string concatenation with Thymeleaf templates |
| **Description** | Create HTML templates, move HTML from Java to template files |
| **Priority** | P2 (Medium) |
| **Effort** | 4-6 hours |
| **Dependencies** | T01 (XSS fix - templates handle escaping), T12 (controllers) |
| **Files Affected** | New `templates/` directory, all controller files |
| **Risk** | Medium |
| **Risk Details** | HTML output may change slightly |
| **Mitigation** | Replicate existing HTML structure in templates |
| **Quick Win** | ❌ No - Requires template setup |

**Phase 5 Total**: 9-13 hours

---

### Phase 6: Final Touches (P2 - Medium Priority)

#### Task 6.1: Clean up PhotoGalleryLegacyApplication
| Attribute | Value |
|-----------|-------|
| **ID** | T19 |
| **Title** | Separate bootstrap from controller |
| **Description** | Remove controller annotations from main class, create dedicated HomeController |
| **Priority** | P2 (Medium) |
| **Effort** | 2-3 hours |
| **Dependencies** | T12 (controllers) |
| **Files Affected** | `PhotoGalleryLegacyApplication.java`, new `HomeController.java` |
| **Risk** | Low |
| **Risk Details** | Relocates existing functionality |
| **Mitigation** | Test all endpoints still work |
| **Quick Win** | ⚠️ Medium - Improves separation of concerns |

#### Task 6.2: README.md Documentation
| Attribute | Value |
|-----------|-------|
| **ID** | T20 |
| **Title** | Create comprehensive README |
| **Description** | Document setup, running, configuration, and usage |
| **Priority** | P2 (Medium) |
| **Effort** | 2-3 hours |
| **Dependencies** | All other tasks (document final state) |
| **Files Affected** | New `README.md` |
| **Risk** | Very Low |
| **Risk Details** | Documentation only |
| **Mitigation** | None needed |
| **Quick Win** | ✅ Yes |

#### Task 6.3: Final Validation
| Attribute | Value |
|-----------|-------|
| **ID** | T21 |
| **Title** | Run comprehensive validation |
| **Description** | Run all tests, check coverage, verify all endpoints, security scan |
| **Priority** | P1 (High) |
| **Effort** | 2-4 hours |
| **Dependencies** | All tasks |
| **Files Affected** | All files (validation only) |
| **Risk** | Low |
| **Risk Details** | May reveal issues in any completed task |
| **Mitigation** | Fix issues as found |
| **Quick Win** | ❌ No - Final step |

**Phase 6 Total**: 6-10 hours

---

## 🎯 RECOMMENDED EXECUTION ORDER

### Critical Path (Must Do in Order)
```
Phase 0: Security First (P0)
  ├─ T01: Fix XSS Vulnerabilities (2-3h)
  ├─ T02: Add File Upload Validation (3-4h)
  └─ T03: Basic Authentication (4-6h)
  
Phase 1: Foundation (P1)
  ├─ T04: Create Test Directory Structure (2-3h)
  ├─ T05: Create Proper Domain Model (3-4h)
  └─ T06: Externalize Configuration (2-3h)
  
Phase 2: Type Safety & Quality (P1)
  ├─ T07: Eliminate Raw Types (4-6h) [depends: T05]
  ├─ T08: Constructor Injection (3-4h) [depends: T04]
  └─ T09: Proper Exception Handling (3-5h) [depends: T04, T06]
  
Phase 3: Architecture (P1)
  ├─ T10: Create Repository Layer (4-6h) [depends: T05, T06]
  ├─ T11: Create Service Layer (4-6h) [depends: T05, T07, T10]
  └─ T12: Refactor Controllers (3-5h) [depends: T08, T11]
  
Phase 4: Testing (P1)
  ├─ T13: Unit Tests for Services (4-6h) [depends: T04, T10, T11]
  ├─ T14: Integration Tests for Controllers (4-6h) [depends: T04, T12]
  └─ T15: Achieve 80% Coverage (3-4h) [depends: T13, T14]
  
Phase 5: Code Quality (P2)
  ├─ T16: Add JavaDoc Documentation (3-4h) [depends: all refactoring]
  ├─ T17: Implement Logging (2-3h) [depends: T09]
  └─ T18: Thymeleaf Templates (4-6h) [depends: T01, T12]
  
Phase 6: Final Touches (P2/P1)
  ├─ T19: Clean up PhotoGalleryLegacyApplication (2-3h) [depends: T12]
  ├─ T20: README.md Documentation (2-3h) [depends: all tasks]
  └─ T21: Final Validation (2-4h) [depends: all tasks]
```

### Parallelizable Tasks

| Phase | Can Run in Parallel | Notes |
|-------|---------------------|-------|
| Phase 0 | ❌ No | Security tasks should be done sequentially |
| Phase 1 | ✅ Yes | T04, T05, T06 are independent |
| Phase 2 | ⚠️ Partial | T08 can run with T04, but T07 depends on T05 |
| Phase 3 | ❌ No | T10 → T11 → T12 dependency chain |
| Phase 4 | ✅ Yes | T13 and T14 can run in parallel |
| Phase 5 | ✅ Yes | All tasks are independent |
| Phase 6 | ⚠️ Partial | T19 and T20 can run in parallel, T21 must be last |

---

## ⚡ QUICK WINS vs LONG-TERM IMPROVEMENTS

### Quick Wins (Can be Done Early, High Impact)

| Task | Effort | Impact | Why Quick Win |
|------|--------|--------|---------------|
| **T01** | 2-3h | 🔴 Critical | Fixes XSS - immediate security improvement |
| **T02** | 3-4h | 🔴 Critical | Prevents malicious uploads |
| **T03** | 4-6h | 🔴 Critical | Adds authentication and CSRF protection |
| **T04** | 2-3h | 🟡 High | Enables all other testing |
| **T06** | 2-3h | 🟡 High | Externalizes config - best practice |
| **T16** | 3-4h | 🟢 Medium | Documentation - can be done anytime |
| **T17** | 2-3h | 🟢 Medium | Logging - can be done anytime |
| **T20** | 2-3h | 🟢 Medium | README - can be done last |

**Total Quick Wins Effort**: ~18-24 hours  
**Quick Wins Impact**: Addresses all P0 (Critical) goals + improves maintainability

### Long-Term Improvements (Foundation for Future)

| Task | Effort | Impact | Why Long-Term |
|------|--------|--------|---------------|
| **T05** | 3-4h | 🟡 High | Domain model - used by many other tasks |
| **T07** | 4-6h | 🟡 High | Type safety - prevents many bugs |
| **T08** | 3-4h | 🟡 High | Constructor injection - best practice |
| **T09** | 3-5h | 🟡 High | Exception handling - reliability |
| **T10** | 4-6h | 🟡 High | Repository layer - architecture foundation |
| **T11** | 4-6h | 🟡 High | Service layer - architecture foundation |
| **T12** | 3-5h | 🟡 High | Controller refactoring - clean separation |
| **T13** | 4-6h | 🟡 High | Unit tests - prevents regressions |
| **T14** | 4-6h | 🟡 High | Integration tests - end-to-end verification |
| **T15** | 3-4h | 🟡 High | Coverage - quality metric |
| **T18** | 4-6h | 🟢 Medium | Thymeleaf - proper templating |
| **T19** | 2-3h | 🟢 Medium | Clean separation - maintainability |

**Total Long-Term Effort**: ~47-61 hours  
**Long-Term Impact**: Sustainable architecture, maintainable codebase, testable system

---

## 📈 MILESTONES & CHECKPOINTS

### Milestone 1: Security Complete (End of Day 1-2)
- ✅ T01, T02, T03 completed
- ✅ All critical security vulnerabilities addressed
- **Checkpoint**: Run security scan, verify no XSS/input validation issues

### Milestone 2: Foundation Complete (End of Day 3-5)
- ✅ T04, T05, T06, T07, T08, T09 completed
- ✅ Test infrastructure ready
- ✅ Domain model and type safety established
- **Checkpoint**: Code compiles, basic tests pass, type safety verified

### Milestone 3: Architecture Complete (End of Day 8-10)
- ✅ T10, T11, T12 completed
- ✅ Proper layered architecture implemented
- **Checkpoint**: All endpoints work, architecture review

### Milestone 4: Testing Complete (End of Day 11-13)
- ✅ T13, T14, T15 completed
- ✅ 80%+ code coverage achieved
- **Checkpoint**: `mvn clean test` passes, coverage report reviewed

### Milestone 5: Quality Complete (End of Day 14-15)
- ✅ T16, T17, T18, T19, T20 completed
- ✅ All quality improvements implemented
- **Checkpoint**: Code review, style check, documentation review

### Milestone 6: Final Delivery (End of Day 15-16)
- ✅ T21 completed
- ✅ All acceptance criteria met
- **Checkpoint**: Final validation, stakeholder approval

---

## 🎲 RISK MITIGATION STRATEGY

### High Risk Tasks

| Task | Risk | Mitigation |
|------|------|------------|
| **T03** | Breaking existing access | Implement gradually, permit-all for GET endpoints initially |
| **T07** | Exposing hidden type bugs | Compile frequently, fix issues immediately |
| **T10** | Major data access refactoring | Keep StorageSvc as backup, test thoroughly |
| **T11** | Business logic relocation | Move logic incrementally, test at each step |
| **T12** | Renaming affects references | Use IDE refactoring tools, verify all references |
| **T14** | Integration tests are fragile | Use test profiles, mock external dependencies |

### Medium Risk Tasks

| Task | Risk | Mitigation |
|------|------|------------|
| **T02** | May reject previously accepted files | Document accepted types, add clear error messages |
| **T09** | May expose previously hidden errors | Handle exceptions gracefully, don't break user flows |
| **T18** | HTML output may change slightly | Replicate existing HTML structure in templates |

### Low/No Risk Tasks

| Task | Risk | Notes |
|------|------|-------|
| T01, T04, T06, T16, T17, T20 | Very Low | Isolated changes, minimal impact |

---

## 📊 EFFORT SUMMARY

| Category | Tasks | Min Hours | Max Hours | % of Total |
|----------|-------|-----------|-----------|------------|
| **Quick Wins** | 8 | 18 | 24 | 22-28% |
| **Long-Term** | 13 | 47 | 61 | 55-72% |
| **Total** | **21** | **65** | **85** | **100%** |

### By Phase
| Phase | Tasks | Min Hours | Max Hours |
|-------|-------|-----------|-----------|
| Phase 0: Security | 3 | 9 | 13 |
| Phase 1: Foundation | 3 | 7 | 10 |
| Phase 2: Type Safety | 3 | 10 | 15 |
| Phase 3: Architecture | 3 | 11 | 17 |
| Phase 4: Testing | 3 | 11 | 16 |
| Phase 5: Quality | 3 | 9 | 13 |
| Phase 6: Final | 3 | 6 | 10 |

---

## 🎯 RECOMMENDED APPROACH

### For Single Developer
1. **Start with Quick Wins (Phase 0)** - Immediate security improvements
2. **Build Foundation (Phase 1)** - Test infrastructure, domain model
3. **Address Type Safety (Phase 2)** - Eliminate raw types, improve injection
4. **Implement Architecture (Phase 3)** - Repository and service layers
5. **Add Testing (Phase 4)** - Comprehensive test coverage
6. **Polish Quality (Phase 5-6)** - Documentation, logging, templates

### For Two Developers (Parallel Work)
- **Developer 1**: Focus on **Security (Phase 0)** and **Architecture (Phase 3)**
- **Developer 2**: Focus on **Foundation (Phase 1)**, **Type Safety (Phase 2)**, and **Testing (Phase 4)**
- **Both**: Collaborate on **Quality (Phase 5)** and **Final (Phase 6)**

### For Time-Constrained (1 week sprint)
1. **Day 1-2**: Complete Phase 0 (Security) - **P0 Critical**
2. **Day 3-4**: Complete Phase 1 (Foundation) + Quick Wins
3. **Day 5**: Start Phase 2 (Type Safety)
4. **Weekend**: Optional - Continue Phase 2
5. **Day 6-7**: Complete Phase 3 (Architecture)

This delivers **security-critical improvements** in the first 2 days and **foundation** by day 4.

---

## 🏁 DELIVERY CHECKLIST

Before considering the migration complete:

- [ ] All P0 (Critical) tasks completed
- [ ] All P1 (High) tasks completed
- [ ] All P2 (Medium) tasks completed (or explicitly deferred)
- [ ] `mvn clean compile` succeeds without warnings
- [ ] `mvn clean test` passes all tests
- [ ] 80%+ code coverage achieved
- [ ] All existing endpoints work correctly
- [ ] Security scan passes (no critical vulnerabilities)
- [ ] README.md is complete and accurate
- [ ] All JavaDoc is added
- [ ] Final validation (T21) completed

---

## 📞 CONTACT & SUPPORT

- **Primary Contact**: [Your Name]
- **Reviewer**: [Reviewer Name]
- **Related Documents**: REFACTORING_SPEC.md, AGENTS.md
- **Version Control**: Git repository at current location

---

*This migration plan provides a detailed, actionable roadmap for refactoring the photo-gallery-legacy-java project. All tasks, dependencies, effort estimates, and risks have been carefully considered based on the REFACTORING_SPEC.md requirements and AGENTS.md guidelines.*
