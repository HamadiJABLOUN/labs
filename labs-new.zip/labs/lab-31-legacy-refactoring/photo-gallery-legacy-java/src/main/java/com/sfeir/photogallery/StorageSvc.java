// StorageSvc.java - Intentionally poor service with technical debt
package com.sfeir.photogallery;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import org.springframework.stereotype.Service;

@Service
public class StorageSvc { // Inconsistent naming: should be StorageService

    // Hardcoded storage path - should be configurable
    private String KEY = "photos_data.json";

    private ObjectMapper mapper = new ObjectMapper();

    // No error handling, accepts anything
    public void save(Object data) { // Using Object - poor practice
        try {
            mapper.writeValue(new File(KEY), data);
        } catch (Exception e) {
            // Exception swallowed: a failed write looks exactly like a successful one
        }
    }

    // No validation of returned data
    public List load() { // Raw type
        File f = new File(KEY);
        if (!f.exists()) {
            return new ArrayList();
        }
        try {
            return mapper.readValue(f, List.class);
        } catch (Exception e) {
            return new ArrayList(); // A corrupt file is indistinguishable from an empty gallery
        }
    }

    // Return value ignored, no check that anything was deleted
    public void clearAll() {
        new File(KEY).delete();
    }
}
