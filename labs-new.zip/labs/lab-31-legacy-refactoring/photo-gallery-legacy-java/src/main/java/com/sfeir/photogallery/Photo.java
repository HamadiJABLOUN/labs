// Intentionally poor code - no record, public mutable fields, inconsistent naming
package com.sfeir.photogallery;

public class Photo {
    public String id;
    public String fileName; // Inconsistent: should be filename
    public String data;
    public String date; // Inconsistent: should be uploadedAt, and a String instead of an Instant
    public String tagz; // Typo and wrong type (should be List<String>)
    public Integer fileSize;
}
