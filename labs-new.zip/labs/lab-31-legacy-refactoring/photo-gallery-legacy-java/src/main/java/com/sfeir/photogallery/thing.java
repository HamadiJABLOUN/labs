// thing.java - Another poor class name
package com.sfeir.photogallery;

import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@Controller
public class thing { // Class name doesn't follow conventions

    @Autowired
    private StorageSvc storage; // Second component reaching the file directly

    // No confirmation, no error handling
    @GetMapping("/delete/{id}")
    public String delete(@PathVariable String id) {
        List photos = storage.load();
        photos.removeIf(p -> id.equals(((Map) p).get("id")));
        storage.save(photos);
        return "redirect:/";
    }

    // HTML built by string concatenation in a loop, no templating, no escaping
    public String render(List photos) {
        String html = "<div class=\"grid\">";
        for (Object o : photos) {
            Map p = (Map) o;
            html = html + "<div class=\"photo-card\">"
                    + "<img src=\"" + p.get("data") + "\" alt=\"\" />"
                    + "<p>" + p.get("fileName") + "</p>"
                    + "<p>" + p.get("tagz") + "</p>"
                    + "<a href=\"/delete/" + p.get("id") + "\">Delete</a>"
                    + "</div>";
        }
        return html + "</div>";
    }
}
