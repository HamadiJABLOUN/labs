// comp1.java - Poor class name, no documentation
package com.sfeir.photogallery;

import java.time.LocalDateTime;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

@Controller
public class comp1 { // Class name doesn't follow PascalCase

    // Field injection instead of constructor injection
    @Autowired
    private StorageSvc storage;

    // No input validation
    @PostMapping("/upload")
    public String upload(@RequestParam("photo") MultipartFile file,
                         @RequestParam("tags") String tags) throws Exception {

        // No file size check, no type validation
        byte[] raw = file.getBytes();
        String data = "data:" + file.getContentType() + ";base64,"
                + Base64.getEncoder().encodeToString(raw);

        List photos = storage.load(); // Raw type

        // No validation of data
        Map photo = new HashMap();
        photo.put("id", String.valueOf(System.currentTimeMillis()));
        photo.put("fileName", file.getOriginalFilename());
        photo.put("data", data);
        photo.put("date", LocalDateTime.now().toString());
        photo.put("tagz", tags); // Storing as string, not list
        photo.put("fileSize", raw.length);
        photos.add(photo);

        storage.save(photos);

        return "redirect:/";
    }
}
