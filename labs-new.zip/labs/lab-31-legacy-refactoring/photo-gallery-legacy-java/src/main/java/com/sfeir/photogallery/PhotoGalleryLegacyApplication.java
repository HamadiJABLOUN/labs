// Main app - Minimal documentation, poor structure
package com.sfeir.photogallery;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;

// Bootstrap class and web controller mixed into one
@SpringBootApplication
@Controller
public class PhotoGalleryLegacyApplication {

    @Autowired
    private StorageSvc storage; // Third component touching the same file

    @Autowired
    private thing thing;

    // Hardcoded title, public mutable field
    public String title = "Photo Gallery";

    public static void main(String[] args) {
        SpringApplication.run(PhotoGalleryLegacyApplication.class, args);
    }

    @GetMapping("/")
    @ResponseBody
    public String index() {
        // Direct call without error handling, no loading state
        List photos = storage.load();

        return "<!doctype html><html><head><title>" + title + "</title><style>"
                + ".container { max-width: 1200px; margin: 0 auto; padding: 20px; font-family: Arial, sans-serif; }"
                + "h1 { color: #333; border-bottom: 2px solid #007bff; padding-bottom: 10px; }"
                + ".upload-area { border: 1px solid #ccc; padding: 20px; margin: 10px; }"
                + ".grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)); gap: 10px; }"
                + ".photo-card { border: 1px solid #ddd; padding: 10px; }"
                + ".photo-card img { width: 100%; height: 150px; object-fit: cover; }"
                + "</style></head><body><div class=\"container\">"
                + "<h1>Photo Gallery</h1>"
                + "<div class=\"upload-area\"><h2>Upload Photo</h2>"
                // No validation on file input
                + "<form action=\"/upload\" method=\"post\" enctype=\"multipart/form-data\">"
                + "<input type=\"file\" name=\"photo\" accept=\"image/*\" />"
                + "<input type=\"text\" name=\"tags\" placeholder=\"Tags (comma separated)\" />"
                + "<button type=\"submit\">Upload</button>"
                + "</form></div>"
                // No loading state, no error handling
                + "<div class=\"photo-list\"><h2>Photos</h2>" + thing.render(photos) + "</div>"
                + "</div></body></html>";
    }
}
