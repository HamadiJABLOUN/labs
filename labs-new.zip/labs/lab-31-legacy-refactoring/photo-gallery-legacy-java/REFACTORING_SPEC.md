# REFACTORING SPECIFICATION - Photo Gallery Legacy Java

**Project**: photo-gallery-legacy-java  
**Lab**: 31 - Legacy Refactoring (SFEIR Institute)  
**Version**: 1.0  
**Date**: 2026-10-02  
**Status**: Draft  

---

## 1. GOALS

### Primary Objectives

| Goal | Description | Priority |
|------|-------------|----------|
| **G1** | Eliminate critical security vulnerabilities (XSS, input validation) | Critical |
| **G2** | Improve code quality and maintainability | High |
| **G3** | Establish proper layered architecture | High |
| **G4** | Add comprehensive test coverage | High |
| **G5** | Modernize code to follow Java/Spring best practices | Medium |

### Detailed Goals

#### G1: Security Hardening
- Fix all XSS vulnerabilities in HTML rendering
- Add file upload validation (type, size, content verification)
- Implement authentication/authorization for destructive operations
- Add CSRF protection for state-changing endpoints
- Sanitize all user input before storage and display

#### G2: Code Quality Improvement
- Eliminate raw type usage (`List`, `Map`, `Object`)
- Replace field injection with constructor injection
- Remove public mutable fields
- Fix naming conventions (PascalCase, camelCase)
- Add proper exception handling with logging
- Remove hardcoded configuration values

#### G3: Architecture Modernization
- Implement proper layered architecture (Controller → Service → Repository)
- Separate concerns between presentation, business logic, and data access
- Introduce proper service layer
- Create repository abstraction for storage
- Use the `Photo` domain class consistently instead of `Map`

#### G4: Testing
- Create test directory structure (`src/test/java/`)
- Add unit tests for all services
- Add integration tests for all controllers
- Achieve minimum 80% code coverage
- Implement test data builders for consistency

#### G5: Modernization
- Add proper logging (SLF4J/Logback)
- Use proper date/time types (Instant, LocalDateTime) instead of String
- Implement proper configuration management
- Add input validation using Spring Validation
- Introduce template engine (Thymeleaf) for HTML rendering

---

## 2. SCOPE

### In Scope

#### ✅ Application Code
- All Java source files in `src/main/java/com/sfeir/photogallery/`
- `Photo.java` - Domain model improvements
- `PhotoGalleryLegacyApplication.java` - Separation of concerns
- `StorageSvc.java` - Architecture and quality improvements
- `comp1.java` - Rename and refactor
- `thing.java` - Rename and refactor

#### ✅ Configuration
- `application.properties` - Add configuration properties
- `pom.xml` - Add dependencies (Security, Thymeleaf, Validation, Lombok, Mockito)

#### ✅ Build & Test
- Test directory creation and structure
- Unit test implementation
- Integration test implementation
- Code quality tooling configuration (optional)

#### ✅ Documentation
- Update AGENTS.md as needed
- Add README.md with project information
- Add JavaDoc to public classes and methods

### Out of Scope

#### ❌ Infrastructure
- Deployment configuration (Docker, Kubernetes)
- CI/CD pipeline setup (Jenkins, GitHub Actions)
- Database migration (not applicable - file-based storage)
- Monitoring and observability setup

#### ❌ Advanced Features
- User registration and management
- Photo editing capabilities
- Social sharing features
- Advanced search and filtering
- Image processing (resizing, thumbnail generation)

#### ❌ Performance Optimization
- Caching implementation
- Performance profiling and optimization
- Load testing and scaling
- Database optimization

---

## 3. SUCCESS CRITERIA

### 3.1 Functional Requirements

| ID | Criteria | Verification Method |
|----|----------|---------------------|
| **SC1.1** | All existing functionality preserved | Manual testing, automated integration tests |
| **SC1.2** | Upload endpoint validates file type (images only) | Unit test, manual testing |
| **SC1.3** | Upload endpoint validates file size (max 10MB) | Unit test, manual testing |
| **SC1.4** | XSS protection implemented for all user input | Security scan, manual testing |
| **SC1.5** | Delete endpoint requires authentication | Manual testing, integration test |
| **SC1.6** | CSRF protection enabled | Configuration review, manual testing |

### 3.2 Code Quality Requirements

| ID | Criteria | Verification Method |
|----|----------|---------------------|
| **SC2.1** | No raw types used (`List`, `Map`, `Object`) | Static code analysis, code review |
| **SC2.2** | All classes use constructor injection | Code inspection |
| **SC2.3** | No field injection (`@Autowired` on fields) | Code inspection |
| **SC2.4** | All classes follow Java naming conventions | Code inspection, Checkstyle |
| **SC2.5** | No swallowed exceptions | Code inspection, static analysis |
| **SC2.6** | All public methods have JavaDoc | Code inspection, Checkstyle |
| **SC2.7** | No hardcoded configuration values | Code inspection |
| **SC2.8** | Proper layered architecture implemented | Architecture review |

### 3.3 Testing Requirements

| ID | Criteria | Verification Method |
|----|----------|---------------------|
| **SC3.1** | `src/test/java/` directory exists and structured | Directory inspection |
| **SC3.2** | Unit tests exist for all service classes | Test file count, coverage report |
| **SC3.3** | Integration tests exist for all controllers | Test file count, coverage report |
| **SC3.4** | Minimum 80% code coverage achieved | Coverage report (JaCoCo) |
| **SC3.5** | All tests pass | `mvn test` execution |
| **SC3.6** | Tests run in under 2 minutes | Test execution timing |

### 3.4 Documentation Requirements

| ID | Criteria | Verification Method |
|----|----------|---------------------|
| **SC4.1** | README.md exists with project description | File inspection |
| **SC4.2** | README.md includes setup and run instructions | File inspection |
| **SC4.3** | AGENTS.md updated with any new conventions | File inspection |
| **SC4.4** | All public classes have class-level JavaDoc | Code inspection |
| **SC4.5** | All public methods have method-level JavaDoc | Code inspection |

### 3.5 Acceptance Criteria

The refactoring is considered **complete** when:

1. ✅ All **Critical** and **High** priority goals (G1, G2, G3, G4) are achieved
2. ✅ All **Success Criteria** in sections 3.1, 3.2, 3.3, 3.4 are met
3. ✅ All existing functionality works as before
4. ✅ `mvn clean test` passes successfully
5. ✅ Code compiles without warnings
6. ✅ No critical security vulnerabilities remain

---

## 4. CONSTRAINTS

### 4.1 Time Constraints

| Phase | Estimated Duration | Deadline |
|-------|-------------------|----------|
| Phase 1: Security First | 1-2 days | TBD |
| Phase 2: Type Safety | 2-3 days | TBD |
| Phase 3: Architecture | 2-3 days | TBD |
| Phase 4: Testing | 2-3 days | TBD |
| Phase 5: Code Quality | 1-2 days | TBD |
| Phase 6: Configuration | 1-2 days | TBD |
| **Total** | **10-15 days** | **TBD** |

**Note**: Phases can overlap, and duration may vary based on team size and experience.

### 4.2 Technical Constraints

| Constraint | Description |
|------------|-------------|
| **C1** | Must use Java 17 | Compatibility requirement |
| **C2** | Must use Spring Boot 3.5.16 | Current version, no major version upgrade |
| **C3** | Must maintain Maven build system | No migration to Gradle |
| **C4** | Must preserve existing REST API endpoints | `/`, `/upload`, `/delete/{id}` |
| **C5** | Must use existing `Photo` class as domain model | Don't replace, improve |
| **C6** | Storage must remain file-based (JSON) | No database migration |
| **C7** | Must work on port 42313 (configurable) | Current configuration |

### 4.3 Backwards Compatibility

| Requirement | Description |
|-------------|-------------|
| **BC1** | All existing REST endpoints must remain functional | No breaking changes to API |
| **BC2** | HTML output format must remain visually similar | CSS classes preserved |
| **BC3** | JSON storage file format must be compatible | Can read existing data |
| **BC4** | No changes to HTTP methods | GET, POST preserved |

### 4.4 Resource Constraints

| Resource | Limit |
|----------|-------|
| Team Size | 1-2 developers |
| Available Time | 2-3 weeks (part-time) |
| Memory Usage | Must run on standard development machines |
| Disk Space | Storage file size limited to reasonable image sizes |

### 4.5 Process Constraints

| Constraint | Description |
|------------|-------------|
| **PC1** | Must use Git for version control | All changes committed |
| **PC2** | Must use conventional commits | `feat:`, `fix:`, `refactor:`, etc. |
| **PC3** | Must use pull requests for review | No direct pushes to main |
| **PC4** | Must document breaking changes | In CHANGELOG.md if added |
| **PC5** | Must run tests before commit | `mvn test` must pass |

---

## 5. NON-GOALS

### Explicitly Excluded

| Non-Goal | Reason |
|----------|--------|
| **NG1** | Migrate to different framework (e.g., Micronaut, Quarkus) | Scope creep, not needed |
| **NG2** | Migrate to different language (e.g., Kotlin) | Educational focus on Java |
| **NG3** | Add database persistence (JPA, JDBC) | Out of scope, file-based is sufficient |
| **NG4** | Add user authentication UI (login page) | Use basic auth or token-based for now |
| **NG5** | Implement frontend framework (React, Angular) | Backend-only focus |
| **NG6** | Add caching layer (Redis, Ehcache) | Premature optimization |
| **NG7** | Migrate to Gradle build system | Maven is sufficient |
| **NG8** | Add API versioning | Not needed for this scale |
| **NG9** | Implement OpenAPI/Swagger documentation | Nice-to-have, not required |
| **NG10** | Add internationalization (i18n) | Not in requirements |
| **NG11** | Migrate to Spring Boot 3.x if not already | Already on 3.5.16 |
| **NG12** | Add microservices architecture | Single service is sufficient |
| **NG13** | Implement event-driven architecture | Overkill for this use case |
| **NG14** | Add distributed tracing | Not needed for this scale |
| **NG15** | Implement comprehensive monitoring | Out of scope |

### Deferred for Future Phases

| Future Enhancement | Priority | Notes |
|-------------------|----------|-------|
| Add user registration | Low | Could be Phase 2 |
| Add photo categories | Low | Could be Phase 2 |
| Add search functionality | Medium | Could be Phase 2 |
| Add pagination | Medium | Could be Phase 2 |
| Add photo editing | Low | Could be Phase 3 |
| Migrate to database | Low | Could be Phase 3 |

---

## 6. RISK ASSESSMENT

### High Risks

| Risk | Likelihood | Impact | Mitigation |
|------|------------|--------|------------|
| Breaking existing functionality | Medium | High | Comprehensive testing, incremental changes |
| Security vulnerability introduction | Low | High | Security review, penetration testing |
| Performance degradation | Low | Medium | Performance testing, profiling |

### Medium Risks

| Risk | Likelihood | Impact | Mitigation |
|------|------------|--------|------------|
| Scope creep | Medium | Medium | Strict scope management, regular reviews |
| Test flakiness | Medium | Medium | Reliable test data, isolated tests |
| Merge conflicts | Medium | Medium | Regular commits, pull request reviews |

### Low Risks

| Risk | Likelihood | Impact | Mitigation |
|------|------------|--------|------------|
| Build failures | Low | Low | CI/CD pipeline, local testing |
| Documentation gaps | Low | Low | Regular documentation reviews |

---

## 7. DELIVERABLES

### Phase 1: Security First (Days 1-2)
- [ ] Security vulnerability fixes (XSS, input validation)
- [ ] Spring Security configuration
- [ ] Basic authentication implementation
- [ ] Security test cases

### Phase 2: Type Safety (Days 3-5)
- [ ] Generic types implemented throughout
- [ ] Constructor injection for all classes
- [ ] Domain model improvements (Photo class)
- [ ] Proper exception handling

### Phase 3: Architecture (Days 6-8)
- [ ] Layered architecture implemented
- [ ] Service layer created
- [ ] Repository layer created
- [ ] Controller layer refactored

### Phase 4: Testing (Days 9-11)
- [ ] Test directory structure created
- [ ] Unit tests for all services
- [ ] Integration tests for all controllers
- [ ] 80%+ code coverage achieved

### Phase 5: Code Quality (Days 12-13)
- [ ] Class renaming completed
- [ ] JavaDoc added
- [ ] Logging implemented
- [ ] Code style standardized

### Phase 6: Configuration (Days 14-15)
- [ ] Configuration properties externalized
- [ ] Thymeleaf templates created
- [ ] Validation framework integrated
- [ ] README.md completed

### Final Deliverables
- [ ] Complete refactored codebase
- [ ] Passing test suite
- [ ] Updated documentation (README.md, AGENTS.md)
- [ ] Refactoring summary report

---

## 8. APPROVAL & REVIEW

| Role | Name | Approval Date | Status |
|------|------|---------------|--------|
| Author | [Your Name] | 2026-10-02 | Draft |
| Reviewer | [Reviewer Name] | TBD | Pending |
| Approver | [Approver Name] | TBD | Pending |

---

## 9. REVISION HISTORY

| Version | Date | Author | Changes |
|---------|------|--------|---------|
| 1.0 | 2026-10-02 | [Your Name] | Initial specification |

---

## 10. REFERENCES

- [SFEIR Institute Lab 31 Documentation](TBD)
- [Spring Boot Reference Documentation](https://docs.spring.io/spring-boot/docs/3.5.16/reference/html/)
- [Java 17 Documentation](https://docs.oracle.com/en/java/javase/17/)
- [OWASP Top 10](https://owasp.org/www-project-top-ten/)
- [Clean Code: A Handbook of Agile Software Craftsmanship](https://www.amazon.com/Clean-Code-Handbook-Software-Craftsmanship/dp/0132350882)

---

*This document defines the complete refactoring specification for the photo-gallery-legacy-java project. All stakeholders should review and agree to this specification before refactoring begins.*
