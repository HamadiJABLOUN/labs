# Main app - Minimal documentation, poor structure
from flask import Flask, render_template

from comp1 import comp1
from storage_svc import StorageSvc
from thing import thing

app = Flask(__name__)
app.register_blueprint(comp1)
app.register_blueprint(thing)

storage = StorageSvc()  # Third instance, three places touching the same file

title = 'Photo Gallery'  # Hardcoded title, module-level global


@app.route('/')
def index():
    # Direct call without error handling, no loading state
    photos = storage.load()
    return render_template('index.html', photos=photos, title=title)


if __name__ == '__main__':
    app.run(port=42312, debug=True)
