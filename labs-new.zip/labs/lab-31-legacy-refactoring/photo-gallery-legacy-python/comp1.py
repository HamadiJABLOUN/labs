# comp1.py - Poor module name, no documentation
import base64
from datetime import datetime

from flask import Blueprint, redirect, request, url_for

from storage_svc import StorageSvc

comp1 = Blueprint('comp1', __name__)

storage = StorageSvc()  # Module-level global, direct dependency on storage


# No input validation
@comp1.route('/upload', methods=['POST'])
def upload():
    file = request.files['photo']  # KeyError if the field is missing
    tags = request.form['tags']

    # No file size check, no type validation
    raw = file.read()
    data = 'data:' + file.mimetype + ';base64,' + base64.b64encode(raw).decode()

    photos = storage.load()

    # No validation of data
    photos.append({
        'id': str(int(datetime.now().timestamp() * 1000)),
        'fileName': file.filename,
        'data': data,
        'date': datetime.now().isoformat(),
        'tagz': tags,  # Storing as string, not list
        'fileSize': len(raw),
    })

    storage.save(photos)

    return redirect(url_for('index'))
