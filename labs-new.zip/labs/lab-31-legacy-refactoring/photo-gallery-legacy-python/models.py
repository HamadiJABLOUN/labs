# Intentionally poor code - no dataclass, no type hints, inconsistent naming
class Photo:
    def __init__(self):
        self.id = None
        self.fileName = None  # Inconsistent: should be filename (PEP 8)
        self.data = None
        self.date = None  # Inconsistent: should be uploaded_at
        self.tagz = None  # Typo and wrong type (should be list[str])
        self.fileSize = None
