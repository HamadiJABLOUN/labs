# storage_svc.py - Intentionally poor service with technical debt
import json
import os


class StorageSvc:  # Inconsistent naming: should be StorageService
    # Hardcoded storage path - should be configurable
    KEY = 'photos_data.json'

    # No error handling
    def save(self, data):  # No type hints - poor practice
        f = open(self.KEY, 'w')
        json.dump(data, f)
        f.close()

    # No validation of returned data
    def load(self):
        if not os.path.exists(self.KEY):
            return []
        f = open(self.KEY)
        return json.load(f)

    # camelCase method name in a Python codebase
    def clearAll(self):
        os.remove(self.KEY)
