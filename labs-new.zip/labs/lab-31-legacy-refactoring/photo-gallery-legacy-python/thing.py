# thing.py - Another poor module name
from flask import Blueprint, redirect, url_for

from storage_svc import StorageSvc

thing = Blueprint('thing', __name__)

storage = StorageSvc()  # Second instance touching the same file


# No confirmation, no error handling
@thing.route('/delete/<id>')
def delete(id):
    photos = storage.load()
    photos = [p for p in photos if p['id'] != id]
    storage.save(photos)
    return redirect(url_for('index'))
