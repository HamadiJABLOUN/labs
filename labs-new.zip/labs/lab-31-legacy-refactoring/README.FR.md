# Lab 31 : Refactoring de code legacy avec un workflow agentique

**Durée** : 45-65 minutes  
**Difficulté** : Intermédiaire  
**Prérequis** : Section fondamentaux du Module 3 terminée

## Vue d'ensemble

Dans ce lab, vous allez appliquer les phases **Specify** et **Plan** du workflow agentique pour analyser une application legacy de galerie photo et créer un plan de refactoring complet.

### Objectifs pédagogiques

À la fin de ce lab, vous serez capable de :

1. Utiliser l'IA pour analyser systématiquement du code legacy et identifier la dette technique
2. Créer un **fichier de contexte** (`AGENTS.md`) efficace documentant l'état du projet
3. Rédiger une spécification de refactoring définissant des objectifs d'amélioration clairs
4. Élaborer un plan de migration priorisé avec des estimations de charge

## Scénario

Vous héritez d'une application legacy de galerie photo qui fonctionne, mais qui a accumulé une dette technique importante :

- ❌ Aucun test
- ❌ Conventions de nommage incohérentes
- ❌ Aucune validation des entrées
- ❌ Valeurs de configuration codées en dur
- ❌ Documentation absente
- ❌ Dépendances enchevêtrées

Votre mission : analyser ce code et créer un plan de modernisation systématique en vous appuyant sur les pratiques agentiques assistées par IA.

## Choisissez votre langage

La même galerie legacy est fournie dans **trois stacks**, porteuses de la même dette technique. **Choisissez celle que vous pratiquez au quotidien** : vous repérerez la dette bien plus vite sur un terrain familier, et ce lab porte sur l'analyse, pas sur la syntaxe.

| Stack                      | Dossier du projet             | Lancement                                              |
| -------------------------- | ----------------------------- | ------------------------------------------------------ |
| **TypeScript** (Angular)   | `photo-gallery-legacy`        | `npx nx serve photo-gallery-legacy`                    |
| **Python** (Flask)         | `photo-gallery-legacy-python` | `pip install -r requirements.txt` puis `python app.py` |
| **Java** (Spring Boot 3.5) | `photo-gallery-legacy-java`   | `./mvnw spring-boot:run` (`mvnw.cmd` sous Windows)     |

Vous n'avez jamais besoin d'exécuter l'application pour terminer ce lab — les livrables sont trois
documents Markdown — mais chaque projet démarre si vous voulez voir la dette à l'œuvre.

> Les trois variantes sont volontairement équivalentes : mêmes fonctionnalités, mêmes smells,
> mêmes livrables. Quel que soit votre choix, la solution de référence le couvre.

## Partie 1 : Analyser le code legacy (15-20 minutes)

### Étape 1 : Explorer le projet legacy

Rendez-vous dans le projet legacy correspondant à la stack choisie :

```bash
cd labs/lab-31-legacy-refactoring/photo-gallery-legacy          # TypeScript / Angular
# ou
cd labs/lab-31-legacy-refactoring/photo-gallery-legacy-python   # Python / Flask
# ou
cd labs/lab-31-legacy-refactoring/photo-gallery-legacy-java     # Java / Spring Boot
```

Examinez le code dans votre IDE.

### Étape 2 : Utiliser l'IA pour identifier la dette technique

Ouvrez votre assistant de code IA depuis le dossier du projet et demandez-lui d'analyser le code :

**Exemple de prompt** :

```
Analyze the photo gallery application in this directory. Identify:
1. Technical debt patterns (missing tests, poor naming, etc.)
2. Code quality issues
3. Security concerns
4. Maintainability problems

Provide specific examples from the codebase.
```

### Étape 3 : Documenter vos constats

Prenez des notes sur :

- Les fichiers qui concentrent le plus de problèmes
- Les patterns qui se répètent
- Les améliorations critiques vs celles simplement souhaitables
- Les zones à risque nécessitant une attention immédiate

## Partie 2 : Créer le fichier de contexte (10-15 minutes)

### Étape 4 : Démarrer AGENTS.md

Créez un fichier de contexte `AGENTS.md` qui aidera l'IA à comprendre le projet à chacune de vos prochaines sollicitations. Utilisez l'IDE ou la console pour le créer.

▶ **⚠️ Note importante pour les agents IA ne supportant pas le standard `AGENTS.md`**

Certains agents IA comme Claude Code ou Gemini CLI ne lisent pas encore `AGENTS.md` nativement ; pour ceux-là,
**vous devez créer en plus leur fichier de contexte natif** (par exemple `GEMINI.md` ou `CLAUDE.md`) qui peut renvoyer vers `AGENTS.md` pour le contenu réel. Par exemple :

```bash
echo "Follow the instructions in [AGENTS.md](./AGENTS.md)" > GEMINI.md #for Gemini CLI
# or
echo "Follow the instructions in @AGENTS.md" > CLAUDE.md  #for Claude Code
```

### Étape 5 : Compléter le fichier de contexte

Faites-vous aider par l'IA pour remplir le template AGENTS.md avec les informations du projet :

```markdown
# Project Context for AI Assistants

## Project Overview

[Brief description: What does this application do?]

## Architecture

[Component structure, data flow, key dependencies]

## Tech Stack

[Versions, frameworks, build tools]

## Main Commands

[How to run, build, test the application]

## Coding Conventions

[Naming patterns, file structure, style guides]

## Current State

[Technical debt identified, architecture issues]

## Known Issues

[Bugs, technical debt, missing features]

## Refactoring Goals

[What we want to achieve]
```

**Astuce** : demandez à l'IA de vous aider à alimenter chaque section à partir de l'analyse du code.

## Partie 3 : Rédiger la spécification de refactoring (10-15 minutes)

### Étape 6 : Créer REFACTORING_SPEC.md

Définissez **ce qui** doit être amélioré (pas encore **comment**) :

**Prompt pour l'IA** :

```
Based on the AGENTS.md context and the technical debt we identified,
help me create a refactoring specification that includes:

1. Goals: What we want to achieve
2. Scope: What's included and excluded
3. Success Criteria: How we'll know we're done
4. Constraints: Time, backwards compatibility, etc.
5. Non-Goals: What we explicitly won't do

Save the final refactoring specification in REFACTORING_SPEC.md
```

### Étape 7 : Relire et affiner

Vérifiez que votre spécification :

- ✅ Fixe des objectifs clairs et mesurables
- ✅ Définit les limites du périmètre
- ✅ Liste des critères de succès précis
- ✅ Reconnaît les contraintes
- ✅ Indique ce qui est hors périmètre

## Partie 4 : Élaborer le plan de migration (10-15 minutes)

### Étape 8 : Créer MIGRATION_PLAN.md

Découpez le refactoring en tâches priorisées :

**Prompt pour l'IA** :

```
Using the REFACTORING_SPEC.md and AGENTS.md context,
create a prioritized migration plan with:

1. Task list with dependencies
2. Effort estimates (hours)
3. Risk assessment for each task
4. Recommended order of execution
5. Quick wins vs long-term improvements

Save the migration plan in MIGRATION_PLAN.md
```

### Étape 9 : Prioriser les tâches

Travaillez avec l'IA pour organiser les tâches selon :

- **P1 Critique** : à faire absolument (sécurité, bugs, points bloquants)
- **P2 Élevée** : à faire (couverture de tests, refactoring majeur)
- **P3 Moyenne** : souhaitable (nettoyage de code, optimisation)
- **P4 Basse** : améliorations futures

### Étape 10 : Estimer et ordonner

Pour chaque tâche, ajoutez :

- La charge estimée (heures)
- Les dépendances vers d'autres tâches
- Le niveau de risque (élevé/moyen/faible)
- L'impact attendu

## Livrables

Tous les livrables doivent être créés dans le dossier du projet que vous avez choisi
(`photo-gallery-legacy/`, `photo-gallery-legacy-python/` ou `photo-gallery-legacy-java/`) :

1. ✅ **AGENTS.md** : fichier de contexte documentant l'état du projet
2. ✅ **REFACTORING_SPEC.md** : spécification claire des objectifs de refactoring
3. ✅ **MIGRATION_PLAN.md** : liste de tâches priorisée avec estimations

## Checklist de validation

- [ ] Le fichier de contexte contient toutes les sections requises avec des détails propres au projet
- [ ] La spec de refactoring a des critères de succès mesurables
- [ ] Le plan de migration comporte au moins 10 tâches précises et actionnables
- [ ] Les tâches sont priorisées avec des dépendances explicites
- [ ] Les estimations de charge sont réalistes (examinez chaque tâche avec soin)
- [ ] Le plan traite toute la dette technique critique identifiée

## Conseils pour réussir

### Des prompts IA efficaces

**❌ Faible** : « Que devrais-je refactorer ? »
**✅ Bon** : « À partir du composant d'upload photo dans `src/app/comp1.ts`, quelles améliorations précises suggérerais-tu ? Prends en compte la validation, la gestion d'erreurs et les tests. »

Le fichier équivalent dans les autres stacks : `comp1.py` (Python) ou `comp1.java` (Java). Nommez le
fichier réel dans votre prompt — une question ancrée sur un chemin obtient une réponse bien plus
concrète qu'une question générale.

### Stratégie d'itération

1. Commencez par une analyse large
2. Descendez ensuite sur des composants précis
3. Demandez à l'IA des exemples et des alternatives
4. Affinez selon les contraintes du projet

### Le contexte est déterminant

Plus le contexte fourni dans AGENTS.md est précis, mieux l'IA pourra vous aider à :

- Comprendre les patterns legacy
- Proposer des approches de refactoring adaptées
- Estimer la charge de façon réaliste
- Identifier les dépendances

## Pièges courants

❌ **Spécifications vagues** : « Améliore le code »
✅ **Objectifs précis** : « Ajouter une validation des entrées sur tous les uploads de fichiers, avec limites de taille et contrôle de type »

❌ **Aucune priorisation** : toutes les tâches marquées critiques
✅ **Priorités claires** : P1 correctifs de sécurité, P2 couverture de tests, P3 nettoyage de code

❌ **Contraintes ignorées** : un plan qui demande 3 mois de travail
✅ **Périmètre réaliste** : se concentrer sur les améliorations à fort impact réalisables en 2-3 semaines

## Prochaines étapes

Après ce lab :

1. Consultez la solution dans `labs/lab-31-legacy-refactoring-solution/` — les variantes Python
   et Java sont dans `resources/python/`, `resources/java/` et leurs dossiers `*-solution/`
2. Comparez votre approche avec l'exemple fourni
3. Notez ce que vous retenez de votre démarche d'analyse
4. Préparez vos questions pour le débrief de la solution
   /
