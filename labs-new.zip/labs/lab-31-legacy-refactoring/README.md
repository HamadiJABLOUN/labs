# Lab 31: Legacy Code Refactoring with Agentic Workflow

**Duration**: 45-65 minutes  
**Difficulty**: Intermediate  
**Prerequisites**: Completed Module 3 fundamentals section

## Overview

In this lab, you'll apply the **Specify** and **Plan** phases of the agentic workflow to analyze a legacy photo gallery application and create a comprehensive refactoring plan.

### Learning Objectives

By the end of this lab, you will be able to:

1. Use AI to systematically analyze legacy code and identify technical debt
2. Create an effective **context file** (`AGENTS.md`) documenting project state
3. Write a refactoring specification defining clear improvement goals
4. Develop a prioritized migration plan with effort estimates

## Scenario

You've inherited a legacy photo gallery application that works but has accumulated significant technical debt:

- ❌ No tests
- ❌ Inconsistent naming conventions
- ❌ No input validation
- ❌ Hardcoded configuration values
- ❌ Missing documentation
- ❌ Tangled dependencies

Your task is to analyze this codebase and create a systematic plan for modernization using AI-assisted agentic practices.

## Choose Your Language

The same legacy gallery is provided in **three stacks**, carrying the same technical debt. **Pick the one you work in every day**: you will spot debt far faster on familiar ground, and this lab is about the analysis, not the syntax.

| Stack                      | Project folder                | Run it with                                            |
| -------------------------- | ----------------------------- | ------------------------------------------------------ |
| **TypeScript** (Angular)   | `photo-gallery-legacy`        | `npx nx serve photo-gallery-legacy`                    |
| **Python** (Flask)         | `photo-gallery-legacy-python` | `pip install -r requirements.txt` then `python app.py` |
| **Java** (Spring Boot 3.5) | `photo-gallery-legacy-java`   | `./mvnw spring-boot:run` (`mvnw.cmd` on Windows)       |

You never need to run the application to complete this lab — the deliverables are three Markdown
documents — but each project does run if you want to see the debt in action.

> The three variants are deliberately equivalent: same features, same smells, same deliverables.
> Whichever you pick, the reference solution covers it.

## Part 1: Analyze the Legacy Codebase (15-20 minutes)

### Step 1: Explore the Legacy Project

Navigate to the legacy photo gallery project matching your chosen stack:

```bash
cd labs/lab-31-legacy-refactoring/photo-gallery-legacy          # TypeScript / Angular
# or
cd labs/lab-31-legacy-refactoring/photo-gallery-legacy-python   # Python / Flask
# or
cd labs/lab-31-legacy-refactoring/photo-gallery-legacy-java     # Java / Spring Boot
```

Examine the codebase in your IDE.

### Step 2: Use AI to Identify Technical Debt

Open your AI coding assistant from the project folder and ask it to analyze the codebase:

**Prompt Example**:

```
Analyze the photo gallery application in this directory. Identify:
1. Technical debt patterns (missing tests, poor naming, etc.)
2. Code quality issues
3. Security concerns
4. Maintainability problems

Provide specific examples from the codebase.
```

### Step 3: Document Your Findings

Create notes about:

- Which files have the most issues
- Patterns you see repeated
- Critical vs nice-to-have improvements
- Risk areas that need immediate attention

## Part 2: Create Context File (10-15 minutes)

### Step 4: Start AGENTS.md

Create a context file `AGENTS.md` that will help AI understand the project every time you ask it something next. Use the IDE/console to create it.

▶ **⚠️ Important Note for AI Agents not supporting `AGENTS.md` standard**

Some AI agents like Claude Code or Gemini CLI don't natively read `AGENTS.md` yet, so for those,
**you need to additionally create their native context file** (e.g., `GEMINI.md` or `CLAUDE.md`) that can refer to `AGENTS.md` for the actual content. For example:

```bash
echo "Follow the instructions in [AGENTS.md](./AGENTS.md)" > GEMINI.md #for Gemini CLI
# or
echo "Follow the instructions in @AGENTS.md" > CLAUDE.md  #for Claude Code
```

### Step 5: Complete the Context File

Use AI to help you fill in the AGENTS.md template with project information:

```markdown
# Project Context for AI Assistants

## Project Overview

[Brief description: What does this application do?]

## Architecture

[Component structure, data flow, key dependencies]

## Tech Stack

[Versions, frameworks, build tools]

## Main Commands

[How to run, build, test the application]

## Coding Conventions

[Naming patterns, file structure, style guides]

## Current State

[Technical debt identified, architecture issues]

## Known Issues

[Bugs, technical debt, missing features]

## Refactoring Goals

[What we want to achieve]
```

**Tip**: Ask AI to help populate each section based on the codebase analysis.

## Part 3: Write Refactoring Specification (10-15 minutes)

### Step 6: Create REFACTORING_SPEC.md

Define **what** needs to be improved (not **how** yet):

**Prompt for AI**:

```
Based on the AGENTS.md context and the technical debt we identified,
help me create a refactoring specification that includes:

1. Goals: What we want to achieve
2. Scope: What's included and excluded
3. Success Criteria: How we'll know we're done
4. Constraints: Time, backwards compatibility, etc.
5. Non-Goals: What we explicitly won't do

Save the final refactoring specification in REFACTORING_SPEC.md
```

### Step 7: Review and Refine

Ensure your specification:

- ✅ Has clear, measurable goals
- ✅ Defines scope boundaries
- ✅ Lists specific success criteria
- ✅ Acknowledges constraints
- ✅ States what's out of scope

## Part 4: Develop Migration Plan (10-15 minutes)

### Step 8: Create MIGRATION_PLAN.md

Break down the refactoring into prioritized tasks:

**Prompt for AI**:

```
Using the REFACTORING_SPEC.md and AGENTS.md context,
create a prioritized migration plan with:

1. Task list with dependencies
2. Effort estimates (hours)
3. Risk assessment for each task
4. Recommended order of execution
5. Quick wins vs long-term improvements

Save the migration plan in MIGRATION_PLAN.md
```

### Step 9: Prioritize Tasks

Work with AI to organize tasks by:

- **P1 Critical**: Must do (security, bugs, blocking issues)
- **P2 High**: Should do (test coverage, major refactoring)
- **P3 Medium**: Nice to have (code cleanup, optimization)
- **P4 Low**: Future improvements

### Step 10: Estimate and Sequence

For each task, add:

- Estimated effort (hours)
- Dependencies on other tasks
- Risk level (high/medium/low)
- Expected impact

## Deliverables

All deliverables should be created in the project folder you chose (`photo-gallery-legacy/`,
`photo-gallery-legacy-python/` or `photo-gallery-legacy-java/`):

1. ✅ **AGENTS.md**: Context file documenting project state
2. ✅ **REFACTORING_SPEC.md**: Clear specification of refactoring goals
3. ✅ **MIGRATION_PLAN.md**: Prioritized task list with estimates

## Validation Checklist

- [ ] Context file includes all required sections with specific project details
- [ ] Refactoring spec has measurable success criteria
- [ ] Migration plan has at least 10 specific, actionable tasks
- [ ] Tasks are prioritized with clear dependencies
- [ ] Effort estimates are realistic (consider each task carefully)
- [ ] Plan addresses all critical technical debt identified

## Tips for Success

### Effective AI Prompts

**❌ Poor**: "What should I refactor?"
**✅ Good**: "Based on the photo upload component in `src/app/comp1.ts`, what specific improvements would you suggest? Consider validation, error handling, and testing."

The equivalent file in the other stacks: `comp1.py` (Python) or `comp1.java` (Java). Name the actual
file in your prompt — a question anchored to a path gets a far more concrete answer than a general one.

### Iteration Strategy

1. Start with broad analysis
2. Drill down into specific components
3. Ask AI for examples and alternatives
4. Refine based on project constraints

### Context is Key

The more specific context you provide in AGENTS.md, the better AI can assist with:

- Understanding legacy patterns
- Suggesting appropriate refactoring approaches
- Estimating effort realistically
- Identifying dependencies

## Common Pitfalls

❌ **Vague specifications**: "Make the code better"
✅ **Specific goals**: "Add input validation to all file uploads with size limits and type checking"

❌ **No prioritization**: All tasks marked as critical
✅ **Clear priorities**: P1 security fixes, P2 test coverage, P3 code cleanup

❌ **Ignoring constraints**: Plan requires 3 months of work
✅ **Realistic scope**: Focus on high-impact improvements achievable in 2-3 weeks

## Next Steps

After completing this lab:

1. Review the solution in `labs/lab-31-legacy-refactoring-solution/` — the Python and Java
   variants live in `resources/python/`, `resources/java/` and their `*-solution/` project folders
2. Compare your approach with the provided example
3. Note any insights about your analysis process
4. Prepare questions for the solution walkthrough
   /
