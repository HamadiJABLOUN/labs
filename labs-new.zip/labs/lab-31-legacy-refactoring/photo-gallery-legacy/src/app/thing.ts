// thing.ts - Another poor component name
import { Component, OnInit } from '@angular/core';

import { StorageSvc } from './storage.service';

@Component({
  selector: 'app-thing',
  standalone: true,
  imports: [],
  template: `
    <div class="photo-list">
      <h2>Photos</h2>
      <!-- No loading state, no error handling -->
      <div class="grid">
        @for (p of photos; track p) {
        <div class="photo-card">
          <img [src]="p.data" alt="" />
          <p>{{ p.fileName }}</p>
          <p>{{ p.tagz }}</p>
          <button (click)="delete(p.id)">Delete</button>
        </div>
        }
      </div>
    </div>
  `,
  styles: [
    `
      .grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
        gap: 10px;
      }
      .photo-card {
        border: 1px solid #ddd;
        padding: 10px;
      }
      .photo-card img {
        width: 100%;
        height: 150px;
        object-fit: cover;
      }
    `,
  ],
})
export class thing implements OnInit {
  // Class name doesn't follow conventions
  photos: any[] = []; // Using 'any'

  // Intentionally disabled: legacy code uses constructor injection as a teaching example
  // eslint-disable-next-line @angular-eslint/prefer-inject
  constructor(private storage: StorageSvc) {}

  ngOnInit() {
    // Direct call without error handling
    this.photos = this.storage.load();
  }

  // No confirmation dialog
  delete(id: string) {
    this.photos = this.photos.filter((p: any) => p.id !== id);
    this.storage.save(this.photos);
  }
}
