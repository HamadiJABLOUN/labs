// Intentionally poor code - no interface, inconsistent naming
export class Photo {
  id?: string;
  fileName?: string;  // Inconsistent: should be filename
  data?: string;
  date?: string;  // Inconsistent: should be uploadedAt
  tagz?: string;  // Typo and wrong type (should be string[])
  fileSize?: number;
}
