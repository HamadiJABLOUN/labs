// storage.service.ts - Intentionally poor service with technical debt
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class StorageSvc {  // Inconsistent naming: should be StorageService
  // Hardcoded storage key - should be configurable
  private KEY = 'photos_data';
  
  // No error handling
  save(data: any) {  // Using 'any' type - poor practice
    localStorage.setItem(this.KEY, JSON.stringify(data));
  }
  
  // No validation of returned data
  load() {
    const data = localStorage.getItem(this.KEY);
    return data ? JSON.parse(data) : [];
  }
  
  // Typo in method name
  clearAll() {
    localStorage.removeItem(this.KEY);
  }
}
