// comp1.ts - Poor component name, no documentation
import { Component } from '@angular/core';

import { FormsModule } from '@angular/forms';
import { StorageSvc } from './storage.service';

@Component({
  selector: 'app-comp1', // Unclear name
  standalone: true,
  imports: [FormsModule],
  template: `
    <div class="upload-area">
      <h2>Upload Photo</h2>
      <!-- No validation on file input -->
      <input type="file" (change)="onFileSelect($event)" accept="image/*" />
      @if (preview) {
      <div>
        <!-- Intentionally disabled: legacy template is missing alt text as a teaching example -->
        <!-- eslint-disable-next-line @angular-eslint/template/alt-text -->
        <img [src]="preview" style="max-width: 200px;" />
      </div>
      }
      <input
        type="text"
        [(ngModel)]="tags"
        placeholder="Tags (comma separated)"
      />
      <button (click)="upload()">Upload</button>
    </div>
  `,
  styles: [
    `
      .upload-area {
        border: 1px solid #ccc;
        padding: 20px;
        margin: 10px;
      }
    `,
  ],
})
export class comp1 {
  // Class name doesn't follow PascalCase
  preview: any; // Using 'any'
  selectedFile: any; // Using 'any'
  tags = '';

  // Intentionally disabled: legacy code uses constructor injection as a teaching example
  // eslint-disable-next-line @angular-eslint/prefer-inject
  constructor(private storage: StorageSvc) {} // Direct dependency on storage

  // No input validation
  onFileSelect(event: any) {
    const file = event.target.files[0];
    this.selectedFile = file;

    // No file size check, no type validation
    const reader = new FileReader();
    reader.onload = (e: any) => {
      this.preview = e.target.result;
    };
    reader.readAsDataURL(file);
  }

  // No error handling
  upload() {
    if (!this.selectedFile) return;

    const photos = this.storage.load();

    // No validation of data
    photos.push({
      id: Date.now().toString(),
      fileName: this.selectedFile.name,
      data: this.preview,
      date: new Date().toISOString(),
      tagz: this.tags, // Storing as string, not array
      fileSize: this.selectedFile.size,
    });

    this.storage.save(photos);

    // Reset without proper cleanup
    this.preview = null;
    this.selectedFile = null;
    this.tags = '';
  }
}
