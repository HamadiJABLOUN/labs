// Main app - Minimal documentation, poor structure
import { Component } from '@angular/core';
import { comp1 } from './comp1';
import { thing } from './thing';

@Component({
  selector: 'app-root',
  imports: [comp1, thing],
  template: `
    <div class="container">
      <h1>Photo Gallery</h1>
      <!-- Components directly embedded without proper container structure -->
      <app-comp1></app-comp1>
      <app-thing></app-thing>
    </div>
  `,
  styles: [`
    .container {
      max-width: 1200px;
      margin: 0 auto;
      padding: 20px;
      font-family: Arial, sans-serif;
    }
    h1 {
      color: #333;
      border-bottom: 2px solid #007bff;
      padding-bottom: 10px;
    }
  `]
})
export class AppComponent {
  // Hardcoded title
  title = 'Photo Gallery';
}
