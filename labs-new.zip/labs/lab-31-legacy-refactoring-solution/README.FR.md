# Solution du Lab 31 : Refactoring de code legacy

> **Public : formateurs.** Ce document contient le script de démonstration live, les repères de
> timing et les critères d'évaluation. Il n'est _pas_ écrit pour les stagiaires.
>
> **Les stagiaires** liront plutôt les artefacts eux-mêmes — ce sont eux le vrai livrable :
> `resources/` pour les documents de cadrage, et les dossiers `*-solution/` pour le code.

**Objectif** : Fournir aux formateurs et aux apprenants un exemple complet d'application du workflow agentique à l'analyse de code legacy et à la planification d'un refactoring, ainsi que le code refactoré montrant l'état « après ».

## Vue d'ensemble de la solution

Cette solution montre comment analyser méthodiquement une base de code legacy et construire un plan de refactoring complet grâce aux pratiques agentiques assistées par IA.

## 📁 Structure de la solution

```
lab-31-legacy-refactoring-solution/
├── README.md                           # This file - trainer guide
└── resources/
      ├── REFACTORING_SPEC.md         # Refactoring goals & acceptance criteria  (TypeScript)
      ├── MIGRATION_PLAN.md           # 20-task implementation plan              (TypeScript)
      ├── python/                     # ⭐ Variante Python des deux documents de cadrage
      │     ├── REFACTORING_SPEC.md
      │     └── MIGRATION_PLAN.md
      ├── java/                       # ⭐ Variante Java des deux documents de cadrage
      │     ├── REFACTORING_SPEC.md
      │     └── MIGRATION_PLAN.md
      ├── photo-gallery-legacy-python-solution/  # ⭐ CODE REFACTORÉ (Flask, 55 tests)
      ├── photo-gallery-legacy-java-solution/    # ⭐ CODE REFACTORÉ (Spring Boot, 59 tests)
      └── photo-gallery-legacy-solution/ # ⭐ REFACTORED CODE
         ├── AGENTS.md                   # Legacy code analysis (context file)
         ├── README.md                   # Refactored solution documentation
         ├── src/app/
         │   ├── models/
         │   │   ├── photo.model.ts         # Proper Photo interface + validation
         │   │   └── photo.model.spec.ts    # 24 tests (vs 0 in legacy)
         │   ├── services/
         │   │   ├── photo-storage.service.ts  # Refactored service
         │   │   └── photo-storage.service.spec.ts  # 25 tests
         │   ├── components/
         │   │   ├── photo-upload.component.ts    # Refactored upload
         │   │   └── photo-list.component.ts      # Refactored list
         │   └── app.ts                   # Root component
         └── ...
```

**Livrables clés :**

1. **AGENTS.md** - Analyse complète du code legacy identifiant 6 patterns de dette technique
2. **REFACTORING_SPEC.md** - Objectifs, périmètre et critères d'acceptation organisés par priorité
3. **MIGRATION_PLAN.md** - 20 tâches avec estimations d'effort (21-27 heures)
4. **photo-gallery-legacy-solution/** - ⭐ **Code refactoré réellement fonctionnel** (50 tests, >70 % de couverture)

## Variantes par langage

Le lab fournit la même galerie legacy dans trois stacks. Chacune a sa solution complète : le fichier
de contexte, les deux documents de cadrage, et un projet refactoré avec une suite de tests qui passe.

| Stack                      | Projet legacy (stagiaire)     | Solution refactorée                               | Tests                              |
| -------------------------- | ----------------------------- | ------------------------------------------------- | ---------------------------------- |
| **TypeScript** (Angular)   | `photo-gallery-legacy`        | `resources/photo-gallery-legacy-solution/`        | 50, Vitest                         |
| **Python** (Flask)         | `photo-gallery-legacy-python` | `resources/photo-gallery-legacy-python-solution/` | **55, pytest, 96 % de couverture** |
| **Java** (Spring Boot 3.5) | `photo-gallery-legacy-java`   | `resources/photo-gallery-legacy-java-solution/`   | **59, JUnit 5 + MockMvc**          |

Les documents de cadrage se trouvent à côté :

- TypeScript : `resources/REFACTORING_SPEC.md`, `resources/MIGRATION_PLAN.md`
- Python : `resources/python/REFACTORING_SPEC.md`, `resources/python/MIGRATION_PLAN.md`
- Java : `resources/java/REFACTORING_SPEC.md`, `resources/java/MIGRATION_PLAN.md`

Chaque `AGENTS.md` est placé dans son propre projet solution, là où le stagiaire doit l'écrire.

### Ce qui diffère entre les stacks, et pourquoi le montrer

Les trois variantes portent les _mêmes_ six motifs de dette, mais chaque langage en expose un de
façon plus tranchée. Ce contraste est ce qu'il y a de plus exploitable au débriefing :

- **TypeScript** — du `any` partout. Le vérificateur de types était disponible, il n'a simplement pas
  été utilisé.
- **Python** — contrats implicites. L'enregistrement est un `dict` nu ; rien n'indique que `tagz` est
  une chaîne plutôt qu'une liste avant que quelque chose casse à l'exécution. Cette variante porte
  aussi un `debug=True` en dur, qui est une faille d'exécution de code à distance, pas un problème de
  style.
- **Java** — types bruts et exceptions avalées. `List load()` et `save(Object)` compilent sans broncher
  et échouent au cast. `StorageSvc.save()` attrape `Exception` et ne fait rien : une écriture échouée
  signale un succès. C'est aussi la seule variante porteuse d'un **XSS stocké** : le HTML est construit
  par concaténation, donc un nom de fichier contenant une balise `<script>` s'exécute.

Demandez à la salle quelle dette leur assistant IA a repérée en premier. En pratique il trouve
immédiatement les problèmes de nommage dans les trois cas, et presque jamais l'exception avalée en
Java — bonne illustration de la raison pour laquelle l'étape d'analyse a besoin d'un humain qui lit
le diff.

### Lancer les variantes

```bash
# Python
cd resources/photo-gallery-legacy-python-solution
python -m venv .venv && .venv/Scripts/activate   # source .venv/bin/activate sous macOS/Linux
pip install -r requirements-dev.txt
pytest                                            # 55 passed, 96 % de couverture
python app.py                                     # http://localhost:42312

# Java
cd resources/photo-gallery-legacy-java-solution
./mvnw test                                       # 59 tests, BUILD SUCCESS
./mvnw spring-boot:run                            # http://localhost:42313
```

Sous Windows, utilisez `mvnw.cmd` au lieu de `./mvnw`.

## Notes de démonstration pour le formateur

### Intégration de la démo live (15-20 minutes)

Lors de la présentation de cette solution, montrez le **workflow Agentic Coding en action** :

#### Partie 1 : Analyse du code legacy (5-7 minutes)

**Montrer le processus** :

1. **Ouvrir la base de code legacy** dans votre IDE
2. **Utiliser l'IA pour analyser** la dette technique :

   ```
   Prompt: "Analyze this photo gallery codebase and identify technical debt patterns.
   Focus on: missing tests, inconsistent naming, validation issues, hardcoded values,
   missing documentation, and tangled dependencies. Provide specific examples."
   ```

3. **Parcourir les conclusions de l'IA** :
   - Pointer des exemples de code précis à l'écran
   - Expliquer comment l'IA a identifié les patterns
   - Mettre en avant les problèmes les plus critiques

4. **Insister sur l'approche systématique** :
   - Traditionnel : le développeur relit le code à la main et peut manquer des problèmes
   - Agentique : l'IA balaie systématiquement toute la base de code et identifie les patterns

#### Partie 2 : Création du fichier de contexte (3-5 minutes)

**Montrer le processus** :

1. **Créer AGENTS.md** et expliquer son rôle
2. **Utiliser l'IA pour remplir les sections** :

   ```
   Prompt: "Based on your analysis, help me complete this AGENTS.md context file.
   Include: project overview, current state with identified issues, architecture
   description, tech stack, and refactoring goals."
   ```

3. **Démontrer l'itération** :
   - Montrer la première réponse de l'IA
   - Affiner avec des questions de relance
   - Souligner comment le contexte s'améliore à chaque itération

4. **Point pédagogique clé** :
   - « Ce fichier de contexte devient notre "compréhension partagée" avec l'IA »
   - « Meilleur est le contexte, meilleure est l'assistance de l'IA »

#### Partie 3 : Rédaction de la spécification (4-5 minutes)

**Montrer le processus** :

1. **Créer REFACTORING_SPEC.md**
2. **Utiliser l'IA pour rédiger la spécification** :

   ```
   Prompt: "Using the AGENTS.md context and technical debt identified,
   create a refactoring specification with: goals, scope, success criteria,
   constraints, and non-goals."
   ```

3. **Relire et affiner** :
   - Vérifier que les objectifs sont précis et mesurables
   - S'assurer que le périmètre est réaliste
   - Vérifier que les contraintes sont prises en compte

4. **Contraster avec l'approche traditionnelle** :
   - Traditionnel : objectifs vagues du type « faire mieux »
   - Agentique : critères de succès précis et mesurables

#### Partie 4 : Plan de migration (3-5 minutes)

**Montrer le processus** :

1. **Créer MIGRATION_PLAN.md**
2. **Utiliser l'IA pour générer le découpage en tâches** :

   ```
   Prompt: "Create a prioritized migration plan with: task list with dependencies,
   effort estimates in hours, risk assessment, recommended execution order.
   Organize by P1 (critical), P2 (high), P3 (medium), P4 (low)."
   ```

3. **Parcourir la logique de priorisation** :
   - Pourquoi certaines tâches sont en P1 (sécurité, points bloquants)
   - Dépendances entre les tâches
   - Gains rapides vs améliorations de long terme

4. **Mettre en avant la pensée systématique** :
   - Pas de correctifs au hasard
   - Approche stratégique et priorisée
   - Planification consciente des risques

### Points pédagogiques clés

**Tout au long de la démonstration, insistez sur** :

1. **Processus structuré** : chaque phase s'appuie sur la précédente
2. **L'IA comme collaboratrice** : le développeur mène, l'IA assiste sur l'analyse
3. **Focus qualité** : l'approche systématique détecte des problèmes qu'une relecture manuelle laisserait passer
4. **Le contexte est critique** : AGENTS.md permet une meilleure assistance de l'IA
5. **Itération** : affiner les sorties de l'IA par le dialogue

### Questions fréquentes des apprenants

**Q : « Combien de temps prend cette analyse sur de vrais projets ? »**
R : Pour une base de code de cette taille (500-1000 LOC), environ 45-60 minutes. Les projets plus gros passent à l'échelle linéairement, mais le processus reste le même.

**Q : « Et si l'IA rate quelque chose d'important ? »**
R : L'IA est un outil, pas un remplacement du jugement d'ingénieur. Relisez et validez toujours son analyse. L'approche systématique aide à garantir l'exhaustivité.

**Q : « Ai-je toujours besoin d'un AGENTS.md ? »**
R : Pour tout projet non trivial, oui. Les fichiers de contexte améliorent nettement la qualité de l'assistance de l'IA. Ils sont particulièrement critiques sur les bases de code legacy.

**Q : « Et si ma priorisation diffère de celle de l'IA ? »**
R : Votre expertise compte ! Utilisez les suggestions de l'IA comme entrée, mais décidez en dernier ressort selon les besoins métier, les contraintes techniques et la capacité de l'équipe.

## Artefacts de la solution

Le répertoire `resources/photo-gallery-legacy-solution/` contient des exemples complets :

### AGENTS.md

Montre une analyse de code legacy efficace, documentant :

- La dette technique actuelle avec des exemples précis
- Les patterns d'architecture (bons et problématiques)
- Les zones de risque demandant une attention immédiate
- Les dépendances et les contraintes

### REFACTORING_SPEC.md

Illustre une spécification claire avec :

- Des objectifs mesurables (ex. « Atteindre 80 % de couverture de tests »)
- Un périmètre borné (ce qui est inclus/exclu)
- Des critères de succès précis
- Des contraintes assumées (temps, compatibilité)

### MIGRATION_PLAN.md

Fournit un découpage priorisé en tâches avec :

- 15-20 tâches précises organisées par priorité
- Des estimations d'effort (2-16 heures par tâche)
- Une cartographie des dépendances
- Une évaluation des risques pour chaque tâche
- Un ordre d'exécution recommandé

### photo-gallery-legacy-solution/

Implémentation de référence complète montrant l'état « après » :

- **Démontre les 6 améliorations** : nommage clair, tests exhaustifs, logique de validation, constantes de configuration, documentation complète, types stricts
- **Application fonctionnelle** : app Nx Angular buildable avec 50 tests qui passent
- **Comparaison avant/après** : exemples côte à côte dans le README montrant les améliorations précises
- **Valeur pédagogique** : les apprenants peuvent explorer du vrai code refactoré, pas seulement des documents de planification

**Utilisation en démo** :

```bash
# Show students the working refactored code
npx nx serve photo-gallery-legacy-solution

# Run tests to demonstrate coverage
npx nx test photo-gallery-legacy-solution --run
```

> **Note** : comparez le code legacy dans `lab-31-legacy-refactoring/photo-gallery-legacy/src/app/` avec le code refactoré dans `src/app/` pour voir les améliorations (ex. `comp1.ts` → `components/photo-upload.component.ts`).

## Critères d'évaluation

Lors de la relecture des rendus des apprenants, vérifiez :

- [ ] Le fichier de contexte capture toute la dette technique majeure
- [ ] La spécification a des critères de succès mesurables (pas vagues)
- [ ] Le plan de migration a des priorités réalistes (sécurité > cosmétique)
- [ ] Les tâches sont précises et actionnables (pas « améliorer la qualité du code »)
- [ ] Les estimations d'effort sont dans une fourchette raisonnable
- [ ] Les dépendances sont identifiées

## Extensions et variantes

Pour les apprenants avancés ou les sessions longues :

1. **Implémenter réellement les tâches P1** du plan de migration
2. **Mesurer l'amélioration** : lancer les linters et la couverture de tests avant/après
3. **Comparer les approches** : refactoring manuel vs assisté par IA
4. **Exercice en équipe** : différents groupes priorisent différemment, comparer les résultats

## Ressources complémentaires

- Exemples de templates AGENTS.md
- Checklist de refactoring
- Frameworks de priorisation
- Guides d'évaluation des risques

---

**Rappel formateur** : l'objectif est d'enseigner la **pensée systématique** et la **collaboration efficace avec l'IA**, pas seulement de terminer l'exercice. Les apprenants doivent partir en comprenant POURQUOI cette approche fonctionne, pas seulement COMMENT suivre les étapes.
