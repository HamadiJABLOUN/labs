# Lab 31: Migration Plan

**Project**: Legacy Photo Gallery Modernization  
**Based On**: [REFACTORING_SPEC.md](./REFACTORING_SPEC.md) and [AGENTS.md](./photo-gallery-legacy-solution/AGENTS.md)  
**Total Estimated Effort**: 21-27 hours  
**Recommended Timeline**: 3-4 sprints (assuming 2-week sprints with partial allocation)

## Executive Summary

This migration plan breaks down the photo gallery refactoring into prioritized, sequenced tasks with effort estimates and risk assessments. Tasks are organized by priority and dependencies to enable safe, incremental improvement.

**Quick Wins** (complete first for immediate impact):

- Rename components and files (2h) - improves navigation
- Add Photo interface (1h) - enables type safety
- Add file validation (2h) - prevents crashes

**Foundation** (required before major refactoring):

- Set up test infrastructure (3h)
- Create basic test suite (4h)

## Task Breakdown by Priority

### P1: Critical - Must Complete (Total: 12-14 hours)

These tasks address critical technical debt and must be completed to achieve minimum success criteria.

#### T001 - Set Up Test Infrastructure [P1] {3 hours}

**Description**: Configure Vitest test runner, create test utilities, set up coverage reporting

**Dependencies**: None

**Implementation**:

1. Verify Vitest configuration in `vite.config.mts`
2. Create `test-utils.ts` with common test helpers
3. Set up coverage thresholds in config (target 70%)
4. Create sample test to verify setup works

**Risk**: Low (Vitest already configured by Nx)

**Validation**:

- [ ] `nx test photo-gallery-legacy` runs successfully
- [ ] Coverage report generates
- [ ] Sample test passes

---

#### T002 - Create Photo Interface and Types [P1] {1 hour}

**Description**: Define proper TypeScript interface for Photo model, replace class with interface

**Dependencies**: None

**Implementation**:

1. Create `src/app/models/photo.model.ts`
2. Define Photo interface with proper types:
   ```typescript
   export interface Photo {
     id: string;
     filename: string;
     dataUrl: string;
     uploadedAt: Date;
     tags: string[];
     size: number;
   }
   ```
3. Delete old `models.ts` file
4. Update imports across components

**Risk**: Low

**Validation**:

- [ ] No TypeScript compilation errors
- [ ] Photo interface used throughout codebase

---

#### T003 - Rename StorageSvc to PhotoStorageService [P1] {0.5 hours}

**Description**: Rename service to follow naming conventions, update all references

**Dependencies**: None

**Implementation**:

1. Rename file: `storage.service.ts` → `photo.service.ts`
2. Rename class: `StorageSvc` → `PhotoService`
3. Update all component imports
4. Update service registration

**Risk**: Low (simple refactor with IDE support)

**Validation**:

- [ ] Application builds without errors
- [ ] All components import correct service name

---

#### T004 - Rename comp1 to PhotoUploadComponent [P1] {0.5 hours}

**Description**: Rename upload component to follow conventions

**Dependencies**: None

**Implementation**:

1. Rename file: `comp1.ts` → `photo-upload.component.ts`
2. Rename class: `comp1` → `PhotoUploadComponent`
3. Update selector: `app-comp1` → `app-photo-upload`
4. Update AppComponent template

**Risk**: Low

**Validation**:

- [ ] Component renders correctly in app
- [ ] Upload functionality still works

---

#### T005 - Rename thing to PhotoListComponent [P1] {0.5 hours}

**Description**: Rename list component to follow conventions

**Dependencies**: None

**Implementation**:

1. Rename file: `thing.ts` → `photo-list.component.ts`
2. Rename class: `thing` → `PhotoListComponent`
3. Update selector: `app-thing` → `app-photo-list`
4. Update AppComponent template

**Risk**: Low

**Validation**:

- [ ] Component renders correctly in app
- [ ] Photo list displays correctly

---

#### T006 - Add File Upload Validation [P1] {2 hours}

**Description**: Validate file size (≤5MB) and type (images only) before upload

**Dependencies**: T002 (Photo interface)

**Implementation**:

1. Create validation constants in `src/app/constants.ts`:
   ```typescript
   export const MAX_FILE_SIZE = 5 * 1024 * 1024; // 5MB
   export const ALLOWED_TYPES = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/webp'];
   ```
2. Add validation method to PhotoUploadComponent
3. Display error messages for invalid files
4. Prevent upload if validation fails

**Risk**: Medium (must not break existing uploads)

**Validation**:

- [ ] Files >5MB are rejected with error message
- [ ] Non-image files are rejected
- [ ] Valid files upload successfully
- [ ] Error messages are user-friendly

---

#### T007 - Add LocalStorage Error Handling [P1] {2 hours}

**Description**: Handle LocalStorage quota exceeded and JSON parse errors

**Dependencies**: T003 (renamed service)

**Implementation**:

1. Wrap `localStorage.setItem()` in try-catch (quota)
2. Wrap `JSON.parse()` in try-catch (corrupt data)
3. Return appropriate error states
4. Add error handling in components

**Risk**: Medium (must handle existing data)

**Validation**:

- [ ] Quota exceeded doesn't crash app
- [ ] Corrupt data doesn't crash app
- [ ] Users see appropriate error messages
- [ ] Existing valid data loads correctly

---

#### T008 - Replace 'any' Types in Storage Service [P1] {1 hour}

**Description**: Use Photo interface instead of `any` in PhotoStorageService

**Dependencies**: T002 (Photo interface), T003 (renamed service)

**Implementation**:

1. Update `save(data: Photo[])`
2. Update `load(): Photo[]`
3. Handle type validation when loading

**Risk**: Low

**Validation**:

- [ ] No `any` types in service
- [ ] TypeScript compiles without errors
- [ ] Save/load operations work correctly

---

#### T009 - Replace 'any' Types in Components [P1] {2 hours}

**Description**: Use proper types in PhotoUploadComponent and PhotoListComponent

**Dependencies**: T002 (Photo interface), T004, T005 (renamed components)

**Implementation**:

1. PhotoUploadComponent:
   - `selectedFile: File | null`
   - `preview: string | null`
   - Event types: `Event`, `ProgressEvent<FileReader>`
2. PhotoListComponent:
   - `photos: Photo[]`
   - Remove inline `any` in filter

**Risk**: Low

**Validation**:

- [ ] No `any` types in components
- [ ] All operations type-safe
- [ ] Functionality unchanged

---

#### T010 - Write Storage Service Tests [P1] {2 hours}

**Description**: Create comprehensive test suite for PhotoStorageService

**Dependencies**: T001 (test setup), T003 (renamed service), T007 (error handling)

**Implementation**:

1. Test save operation
2. Test load operation
3. Test error handling (quota, parse errors)
4. Mock localStorage
5. Test data persistence

**Risk**: Low

**Validation**:

- [ ] All tests pass
- [ ] Coverage >80% for service
- [ ] Edge cases covered

---

#### T011 - Write Component Basic Tests [P1] {3 hours}

**Description**: Create basic test suite for both components

**Dependencies**: T001 (test setup), T004, T005 (renamed components)

**Implementation**:

1. PhotoUploadComponent:
   - Test component renders
   - Test file selection
   - Test validation logic
   - Test upload flow
2. PhotoListComponent:
   - Test component renders
   - Test photo display
   - Test delete operation

**Risk**: Medium (component testing can be complex)

**Validation**:

- [ ] All tests pass
- [ ] Coverage >60% for components
- [ ] Critical paths tested

---

### P2: High Priority - Should Complete (Total: 6-8 hours)

These tasks significantly improve code quality and should be completed if time allows.

#### T012 - Create PhotoService with Signals [P2] {3 hours}

**Description**: Centralize photo management logic with Angular signals

**Dependencies**: T002 (Photo interface), T008 (typed storage)

**Implementation**:

1. Create `photo.service.ts`
2. Implement signal-based state: `photos = signal<Photo[]>([])`
3. Methods: `addPhoto()`, `removePhoto()`, `loadPhotos()`
4. Integrate PhotoStorageService
5. Update components to use PhotoService

**Risk**: Medium (architectural change)

**Validation**:

- [ ] Components use PhotoService
- [ ] Photo list updates reactively
- [ ] All operations work correctly

---

#### T013 - Add JSDoc to All Services [P2] {1 hour}

**Description**: Document PhotoStorageService and PhotoService with JSDoc

**Dependencies**: T003 (storage service), T012 (photo service)

**Implementation**:

1. Add class-level JSDoc
2. Add method-level JSDoc with @param and @returns
3. Document error scenarios

**Risk**: Low

**Validation**:

- [ ] All public methods documented
- [ ] JSDoc renders correctly in IDE

---

#### T014 - Add JSDoc to All Components [P2] {1 hour}

**Description**: Document component classes and public methods

**Dependencies**: T004, T005 (renamed components)

**Implementation**:

1. Add class-level JSDoc explaining component purpose
2. Document public methods
3. Document @Input and @Output (if any added)

**Risk**: Low

**Validation**:

- [ ] All components documented
- [ ] Purpose clear from documentation

---

#### T015 - Extract Configuration Constants [P2] {0.5 hours}

**Description**: Create constants file for hardcoded values

**Dependencies**: T006 (validation uses some constants)

**Implementation**:

1. Create `src/app/config/constants.ts`
2. Extract: MAX_FILE_SIZE, ALLOWED_TYPES, STORAGE_KEY
3. Update all references

**Risk**: Low

**Validation**:

- [ ] No hardcoded strings/numbers in components
- [ ] All constants in one place

---

#### T016 - Migrate to inject() Function [P2] {1 hour}

**Description**: Replace constructor injection with `inject()` function

**Dependencies**: T003-T005 (renamed services/components)

**Implementation**:

1. Update all components to use `inject()`:
   ```typescript
   private photoService = inject(PhotoService);
   ```
2. Remove constructor parameters
3. Verify functionality unchanged

**Risk**: Low (straightforward migration)

**Validation**:

- [ ] No constructor injection remains
- [ ] All services injected correctly
- [ ] App works identically

---

#### T017 - Create Project README [P2] {1 hour}

**Description**: Document how to set up, develop, and test the application

**Dependencies**: None (but easier after refactoring)

**Implementation**:

1. Create `README.md` with:
   - Project description
   - Setup instructions (`npm install`, `nx serve`)
   - Development workflow
   - Testing instructions (`nx test`)
   - Architecture overview
   - Contributing guidelines

**Risk**: Low

**Validation**:

- [ ] New developer can follow README to run app
- [ ] All commands work as documented

---

### P3: Medium Priority - Could Complete (Total: 3-5 hours)

Nice-to-have improvements that enhance quality but aren't critical.

#### T018 - Add Loading States [P3] {2 hours}

**Description**: Show loading indicators during file operations

**Dependencies**: T004 (PhotoUploadComponent)

**Implementation**:

1. Add `isUploading` boolean to component
2. Disable upload button while processing
3. Show spinner/progress indicator
4. Handle error states visually

**Risk**: Low

**Validation**:

- [ ] Loading state shows during upload
- [ ] UI provides feedback on operation status

---

#### T019 - Add Delete Confirmation [P3] {1 hour}

**Description**: Confirm before deleting photos

**Dependencies**: T005 (PhotoListComponent)

**Implementation**:

1. Add confirmation dialog before delete
2. Show photo filename in confirmation
3. Handle cancel/confirm actions

**Risk**: Low

**Validation**:

- [ ] Confirmation appears on delete
- [ ] Cancel prevents deletion
- [ ] Confirm deletes photo

---

#### T020 - Improve Accessibility [P3] {2 hours}

**Description**: Add ARIA labels, alt text, keyboard navigation

**Dependencies**: T004, T005 (components)

**Implementation**:

1. Add alt text to all images
2. Add ARIA labels to buttons and inputs
3. Ensure keyboard navigation works
4. Test with screen reader

**Risk**: Low

**Validation**:

- [ ] All images have alt text
- [ ] Keyboard navigation works
- [ ] Screen reader announces correctly

---

## Execution Strategy

### Phase 1: Foundation (Sprints 1-2)

**Focus**: Critical fixes and test setup  
**Tasks**: T001-T011 (all P1 tasks)  
**Goal**: Stable, tested, well-named codebase

**Week 1**:

- T001: Test setup (Mon)
- T002-T005: Rename everything (Tue-Wed)
- T006-T007: Validation and error handling (Thu-Fri)

**Week 2**:

- T008-T009: Remove `any` types (Mon-Tue)
- T010-T011: Write tests (Wed-Fri)

### Phase 2: Enhancement (Sprint 3)

**Focus**: Architecture and documentation  
**Tasks**: T012-T017 (all P2 tasks)  
**Goal**: Clean architecture, well-documented

**Week 3**:

- T012: PhotoService with signals (Mon-Tue)
- T013-T014: JSDoc documentation (Wed)
- T015-T016: Constants and inject() (Thu)
- T017: README (Fri)

### Phase 3: Polish (Sprint 4 - Optional)

**Focus**: UX improvements  
**Tasks**: T018-T020 (P3 tasks)  
**Goal**: Professional user experience

## Risk Mitigation

### High-Risk Tasks

- **T012 (PhotoService)**: Architectural change, test thoroughly
  - Mitigation: Implement behind feature flag, roll out gradually

### Data Migration Concerns

- **All tasks**: Must preserve existing LocalStorage data
  - Mitigation: Test with real data, backup before refactoring

### Time Management

- **If behind schedule**: Complete P1 only, defer P2/P3
- **If ahead**: Tackle P2 tasks in priority order

## Dependencies Graph

```
T001 (Test Setup)
  ├─→ T010 (Service Tests)
  └─→ T011 (Component Tests)

T002 (Photo Interface)
  ├─→ T006 (Validation)
  ├─→ T008 (Typed Storage)
  └─→ T012 (PhotoService)

T003 (Rename Service)
  ├─→ T007 (Error Handling)
  └─→ T008 (Typed Storage)

T004, T005 (Rename Components)
  ├─→ T009 (Typed Components)
  ├─→ T011 (Component Tests)
  └─→ T016 (inject())

T012 (PhotoService)
  └─→ T013 (JSDoc Services)
```

## Success Validation Checklist

After completing each phase, verify:

**Phase 1 Complete**:

- [ ] All P1 tasks marked done
- [ ] Test coverage ≥70%
- [ ] Zero linter errors
- [ ] All features work correctly
- [ ] No `any` types

**Phase 2 Complete**:

- [ ] PhotoService implemented
- [ ] All code documented
- [ ] README exists and accurate
- [ ] Modern Angular patterns used

**Phase 3 Complete**:

- [ ] Loading states implemented
- [ ] Confirmations added
- [ ] Accessibility improved

**Final Validation**:

- [ ] All acceptance criteria from REFACTORING_SPEC.md met
- [ ] Application works smoothly
- [ ] Code is maintainable
- [ ] New developer can contribute

---

**Total Effort Summary**:

- **P1 Tasks**: 12-14 hours (critical)
- **P2 Tasks**: 6-8 hours (important)
- **P3 Tasks**: 3-5 hours (nice-to-have)
- **Total**: 21-27 hours

**Recommended Approach**: Complete P1 fully before starting P2. Evaluate time remaining before committing to P3.
