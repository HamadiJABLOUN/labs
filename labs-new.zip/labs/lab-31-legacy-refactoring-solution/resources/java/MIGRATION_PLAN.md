# Migration Plan — Photo Gallery (Java / Spring Boot)

> Java variant of [`../MIGRATION_PLAN.md`](../MIGRATION_PLAN.md).
> Derived from `REFACTORING_SPEC.md` and `photo-gallery-legacy-java-solution/AGENTS.md`.

**Total estimated effort**: 17.75 h — the reference solution in
`../photo-gallery-legacy-java-solution/` follows this plan end to end.

---

## Priority legend

| Level  | Meaning                                 |
| ------ | --------------------------------------- |
| **P1** | Critical — security, data loss, crashes |
| **P2** | High — test coverage, major refactoring |
| **P3** | Medium — cleanup, documentation         |
| **P4** | Low — future improvements               |

Risk is the chance the task breaks something while it is being done.

---

## Task list

| #   | Task                                                          | Pri | Effort | Depends on | Risk   |
| --- | ------------------------------------------------------------- | --- | ------ | ---------- | ------ |
| T1  | Move deletion from `GET` to `POST`                            | P1  | 0.25 h | —          | Low    |
| T2  | Create `src/test/`, wire JUnit 5 + AssertJ + MockMvc          | P2  | 0.5 h  | —          | Low    |
| T3  | Characterisation tests on the legacy behaviour                | P2  | 2 h    | T2         | Low    |
| T4  | `GalleryProperties` + `application.properties`                | P2  | 0.75 h | —          | Low    |
| T5  | `Photo` record with validation + `parseTags`                  | P2  | 2 h    | T4         | Medium |
| T6  | `PhotoStorageService`: generics, injected path, atomic write  | P1  | 2 h    | T5         | Medium |
| T7  | Stop swallowing write failures; skip-and-log bad records      | P1  | 1 h    | T6         | Medium |
| T8  | `PhotoService` holding the validation rules                   | P1  | 1.5 h  | T5, T6     | Medium |
| T9  | `PhotoController`; split bootstrap from web                   | P2  | 1.5 h  | T8         | High   |
| T10 | Constructor injection everywhere; drop `@Autowired` on fields | P2  | 0.5 h  | T9         | Medium |
| T11 | Replace the concatenated HTML with Thymeleaf                  | P1  | 1.5 h  | T9         | Medium |
| T12 | Accessibility: `alt`, labels, empty state                     | P3  | 0.75 h | T11        | Low    |
| T13 | Extract the stylesheet to `static/styles.css`                 | P3  | 0.5 h  | T11        | Low    |
| T14 | Javadoc across every public class and method                  | P3  | 1 h    | T10        | Low    |
| T15 | README with setup and run instructions                        | P3  | 0.5 h  | T14        | Low    |
| T16 | Raise coverage above 70%, add the edge cases                  | P2  | 1.5 h  | T11        | Low    |

**Sum**: 17.75 h across 16 tasks.

> Why Java costs ~3 h more than the Python variant: the raw-type removal (T6) touches every call
> site rather than a handful of signatures, and swapping concatenated HTML for a template engine
> (T11) has no Python equivalent — the Flask version already had Jinja2.

---

## Recommended order of execution

### Stage 0 — Stop the bleeding (0.25 h)

**T1** first, alone. Deletion over `GET` means any crawler, prefetcher or browser preview can empty
the gallery. It is a one-line change and it is the only genuinely urgent task. Ship it as its own commit.

> The stored XSS (T11) is the more serious hole, but it cannot be fixed in one line — it needs the
> template engine, which needs the controller split first. That is why it lands in Stage 3, not here.

### Stage 1 — Build the safety net (2.5 h)

**T2 → T3**. Write tests against the legacy code _as it behaves today_, including the behaviour you
intend to change. They exist to tell you when a refactor altered something, not to bless the current
design. Delete or rewrite them as the design moves.

> This stage is the one trainees skip. Everything after it is a gamble without it.

### Stage 2 — Foundations (5.75 h)

**T4 → T5 → T6 → T7**. Bottom-up: configuration, then the model, then persistence.

T6 is the heaviest single task in the plan. Removing the raw `List` and `Map` forces every reader to
declare what it actually expects, and that is where the latent `ClassCastException`s surface. Expect
the compiler to find bugs the tests did not.

### Stage 3 — Architecture and the XSS fix (5 h)

**T8 → T9 → T10 → T11**.

> **T9 is the riskiest task in the plan.** Splitting `@SpringBootApplication` from `@Controller`
> rearranges component scanning; a stray annotation and the context stops loading at all. Keep the
> suite green before and after, and do not mix it with any other change in the same commit.

T11 closes the stored XSS. Assert it explicitly: upload a file named `<script>alert(1)</script>.png`
and check the rendered page contains the escaped form, not the tag. A code review cannot prove
escaping; a test can.

### Stage 4 — Surface (2.75 h)

**T12 → T13**, then **T14 → T15**. Presentation and documentation. Safe to interrupt; safe to defer
if the timebox runs out.

### Stage 5 — Close the gaps (1.5 h)

**T16**. With the design settled, fill in the edge cases the earlier tests did not reach: corrupt
files, partial records, boundary sizes, duplicate tags, unknown ids.

---

## Quick wins vs long-term

**Quick wins** — under 45 minutes each, ship immediately:

- T1 `POST` for deletion (0.25 h) — stops crawlers emptying the gallery
- T4 `GalleryProperties` (0.75 h) — unblocks four later tasks
- T10 constructor injection (0.5 h) — makes every class testable without a context
- T13 extract the stylesheet (0.5 h)

**Long-term** — the structural work, worth the time only because the tests exist first:

- T6 generics and atomic writes — the difference between losing the gallery and not
- T7 surfacing write failures — today a failed save reports success
- T11 the template engine — the only real fix for the stored XSS
- T16 full edge-case coverage — what keeps the rest honest

---

## Risk assessment

| Task | Risk   | What could go wrong                                               | Mitigation                                                         |
| ---- | ------ | ----------------------------------------------------------------- | ------------------------------------------------------------------ |
| T5   | Medium | Renaming `tagz` → `tags` breaks every existing `photos_data.json` | Accepted and documented in the spec; delete the file and restart   |
| T6   | Medium | Removing raw types surfaces `ClassCastException`s at new places   | Fix each one as the compiler reports it; do not cast to silence it |
| T7   | Medium | Errors that were swallowed now propagate and fail requests        | A test per error path asserting the message reaches the user       |
| T8   | Medium | Validation rejects input the old code accepted                    | Covered by T3; each rule gets its own test                         |
| T9   | High   | Component scanning changes and the context stops loading          | Full suite green before and after; isolated commit                 |
| T10  | Medium | A missed `@Autowired` field becomes a silent `null`               | Make every collaborator `final`; the compiler then catches it      |
| T11  | Medium | A Thymeleaf expression silently renders empty instead of failing  | Assert on rendered output, not on the model                        |

### One trap worth naming

`PhotoStorageService` ends up with two constructors — one taking `GalleryProperties` for production,
one taking a `Path` so tests can point at a temporary directory. Spring cannot choose between them
and fails with a misleading _"No default constructor found"_. Annotate the production constructor
with `@Autowired`. The reference implementation hit exactly this, and it costs twenty minutes to
diagnose if you have not seen it before.

---

## Definition of done

A task is done when:

1. Its tests pass, and the whole suite still passes
2. Coverage has not dropped
3. The public API it touched carries Javadoc
4. The build emits no new warnings
5. The app still uploads, lists and deletes a photo by hand
6. It is committed on its own, with a message naming the task id

---

## Verification

```bash
cd photo-gallery-legacy-java-solution
./mvnw test          # mvnw.cmd on Windows
./mvnw spring-boot:run
```

Expected, and what the reference solution actually produces:

```
Tests run: 59, Failures: 0, Errors: 0, Skipped: 0
BUILD SUCCESS
```
