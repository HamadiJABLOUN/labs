# Refactoring Specification — Photo Gallery (Java / Spring Boot)

> Java variant of [`../REFACTORING_SPEC.md`](../REFACTORING_SPEC.md).
> Target codebase: `labs/lab-31-legacy-refactoring/photo-gallery-legacy-java/`.
> Reference implementation: `../photo-gallery-legacy-java-solution/`.

**Status**: Implemented
**Related**: `photo-gallery-legacy-java-solution/AGENTS.md`, `MIGRATION_PLAN.md`

---

## 1. Goals

| #   | Goal                     | Measurable outcome                                                                   |
| --- | ------------------------ | ------------------------------------------------------------------------------------ |
| G1  | Close the security holes | User-supplied text escaped before rendering; deletion no longer reachable by `GET`   |
| G2  | Make refactoring safe    | A test suite covering every layer, above 70% line coverage                           |
| G3  | Stop accepting bad input | Size, MIME type, filename and tags validated before anything is written              |
| G4  | Survive bad data         | A corrupt or partially written store never crashes the app and never loses good rows |
| G5  | Restore type safety      | No raw types, no unchecked casts, no `Object` parameters                             |
| G6  | Separate the concerns    | Bootstrap, web, business and persistence each in their own class                     |

## 2. Scope

### In scope

- `Photo.java`, `StorageSvc.java`, `comp1.java`, `thing.java`, `PhotoGalleryLegacyApplication.java`
- Introducing a test source tree and the dependencies it needs
- Introducing `@ConfigurationProperties` and an `application.properties`
- Replacing the concatenated HTML with a template engine
- Correcting the persisted record shape (`fileName` → `filename`, `date` → `uploadedAt`, `tagz` → `tags`)

### Out of scope

- Replacing Spring Boot with another framework
- Replacing the JSON file with a database or JPA
- Authentication, multi-user support, photo editing
- Deployment, containerisation, CI configuration
- Thumbnailing or any image processing

## 3. Functional requirements

| #    | Requirement                                                                               | Priority |
| ---- | ----------------------------------------------------------------------------------------- | -------- |
| FR-1 | An upload is rejected, with a message shown to the user, when no file was selected        | P1       |
| FR-2 | An upload above the configured size limit is rejected with a message naming the limit     | P1       |
| FR-3 | An upload whose MIME type is not in the allow-list is rejected with a message             | P1       |
| FR-4 | Tags are split on commas, trimmed, lowercased, de-duplicated, and bounded in count/length | P2       |
| FR-5 | A rejected upload leaves the gallery byte-for-byte unchanged                              | P1       |
| FR-6 | Photos are listed newest first                                                            | P3       |
| FR-7 | Deleting an unknown id reports it instead of failing silently                             | P2       |
| FR-8 | Deletion happens over `POST`; a `GET` returns 405                                         | P1       |

## 4. Non-functional requirements

| #     | Requirement                                                                        | Priority |
| ----- | ---------------------------------------------------------------------------------- | -------- |
| NFR-1 | A filename or tag containing HTML is rendered as text, never as markup             | P1       |
| NFR-2 | A failed write surfaces to the user; it is never swallowed                         | P1       |
| NFR-3 | A write is atomic: an interrupted save never truncates the gallery                 | P1       |
| NFR-4 | A malformed record is skipped and logged; the valid records still load             | P1       |
| NFR-5 | A corrupt file is never silently overwritten with an empty gallery                 | P1       |
| NFR-6 | The build produces zero unchecked warnings                                         | P2       |
| NFR-7 | The storage path, title, size limit, allowed types and tag bounds are configurable | P2       |
| NFR-8 | Every public class and method carries Javadoc                                      | P3       |
| NFR-9 | Images carry meaningful `alt` text; every form control has a label                 | P3       |

## 5. Success criteria

The refactoring is done when all of the following hold:

- [x] `./mvnw test` is green — **achieved: 57 tests, BUILD SUCCESS**
- [x] Coverage above 70% across model, storage, service and web layers
- [x] Every class name follows PascalCase; `comp1` and `thing` are gone
- [x] No raw types remain; the build emits no unchecked warnings
- [x] Constructor injection everywhere; no `@Autowired` on a field except the documented test seam
- [x] Uploading a 3 MiB file returns a readable error, not a stack trace
- [x] Uploading a PDF returns a readable error
- [x] A file named `<script>alert(1)</script>.png` renders as text
- [x] `GET /delete/{id}` returns 405
- [x] Hand-corrupting `photos_data.json` does not crash the index page
- [x] Adding a broken record to a valid file still lists the valid ones
- [x] The persisted record uses `filename`, `uploadedAt`, `tags`
- [x] Upload, list and delete behave exactly as before for valid input

## 6. Constraints

- **Behaviour preserving**: the three user-visible features must keep working
- **Timebox**: the full migration fits in roughly two working days
- **Java 17**: the target language level, matching the rest of the training
- **New dependency allowed**: a template engine is in scope, because closing the XSS hole
  without one means hand-rolling escaping. Nothing else is added: validation needs no library
- **Breaking storage format accepted**: the existing `photos_data.json` shape is a bug,
  not a contract. Fixing `tagz` means old files will not load — acceptable here because the
  gallery is a lab artefact. In production this would demand a migration step, and that
  trade-off is worth stating out loud in the debrief.

## 7. Non-goals

Explicitly **not** attempted, so nobody plans for them:

- Concurrency safety beyond atomic replacement. The read-modify-write race remains;
  closing it properly means a lock or a database, and that is a different decision.
- Streaming uploads. Files are still read fully into memory, which is why the size limit matters.
- Bean Validation annotations on the web layer. Validation lives in the domain constructor
  instead, so an invalid `Photo` cannot exist anywhere in the system, not only at the HTTP edge.
- Internationalisation of the error messages.
- Any change to the visual design beyond what accessibility requires.
