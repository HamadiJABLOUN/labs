"""Development entry point: ``python app.py``."""

from photo_gallery import create_app

app = create_app()

if __name__ == "__main__":
    app.run(port=42312, debug=True)
