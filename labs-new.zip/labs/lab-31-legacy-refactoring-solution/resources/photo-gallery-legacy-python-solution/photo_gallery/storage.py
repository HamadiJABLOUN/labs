"""Persistence layer for the photo gallery."""

from __future__ import annotations

import json
import logging
import os
import tempfile
from pathlib import Path

from photo_gallery.models import InvalidPhotoError, Photo

logger = logging.getLogger(__name__)


class PhotoStorageService:
    """Reads and writes the gallery to a JSON file.

    The path is injected rather than hardcoded, so tests and deployments can
    point at their own file. Reads never raise on malformed data: a corrupt
    record is logged and skipped, which keeps one bad entry from taking the
    whole gallery down.
    """

    def __init__(self, path: Path) -> None:
        self._path = Path(path)

    @property
    def path(self) -> Path:
        """The file backing this store."""
        return self._path

    def load(self) -> list[Photo]:
        """Return every valid photo on disk, oldest first.

        A missing file yields an empty gallery. A corrupt file, or a record
        that fails validation, is logged and skipped.
        """
        if not self._path.exists():
            return []

        try:
            raw = json.loads(self._path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            logger.exception("Could not read gallery at %s", self._path)
            return []

        if not isinstance(raw, list):
            logger.error("Expected a list at %s, got %s", self._path, type(raw).__name__)
            return []

        photos: list[Photo] = []
        for record in raw:
            try:
                photos.append(Photo.from_dict(record))
            except InvalidPhotoError:
                logger.warning("Skipping malformed record in %s", self._path)
        return photos

    def save(self, photos: list[Photo]) -> None:
        """Persist the gallery atomically.

        Writes to a temporary file in the same directory, then replaces the
        target, so an interrupted write can never truncate the gallery.

        Raises:
            OSError: if the gallery cannot be written.
        """
        payload = json.dumps([photo.to_dict() for photo in photos], indent=2)

        self._path.parent.mkdir(parents=True, exist_ok=True)
        handle, temp_name = tempfile.mkstemp(
            dir=str(self._path.parent), prefix=".photos-", suffix=".tmp"
        )
        try:
            with os.fdopen(handle, "w", encoding="utf-8") as stream:
                stream.write(payload)
            os.replace(temp_name, self._path)
        except OSError:
            Path(temp_name).unlink(missing_ok=True)
            logger.exception("Could not write gallery to %s", self._path)
            raise

    def clear(self) -> None:
        """Delete the gallery file if it exists."""
        self._path.unlink(missing_ok=True)
