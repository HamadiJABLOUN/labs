"""Configuration constants for the photo gallery.

Every value the legacy code hardcoded lives here, so it can be overridden per
environment without touching business logic.
"""

from __future__ import annotations

import os
from pathlib import Path

#: Where the gallery is persisted. Overridable for tests and deployments.
STORAGE_PATH: Path = Path(os.environ.get("PHOTO_GALLERY_STORAGE", "photos_data.json"))

#: Largest accepted upload, in bytes (2 MiB).
MAX_FILE_SIZE: int = 2 * 1024 * 1024

#: MIME types the gallery accepts.
ALLOWED_MIME_TYPES: frozenset[str] = frozenset(
    {"image/png", "image/jpeg", "image/gif", "image/webp"}
)

#: Upper bound on the number of tags attached to a single photo.
MAX_TAGS: int = 10

#: Upper bound on the length of a single tag.
MAX_TAG_LENGTH: int = 32
