"""Photo gallery application factory."""

from __future__ import annotations

import os
from pathlib import Path

from flask import Flask

from photo_gallery.config import STORAGE_PATH
from photo_gallery.service import PhotoService
from photo_gallery.storage import PhotoStorageService

__all__ = ["create_app"]


def create_app(storage_path: Path | None = None) -> Flask:
    """Build a configured application.

    Args:
        storage_path: where to persist the gallery. Defaults to
            :data:`photo_gallery.config.STORAGE_PATH`; tests pass a tmp path.
    """
    app = Flask(__name__)
    app.config["SECRET_KEY"] = os.environ.get("PHOTO_GALLERY_SECRET", "dev-only-secret")
    app.config["GALLERY_TITLE"] = "Photo Gallery"

    storage = PhotoStorageService(storage_path or STORAGE_PATH)
    app.extensions["photo_service"] = PhotoService(storage)

    from photo_gallery.routes import bp

    app.register_blueprint(bp)
    return app
