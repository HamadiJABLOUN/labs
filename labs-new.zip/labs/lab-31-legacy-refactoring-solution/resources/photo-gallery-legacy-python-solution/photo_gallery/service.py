"""Business logic for managing photos.

The routes stay thin: every rule about what may enter the gallery lives here.
"""

from __future__ import annotations

import base64
import uuid

from photo_gallery.config import ALLOWED_MIME_TYPES, MAX_FILE_SIZE
from photo_gallery.models import InvalidPhotoError, Photo, parse_tags, utcnow
from photo_gallery.storage import PhotoStorageService


class PhotoService:
    """Coordinates validation, encoding, and persistence of photos."""

    def __init__(self, storage: PhotoStorageService) -> None:
        self._storage = storage

    def list_photos(self) -> list[Photo]:
        """Return every stored photo, newest first."""
        return sorted(self._storage.load(), key=lambda photo: photo.uploaded_at, reverse=True)

    def add_photo(
        self, *, content: bytes, filename: str, content_type: str, tags: str | None
    ) -> Photo:
        """Validate, encode, and store an uploaded image.

        Args:
            content: the raw bytes of the uploaded file.
            filename: the original file name.
            content_type: the MIME type reported by the client.
            tags: the raw comma-separated tag string, possibly empty.

        Returns:
            The stored photo.

        Raises:
            InvalidPhotoError: if the upload is empty, too large, of an
                unsupported type, or carries invalid tags.
            OSError: if the gallery cannot be written.
        """
        if not content:
            raise InvalidPhotoError("no file was uploaded")
        if len(content) > MAX_FILE_SIZE:
            raise InvalidPhotoError(
                f"file is {len(content)} bytes, the maximum is {MAX_FILE_SIZE}"
            )
        if content_type not in ALLOWED_MIME_TYPES:
            raise InvalidPhotoError(f"unsupported file type: {content_type}")
        if not filename:
            raise InvalidPhotoError("filename must not be empty")

        photo = Photo(
            id=uuid.uuid4().hex,
            filename=filename,
            data=f"data:{content_type};base64,{base64.b64encode(content).decode('ascii')}",
            uploaded_at=utcnow(),
            file_size=len(content),
            tags=parse_tags(tags),
        )

        photos = self._storage.load()
        photos.append(photo)
        self._storage.save(photos)
        return photo

    def delete_photo(self, photo_id: str) -> bool:
        """Remove a photo by id.

        Returns:
            ``True`` if a photo was removed, ``False`` if the id was unknown.
        """
        photos = self._storage.load()
        remaining = [photo for photo in photos if photo.id != photo_id]

        if len(remaining) == len(photos):
            return False

        self._storage.save(remaining)
        return True
