"""HTTP routes. Thin by design: all rules live in :mod:`photo_gallery.service`."""

from __future__ import annotations

from flask import Blueprint, current_app, flash, redirect, render_template, url_for

from photo_gallery.models import InvalidPhotoError

bp = Blueprint("gallery", __name__)


def _service():
    """Return the PhotoService attached to the running application."""
    return current_app.extensions["photo_service"]


@bp.get("/")
def index():
    """Render the gallery."""
    return render_template("index.html", photos=_service().list_photos())


@bp.post("/upload")
def upload():
    """Accept an uploaded photo, or report why it was rejected."""
    from flask import request

    uploaded = request.files.get("photo")
    if uploaded is None or not uploaded.filename:
        flash("Please choose a file to upload.", "error")
        return redirect(url_for("gallery.index"))

    try:
        _service().add_photo(
            content=uploaded.read(),
            filename=uploaded.filename,
            content_type=uploaded.mimetype or "",
            tags=request.form.get("tags"),
        )
    except InvalidPhotoError as exc:
        flash(str(exc), "error")
    except OSError:
        current_app.logger.exception("Upload failed while writing the gallery")
        flash("The gallery could not be saved. Please try again.", "error")

    return redirect(url_for("gallery.index"))


@bp.post("/delete/<photo_id>")
def delete(photo_id: str):
    """Delete a photo. POST-only, so a crawler cannot wipe the gallery."""
    if not _service().delete_photo(photo_id):
        flash("That photo no longer exists.", "error")
    return redirect(url_for("gallery.index"))
