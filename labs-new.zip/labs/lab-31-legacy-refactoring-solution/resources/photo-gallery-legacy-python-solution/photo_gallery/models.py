"""Domain model for a stored photo."""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from datetime import datetime, timezone

from photo_gallery.config import MAX_TAG_LENGTH, MAX_TAGS

_DATA_URL = re.compile(r"^data:[\w.+-]+/[\w.+-]+;base64,")


class InvalidPhotoError(ValueError):
    """Raised when a photo fails validation."""


@dataclass(frozen=True, slots=True)
class Photo:
    """An immutable photo record.

    Attributes:
        id: unique identifier, assigned at upload time.
        filename: the original file name, as submitted.
        data: the image encoded as a base64 data URL.
        uploaded_at: timezone-aware upload timestamp.
        tags: normalised, de-duplicated tags.
        file_size: size of the decoded image in bytes.
    """

    id: str
    filename: str
    data: str
    uploaded_at: datetime
    file_size: int
    tags: tuple[str, ...] = field(default=())

    def __post_init__(self) -> None:
        if not self.id:
            raise InvalidPhotoError("id must not be empty")
        if not self.filename:
            raise InvalidPhotoError("filename must not be empty")
        if not _DATA_URL.match(self.data):
            raise InvalidPhotoError("data must be a base64 data URL")
        if self.uploaded_at.tzinfo is None:
            raise InvalidPhotoError("uploaded_at must be timezone-aware")
        if self.file_size <= 0:
            raise InvalidPhotoError("file_size must be positive")
        if len(self.tags) > MAX_TAGS:
            raise InvalidPhotoError(f"at most {MAX_TAGS} tags are allowed")

    def to_dict(self) -> dict:
        """Serialise to a JSON-compatible dict."""
        return {
            "id": self.id,
            "filename": self.filename,
            "data": self.data,
            "uploadedAt": self.uploaded_at.isoformat(),
            "fileSize": self.file_size,
            "tags": list(self.tags),
        }

    @classmethod
    def from_dict(cls, raw: dict) -> "Photo":
        """Rebuild a photo from its serialised form.

        Raises:
            InvalidPhotoError: if a required field is missing or malformed.
        """
        if not isinstance(raw, dict):
            raise InvalidPhotoError(f"expected a dict, got {type(raw).__name__}")
        try:
            return cls(
                id=raw["id"],
                filename=raw["filename"],
                data=raw["data"],
                uploaded_at=datetime.fromisoformat(raw["uploadedAt"]),
                file_size=raw["fileSize"],
                tags=tuple(raw.get("tags", ())),
            )
        except (KeyError, TypeError, ValueError) as exc:
            raise InvalidPhotoError(f"malformed photo record: {exc}") from exc


def parse_tags(raw: str | None) -> tuple[str, ...]:
    """Turn a comma-separated tag string into normalised, unique tags.

    Empty segments are dropped, whitespace is trimmed, case is lowered, and
    order is preserved. Tags longer than ``MAX_TAG_LENGTH`` are rejected.

    Raises:
        InvalidPhotoError: if a tag exceeds the maximum length.
    """
    if not raw:
        return ()

    seen: dict[str, None] = {}
    for chunk in raw.split(","):
        tag = chunk.strip().lower()
        if not tag:
            continue
        if len(tag) > MAX_TAG_LENGTH:
            raise InvalidPhotoError(f"tag '{tag}' exceeds {MAX_TAG_LENGTH} characters")
        seen.setdefault(tag, None)

    tags = tuple(seen)
    if len(tags) > MAX_TAGS:
        raise InvalidPhotoError(f"at most {MAX_TAGS} tags are allowed")
    return tags


def utcnow() -> datetime:
    """Return the current time as a timezone-aware UTC datetime."""
    return datetime.now(timezone.utc)
