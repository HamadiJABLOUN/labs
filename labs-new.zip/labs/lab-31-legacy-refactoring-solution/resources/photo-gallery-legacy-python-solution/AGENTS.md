# Lab 31 Solution (Python): Context File Example

> Python variant of [`../photo-gallery-legacy-solution/AGENTS.md`](../photo-gallery-legacy-solution/AGENTS.md).
> Same lab, same deliverable, analysed against `photo-gallery-legacy-python/`.

## Project Overview

A legacy photo gallery built with Flask. Users upload photos through an HTML form, add comma-separated tags, and browse them in a grid. Data persists in a JSON file next to the working directory.

## Current State Analysis

### Working Features

- Photo upload via a multipart form (image files only, enforced by the browser)
- Tag input (comma-separated)
- Grid display of uploaded photos
- Photo deletion
- Persistence across restarts, in `photos_data.json`

### Technical Debt Identified

**1. Missing Tests**

- Zero test coverage; no `tests/` directory, no `pytest` in the dependencies
- Makes any refactoring a gamble

**2. Inconsistent Naming Conventions**

- Modules named `comp1.py` and `thing.py` — nothing conveys their purpose
- Class `StorageSvc` (should be `PhotoStorageService`)
- Method `clearAll()` is camelCase in a Python codebase (should be `clear_all`, or just `clear`)
- Record keys `fileName`, `fileSize`, `date`, `tagz` — camelCase, a typo, and a misnomer, all in one dict

**3. No Input Validation**

- `request.files['photo']` raises `KeyError` (HTTP 400 with no message) when the field is missing
- No file size limit: a large upload is base64-encoded into memory and written whole
- No MIME type check beyond the browser's `accept` attribute, which any client can ignore
- Tags are stored as the raw string, never split, trimmed, or bounded

**4. Hardcoded Configuration Values**

- `StorageSvc.KEY = 'photos_data.json'` — relative to the current working directory, so the gallery silently changes depending on where the app is launched from
- Page title hardcoded as a module-level global in `app.py`
- Port hardcoded in the `app.run()` call

**5. Missing Documentation**

- No docstrings on any module, class, or function
- No type hints anywhere
- No README: nothing states that `pip install -r requirements.txt` then `python app.py` is the way in

**6. Tangled Dependencies & Poor Architecture**

- `StorageSvc()` is instantiated three separate times, at module level, in `app.py`, `comp1.py` and `thing.py` — three objects writing the same file with no coordination
- Business logic (base64 encoding, record construction) lives inside the request handler
- No service layer between the routes and persistence
- Module-level globals make the app impossible to configure per test

### Python-specific findings

These have no equivalent in the Angular version and are worth calling out in the debrief:

- **Leaked file handle**: `StorageSvc.load()` opens the file and never closes it. It works, because CPython refcounting closes it eventually, but it is not deterministic and would leak on PyPy.
- **No `if __name__` guard on the blueprints**: importing `comp1` for a test has the side effect of creating a `StorageSvc` and touching the filesystem.
- **`debug=True` hardcoded**: the Werkzeug debugger allows arbitrary code execution. Shipping this to anything reachable is a remote code execution hole, not a style issue.

## Architecture

**Current Structure**:

```
photo-gallery-legacy-python/
├── app.py              (Flask app + index route + hardcoded title)
├── comp1.py            (upload blueprint)
├── thing.py            (delete blueprint)
├── storage_svc.py      (JSON file wrapper)
├── models.py           (Photo class, unused by the rest of the code)
├── templates/index.html
└── requirements.txt
```

**Component Relationships**:

- `app.py` registers both blueprints and renders the page
- `comp1.py` and `thing.py` each own a module-level `StorageSvc`
- `app.py` owns a third one
- All three read and write the same file with no locking

**Data Flow Issues**:

- Read-modify-write with no coordination: two concurrent requests lose one of the writes
- Writes are not atomic — an interrupted `json.dump` truncates the gallery permanently
- `models.Photo` is dead code: the handlers build raw dicts instead

## Tech Stack

| Technology | Version   | Purpose                          |
| ---------- | --------- | -------------------------------- |
| Python     | 3.12+     | Language                         |
| Flask      | 3.1.0     | Web framework                    |
| Jinja2     | via Flask | Templating                       |
| JSON file  | -         | Persistence (`photos_data.json`) |

## Quick Commands

```bash
cd labs/lab-31-legacy-refactoring/photo-gallery-legacy-python

python -m venv .venv
.venv/Scripts/activate      # Windows
# source .venv/bin/activate # macOS / Linux

pip install -r requirements.txt
python app.py               # http://localhost:42312

# Tests: none exist yet
```

## Coding Conventions (Current State)

**Problems to Fix**:

- ❌ Module and class names carry no meaning (`comp1`, `thing`, `StorageSvc`)
- ❌ No type hints anywhere
- ❌ camelCase leaking into Python identifiers and dict keys
- ❌ Module-level globals instead of an application factory
- ❌ No docstrings
- ❌ Mutable state shared through import side effects

**Should Follow**:

- ✅ PEP 8: `snake_case` for functions and variables, `PascalCase` for classes
- ✅ Type hints on every public function
- ✅ Docstrings (Google style) on modules, classes, and public functions
- ✅ An application factory (`create_app`) so tests get an isolated instance
- ✅ Dependency injection instead of module-level singletons

## Known Issues

### Critical (P1)

1. **`debug=True` in the committed code**: remote code execution if ever exposed
2. **No input validation**: an oversized upload fills memory and disk
3. **Non-atomic writes**: an interrupted save truncates the gallery with no recovery
4. **`KeyError` on a missing form field**: returns a bare 400 with no explanation

### High Priority (P2)

1. **Zero test coverage**: cannot refactor safely
2. **Three uncoordinated storage instances**: lost updates under concurrency
3. **No type hints**: nothing catches the `tagz` / `tags` confusion

### Medium Priority (P3)

1. **Missing documentation**: no docstrings, no README
2. **Hardcoded values**: storage path, title, port
3. **No separation of concerns**: business logic inside request handlers

### Low Priority (P4)

1. **Leaked file handle** in `load()`
2. **Dead code**: `models.Photo` is never used
3. **No accessibility**: images carry an empty `alt`, delete is a `GET` link

## Constraints

- **Must remain functional**: refactoring cannot break upload, display, or delete
- **File-based persistence only**: no database, to keep the lab self-contained
- **Flask**: no rewrite to FastAPI or Django within this lab
- **Small scope**: ~160 LOC, must stay manageable in the lab timeframe

## Refactoring Goals

### Phase 1: Foundation (High Priority)

1. **Add test infrastructure**: `pytest` + `pytest-cov`, one test module per layer
2. **Fix naming**: meaningful modules, `PhotoStorageService`, `snake_case` throughout
3. **Add validation**: file size, MIME type, tag count and length
4. **Type safety**: type hints everywhere, a `Photo` dataclass instead of raw dicts

### Phase 2: Architecture (Medium Priority)

1. **Application factory**: `create_app(storage_path)` so tests get isolation
2. **Service layer**: `PhotoService` owns the rules, routes stay thin
3. **One storage instance**: injected, not three module-level globals
4. **Atomic writes and error handling**: temp file plus `os.replace`, flash messages on failure

### Phase 3: Quality (Lower Priority)

1. **Documentation**: docstrings on every public API, a README with setup steps
2. **Extract configuration**: a `config.py` holding every previously hardcoded value
3. **Accessibility**: real `alt` text, `POST` for deletion, labelled form controls
4. **Externalise styles**: a stylesheet instead of a `<style>` block

## Success Criteria

- ✅ Test coverage > 70%
- ✅ All modules and classes follow PEP 8 naming
- ✅ Type hints on every public function
- ✅ Input validation prevents oversized and unsupported uploads
- ✅ A corrupt storage file degrades gracefully instead of crashing
- ✅ Photo operations go through a single service
- ✅ Docstrings on all public classes and functions
- ✅ README with development instructions

## Next Steps

1. Create REFACTORING_SPEC.md defining specific improvements
2. Develop MIGRATION_PLAN.md with prioritized tasks
3. Implement changes incrementally with tests
4. Validate against success criteria
