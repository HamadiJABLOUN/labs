# Photo Gallery — Refactored (Python / Flask)

Reference "after" state for [Lab 31](../../../lab-31-legacy-refactoring/README.md), starting from
`photo-gallery-legacy-python/`.

See [`AGENTS.md`](AGENTS.md) for the analysis of the legacy code, and
[`../python/REFACTORING_SPEC.md`](../python/REFACTORING_SPEC.md) /
[`../python/MIGRATION_PLAN.md`](../python/MIGRATION_PLAN.md) for the plan this implements.

## Setup

```bash
python -m venv .venv
.venv/Scripts/activate        # Windows
# source .venv/bin/activate   # macOS / Linux

pip install -r requirements-dev.txt
```

## Run

```bash
python app.py                 # http://localhost:42312
```

## Test

```bash
pytest                        # 55 tests, 96% coverage
```

## Structure

```
photo_gallery/
├── __init__.py     create_app() factory — injects the storage path, so tests get isolation
├── config.py       every value the legacy code hardcoded
├── models.py       Photo dataclass (frozen, validated) + parse_tags()
├── storage.py      PhotoStorageService — atomic writes, skip-and-log on bad records
├── service.py      PhotoService — the validation rules live here, not in the routes
├── routes.py       thin HTTP layer
├── templates/
└── static/
tests/              one module per layer
```

## What changed from the legacy version

| Legacy                                    | Refactored                                                      |
| ----------------------------------------- | --------------------------------------------------------------- |
| `comp1.py`, `thing.py`, `StorageSvc`      | `routes.py`, `PhotoStorageService`, `PhotoService`              |
| three module-level `StorageSvc()` globals | one instance, injected through `create_app()`                   |
| raw `dict` with `fileName`/`date`/`tagz`  | frozen `Photo` dataclass with `filename`/`uploaded_at`/`tags`   |
| no validation                             | size, MIME type, filename and tag rules, all tested             |
| `json.dump` straight onto the target      | temp file + `os.replace` — an interrupted write cannot truncate |
| a corrupt file crashed the page           | malformed records are skipped and logged                        |
| `debug=True` hardcoded                    | debug is opt-in, never the committed default                    |
| delete over `GET`                         | delete over `POST`                                              |
| no type hints, no docstrings, no tests    | hints and docstrings throughout, 55 tests                       |

> **Storage format**: `tagz` → `tags` is a breaking change. An old `photos_data.json` will not load.
> That trade-off is recorded in the spec under _Constraints_.
