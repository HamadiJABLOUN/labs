"""Tests for the persistence layer."""

from __future__ import annotations

import json

from tests.conftest import make_photo


class TestLoad:
    def test_missing_file_is_an_empty_gallery(self, storage):
        assert storage.load() == []

    def test_reads_back_what_was_written(self, storage):
        photo = make_photo()
        storage.save([photo])
        assert storage.load() == [photo]

    def test_corrupt_json_does_not_raise(self, storage, storage_path):
        storage_path.write_text("{ not json", encoding="utf-8")
        assert storage.load() == []

    def test_a_non_list_payload_does_not_raise(self, storage, storage_path):
        storage_path.write_text('{"id": "x"}', encoding="utf-8")
        assert storage.load() == []

    def test_one_bad_record_does_not_hide_the_good_ones(self, storage, storage_path):
        good = make_photo(id="good")
        storage_path.write_text(
            json.dumps([good.to_dict(), {"id": "broken"}]), encoding="utf-8"
        )

        loaded = storage.load()

        assert [photo.id for photo in loaded] == ["good"]


class TestSave:
    def test_creates_parent_directories(self, tmp_path):
        from photo_gallery.storage import PhotoStorageService

        nested = PhotoStorageService(tmp_path / "deep" / "nested" / "photos.json")
        nested.save([make_photo()])
        assert nested.path.exists()

    def test_leaves_no_temporary_files_behind(self, storage, storage_path):
        storage.save([make_photo()])
        leftovers = list(storage_path.parent.glob(".photos-*"))
        assert leftovers == []

    def test_writes_indented_json(self, storage, storage_path):
        storage.save([make_photo()])
        assert storage_path.read_text(encoding="utf-8").startswith("[\n")


class TestClear:
    def test_removes_the_file(self, storage):
        storage.save([make_photo()])
        storage.clear()
        assert storage.load() == []

    def test_is_safe_when_nothing_was_stored(self, storage):
        storage.clear()  # must not raise
