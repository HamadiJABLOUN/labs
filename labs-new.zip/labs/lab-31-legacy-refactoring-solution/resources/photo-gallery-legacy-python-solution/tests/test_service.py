"""Tests for the business layer."""

from __future__ import annotations

import pytest

from photo_gallery.config import MAX_FILE_SIZE
from photo_gallery.models import InvalidPhotoError
from tests.conftest import PNG_BYTES


def upload(service, **overrides):
    payload = dict(
        content=PNG_BYTES, filename="holiday.png", content_type="image/png", tags="beach"
    )
    payload.update(overrides)
    return service.add_photo(**payload)


class TestAddPhoto:
    def test_stores_a_valid_upload(self, service):
        photo = upload(service)
        assert photo.filename == "holiday.png"
        assert photo.tags == ("beach",)
        assert photo.file_size == len(PNG_BYTES)
        assert service.list_photos() == [photo]

    def test_assigns_a_unique_id(self, service):
        first = upload(service)
        second = upload(service)
        assert first.id != second.id

    def test_encodes_as_a_data_url(self, service):
        assert upload(service).data.startswith("data:image/png;base64,")

    def test_rejects_an_empty_upload(self, service):
        with pytest.raises(InvalidPhotoError, match="no file"):
            upload(service, content=b"")

    def test_rejects_an_oversized_upload(self, service):
        with pytest.raises(InvalidPhotoError, match="maximum"):
            upload(service, content=b"x" * (MAX_FILE_SIZE + 1))

    def test_rejects_an_unsupported_type(self, service):
        with pytest.raises(InvalidPhotoError, match="unsupported"):
            upload(service, content_type="application/pdf")

    def test_rejects_an_empty_filename(self, service):
        with pytest.raises(InvalidPhotoError, match="filename"):
            upload(service, filename="")

    def test_rejects_invalid_tags(self, service):
        with pytest.raises(InvalidPhotoError):
            upload(service, tags="x" * 33)

    def test_a_rejected_upload_leaves_the_gallery_untouched(self, service):
        upload(service)
        with pytest.raises(InvalidPhotoError):
            upload(service, content_type="application/pdf")
        assert len(service.list_photos()) == 1


class TestListPhotos:
    def test_is_empty_to_begin_with(self, service):
        assert service.list_photos() == []

    def test_returns_newest_first(self, service):
        first = upload(service, filename="first.png")
        second = upload(service, filename="second.png")
        assert [p.filename for p in service.list_photos()] == [
            second.filename,
            first.filename,
        ]


class TestDeletePhoto:
    def test_removes_an_existing_photo(self, service):
        photo = upload(service)
        assert service.delete_photo(photo.id) is True
        assert service.list_photos() == []

    def test_reports_an_unknown_id(self, service):
        assert service.delete_photo("does-not-exist") is False

    def test_leaves_the_other_photos_alone(self, service):
        keep = upload(service, filename="keep.png")
        drop = upload(service, filename="drop.png")
        service.delete_photo(drop.id)
        assert [p.filename for p in service.list_photos()] == [keep.filename]
