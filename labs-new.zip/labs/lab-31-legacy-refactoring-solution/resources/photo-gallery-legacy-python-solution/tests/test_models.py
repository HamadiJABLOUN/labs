"""Tests for the Photo model and tag parsing."""

from __future__ import annotations

from datetime import datetime

import pytest

from photo_gallery.models import InvalidPhotoError, Photo, parse_tags
from tests.conftest import make_photo


class TestPhotoValidation:
    def test_accepts_a_well_formed_photo(self):
        photo = make_photo()
        assert photo.filename == "holiday.png"
        assert photo.tags == ("beach", "summer")

    @pytest.mark.parametrize(
        "field,value",
        [
            ("id", ""),
            ("filename", ""),
            ("data", "not-a-data-url"),
            ("file_size", 0),
            ("file_size", -1),
        ],
    )
    def test_rejects_invalid_fields(self, field, value):
        with pytest.raises(InvalidPhotoError):
            make_photo(**{field: value})

    def test_rejects_naive_timestamp(self):
        with pytest.raises(InvalidPhotoError, match="timezone-aware"):
            make_photo(uploaded_at=datetime(2026, 1, 1))

    def test_is_immutable(self):
        photo = make_photo()
        with pytest.raises(Exception):
            photo.filename = "other.png"


class TestSerialisation:
    def test_round_trips_through_dict(self):
        photo = make_photo()
        assert Photo.from_dict(photo.to_dict()) == photo

    def test_uses_the_fixed_field_names(self):
        raw = make_photo().to_dict()
        assert set(raw) == {"id", "filename", "data", "uploadedAt", "fileSize", "tags"}
        assert isinstance(raw["tags"], list)

    @pytest.mark.parametrize("bad", [None, "a string", 42, {"id": "x"}])
    def test_rejects_malformed_records(self, bad):
        with pytest.raises(InvalidPhotoError):
            Photo.from_dict(bad)


class TestParseTags:
    @pytest.mark.parametrize(
        "raw,expected",
        [
            (None, ()),
            ("", ()),
            ("beach", ("beach",)),
            ("beach, summer", ("beach", "summer")),
            ("  Beach ,, SUMMER  ", ("beach", "summer")),
            ("beach, beach", ("beach",)),
        ],
    )
    def test_normalises(self, raw, expected):
        assert parse_tags(raw) == expected

    def test_rejects_an_over_long_tag(self):
        with pytest.raises(InvalidPhotoError, match="exceeds"):
            parse_tags("x" * 33)

    def test_rejects_too_many_tags(self):
        with pytest.raises(InvalidPhotoError, match="at most"):
            parse_tags(",".join(f"tag{i}" for i in range(11)))
