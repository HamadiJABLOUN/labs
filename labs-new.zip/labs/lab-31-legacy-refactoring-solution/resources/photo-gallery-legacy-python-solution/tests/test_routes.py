"""Tests for the HTTP layer."""

from __future__ import annotations

import io

from tests.conftest import PNG_BYTES


def post_upload(client, *, filename="holiday.png", content=PNG_BYTES,
                content_type="image/png", tags="beach, summer"):
    return client.post(
        "/upload",
        data={"photo": (io.BytesIO(content), filename, content_type), "tags": tags},
        content_type="multipart/form-data",
        follow_redirects=True,
    )


class TestIndex:
    def test_renders_an_empty_gallery(self, client):
        page = client.get("/")
        assert page.status_code == 200
        assert "No photos yet" in page.get_data(as_text=True)


class TestUpload:
    def test_accepts_and_lists_a_photo(self, client):
        page = post_upload(client)
        body = page.get_data(as_text=True)
        assert page.status_code == 200
        assert "holiday.png" in body
        assert "beach" in body and "summer" in body

    def test_renders_tags_individually(self, client):
        body = post_upload(client, tags="beach, summer").get_data(as_text=True)
        assert body.count('class="tag"') == 2

    def test_reports_a_missing_file(self, client):
        page = client.post("/upload", data={"tags": ""},
                           content_type="multipart/form-data", follow_redirects=True)
        assert "Please choose a file" in page.get_data(as_text=True)

    def test_reports_an_unsupported_type(self, client):
        page = post_upload(client, content_type="application/pdf", filename="doc.pdf")
        assert "unsupported file type" in page.get_data(as_text=True)

    def test_sets_alt_text_from_the_filename(self, client):
        body = post_upload(client).get_data(as_text=True)
        assert 'alt="holiday.png"' in body


class TestDelete:
    def test_removes_the_photo(self, client):
        post_upload(client)
        page = client.get("/")
        body = page.get_data(as_text=True)
        start = body.index("/delete/") + len("/delete/")
        photo_id = body[start : body.index('"', start)]

        after = client.post(f"/delete/{photo_id}", follow_redirects=True)
        assert "No photos yet" in after.get_data(as_text=True)

    def test_reports_an_unknown_id(self, client):
        page = client.post("/delete/nope", follow_redirects=True)
        assert "no longer exists" in page.get_data(as_text=True)

    def test_is_not_reachable_by_get(self, client):
        assert client.get("/delete/whatever").status_code == 405
