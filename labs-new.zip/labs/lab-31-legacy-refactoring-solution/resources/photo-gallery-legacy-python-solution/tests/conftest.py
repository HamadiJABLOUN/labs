"""Shared fixtures."""

from __future__ import annotations

import base64

import pytest

from photo_gallery import create_app
from photo_gallery.models import Photo, utcnow
from photo_gallery.service import PhotoService
from photo_gallery.storage import PhotoStorageService

PNG_BYTES = b"\x89PNG\r\n\x1a\n" + b"x" * 32


@pytest.fixture
def storage_path(tmp_path):
    return tmp_path / "photos_data.json"


@pytest.fixture
def storage(storage_path):
    return PhotoStorageService(storage_path)


@pytest.fixture
def service(storage):
    return PhotoService(storage)


@pytest.fixture
def client(storage_path):
    app = create_app(storage_path=storage_path)
    app.config.update(TESTING=True)
    return app.test_client()


def make_photo(**overrides) -> Photo:
    defaults = dict(
        id="abc123",
        filename="holiday.png",
        data="data:image/png;base64," + base64.b64encode(PNG_BYTES).decode(),
        uploaded_at=utcnow(),
        file_size=len(PNG_BYTES),
        tags=("beach", "summer"),
    )
    defaults.update(overrides)
    return Photo(**defaults)
