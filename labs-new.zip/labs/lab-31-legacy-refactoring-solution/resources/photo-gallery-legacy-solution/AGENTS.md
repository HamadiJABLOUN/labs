# Lab 31 Solution: Context File Example

## Project Overview

This is a legacy photo gallery application built with Angular standalone components. It allows users to upload photos with file input, add comma-separated tags, and browse photos in a grid layout. Data persists in LocalStorage.

## Current State Analysis

### Working Features

- Photo upload via file input (image files only)
- Image preview before upload
- Tag input (comma-separated)
- Grid display of uploaded photos
- Photo deletion
- LocalStorage persistence across sessions

### Technical Debt Identified

**1. Missing Tests**

- Zero test coverage across all components and services
- No test infrastructure or test files present
- Makes refactoring risky without validation

**2. Inconsistent Naming Conventions**

- Component class names: `comp1`, `thing` (should be `PhotoUploadComponent`, `PhotoListComponent`)
- Service name: `StorageSvc` (should be `StorageService` or `PhotoStorageService`)
- Model properties: `fileName` vs `fileSize`, `tagz` (typo), `date` vs `uploadedAt`
- Methods and variables use inconsistent naming patterns

**3. No Input Validation**

- File upload accepts any image without size limits (risk of filling LocalStorage)
- No file type validation beyond browser's `accept` attribute
- No validation that file was actually selected before upload
- Tags stored as comma-separated string without validation or sanitization

**4. Hardcoded Configuration Values**

- LocalStorage key hardcoded as `'photos_data'` in service
- Style values hardcoded in component templates
- No environment configuration or constants file

**5. Missing Documentation**

- Zero JSDoc comments on classes, methods, or properties
- No inline comments explaining complex logic
- No README explaining how to run or develop the application
- Component purposes unclear from names alone

**6. Tangled Dependencies & Poor Architecture**

- Components directly import and depend on `StorageSvc`
- No separation of concerns: upload component handles file reading, preview, storage
- No abstraction layer for photo management
- Tight coupling makes testing difficult
- No clear data flow or state management pattern

## Architecture

**Current Structure**:

```
src/app/
├── app.ts (Main component)
├── comp1.ts (Photo upload component)
├── thing.ts (Photo list component)
├── storage.service.ts (LocalStorage wrapper)
└── models.ts (Photo class definition)
```

**Component Relationships**:

- AppComponent contains comp1 and thing
- comp1 directly depends on StorageSvc
- thing directly depends on StorageSvc
- Both components manipulate the same LocalStorage key independently (risk of data corruption)

**Data Flow Issues**:

- No shared state management
- Components don't communicate changes
- Photo list doesn't auto-update after upload (requires manual refresh)
- Direct LocalStorage manipulation in multiple places

## Tech Stack

| Technology | Version | Purpose                                       |
| ---------- | ------- | --------------------------------------------- |
| Angular    | 20.3.x  | Frontend framework (standalone components)    |
| Vite       | -       | Build tool with @analogjs/vite-plugin-angular |
| TypeScript | ES2022  | Language                                      |
| Vitest     | -       | Testing framework (configured but unused)     |
| Nx         | 21.4.1+ | Monorepo management                           |
| ESLint     | -       | Linting with Angular-specific rules           |

**Build Configuration:**

- Dev server: Port 42311, hosted on 0.0.0.0
- Production budget: 500KB initial, 1MB max
- Output hashing in production

## Quick Commands

```bash
# Start development server
npx nx serve photo-gallery-legacy

# Build for production
npx nx build photo-gallery-legacy

# Run linting
npx nx lint photo-gallery-legacy

# Run tests (once implemented)
npx nx test photo-gallery-legacy
```

## Coding Conventions (Current State)

**Problems to Fix**:

- ❌ Class names don't follow PascalCase (`comp1`, `thing`)
- ❌ Excessive use of `any` type instead of proper TypeScript types
- ❌ Constructor injection used instead of `inject()` function (modern Angular pattern)
- ❌ No consistent file naming (`.ts` files with unclear names)
- ❌ Inline templates and styles (harder to maintain)
- ❌ No JSDoc or code comments

**Should Follow**:

- ✅ PascalCase for class names
- ✅ camelCase for methods and properties
- ✅ kebab-case for file names
- ✅ `inject()` function for dependency injection
- ✅ Explicit TypeScript types (no `any`)
- ✅ JSDoc comments for public APIs

## Known Issues

### Critical (P1)

1. **No input validation**: Large files can crash browser/fill storage
2. **Data integrity**: No validation when reading from LocalStorage (corrupt data crashes app)
3. **No error handling**: FileReader failures are silent

### High Priority (P2)

1. **Zero test coverage**: Cannot safely refactor
2. **Poor component names**: Unclear purpose and hard to navigate codebase
3. **Type safety**: Extensive use of `any` defeats TypeScript benefits

### Medium Priority (P3)

1. **Missing documentation**: Hard for new developers to understand
2. **Hardcoded values**: Configuration inflexible
3. **No separation of concerns**: Business logic in UI components

### Low Priority (P4)

1. **Inconsistent styling**: Mix of inline styles and style blocks
2. **No loading states**: Poor UX during file operations
3. **No accessibility**: Missing ARIA labels, alt text

## Constraints

- **Must remain functional**: Refactoring cannot break existing upload/display features
- **LocalStorage only**: No backend, must use browser storage
- **Angular standalone**: Must use standalone components (no NgModules)
- **Small scope**: ~500-1000 LOC total, keep it manageable for lab timeframe

## Refactoring Goals

### Phase 1: Foundation (High Priority)

1. **Add test infrastructure**: Set up Vitest, create basic test suite
2. **Fix naming**: Rename components, services, files to follow conventions
3. **Add validation**: File size, type, LocalStorage quota checks
4. **Type safety**: Replace all `any` with proper types/interfaces

### Phase 2: Architecture (Medium Priority)

1. **Create PhotoService**: Centralized photo management with signals
2. **Implement proper data model**: Photo interface with validation
3. **Add error handling**: Try-catch, error states, user feedback
4. **Separate concerns**: Move business logic out of UI components

### Phase 3: Quality (Lower Priority)

1. **Documentation**: JSDoc all public APIs, README with setup instructions
2. **Extract configuration**: Constants file for hardcoded values
3. **Improve UX**: Loading states, better error messages, accessibility
4. **Refine styling**: Consistent approach, responsive design

## Success Criteria

- ✅ Test coverage >70%
- ✅ Zero linter errors
- ✅ All components follow naming conventions
- ✅ No `any` types in production code
- ✅ Input validation prevents crashes
- ✅ Proper error handling throughout
- ✅ Photo operations use centralized service
- ✅ JSDoc on all public classes and methods
- ✅ README with development instructions

## Next Steps

1. Create REFACTORING_SPEC.md defining specific improvements
2. Develop MIGRATION_PLAN.md with prioritized tasks
3. Implement changes incrementally with tests
4. Validate against success criteria
