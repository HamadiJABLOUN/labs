import { Component, computed, signal, inject } from '@angular/core';

import { PhotoStorageService } from '../services/photo-storage.service';

/**
 * Component for displaying and managing the photo list.
 *
 * Replaces the legacy thing.ts with:
 * - Proper naming (PhotoListComponent vs thing)
 * - Type safety (no 'any' types)
 * - Tag filtering capability
 * - Signal-based reactive display
 * - Proper error handling
 *
 * @example
 * <app-photo-list />
 */
@Component({
  selector: 'app-photo-list',
  standalone: true,
  imports: [],
  template: `
    <div class="list-container">
      <div class="header">
        <h2>Photo Gallery</h2>
        <p class="photo-count">
          {{ filteredPhotos().length }} photo{{
            filteredPhotos().length !== 1 ? 's' : ''
          }}
          @if (selectedTags().length > 0) {
          <span class="filter-indicator">
            (filtered by: {{ selectedTags().join(', ') }})
          </span>
          }
        </p>
      </div>

      <!-- Tag Filter -->
      @if (allTags().length > 0) {
      <div class="filter-section">
        <h3>Filter by Tags:</h3>
        <div class="tag-filters">
          @for (tag of allTags(); track tag) {
          <label class="tag-filter">
            <input
              type="checkbox"
              [checked]="selectedTags().includes(tag)"
              (change)="toggleTag(tag)"
            />
            {{ tag }}
          </label>
          }
        </div>
        @if (selectedTags().length > 0) {
        <button
          type="button"
          (click)="clearFilters()"
          class="btn btn-secondary"
        >
          Clear Filters
        </button>
        }
      </div>
      }

      <!-- Photo List -->
      @if (filteredPhotos().length > 0) {
      <div class="photo-grid">
        @for (photo of filteredPhotos(); track photo.id) {
        <div class="photo-card">
          <div class="photo-header">
            <h3 class="photo-filename">{{ photo.filename }}</h3>
            <button
              type="button"
              (click)="deletePhoto(photo.id)"
              class="btn-delete"
              aria-label="Delete photo"
              title="Delete photo"
            >
              Delete
            </button>
          </div>

          <p class="photo-date">Uploaded: {{ formatDate(photo.uploadedAt) }}</p>

          @if (photo.tags.length > 0) {
          <div class="photo-tags">
            @for (tag of photo.tags; track tag) {
            <span
              class="tag"
              [class.selected]="selectedTags().includes(tag)"
              tabindex="0"
              role="button"
              (click)="toggleTag(tag)"
              (keyup.enter)="toggleTag(tag)"
            >
              {{ tag }}
            </span>
            }
          </div>
          } @else {
          <p class="no-tags">No tags</p>
          }
        </div>
        }
      </div>
      } @else {
      <div class="empty-state">
        @if (selectedTags().length > 0) {
        <p>No photos match the selected filters.</p>
        <button type="button" (click)="clearFilters()" class="btn btn-primary">
          Clear Filters
        </button>
        } @else {
        <p>No photos yet. Upload your first photo to get started!</p>
        }
      </div>
      }

      <!-- Error Message -->
      @if (errorMessage()) {
      <div class="error-message" role="alert">
        {{ errorMessage() }}
      </div>
      }
    </div>
  `,
  styles: [
    `
      .list-container {
        padding: 2rem;
        max-width: 1200px;
        margin: 0 auto;
      }

      .header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 2rem;
        flex-wrap: wrap;
        gap: 1rem;
      }

      .header h2 {
        margin: 0;
      }

      .photo-count {
        margin: 0;
        color: #666;
      }

      .filter-indicator {
        color: #007bff;
        font-size: 0.875rem;
      }

      .filter-section {
        background-color: #f8f9fa;
        padding: 1.5rem;
        border-radius: 8px;
        margin-bottom: 2rem;
      }

      .filter-section h3 {
        margin: 0 0 1rem 0;
        font-size: 1.125rem;
      }

      .tag-filters {
        display: flex;
        flex-wrap: wrap;
        gap: 1rem;
        margin-bottom: 1rem;
      }

      .tag-filter {
        display: flex;
        align-items: center;
        gap: 0.5rem;
        cursor: pointer;
      }

      .tag-filter input[type='checkbox'] {
        cursor: pointer;
      }

      .photo-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
        gap: 1.5rem;
      }

      .photo-card {
        background-color: white;
        border: 1px solid #dee2e6;
        border-radius: 8px;
        padding: 1.5rem;
        transition: transform 0.2s, box-shadow 0.2s;
      }

      .photo-card:hover {
        transform: translateY(-4px);
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
      }

      .photo-header {
        display: flex;
        justify-content: space-between;
        align-items: start;
        margin-bottom: 1rem;
      }

      .photo-filename {
        margin: 0;
        font-size: 1.125rem;
        word-break: break-word;
        flex: 1;
      }

      .btn-delete {
        background-color: #dc3545;
        color: white;
        border: none;
        padding: 0.375rem 0.75rem;
        border-radius: 4px;
        font-size: 0.875rem;
        cursor: pointer;
        white-space: nowrap;
        margin-left: 0.5rem;
      }

      .btn-delete:hover {
        background-color: #c82333;
      }

      .photo-date {
        color: #666;
        font-size: 0.875rem;
        margin: 0 0 1rem 0;
      }

      .photo-tags {
        display: flex;
        flex-wrap: wrap;
        gap: 0.375rem;
      }

      .tag {
        display: inline-block;
        padding: 0.25rem 0.625rem;
        background-color: #e9ecef;
        color: #495057;
        border-radius: 12px;
        font-size: 0.75rem;
        cursor: pointer;
        transition: background-color 0.2s, color 0.2s;
      }

      .tag:hover {
        background-color: #007bff;
        color: white;
      }

      .tag.selected {
        background-color: #007bff;
        color: white;
      }

      .no-tags {
        color: #999;
        font-style: italic;
        margin: 0;
        font-size: 0.875rem;
      }

      .empty-state {
        text-align: center;
        padding: 4rem 2rem;
        color: #666;
      }

      .empty-state p {
        margin: 0 0 1.5rem 0;
      }

      .error-message {
        background-color: #f8d7da;
        color: #721c24;
        padding: 0.75rem 1rem;
        border-radius: 4px;
        margin-top: 1rem;
      }

      .btn {
        padding: 0.5rem 1rem;
        border: none;
        border-radius: 4px;
        font-size: 1rem;
        cursor: pointer;
        transition: background-color 0.2s;
      }

      .btn-primary {
        background-color: #007bff;
        color: white;
      }

      .btn-primary:hover {
        background-color: #0056b3;
      }

      .btn-secondary {
        background-color: #6c757d;
        color: white;
      }

      .btn-secondary:hover {
        background-color: #545b62;
      }
    `,
  ],
})
export class PhotoListComponent {
  /** Inject PhotoStorageService */
  private readonly photoStorage = inject(PhotoStorageService);

  /** Selected tags for filtering */
  selectedTags = signal<string[]>([]);

  /** Error message signal */
  errorMessage = signal<string | null>(null);

  /** Get all available tags from service */
  allTags = computed(() => this.photoStorage.allTags());

  /** Get filtered photos based on selected tags */
  filteredPhotos = computed(() => {
    const tags = this.selectedTags();
    if (tags.length === 0) {
      return this.photoStorage.photos();
    }
    return this.photoStorage.filterByTags(tags);
  });

  /**
   * Toggles a tag in the filter selection.
   *
   * @param tag - The tag to toggle
   */
  toggleTag(tag: string): void {
    this.selectedTags.update((tags) => {
      if (tags.includes(tag)) {
        return tags.filter((t) => t !== tag);
      } else {
        return [...tags, tag];
      }
    });
    this.errorMessage.set(null);
  }

  /**
   * Clears all tag filters.
   */
  clearFilters(): void {
    this.selectedTags.set([]);
    this.errorMessage.set(null);
  }

  /**
   * Deletes a photo after confirmation.
   *
   * @param photoId - The ID of the photo to delete
   */
  deletePhoto(photoId: string): void {
    const photo = this.photoStorage.getPhotoById(photoId);
    if (!photo) {
      this.errorMessage.set('Photo not found');
      return;
    }

    if (confirm(`Are you sure you want to delete "${photo.filename}"?`)) {
      try {
        this.photoStorage.removePhoto(photoId);
        this.errorMessage.set(null);
      } catch (error) {
        this.errorMessage.set(
          error instanceof Error ? error.message : 'Failed to delete photo'
        );
      }
    }
  }

  /**
   * Formats a date for display.
   *
   * @param date - The date to format
   * @returns Formatted date string
   */
  formatDate(date: Date | string): string {
    const d = typeof date === 'string' ? new Date(date) : date;
    return new Intl.DateTimeFormat('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    }).format(d);
  }
}
