import { Component, signal, inject } from '@angular/core';

import { FormsModule } from '@angular/forms';
import { PhotoStorageService } from '../services/photo-storage.service';
import { Photo, PhotoConstraints } from '../models/photo.model';

/**
 * Component for uploading photos with tag management.
 *
 * Replaces the legacy comp1.ts with:
 * - Proper naming (PhotoUploadComponent vs comp1)
 * - File validation (size, type, filename checks)
 * - Type safety (no 'any' types)
 * - Clear error messaging
 * - Signal-based state management
 *
 * @example
 * <app-photo-upload />
 */
@Component({
  selector: 'app-photo-upload',
  standalone: true,
  imports: [FormsModule],
  template: `
    <div class="upload-container">
      <h2>Upload Photo</h2>

      <!-- File Input Section -->
      <div class="input-group">
        <label for="file-input">Select Photo:</label>
        <input
          id="file-input"
          type="file"
          accept="image/*"
          (change)="onFileSelected($event)"
          class="file-input"
        />
        @if (selectedFilename()) {
        <p class="file-info">Selected: {{ selectedFilename() }}</p>
        }
      </div>

      <!-- Filename Input -->
      <div class="input-group">
        <label for="filename-input">Filename:</label>
        <input
          id="filename-input"
          type="text"
          [(ngModel)]="filename"
          placeholder="Enter filename"
          maxlength="255"
          class="text-input"
        />
        <small class="hint"
          >Max {{ PhotoConstraints.MAX_FILENAME_LENGTH }} characters</small
        >
      </div>

      <!-- Tag Input -->
      <div class="input-group">
        <label for="tag-input">Tags:</label>
        <div class="tag-input-row">
          <input
            id="tag-input"
            type="text"
            [(ngModel)]="currentTag"
            (keyup.enter)="addTag()"
            placeholder="Enter tag (lowercase, a-z, 0-9, hyphens)"
            [disabled]="tags().length >= PhotoConstraints.MAX_TAGS"
            class="text-input"
          />
          <button
            type="button"
            (click)="addTag()"
            [disabled]="
              !currentTag || tags().length >= PhotoConstraints.MAX_TAGS
            "
            class="btn btn-secondary"
          >
            Add Tag
          </button>
        </div>
        <small class="hint">
          {{ tags().length }} / {{ PhotoConstraints.MAX_TAGS }} tags ({{
            PhotoConstraints.MIN_TAG_LENGTH
          }}-{{ PhotoConstraints.MAX_TAG_LENGTH }} chars, lowercase)
        </small>
      </div>

      <!-- Tag List -->
      @if (tags().length > 0) {
      <div class="tag-list">
        @for (tag of tags(); track tag) {
        <span class="tag">
          {{ tag }}
          <button
            type="button"
            (click)="removeTag(tag)"
            class="tag-remove"
            aria-label="Remove tag"
          >
            ×
          </button>
        </span>
        }
      </div>
      }

      <!-- Error Message -->
      @if (errorMessage()) {
      <div class="error-message" role="alert">
        {{ errorMessage() }}
      </div>
      }

      <!-- Success Message -->
      @if (successMessage()) {
      <div class="success-message" role="status">
        {{ successMessage() }}
      </div>
      }

      <!-- Upload Button -->
      <button
        type="button"
        (click)="upload()"
        [disabled]="!canUpload()"
        class="btn btn-primary btn-upload"
      >
        Upload Photo
      </button>
    </div>
  `,
  styles: [
    `
      .upload-container {
        max-width: 600px;
        margin: 0 auto;
        padding: 2rem;
      }

      .input-group {
        margin-bottom: 1.5rem;
      }

      .input-group label {
        display: block;
        font-weight: 600;
        margin-bottom: 0.5rem;
      }

      .file-input,
      .text-input {
        width: 100%;
        padding: 0.5rem;
        border: 1px solid #ced4da;
        border-radius: 4px;
        font-size: 1rem;
      }

      .file-input {
        cursor: pointer;
      }

      .file-info {
        margin-top: 0.5rem;
        color: #666;
        font-size: 0.875rem;
      }

      .hint {
        display: block;
        margin-top: 0.25rem;
        color: #666;
        font-size: 0.75rem;
      }

      .tag-input-row {
        display: flex;
        gap: 0.5rem;
      }

      .tag-input-row .text-input {
        flex: 1;
      }

      .tag-list {
        display: flex;
        flex-wrap: wrap;
        gap: 0.5rem;
        margin-bottom: 1.5rem;
      }

      .tag {
        display: inline-flex;
        align-items: center;
        gap: 0.25rem;
        padding: 0.25rem 0.75rem;
        background-color: #007bff;
        color: white;
        border-radius: 16px;
        font-size: 0.875rem;
      }

      .tag-remove {
        background: none;
        border: none;
        color: white;
        font-size: 1.25rem;
        line-height: 1;
        cursor: pointer;
        padding: 0;
        margin-left: 0.25rem;
      }

      .tag-remove:hover {
        opacity: 0.8;
      }

      .error-message {
        background-color: #f8d7da;
        color: #721c24;
        padding: 0.75rem 1rem;
        border-radius: 4px;
        margin-bottom: 1rem;
      }

      .success-message {
        background-color: #d4edda;
        color: #155724;
        padding: 0.75rem 1rem;
        border-radius: 4px;
        margin-bottom: 1rem;
      }

      .btn {
        padding: 0.5rem 1rem;
        border: none;
        border-radius: 4px;
        font-size: 1rem;
        cursor: pointer;
        transition: background-color 0.2s;
      }

      .btn:disabled {
        opacity: 0.5;
        cursor: not-allowed;
      }

      .btn-primary {
        background-color: #007bff;
        color: white;
      }

      .btn-primary:hover:not(:disabled) {
        background-color: #0056b3;
      }

      .btn-secondary {
        background-color: #6c757d;
        color: white;
        white-space: nowrap;
      }

      .btn-secondary:hover:not(:disabled) {
        background-color: #545b62;
      }

      .btn-upload {
        width: 100%;
        padding: 0.75rem;
        font-weight: 600;
      }
    `,
  ],
})
export class PhotoUploadComponent {
  /** Constants for validation */
  readonly PhotoConstraints = PhotoConstraints;

  /** Selected file reference */
  private selectedFile: File | null = null;

  /** Signal for selected filename display */
  selectedFilename = signal<string | null>(null);

  /** Filename input value */
  filename = '';

  /** Tags array signal */
  tags = signal<string[]>([]);

  /** Current tag input value */
  currentTag = '';

  /** Error message signal */
  errorMessage = signal<string | null>(null);

  /** Success message signal */
  successMessage = signal<string | null>(null);

  /** Inject PhotoStorageService */
  private readonly photoStorage = inject(PhotoStorageService);

  /**
   * Handles file selection from input.
   *
   * @param event - The file input change event
   */
  onFileSelected(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (!input.files || input.files.length === 0) {
      return;
    }

    const file = input.files[0];

    // Validate file type
    if (!file.type.startsWith('image/')) {
      this.errorMessage.set('Please select an image file');
      return;
    }

    // Store file and update filename
    this.selectedFile = file;
    this.selectedFilename.set(file.name);

    // Pre-fill filename if empty
    if (!this.filename) {
      this.filename = file.name;
    }

    this.clearMessages();
  }

  /**
   * Adds a tag to the collection.
   */
  addTag(): void {
    const tag = this.currentTag.trim().toLowerCase();
    if (!tag) return;

    this.clearMessages();

    // Check tag count limit
    if (this.tags().length >= PhotoConstraints.MAX_TAGS) {
      this.errorMessage.set(`Cannot exceed ${PhotoConstraints.MAX_TAGS} tags`);
      return;
    }

    // Check for duplicates
    if (this.tags().includes(tag)) {
      this.errorMessage.set('Tag already exists');
      return;
    }

    // Validate tag length
    if (tag.length < PhotoConstraints.MIN_TAG_LENGTH) {
      this.errorMessage.set(
        `Tag must be at least ${PhotoConstraints.MIN_TAG_LENGTH} characters`
      );
      return;
    }

    if (tag.length > PhotoConstraints.MAX_TAG_LENGTH) {
      this.errorMessage.set(
        `Tag cannot exceed ${PhotoConstraints.MAX_TAG_LENGTH} characters`
      );
      return;
    }

    // Validate tag pattern
    if (!PhotoConstraints.TAG_PATTERN.test(tag)) {
      this.errorMessage.set(
        'Tag must contain only lowercase letters, numbers, and hyphens'
      );
      return;
    }

    // Add tag
    this.tags.update((tags) => [...tags, tag]);
    this.currentTag = '';
  }

  /**
   * Removes a tag from the collection.
   *
   * @param tag - The tag to remove
   */
  removeTag(tag: string): void {
    this.tags.update((tags) => tags.filter((t) => t !== tag));
    this.clearMessages();
  }

  /**
   * Checks if upload is possible.
   *
   * @returns True if file and filename are present
   */
  canUpload(): boolean {
    return this.selectedFile !== null && this.filename.trim().length > 0;
  }

  /**
   * Uploads the photo.
   */
  upload(): void {
    if (!this.canUpload()) return;

    this.clearMessages();

    try {
      const photo: Photo = {
        id: crypto.randomUUID(),
        filename: this.filename.trim(),
        uploadedAt: new Date(),
        tags: this.tags(),
      };

      this.photoStorage.addPhoto(photo);

      // Show success and reset
      this.successMessage.set(`Successfully uploaded ${photo.filename}`);
      this.resetForm();

      // Clear success message after 3 seconds
      setTimeout(() => this.successMessage.set(null), 3000);
    } catch (error) {
      this.errorMessage.set(
        error instanceof Error ? error.message : 'Upload failed'
      );
    }
  }

  /**
   * Resets the form to initial state.
   *
   * @private
   */
  private resetForm(): void {
    this.selectedFile = null;
    this.selectedFilename.set(null);
    this.filename = '';
    this.tags.set([]);
    this.currentTag = '';
  }

  /**
   * Clears all messages.
   *
   * @private
   */
  private clearMessages(): void {
    this.errorMessage.set(null);
    this.successMessage.set(null);
  }
}
