import { describe, it, expect } from 'vitest';
import {
  validateFilename,
  validateTag,
  validateTags,
  PhotoConstraints,
} from './photo.model';

describe('Photo Model Validation', () => {
  describe('validateFilename', () => {
    it('should accept valid filename', () => {
      const result = validateFilename('photo.jpg');
      expect(result.valid).toBe(true);
      expect(result.error).toBeUndefined();
    });

    it('should reject empty filename', () => {
      const result = validateFilename('');
      expect(result.valid).toBe(false);
      expect(result.error).toBe('Filename cannot be empty');
    });

    it('should reject whitespace-only filename', () => {
      const result = validateFilename('   ');
      expect(result.valid).toBe(false);
      expect(result.error).toBe('Filename cannot be empty');
    });

    it('should reject filename exceeding maximum length', () => {
      const longFilename = 'a'.repeat(PhotoConstraints.MAX_FILENAME_LENGTH + 1);
      const result = validateFilename(longFilename);
      expect(result.valid).toBe(false);
      expect(result.error).toContain('exceeds');
    });

    it('should accept filename at maximum length', () => {
      const maxFilename = 'a'.repeat(PhotoConstraints.MAX_FILENAME_LENGTH);
      const result = validateFilename(maxFilename);
      expect(result.valid).toBe(true);
    });
  });

  describe('validateTag', () => {
    it('should accept valid tag', () => {
      const result = validateTag('vacation');
      expect(result.valid).toBe(true);
      expect(result.error).toBeUndefined();
    });

    it('should accept tag with numbers', () => {
      const result = validateTag('photo2024');
      expect(result.valid).toBe(true);
    });

    it('should accept tag with hyphens', () => {
      const result = validateTag('summer-vacation');
      expect(result.valid).toBe(true);
    });

    it('should reject tag shorter than minimum length', () => {
      const result = validateTag('x');
      expect(result.valid).toBe(false);
      expect(result.error).toContain('at least');
    });

    it('should reject tag exceeding maximum length', () => {
      const longTag = 'a'.repeat(PhotoConstraints.MAX_TAG_LENGTH + 1);
      const result = validateTag(longTag);
      expect(result.valid).toBe(false);
      expect(result.error).toContain('cannot exceed');
    });

    it('should reject tag with uppercase letters', () => {
      const result = validateTag('Vacation');
      expect(result.valid).toBe(false);
      expect(result.error).toContain('lowercase');
    });

    it('should reject tag with spaces', () => {
      const result = validateTag('summer vacation');
      expect(result.valid).toBe(false);
      expect(result.error).toContain('lowercase');
    });

    it('should reject tag with special characters', () => {
      const result = validateTag('vacation!');
      expect(result.valid).toBe(false);
      expect(result.error).toContain('lowercase');
    });

    it('should accept tag at minimum length', () => {
      const minTag = 'ab';
      const result = validateTag(minTag);
      expect(result.valid).toBe(true);
    });

    it('should accept tag at maximum length', () => {
      const maxTag = 'a'.repeat(PhotoConstraints.MAX_TAG_LENGTH);
      const result = validateTag(maxTag);
      expect(result.valid).toBe(true);
    });
  });

  describe('validateTags', () => {
    it('should accept valid tags array', () => {
      const result = validateTags(['vacation', 'beach', 'summer']);
      expect(result.valid).toBe(true);
      expect(result.error).toBeUndefined();
    });

    it('should accept empty tags array', () => {
      const result = validateTags([]);
      expect(result.valid).toBe(true);
    });

    it('should reject tags exceeding maximum count', () => {
      const manyTags = Array(PhotoConstraints.MAX_TAGS + 1)
        .fill(0)
        .map((_, i) => `tag${i}`);
      const result = validateTags(manyTags);
      expect(result.valid).toBe(false);
      expect(result.error).toContain('Cannot exceed');
    });

    it('should reject duplicate tags', () => {
      const result = validateTags(['vacation', 'beach', 'vacation']);
      expect(result.valid).toBe(false);
      expect(result.error).toContain('Duplicate');
    });

    it('should reject if any tag is invalid', () => {
      const result = validateTags(['vacation', 'X', 'beach']); // 'X' is too short
      expect(result.valid).toBe(false);
      expect(result.error).toContain('at least');
    });

    it('should accept tags at maximum count', () => {
      const maxTags = Array(PhotoConstraints.MAX_TAGS)
        .fill(0)
        .map((_, i) => `tag${i}`);
      const result = validateTags(maxTags);
      expect(result.valid).toBe(true);
    });
  });

  describe('PhotoConstraints', () => {
    it('should have correct constraint values', () => {
      expect(PhotoConstraints.MAX_FILENAME_LENGTH).toBe(255);
      expect(PhotoConstraints.MAX_TAGS).toBe(10);
      expect(PhotoConstraints.MIN_TAG_LENGTH).toBe(2);
      expect(PhotoConstraints.MAX_TAG_LENGTH).toBe(30);
      expect(PhotoConstraints.TAG_PATTERN).toBeInstanceOf(RegExp);
    });

    it('TAG_PATTERN should match valid tags', () => {
      expect(PhotoConstraints.TAG_PATTERN.test('vacation')).toBe(true);
      expect(PhotoConstraints.TAG_PATTERN.test('summer2024')).toBe(true);
      expect(PhotoConstraints.TAG_PATTERN.test('my-vacation')).toBe(true);
    });

    it('TAG_PATTERN should reject invalid tags', () => {
      expect(PhotoConstraints.TAG_PATTERN.test('Vacation')).toBe(false);
      expect(PhotoConstraints.TAG_PATTERN.test('summer vacation')).toBe(false);
      expect(PhotoConstraints.TAG_PATTERN.test('vacation!')).toBe(false);
      expect(PhotoConstraints.TAG_PATTERN.test('vacation_2024')).toBe(false);
    });
  });
});
