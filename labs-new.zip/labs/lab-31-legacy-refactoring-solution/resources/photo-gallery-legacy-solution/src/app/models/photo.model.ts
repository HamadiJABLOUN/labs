/**
 * Photo data model with type-safe properties.
 * 
 * This replaces the legacy Photo class with typos and inconsistent property names.
 * 
 * @example
 * const photo: Photo = {
 *   id: '123',
 *   filename: 'vacation.jpg',
 *   uploadedAt: new Date(),
 *   tags: ['vacation', 'beach']
 * };
 */
export interface Photo {
  /** Unique identifier for the photo */
  id: string;
  
  /** Original filename (consistent naming - not 'fileName' vs 'filename') */
  filename: string;
  
  /** Upload timestamp */
  uploadedAt: Date;
  
  /** Associated tags (consistent naming - not 'tagz' typo) */
  tags: string[];
}

/**
 * Photo validation constraints.
 */
export const PhotoConstraints = {
  /** Maximum filename length */
  MAX_FILENAME_LENGTH: 255,
  
  /** Maximum tags per photo */
  MAX_TAGS: 10,
  
  /** Tag validation pattern (lowercase, alphanumeric, hyphens) */
  TAG_PATTERN: /^[a-z0-9-]+$/,
  
  /** Minimum tag length */
  MIN_TAG_LENGTH: 2,
  
  /** Maximum tag length */
  MAX_TAG_LENGTH: 30,
} as const;

/**
 * Validation result type.
 */
export interface ValidationResult {
  valid: boolean;
  error?: string;
}

/**
 * Validates a filename.
 * 
 * @param filename - The filename to validate
 * @returns Validation result
 * 
 * @example
 * const result = validateFilename('vacation.jpg');
 * if (!result.valid) {
 *   console.error(result.error);
 * }
 */
export function validateFilename(filename: string): ValidationResult {
  if (!filename || filename.trim().length === 0) {
    return { valid: false, error: 'Filename cannot be empty' };
  }
  
  if (filename.length > PhotoConstraints.MAX_FILENAME_LENGTH) {
    return { 
      valid: false, 
      error: `Filename exceeds ${PhotoConstraints.MAX_FILENAME_LENGTH} characters` 
    };
  }
  
  return { valid: true };
}

/**
 * Validates a tag string.
 * 
 * @param tag - The tag to validate
 * @returns Validation result
 */
export function validateTag(tag: string): ValidationResult {
  if (tag.length < PhotoConstraints.MIN_TAG_LENGTH) {
    return { 
      valid: false, 
      error: `Tag must be at least ${PhotoConstraints.MIN_TAG_LENGTH} characters` 
    };
  }
  
  if (tag.length > PhotoConstraints.MAX_TAG_LENGTH) {
    return { 
      valid: false, 
      error: `Tag cannot exceed ${PhotoConstraints.MAX_TAG_LENGTH} characters` 
    };
  }
  
  if (!PhotoConstraints.TAG_PATTERN.test(tag)) {
    return { 
      valid: false, 
      error: 'Tag must contain only lowercase letters, numbers, and hyphens' 
    };
  }
  
  return { valid: true };
}

/**
 * Validates an array of tags.
 * 
 * @param tags - The tags to validate
 * @returns Validation result
 */
export function validateTags(tags: string[]): ValidationResult {
  if (tags.length > PhotoConstraints.MAX_TAGS) {
    return { 
      valid: false, 
      error: `Cannot exceed ${PhotoConstraints.MAX_TAGS} tags per photo` 
    };
  }
  
  // Check for duplicates
  const uniqueTags = new Set(tags);
  if (uniqueTags.size !== tags.length) {
    return { valid: false, error: 'Duplicate tags are not allowed' };
  }
  
  // Validate each tag
  for (const tag of tags) {
    const result = validateTag(tag);
    if (!result.valid) {
      return result;
    }
  }
  
  return { valid: true };
}
