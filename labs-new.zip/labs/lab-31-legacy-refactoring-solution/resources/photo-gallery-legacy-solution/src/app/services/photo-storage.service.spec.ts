import { TestBed } from '@angular/core/testing';
import { PhotoStorageService } from './photo-storage.service';
import { Photo } from '../models/photo.model';

describe('PhotoStorageService', () => {
  let service: PhotoStorageService;
  let mockLocalStorage: { [key: string]: string };

  beforeEach(() => {
    // Mock localStorage
    mockLocalStorage = {};
    
    global.Storage.prototype.getItem = vi.fn((key: string) => mockLocalStorage[key] || null);
    global.Storage.prototype.setItem = vi.fn((key: string, value: string) => {
      mockLocalStorage[key] = value;
    });
    global.Storage.prototype.removeItem = vi.fn((key: string) => {
      delete mockLocalStorage[key];
    });

    TestBed.configureTestingModule({});
    service = TestBed.inject(PhotoStorageService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  describe('addPhoto', () => {
    it('should add a photo to the collection', () => {
      const photo: Photo = {
        id: '1',
        filename: 'test.jpg',
        uploadedAt: new Date(),
        tags: ['test'],
      };

      service.addPhoto(photo);

      expect(service.photos()).toHaveLength(1);
      expect(service.photos()[0]).toEqual(photo);
    });

    it('should persist photo to localStorage', () => {
      const photo: Photo = {
        id: '1',
        filename: 'test.jpg',
        uploadedAt: new Date(),
        tags: ['test'],
      };

      service.addPhoto(photo);

      expect(localStorage.setItem).toHaveBeenCalled();
      expect(mockLocalStorage['photo-gallery:photos']).toBeDefined();
    });

    it('should throw error for empty filename', () => {
      const photo: Photo = {
        id: '1',
        filename: '',
        uploadedAt: new Date(),
        tags: [],
      };

      expect(() => service.addPhoto(photo)).toThrow('Filename cannot be empty');
    });

    it('should throw error for invalid tags', () => {
      const photo: Photo = {
        id: '1',
        filename: 'test.jpg',
        uploadedAt: new Date(),
        tags: ['X'], // Too short
      };

      expect(() => service.addPhoto(photo)).toThrow('Tag must be at least 2 characters');
    });

    it('should throw error for duplicate photo ID', () => {
      const photo: Photo = {
        id: '1',
        filename: 'test.jpg',
        uploadedAt: new Date(),
        tags: [],
      };

      service.addPhoto(photo);
      expect(() => service.addPhoto(photo)).toThrow('Photo with ID 1 already exists');
    });
  });

  describe('removePhoto', () => {
    it('should remove a photo from the collection', () => {
      const photo: Photo = {
        id: '1',
        filename: 'test.jpg',
        uploadedAt: new Date(),
        tags: [],
      };

      service.addPhoto(photo);
      expect(service.photos()).toHaveLength(1);

      service.removePhoto('1');
      expect(service.photos()).toHaveLength(0);
    });

    it('should throw error if photo not found', () => {
      expect(() => service.removePhoto('nonexistent')).toThrow('Photo with ID nonexistent not found');
    });

    it('should persist changes after removal', () => {
      const photo: Photo = {
        id: '1',
        filename: 'test.jpg',
        uploadedAt: new Date(),
        tags: [],
      };

      service.addPhoto(photo);
      service.removePhoto('1');

      expect(localStorage.setItem).toHaveBeenCalled();
    });
  });

  describe('updatePhotoTags', () => {
    it('should update tags for a photo', () => {
      const photo: Photo = {
        id: '1',
        filename: 'test.jpg',
        uploadedAt: new Date(),
        tags: ['old-tag'],
      };

      service.addPhoto(photo);
      service.updatePhotoTags('1', ['new-tag', 'another-tag']);

      expect(service.photos()[0].tags).toEqual(['new-tag', 'another-tag']);
    });

    it('should throw error for invalid tags', () => {
      const photo: Photo = {
        id: '1',
        filename: 'test.jpg',
        uploadedAt: new Date(),
        tags: ['test'],
      };

      service.addPhoto(photo);

      expect(() => service.updatePhotoTags('1', ['INVALID'])).toThrow(
        'Tag must contain only lowercase letters, numbers, and hyphens'
      );
    });

    it('should throw error if photo not found', () => {
      expect(() => service.updatePhotoTags('nonexistent', ['tag'])).toThrow(
        'Photo with ID nonexistent not found'
      );
    });
  });

  describe('getPhotoById', () => {
    it('should return photo by ID', () => {
      const photo: Photo = {
        id: '1',
        filename: 'test.jpg',
        uploadedAt: new Date(),
        tags: [],
      };

      service.addPhoto(photo);

      const found = service.getPhotoById('1');
      expect(found).toEqual(photo);
    });

    it('should return undefined if photo not found', () => {
      const found = service.getPhotoById('nonexistent');
      expect(found).toBeUndefined();
    });
  });

  describe('filterByTags', () => {
    beforeEach(() => {
      const photo1: Photo = {
        id: '1',
        filename: 'test1.jpg',
        uploadedAt: new Date(),
        tags: ['vacation', 'beach'],
      };

      const photo2: Photo = {
        id: '2',
        filename: 'test2.jpg',
        uploadedAt: new Date(),
        tags: ['vacation', 'mountains'],
      };

      service.addPhoto(photo1);
      service.addPhoto(photo2);
    });

    it('should return all photos when no tags specified', () => {
      const filtered = service.filterByTags([]);
      expect(filtered).toHaveLength(2);
    });

    it('should filter by single tag', () => {
      const filtered = service.filterByTags(['beach']);
      expect(filtered).toHaveLength(1);
      expect(filtered[0].tags).toContain('beach');
    });

    it('should filter by multiple tags (AND logic)', () => {
      const filtered = service.filterByTags(['vacation', 'beach']);
      expect(filtered).toHaveLength(1);
      expect(filtered[0].tags).toEqual(['vacation', 'beach']);
    });
  });

  describe('allTags computed', () => {
    it('should compute all unique tags', () => {
      const photo1: Photo = {
        id: '1',
        filename: 'test1.jpg',
        uploadedAt: new Date(),
        tags: ['vacation', 'beach'],
      };

      const photo2: Photo = {
        id: '2',
        filename: 'test2.jpg',
        uploadedAt: new Date(),
        tags: ['vacation', 'mountains'],
      };

      service.addPhoto(photo1);
      service.addPhoto(photo2);

      const tags = service.allTags();
      expect(tags).toEqual(['beach', 'mountains', 'vacation']); // Sorted
    });

    it('should return empty array when no photos', () => {
      expect(service.allTags()).toEqual([]);
    });
  });

  describe('count computed', () => {
    it('should compute photo count', () => {
      expect(service.count()).toBe(0);

      const photo: Photo = {
        id: '1',
        filename: 'test.jpg',
        uploadedAt: new Date(),
        tags: [],
      };

      service.addPhoto(photo);
      expect(service.count()).toBe(1);
    });
  });

  describe('clearAll', () => {
    it('should clear all photos', () => {
      const photo: Photo = {
        id: '1',
        filename: 'test.jpg',
        uploadedAt: new Date(),
        tags: [],
      };

      service.addPhoto(photo);
      expect(service.photos()).toHaveLength(1);

      service.clearAll();
      expect(service.photos()).toHaveLength(0);
    });

    it('should remove from localStorage', () => {
      const photo: Photo = {
        id: '1',
        filename: 'test.jpg',
        uploadedAt: new Date(),
        tags: [],
      };

      service.addPhoto(photo);
      service.clearAll();

      expect(localStorage.removeItem).toHaveBeenCalledWith('photo-gallery:photos');
    });
  });

  describe('localStorage persistence', () => {
    it('should load photos from localStorage on init', () => {
      const photos: Photo[] = [
        {
          id: '1',
          filename: 'test.jpg',
          uploadedAt: new Date(),
          tags: ['test'],
        },
      ];

      mockLocalStorage['photo-gallery:photos'] = JSON.stringify(photos);

      // Create new service instance to trigger constructor
      const newService = new PhotoStorageService();

      expect(newService.photos()).toHaveLength(1);
    });

    it('should handle corrupt localStorage data gracefully', () => {
      mockLocalStorage['photo-gallery:photos'] = 'invalid json';

      // Should not throw
      const newService = new PhotoStorageService();
      expect(newService.photos()).toEqual([]);
    });

    it('should handle invalid array format gracefully', () => {
      mockLocalStorage['photo-gallery:photos'] = JSON.stringify({ not: 'an array' });

      const newService = new PhotoStorageService();
      expect(newService.photos()).toEqual([]);
    });
  });
});
