import { Injectable, signal, computed } from '@angular/core';
import { Photo, validateTags, validateFilename } from '../models/photo.model';

/**
 * Storage configuration constants.
 */
const STORAGE_CONFIG = {
  /** LocalStorage key for photo data */
  PHOTOS_KEY: 'photo-gallery:photos',
  
  /** LocalStorage key prefix (for potential future keys) */
  KEY_PREFIX: 'photo-gallery:',
} as const;

/**
 * Service for managing photo data with LocalStorage persistence.
 * 
 * This refactored service replaces the legacy StorageSvc with:
 * - Proper naming (PhotoStorageService vs StorageSvc)
 * - Configuration constants (no hardcoded 'photos_data')
 * - Type safety (no 'any' types)
 * - Error handling for storage operations
 * - Signal-based reactive state
 * - Comprehensive documentation
 * 
 * @example
 * constructor(private photoStorage: PhotoStorageService) {
 *   const photos = this.photoStorage.photos();
 *   console.log(`Loaded ${photos.length} photos`);
 * }
 */
@Injectable({
  providedIn: 'root'
})
export class PhotoStorageService {
  /** Private signal for photo state */
  private photosSignal = signal<Photo[]>([]);
  
  /** Public readonly accessor for photos */
  readonly photos = this.photosSignal.asReadonly();
  
  /** Computed count of photos */
  readonly count = computed(() => this.photos().length);
  
  /** Computed list of all unique tags */
  readonly allTags = computed(() => {
    const tagSet = new Set<string>();
    this.photos().forEach(photo => {
      photo.tags.forEach(tag => tagSet.add(tag));
    });
    return Array.from(tagSet).sort();
  });

  constructor() {
    this.loadFromStorage();
  }

  /**
   * Adds a new photo to the collection.
   * Photo only appears in gallery if successfully saved to storage.
   * 
   * @param photo - The photo to add
   * @throws Error if validation fails, photo ID already exists, or storage save fails
   * 
   * @example
   * const photo: Photo = {
   *   id: crypto.randomUUID(),
   *   filename: 'vacation.jpg',
   *   uploadedAt: new Date(),
   *   tags: ['vacation', 'beach']
   * };
   * this.photoStorage.addPhoto(photo);
   */
  addPhoto(photo: Photo): void {
    // Validate filename
    const filenameValidation = validateFilename(photo.filename);
    if (!filenameValidation.valid) {
      throw new Error(filenameValidation.error);
    }
    
    // Validate tags
    const tagsValidation = validateTags(photo.tags);
    if (!tagsValidation.valid) {
      throw new Error(tagsValidation.error);
    }
    
    // Check for duplicate ID
    if (this.photos().some(p => p.id === photo.id)) {
      throw new Error(`Photo with ID ${photo.id} already exists`);
    }
    
    // Create updated array
    const updatedPhotos = [...this.photos(), photo];
    
    // Try to save to storage first
    this.savePhotosToStorage(updatedPhotos);
    
    // Only update signal if storage succeeds (prevents flickering)
    this.photosSignal.set(updatedPhotos);
  }

  /**
   * Removes a photo from the collection.
   * 
   * @param photoId - The ID of the photo to remove
   * @throws Error if photo not found or storage save fails
   */
  removePhoto(photoId: string): void {
    const updatedPhotos = this.photos().filter(p => p.id !== photoId);
    
    if (updatedPhotos.length === this.photos().length) {
      throw new Error(`Photo with ID ${photoId} not found`);
    }
    
    // Try to save to storage first
    this.savePhotosToStorage(updatedPhotos);
    
    // Only update signal if storage succeeds
    this.photosSignal.set(updatedPhotos);
  }

  /**
   * Updates the tags for a photo.
   * 
   * @param photoId - The ID of the photo to update
   * @param tags - The new tags array
   * @throws Error if photo not found, validation fails, or storage save fails
   */
  updatePhotoTags(photoId: string, tags: string[]): void {
    // Validate tags
    const validation = validateTags(tags);
    if (!validation.valid) {
      throw new Error(validation.error);
    }
    
    const photoIndex = this.photos().findIndex(p => p.id === photoId);
    if (photoIndex === -1) {
      throw new Error(`Photo with ID ${photoId} not found`);
    }
    
    // Create updated array
    const updatedPhotos = [...this.photos()];
    updatedPhotos[photoIndex] = { ...updatedPhotos[photoIndex], tags };
    
    // Try to save to storage first
    this.savePhotosToStorage(updatedPhotos);
    
    // Only update signal if storage succeeds
    this.photosSignal.set(updatedPhotos);
  }

  /**
   * Retrieves a photo by ID.
   * 
   * @param photoId - The ID of the photo to retrieve
   * @returns The photo or undefined if not found
   */
  getPhotoById(photoId: string): Photo | undefined {
    return this.photos().find(p => p.id === photoId);
  }

  /**
   * Filters photos by tags (AND logic - photo must have all specified tags).
   * 
   * @param tags - The tags to filter by
   * @returns Filtered photos
   */
  filterByTags(tags: string[]): Photo[] {
    if (tags.length === 0) {
      return this.photos();
    }
    
    return this.photos().filter(photo =>
      tags.every(tag => photo.tags.includes(tag))
    );
  }

  /**
   * Clears all photos from the collection.
   */
  clearAll(): void {
    this.photosSignal.set([]);
    this.removeFromStorage();
  }

  /**
   * Loads photos from LocalStorage.
   * Handles errors gracefully by starting with empty array.
   * 
   * @private
   */
  private loadFromStorage(): void {
    try {
      const data = localStorage.getItem(STORAGE_CONFIG.PHOTOS_KEY);
      if (!data) {
        this.photosSignal.set([]);
        return;
      }
      
      const parsed = JSON.parse(data);
      if (!Array.isArray(parsed)) {
        console.error('Invalid photo data format in storage');
        this.photosSignal.set([]);
        return;
      }
      
      // Convert date strings back to Date objects
      const photos = parsed.map(p => ({
        ...p,
        uploadedAt: new Date(p.uploadedAt)
      }));
      
      this.photosSignal.set(photos);
    } catch (error) {
      console.error('Failed to load photos from storage:', error);
      this.photosSignal.set([]);
    }
  }

  /**
   * Saves the given photos array to LocalStorage.
   * Handles quota exceeded errors gracefully.
   * 
   * @param photos - The photos array to save
   * @throws Error if storage operation fails
   * @private
   */
  private savePhotosToStorage(photos: Photo[]): void {
    try {
      const data = JSON.stringify(photos);
      localStorage.setItem(STORAGE_CONFIG.PHOTOS_KEY, data);
    } catch (error) {
      if (error instanceof Error && error.name === 'QuotaExceededError') {
        console.error('LocalStorage quota exceeded');
        throw new Error('Storage quota exceeded. Please delete some photos.');
      }
      console.error('Failed to save photos to storage:', error);
      throw new Error('Failed to save photos');
    }
  }

  /**
   * Saves current photos to LocalStorage.
   * 
   * @private
   */
  private saveToStorage(): void {
    this.savePhotosToStorage(this.photos());
  }

  /**
   * Removes photo data from LocalStorage.
   * 
   * @private
   */
  private removeFromStorage(): void {
    try {
      localStorage.removeItem(STORAGE_CONFIG.PHOTOS_KEY);
    } catch (error) {
      console.error('Failed to remove photos from storage:', error);
    }
  }
}
