import { Component } from '@angular/core';
import { PhotoUploadComponent } from './components/photo-upload.component';
import { PhotoListComponent } from './components/photo-list.component';

/**
 * Root application component for the refactored Photo Gallery.
 * 
 * Demonstrates improvements over legacy code:
 * - Proper component organization
 * - Clear separation of concerns
 * - Type-safe implementation
 * - Documented architecture
 * 
 * @example
 * <app-root />
 */
@Component({
  imports: [PhotoUploadComponent, PhotoListComponent],
  selector: 'app-root',
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App {
  protected title = 'Photo Gallery - Refactored';
}
