package com.sfeir.photogallery.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import com.sfeir.photogallery.config.GalleryProperties;
import com.sfeir.photogallery.model.InvalidPhotoException;
import com.sfeir.photogallery.model.Photo;
import com.sfeir.photogallery.storage.PhotoStorageService;
import java.nio.file.Path;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

class PhotoServiceTest {

    static final byte[] PNG = {(byte) 0x89, 'P', 'N', 'G', 1, 2, 3, 4};

    @TempDir
    Path tempDir;

    PhotoService service;
    GalleryProperties properties;

    @BeforeEach
    void setUp() {
        properties = new GalleryProperties(
                "Photo Gallery",
                tempDir.resolve("photos_data.json").toString(),
                2 * 1024 * 1024,
                10,
                32,
                List.of("image/png", "image/jpeg"));
        service = new PhotoService(new PhotoStorageService(properties), properties);
    }

    Photo upload() {
        return service.addPhoto(PNG, "holiday.png", "image/png", "beach");
    }

    @Nested
    @DisplayName("addPhoto")
    class AddPhoto {

        @Test
        @DisplayName("stores a valid upload")
        void storesValidUpload() {
            Photo photo = upload();

            assertThat(photo.filename()).isEqualTo("holiday.png");
            assertThat(photo.tags()).containsExactly("beach");
            assertThat(photo.fileSize()).isEqualTo(PNG.length);
            assertThat(service.listPhotos()).containsExactly(photo);
        }

        @Test
        @DisplayName("assigns a unique id")
        void assignsUniqueId() {
            assertThat(upload().id()).isNotEqualTo(upload().id());
        }

        @Test
        @DisplayName("encodes the image as a data URL")
        void encodesAsDataUrl() {
            assertThat(upload().data()).startsWith("data:image/png;base64,");
        }

        @Test
        @DisplayName("rejects an empty upload")
        void rejectsEmptyUpload() {
            assertThatThrownBy(() -> service.addPhoto(new byte[0], "a.png", "image/png", null))
                    .isInstanceOf(InvalidPhotoException.class)
                    .hasMessageContaining("no file");
        }

        @Test
        @DisplayName("rejects an oversized upload")
        void rejectsOversizedUpload() {
            byte[] tooBig = new byte[(int) properties.maxFileSize() + 1];

            assertThatThrownBy(() -> service.addPhoto(tooBig, "a.png", "image/png", null))
                    .isInstanceOf(InvalidPhotoException.class)
                    .hasMessageContaining("maximum");
        }

        @Test
        @DisplayName("rejects an unsupported type")
        void rejectsUnsupportedType() {
            assertThatThrownBy(() -> service.addPhoto(PNG, "doc.pdf", "application/pdf", null))
                    .isInstanceOf(InvalidPhotoException.class)
                    .hasMessageContaining("unsupported");
        }

        @Test
        @DisplayName("rejects a blank filename")
        void rejectsBlankFilename() {
            assertThatThrownBy(() -> service.addPhoto(PNG, "  ", "image/png", null))
                    .isInstanceOf(InvalidPhotoException.class)
                    .hasMessageContaining("filename");
        }

        @Test
        @DisplayName("rejects invalid tags")
        void rejectsInvalidTags() {
            assertThatThrownBy(() -> service.addPhoto(PNG, "a.png", "image/png", "x".repeat(33)))
                    .isInstanceOf(InvalidPhotoException.class);
        }

        @Test
        @DisplayName("a rejected upload leaves the gallery untouched")
        void rejectedUploadLeavesGalleryUntouched() {
            upload();

            assertThatThrownBy(() -> service.addPhoto(PNG, "doc.pdf", "application/pdf", null))
                    .isInstanceOf(InvalidPhotoException.class);

            assertThat(service.listPhotos()).hasSize(1);
        }
    }

    @Nested
    @DisplayName("listPhotos")
    class ListPhotos {

        @Test
        @DisplayName("is empty to begin with")
        void emptyToBeginWith() {
            assertThat(service.listPhotos()).isEmpty();
        }

        @Test
        @DisplayName("returns newest first")
        void returnsNewestFirst() throws InterruptedException {
            Photo first = service.addPhoto(PNG, "first.png", "image/png", null);
            Thread.sleep(5);
            Photo second = service.addPhoto(PNG, "second.png", "image/png", null);

            assertThat(service.listPhotos())
                    .extracting(Photo::filename)
                    .containsExactly(second.filename(), first.filename());
        }
    }

    @Nested
    @DisplayName("deletePhoto")
    class DeletePhoto {

        @Test
        @DisplayName("removes an existing photo")
        void removesExistingPhoto() {
            Photo photo = upload();

            assertThat(service.deletePhoto(photo.id())).isTrue();
            assertThat(service.listPhotos()).isEmpty();
        }

        @Test
        @DisplayName("reports an unknown id")
        void reportsUnknownId() {
            assertThat(service.deletePhoto("does-not-exist")).isFalse();
        }

        @Test
        @DisplayName("leaves the other photos alone")
        void leavesOthersAlone() {
            Photo keep = service.addPhoto(PNG, "keep.png", "image/png", null);
            Photo drop = service.addPhoto(PNG, "drop.png", "image/png", null);

            service.deletePhoto(drop.id());

            assertThat(service.listPhotos()).extracting(Photo::filename).containsExactly(keep.filename());
        }
    }
}
