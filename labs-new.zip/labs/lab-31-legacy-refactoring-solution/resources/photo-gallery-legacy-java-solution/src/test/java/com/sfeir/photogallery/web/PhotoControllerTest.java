package com.sfeir.photogallery.web;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.multipart;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.flash;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.redirectedUrl;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.sfeir.photogallery.model.Photo;
import com.sfeir.photogallery.service.PhotoService;
import java.nio.file.Path;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.springframework.test.web.servlet.MockMvc;

@SpringBootTest
@AutoConfigureMockMvc
class PhotoControllerTest {

    static final byte[] PNG = {(byte) 0x89, 'P', 'N', 'G', 1, 2, 3, 4};

    @TempDir
    static Path tempDir;

    @DynamicPropertySource
    static void galleryPath(DynamicPropertyRegistry registry) {
        registry.add("gallery.storage-path", () -> tempDir.resolve("photos_data.json").toString());
    }

    @Autowired
    MockMvc mvc;

    @Autowired
    PhotoService photos;

    @AfterEach
    void clearGallery() {
        photos.listPhotos().forEach(photo -> photos.deletePhoto(photo.id()));
    }

    MockMultipartFile file(String filename, String contentType) {
        return new MockMultipartFile("photo", filename, contentType, PNG);
    }

    @Test
    @DisplayName("renders an empty gallery")
    void rendersEmptyGallery() throws Exception {
        String body = mvc.perform(get("/"))
                .andExpect(status().isOk())
                .andReturn()
                .getResponse()
                .getContentAsString();

        assertThat(body).contains("No photos yet");
    }

    @Test
    @DisplayName("accepts and lists a photo")
    void acceptsAndListsPhoto() throws Exception {
        mvc.perform(multipart("/upload").file(file("holiday.png", "image/png")).param("tags", "beach, summer"))
                .andExpect(redirectedUrl("/"));

        String body = mvc.perform(get("/")).andReturn().getResponse().getContentAsString();

        assertThat(body).contains("holiday.png").contains("beach").contains("summer");
    }

    @Test
    @DisplayName("sets alt text from the filename")
    void setsAltText() throws Exception {
        mvc.perform(multipart("/upload").file(file("holiday.png", "image/png")));

        String body = mvc.perform(get("/")).andReturn().getResponse().getContentAsString();

        assertThat(body).contains("alt=\"holiday.png\"");
    }

    @Test
    @DisplayName("escapes HTML in a filename instead of rendering it")
    void escapesHtmlInFilename() throws Exception {
        mvc.perform(multipart("/upload").file(file("<script>alert(1)</script>.png", "image/png")));

        String body = mvc.perform(get("/")).andReturn().getResponse().getContentAsString();

        assertThat(body).doesNotContain("<script>alert(1)</script>");
        assertThat(body).contains("&lt;script&gt;alert(1)&lt;/script&gt;");
    }

    @Test
    @DisplayName("escapes HTML in a tag instead of rendering it")
    void escapesHtmlInTag() throws Exception {
        mvc.perform(multipart("/upload")
                .file(file("holiday.png", "image/png"))
                .param("tags", "<img src=x onerror=alert(1)>"));

        String body = mvc.perform(get("/")).andReturn().getResponse().getContentAsString();

        assertThat(body).doesNotContain("<img src=x onerror=alert(1)>");
    }

    @Test
    @DisplayName("reports a missing file")
    void reportsMissingFile() throws Exception {
        mvc.perform(multipart("/upload").file(new MockMultipartFile("photo", "", "image/png", new byte[0])))
                .andExpect(flash().attribute("error", "Please choose a file to upload."));
    }

    @Test
    @DisplayName("reports an unsupported type")
    void reportsUnsupportedType() throws Exception {
        mvc.perform(multipart("/upload").file(file("doc.pdf", "application/pdf")))
                .andExpect(flash().attributeExists("error"));
    }

    @Test
    @DisplayName("deletes a photo")
    void deletesPhoto() throws Exception {
        Photo photo = photos.addPhoto(PNG, "holiday.png", "image/png", null);

        mvc.perform(post("/delete/" + photo.id())).andExpect(redirectedUrl("/"));

        assertThat(photos.listPhotos()).isEmpty();
    }

    @Test
    @DisplayName("reports an unknown id on delete")
    void reportsUnknownIdOnDelete() throws Exception {
        mvc.perform(post("/delete/nope")).andExpect(flash().attributeExists("error"));
    }

    @Test
    @DisplayName("delete is not reachable by GET")
    void deleteIsPostOnly() throws Exception {
        mvc.perform(get("/delete/whatever")).andExpect(status().isMethodNotAllowed());
    }
}
