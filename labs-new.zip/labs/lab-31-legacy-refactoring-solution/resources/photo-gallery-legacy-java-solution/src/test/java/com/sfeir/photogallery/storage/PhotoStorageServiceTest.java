package com.sfeir.photogallery.storage;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatCode;

import com.sfeir.photogallery.model.Photo;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.stream.Stream;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

class PhotoStorageServiceTest {

    @TempDir
    Path tempDir;

    Path galleryPath;
    PhotoStorageService storage;

    @BeforeEach
    void setUp() {
        galleryPath = tempDir.resolve("photos_data.json");
        storage = new PhotoStorageService(galleryPath);
    }

    static Photo photo(String id) {
        return new Photo(
                id,
                id + ".png",
                "data:image/png;base64,iVBORw0KGgo=",
                Instant.now().truncatedTo(ChronoUnit.MILLIS),
                42L,
                List.of("beach"));
    }

    @Nested
    @DisplayName("load")
    class Load {

        @Test
        @DisplayName("a missing file is an empty gallery")
        void missingFileIsEmpty() {
            assertThat(storage.load()).isEmpty();
        }

        @Test
        @DisplayName("reads back what was written")
        void roundTrips() {
            Photo saved = photo("abc");
            storage.save(List.of(saved));

            assertThat(storage.load()).containsExactly(saved);
        }

        @Test
        @DisplayName("corrupt JSON does not raise")
        void corruptJsonDoesNotRaise() throws IOException {
            Files.writeString(galleryPath, "{ not json");

            assertThat(storage.load()).isEmpty();
        }

        @Test
        @DisplayName("a non-list payload does not raise")
        void nonListDoesNotRaise() throws IOException {
            Files.writeString(galleryPath, "{\"id\": \"x\"}");

            assertThat(storage.load()).isEmpty();
        }

        @Test
        @DisplayName("one bad record does not hide the good ones")
        void skipsOnlyTheBadRecord() throws IOException {
            storage.save(List.of(photo("good")));
            String json = Files.readString(galleryPath);
            String withBroken = json.replaceFirst("\\[", "[ { \"id\": \"broken\" },");
            Files.writeString(galleryPath, withBroken);

            assertThat(storage.load()).extracting(Photo::id).containsExactly("good");
        }
    }

    @Nested
    @DisplayName("save")
    class Save {

        @Test
        @DisplayName("creates parent directories")
        void createsParents() {
            PhotoStorageService nested =
                    new PhotoStorageService(tempDir.resolve("deep/nested/photos.json"));

            nested.save(List.of(photo("abc")));

            assertThat(nested.path()).exists();
        }

        @Test
        @DisplayName("leaves no temporary files behind")
        void leavesNoTempFiles() throws IOException {
            storage.save(List.of(photo("abc")));

            try (Stream<Path> files = Files.list(tempDir)) {
                assertThat(files.map(p -> p.getFileName().toString()))
                        .noneMatch(name -> name.startsWith(".photos-"));
            }
        }

        @Test
        @DisplayName("writes pretty-printed JSON")
        void writesPrettyJson() throws IOException {
            storage.save(List.of(photo("abc")));

            assertThat(Files.readString(galleryPath)).contains("\n");
        }

        @Test
        @DisplayName("replaces the previous content")
        void replacesPreviousContent() {
            storage.save(List.of(photo("first")));
            storage.save(List.of(photo("second")));

            assertThat(storage.load()).extracting(Photo::id).containsExactly("second");
        }
    }

    @Nested
    @DisplayName("clear")
    class Clear {

        @Test
        @DisplayName("removes the file")
        void removesTheFile() {
            storage.save(List.of(photo("abc")));

            storage.clear();

            assertThat(storage.load()).isEmpty();
        }

        @Test
        @DisplayName("is safe when nothing was stored")
        void safeWhenEmpty() {
            assertThatCode(storage::clear).doesNotThrowAnyException();
        }
    }
}
