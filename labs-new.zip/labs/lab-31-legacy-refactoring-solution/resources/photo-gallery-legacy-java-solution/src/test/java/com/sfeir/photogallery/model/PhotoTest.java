package com.sfeir.photogallery.model;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatCode;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import java.time.Instant;
import java.util.List;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.NullAndEmptySource;
import org.junit.jupiter.params.provider.ValueSource;

class PhotoTest {

    static final String DATA_URL = "data:image/png;base64,iVBORw0KGgo=";

    static Photo photo() {
        return new Photo("abc123", "holiday.png", DATA_URL, Instant.now(), 42L, List.of("beach"));
    }

    @Nested
    @DisplayName("validation")
    class Validation {

        @Test
        @DisplayName("accepts a well-formed photo")
        void acceptsWellFormed() {
            assertThat(photo().filename()).isEqualTo("holiday.png");
        }

        @ParameterizedTest
        @NullAndEmptySource
        @ValueSource(strings = {"   "})
        @DisplayName("rejects a blank id")
        void rejectsBlankId(String id) {
            assertThatThrownBy(() -> new Photo(id, "a.png", DATA_URL, Instant.now(), 1L, List.of()))
                    .isInstanceOf(InvalidPhotoException.class)
                    .hasMessageContaining("id");
        }

        @ParameterizedTest
        @NullAndEmptySource
        @DisplayName("rejects a blank filename")
        void rejectsBlankFilename(String filename) {
            assertThatThrownBy(() -> new Photo("id", filename, DATA_URL, Instant.now(), 1L, List.of()))
                    .isInstanceOf(InvalidPhotoException.class)
                    .hasMessageContaining("filename");
        }

        @ParameterizedTest
        @ValueSource(strings = {"not-a-data-url", "http://example.com/a.png", ""})
        @DisplayName("rejects data that is not a base64 data URL")
        void rejectsBadData(String data) {
            assertThatThrownBy(() -> new Photo("id", "a.png", data, Instant.now(), 1L, List.of()))
                    .isInstanceOf(InvalidPhotoException.class)
                    .hasMessageContaining("data URL");
        }

        @Test
        @DisplayName("rejects a null timestamp")
        void rejectsNullTimestamp() {
            assertThatThrownBy(() -> new Photo("id", "a.png", DATA_URL, null, 1L, List.of()))
                    .isInstanceOf(InvalidPhotoException.class)
                    .hasMessageContaining("uploadedAt");
        }

        @ParameterizedTest
        @ValueSource(longs = {0L, -1L})
        @DisplayName("rejects a non-positive file size")
        void rejectsBadSize(long size) {
            assertThatThrownBy(() -> new Photo("id", "a.png", DATA_URL, Instant.now(), size, List.of()))
                    .isInstanceOf(InvalidPhotoException.class)
                    .hasMessageContaining("fileSize");
        }

        @Test
        @DisplayName("treats null tags as no tags")
        void nullTagsBecomeEmpty() {
            assertThat(new Photo("id", "a.png", DATA_URL, Instant.now(), 1L, null).tags()).isEmpty();
        }

        @Test
        @DisplayName("exposes an unmodifiable tag list")
        void tagsAreUnmodifiable() {
            assertThatThrownBy(() -> photo().tags().add("nope"))
                    .isInstanceOf(UnsupportedOperationException.class);
        }
    }

    @Nested
    @DisplayName("parseTags")
    class ParseTags {

        @ParameterizedTest
        @CsvSource({
            "beach,               beach",
            "'beach, summer',     'beach|summer'",
            "'  Beach ,, SUMMER', 'beach|summer'",
            "'beach, beach',      beach"
        })
        @DisplayName("normalises, de-duplicates and preserves order")
        void normalises(String raw, String expected) {
            assertThat(Photo.parseTags(raw, 10, 32)).containsExactly(expected.split("\\|"));
        }

        @ParameterizedTest
        @NullAndEmptySource
        @ValueSource(strings = {"   ", ",,,"})
        @DisplayName("yields no tags for blank input")
        void blankYieldsEmpty(String raw) {
            assertThat(Photo.parseTags(raw, 10, 32)).isEmpty();
        }

        @Test
        @DisplayName("rejects an over-long tag")
        void rejectsLongTag() {
            assertThatThrownBy(() -> Photo.parseTags("x".repeat(33), 10, 32))
                    .isInstanceOf(InvalidPhotoException.class)
                    .hasMessageContaining("exceeds");
        }

        @Test
        @DisplayName("rejects more tags than the configured maximum")
        void rejectsTooManyTags() {
            String eleven = "a,b,c,d,e,f,g,h,i,j,k";

            assertThatThrownBy(() -> Photo.parseTags(eleven, 10, 32))
                    .isInstanceOf(InvalidPhotoException.class)
                    .hasMessageContaining("at most");

            assertThatCode(() -> Photo.parseTags(eleven, 11, 32)).doesNotThrowAnyException();
        }
    }
}
