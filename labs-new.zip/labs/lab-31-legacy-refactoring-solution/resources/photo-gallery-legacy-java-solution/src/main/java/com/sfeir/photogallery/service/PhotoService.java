package com.sfeir.photogallery.service;

import com.sfeir.photogallery.config.GalleryProperties;
import com.sfeir.photogallery.model.InvalidPhotoException;
import com.sfeir.photogallery.model.Photo;
import com.sfeir.photogallery.storage.PhotoStorageService;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Comparator;
import java.util.List;
import java.util.UUID;
import org.springframework.stereotype.Service;

/**
 * Business logic for managing photos.
 *
 * <p>The controller stays thin: every rule about what may enter the gallery
 * lives here.
 */
@Service
public class PhotoService {

    private final PhotoStorageService storage;
    private final GalleryProperties properties;

    public PhotoService(PhotoStorageService storage, GalleryProperties properties) {
        this.storage = storage;
        this.properties = properties;
    }

    /**
     * Returns every stored photo, newest first.
     *
     * @return the gallery, never {@code null}
     */
    public List<Photo> listPhotos() {
        List<Photo> photos = storage.load();
        photos.sort(Comparator.comparing(Photo::uploadedAt).reversed());
        return photos;
    }

    /**
     * Validates, encodes, and stores an uploaded image.
     *
     * @param content     the raw bytes of the uploaded file
     * @param filename    the original file name
     * @param contentType the MIME type reported by the client
     * @param tags        the raw comma-separated tag string, possibly {@code null}
     * @return the stored photo
     * @throws InvalidPhotoException if the upload is empty, too large, of an
     *                               unsupported type, or carries invalid tags
     */
    public Photo addPhoto(byte[] content, String filename, String contentType, String tags) {
        if (content == null || content.length == 0) {
            throw new InvalidPhotoException("no file was uploaded");
        }
        if (content.length > properties.maxFileSize()) {
            throw new InvalidPhotoException(
                    "file is " + content.length + " bytes, the maximum is " + properties.maxFileSize());
        }
        if (contentType == null || !properties.allowedMimeTypes().contains(contentType)) {
            throw new InvalidPhotoException("unsupported file type: " + contentType);
        }
        if (filename == null || filename.isBlank()) {
            throw new InvalidPhotoException("filename must not be empty");
        }

        Photo photo = new Photo(
                UUID.randomUUID().toString().replace("-", ""),
                filename,
                "data:" + contentType + ";base64," + Base64.getEncoder().encodeToString(content),
                // Truncated to milliseconds so a photo survives the JSON round-trip unchanged:
                // Instant.now() carries nanoseconds that the serialised form does not preserve.
                Instant.now().truncatedTo(ChronoUnit.MILLIS),
                content.length,
                Photo.parseTags(tags, properties.maxTags(), properties.maxTagLength()));

        List<Photo> photos = new ArrayList<>(storage.load());
        photos.add(photo);
        storage.save(photos);
        return photo;
    }

    /**
     * Removes a photo by id.
     *
     * @param photoId the id to remove
     * @return {@code true} if a photo was removed, {@code false} if the id was unknown
     */
    public boolean deletePhoto(String photoId) {
        List<Photo> photos = storage.load();
        List<Photo> remaining = photos.stream()
                .filter(photo -> !photo.id().equals(photoId))
                .toList();

        if (remaining.size() == photos.size()) {
            return false;
        }

        storage.save(new ArrayList<>(remaining));
        return true;
    }
}
