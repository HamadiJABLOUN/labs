package com.sfeir.photogallery.model;

/** Raised when a photo, or an upload, fails validation. */
public class InvalidPhotoException extends RuntimeException {

    public InvalidPhotoException(String message) {
        super(message);
    }
}
