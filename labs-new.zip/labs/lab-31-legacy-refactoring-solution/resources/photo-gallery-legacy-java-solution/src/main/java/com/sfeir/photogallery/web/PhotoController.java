package com.sfeir.photogallery.web;

import com.sfeir.photogallery.config.GalleryProperties;
import com.sfeir.photogallery.model.InvalidPhotoException;
import com.sfeir.photogallery.service.PhotoService;
import java.io.IOException;
import java.io.UncheckedIOException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

/** HTTP layer. Thin by design: all rules live in {@link PhotoService}. */
@Controller
public class PhotoController {

    private static final Logger log = LoggerFactory.getLogger(PhotoController.class);

    private final PhotoService photos;
    private final GalleryProperties properties;

    public PhotoController(PhotoService photos, GalleryProperties properties) {
        this.photos = photos;
        this.properties = properties;
    }

    /** Renders the gallery. */
    @GetMapping("/")
    public String index(Model model) {
        model.addAttribute("title", properties.title());
        model.addAttribute("maxFileSizeMib", properties.maxFileSize() / (1024 * 1024));
        model.addAttribute("photos", photos.listPhotos());
        return "index";
    }

    /** Accepts an uploaded photo, or reports why it was rejected. */
    @PostMapping("/upload")
    public String upload(
            @RequestParam("photo") MultipartFile file,
            @RequestParam(value = "tags", required = false) String tags,
            RedirectAttributes redirect) {

        if (file.isEmpty()) {
            redirect.addFlashAttribute("error", "Please choose a file to upload.");
            return "redirect:/";
        }

        try {
            photos.addPhoto(file.getBytes(), file.getOriginalFilename(), file.getContentType(), tags);
        } catch (InvalidPhotoException e) {
            redirect.addFlashAttribute("error", e.getMessage());
        } catch (IOException | UncheckedIOException e) {
            log.error("Upload failed while writing the gallery", e);
            redirect.addFlashAttribute("error", "The gallery could not be saved. Please try again.");
        }

        return "redirect:/";
    }

    /** Deletes a photo. POST-only, so a crawler cannot wipe the gallery. */
    @PostMapping("/delete/{id}")
    public String delete(@PathVariable String id, RedirectAttributes redirect) {
        if (!photos.deletePhoto(id)) {
            redirect.addFlashAttribute("error", "That photo no longer exists.");
        }
        return "redirect:/";
    }
}
