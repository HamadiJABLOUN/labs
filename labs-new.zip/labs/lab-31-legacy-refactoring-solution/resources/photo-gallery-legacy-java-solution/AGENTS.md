# Lab 31 Solution (Java): Context File Example

> Java variant of [`../photo-gallery-legacy-solution/AGENTS.md`](../photo-gallery-legacy-solution/AGENTS.md).
> Same lab, same deliverable, analysed against `photo-gallery-legacy-java/`.

## Project Overview

A legacy photo gallery built with Spring Boot. Users upload photos through an HTML form, add comma-separated tags, and browse them in a grid. Data persists in a JSON file next to the working directory. The HTML is assembled by string concatenation inside the controllers.

## Current State Analysis

### Working Features

- Photo upload via a multipart form
- Tag input (comma-separated)
- Grid display of uploaded photos
- Photo deletion
- Persistence across restarts, in `photos_data.json`

### Technical Debt Identified

**1. Missing Tests**

- Zero test coverage; `src/test/` does not exist, though `spring-boot-starter-test` is on the classpath
- Makes any refactoring a gamble

**2. Inconsistent Naming Conventions**

- Classes `comp1` and `thing` — lowercase, and meaningless. They compile, but violate every Java convention
- Class `StorageSvc` (should be `PhotoStorageService`)
- Field `KEY` is `private String`, not `static final`, despite the constant-style name
- Record keys `fileName`, `fileSize`, `date`, `tagz` — a typo and a misnomer baked into the persisted format

**3. No Input Validation**

- No file size limit beyond Spring's default multipart cap
- No MIME type check: `file.getContentType()` is trusted and echoed into the data URL
- `filename` is never checked for null or blank
- Tags are stored as the raw string, never split, trimmed, or bounded

**4. Hardcoded Configuration Values**

- `StorageSvc.KEY = "photos_data.json"` — relative to the working directory, so the gallery changes with the launch location
- Page title is a `public String` field on the application class
- Every CSS rule is concatenated into the Java source

**5. Missing Documentation**

- No Javadoc on any class or method
- No README: nothing states that `./mvnw spring-boot:run` is the way in
- Class names convey nothing about purpose

**6. Tangled Dependencies & Poor Architecture**

- Three components (`comp1`, `thing`, and the application class itself) each `@Autowired` the same `StorageSvc`
- `@SpringBootApplication` and `@Controller` on the same class: bootstrap and web concerns mixed
- Business logic (base64 encoding, record construction) lives inside the request handler
- No service layer between the controllers and persistence

### Java-specific findings

These have no equivalent in the Angular version and are worth calling out in the debrief:

- **Raw types everywhere**: `List load()`, `List photos`, `Map photo`. Every call site compiles with unchecked warnings and every read is an unguarded cast. This is the Java analogue of the Angular version's `any`, but it fails at runtime rather than at the type checker.
- **Swallowed exceptions**: `StorageSvc.save()` catches `Exception` and does nothing. A failed write is indistinguishable from a successful one — the user sees their photo vanish on the next page load with no error anywhere.
- **Corrupt file reads as empty**: `load()` returns `new ArrayList()` on any parse failure. The next `save()` then overwrites the damaged file with an empty list, destroying whatever could have been recovered.
- **Field injection**: `@Autowired` on private fields makes the class untestable without a Spring context, and hides how many collaborators it really has.
- **String concatenation in a loop**: `thing.render()` builds HTML with `html = html + ...`, allocating a new `String` per photo.
- **No HTML escaping**: filenames and tags are concatenated straight into the markup. A file named `<script>alert(1)</script>.png` is stored XSS.

## Architecture

**Current Structure**:

```
photo-gallery-legacy-java/
├── pom.xml
└── src/main/java/com/sfeir/photogallery/
    ├── PhotoGalleryLegacyApplication.java  (bootstrap + index route + hardcoded title)
    ├── comp1.java                          (upload controller)
    ├── thing.java                          (delete controller + HTML builder)
    ├── StorageSvc.java                     (JSON file wrapper)
    └── Photo.java                          (public-field bean, unused by the rest of the code)
```

**Component Relationships**:

- The application class renders the page and delegates the photo grid to `thing.render()`
- `comp1` and `thing` each inject `StorageSvc`
- The application class injects it a third time
- All three read and write the same file with no locking

**Data Flow Issues**:

- Read-modify-write with no coordination: two concurrent requests lose one of the writes
- Writes are not atomic — an interrupted `writeValue` truncates the gallery permanently
- `Photo.java` is dead code: the handlers build raw `HashMap`s instead

## Tech Stack

| Technology  | Version         | Purpose                          |
| ----------- | --------------- | -------------------------------- |
| Java        | 17              | Language                         |
| Spring Boot | 3.5.16          | Web framework                    |
| Jackson     | via Boot        | JSON serialisation               |
| Maven       | 3.9.9 (wrapper) | Build                            |
| JSON file   | -               | Persistence (`photos_data.json`) |

## Quick Commands

```bash
cd labs/lab-31-legacy-refactoring/photo-gallery-legacy-java

./mvnw spring-boot:run      # http://localhost:42313
./mvnw compile
./mvnw test                 # no tests exist yet
```

On Windows use `mvnw.cmd` instead of `./mvnw`.

## Coding Conventions (Current State)

**Problems to Fix**:

- ❌ Class names violate PascalCase (`comp1`, `thing`)
- ❌ Raw types instead of generics
- ❌ Field injection instead of constructor injection
- ❌ Mutable public fields on the model and the application class
- ❌ HTML assembled in Java string literals
- ❌ No Javadoc

**Should Follow**:

- ✅ PascalCase for classes, camelCase for methods and fields
- ✅ Generics everywhere; no raw types, no unchecked casts
- ✅ Constructor injection, `final` fields
- ✅ `record` for immutable data carriers
- ✅ A template engine for HTML
- ✅ Javadoc on all public APIs

## Known Issues

### Critical (P1)

1. **Stored XSS**: filenames and tags are concatenated into HTML unescaped
2. **Swallowed write failures**: a failed save reports success
3. **Corrupt file is overwritten**: a parse error silently destroys the gallery on the next write
4. **No input validation**: an oversized or non-image upload is accepted and encoded whole
5. **Delete over `GET`**: any crawler or prefetcher can empty the gallery

### High Priority (P2)

1. **Zero test coverage**: cannot refactor safely
2. **Raw types**: every read from storage is an unguarded cast
3. **Three uncoordinated storage instances**: lost updates under concurrency

### Medium Priority (P3)

1. **Missing documentation**: no Javadoc, no README
2. **Hardcoded values**: storage path, title, styles
3. **No separation of concerns**: business logic inside controllers

### Low Priority (P4)

1. **String concatenation in a loop** in `thing.render()`
2. **Dead code**: `Photo.java` is never used
3. **No accessibility**: images carry an empty `alt`, no form labels

## Constraints

- **Must remain functional**: refactoring cannot break upload, display, or delete
- **File-based persistence only**: no database, to keep the lab self-contained
- **Spring Boot**: no rewrite to another framework within this lab
- **Small scope**: ~200 LOC, must stay manageable in the lab timeframe

## Refactoring Goals

### Phase 1: Foundation (High Priority)

1. **Add test infrastructure**: JUnit 5 + AssertJ + MockMvc, one test class per layer
2. **Fix naming**: `PhotoController`, `PhotoService`, `PhotoStorageService`
3. **Add validation**: file size, MIME type, tag count and length
4. **Type safety**: a `Photo` record with generics; no raw types left

### Phase 2: Architecture (Medium Priority)

1. **Separate bootstrap from web**: `PhotoGalleryApplication` does nothing but start Spring
2. **Service layer**: `PhotoService` owns the rules, the controller stays thin
3. **Constructor injection**: `final` collaborators, testable without a context
4. **Atomic writes and real error handling**: temp file plus `Files.move`, flash attributes on failure

### Phase 3: Quality (Lower Priority)

1. **Template engine**: Thymeleaf, which escapes by default and closes the XSS hole
2. **Externalise configuration**: `@ConfigurationProperties` bound to `gallery.*`
3. **Documentation**: Javadoc on every public API, a README with setup steps
4. **Accessibility**: real `alt` text, `POST` for deletion, labelled form controls

## Success Criteria

- ✅ Test coverage > 70%
- ✅ All classes follow PascalCase
- ✅ Zero raw types, zero unchecked warnings
- ✅ Input validation prevents oversized and unsupported uploads
- ✅ A corrupt storage file degrades gracefully instead of destroying data
- ✅ User-supplied text is escaped before rendering
- ✅ Photo operations go through a single service
- ✅ Javadoc on all public classes and methods
- ✅ README with development instructions

## Next Steps

1. Create REFACTORING_SPEC.md defining specific improvements
2. Develop MIGRATION_PLAN.md with prioritized tasks
3. Implement changes incrementally with tests
4. Validate against success criteria
