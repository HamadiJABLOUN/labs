# Photo Gallery — Refactored (Java / Spring Boot)

Reference "after" state for [Lab 31](../../../lab-31-legacy-refactoring/README.md), starting from
`photo-gallery-legacy-java/`.

See [`AGENTS.md`](AGENTS.md) for the analysis of the legacy code, and
[`../java/REFACTORING_SPEC.md`](../java/REFACTORING_SPEC.md) /
[`../java/MIGRATION_PLAN.md`](../java/MIGRATION_PLAN.md) for the plan this implements.

## Requirements

JDK 17 or later. Maven comes via the wrapper.

## Run

```bash
./mvnw spring-boot:run        # mvnw.cmd on Windows — http://localhost:42313
```

## Test

```bash
./mvnw test                   # 59 tests
```

## Structure

```
src/main/java/com/sfeir/photogallery/
├── PhotoGalleryApplication.java   bootstrap only — no web concerns
├── config/GalleryProperties.java  @ConfigurationProperties bound to gallery.*
├── model/Photo.java               record, validated in the constructor
├── model/InvalidPhotoException.java
├── storage/PhotoStorageService.java  atomic writes, skip-and-log on bad records
├── service/PhotoService.java      the validation rules live here, not in the controller
└── web/PhotoController.java       thin HTTP layer
src/main/resources/
├── application.properties         every value the legacy code hardcoded
├── templates/index.html           Thymeleaf — escapes by default
└── static/styles.css
src/test/java/...                  one test class per layer
```

## What changed from the legacy version

| Legacy                                          | Refactored                                                   |
| ----------------------------------------------- | ------------------------------------------------------------ |
| classes `comp1`, `thing`, `StorageSvc`          | `PhotoController`, `PhotoService`, `PhotoStorageService`     |
| `@SpringBootApplication` + `@Controller` merged | bootstrap and web split into separate classes                |
| `List load()`, `save(Object)`, `Map photo`      | `List<Photo>`, `save(List<Photo>)`, a `Photo` record         |
| `@Autowired` on private fields                  | constructor injection, `final` collaborators                 |
| HTML concatenated in Java, unescaped            | Thymeleaf — **closes the stored XSS**, asserted by two tests |
| `catch (Exception e) {}` on write               | failures surface to the user and are logged                  |
| a corrupt file was overwritten with `[]`        | malformed records are skipped; valid ones still load         |
| no validation                                   | size, MIME type, filename and tag rules, all tested          |
| delete over `GET`                               | delete over `POST`; a `GET` returns 405                      |
| no Javadoc, no tests                            | Javadoc throughout, 59 tests                                 |

> **Storage format**: `tagz` → `tags` is a breaking change. An old `photos_data.json` will not load.
> That trade-off is recorded in the spec under _Constraints_.
