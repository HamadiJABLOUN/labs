# Migration Plan — Photo Gallery (Python / Flask)

> Python variant of [`../MIGRATION_PLAN.md`](../MIGRATION_PLAN.md).
> Derived from `REFACTORING_SPEC.md` and `photo-gallery-legacy-python-solution/AGENTS.md`.

**Total estimated effort**: 14.5 h — **actual, as implemented**: the reference solution in
`../photo-gallery-legacy-python-solution/` follows this plan end to end.

---

## Priority legend

| Level  | Meaning                                 |
| ------ | --------------------------------------- |
| **P1** | Critical — security, data loss, crashes |
| **P2** | High — test coverage, major refactoring |
| **P3** | Medium — cleanup, documentation         |
| **P4** | Low — future improvements               |

Risk is the chance the task breaks something while it is being done.

---

## Task list

| #   | Task                                                       | Pri | Effort | Depends on | Risk   |
| --- | ---------------------------------------------------------- | --- | ------ | ---------- | ------ |
| T1  | Remove `debug=True`; move the port to configuration        | P1  | 0.25 h | —          | Low    |
| T2  | Add `pytest` + `pytest-cov`, `pytest.ini`, `tests/`        | P2  | 0.5 h  | —          | Low    |
| T3  | Characterisation tests on the legacy behaviour             | P2  | 1.5 h  | T2         | Low    |
| T4  | Extract `config.py` with every hardcoded value             | P2  | 0.5 h  | —          | Low    |
| T5  | `Photo` dataclass with validation + `parse_tags`           | P2  | 1.5 h  | T4         | Medium |
| T6  | `PhotoStorageService`: injected path, atomic write         | P1  | 1.5 h  | T5         | Medium |
| T7  | Skip-and-log malformed records on load                     | P1  | 0.5 h  | T6         | Low    |
| T8  | `PhotoService` holding the validation rules                | P1  | 1.5 h  | T5, T6     | Medium |
| T9  | `create_app()` factory; delete the three globals           | P2  | 1 h    | T8         | High   |
| T10 | Thin the routes; flash errors instead of raising           | P1  | 1 h    | T9         | Medium |
| T11 | Move deletion from `GET` to `POST`                         | P2  | 0.25 h | T10        | Low    |
| T12 | Rewrite the template: escaping, labels, `alt`, empty state | P3  | 1 h    | T10        | Low    |
| T13 | Extract the stylesheet out of the template                 | P3  | 0.5 h  | T12        | Low    |
| T14 | Docstrings and type hints across every module              | P3  | 1 h    | T10        | Low    |
| T15 | README with setup and run instructions                     | P3  | 0.5 h  | T14        | Low    |
| T16 | Raise coverage above 70%, add the edge cases               | P2  | 1.5 h  | T10        | Low    |

**Sum**: 14.5 h across 16 tasks.

---

## Recommended order of execution

### Stage 0 — Stop the bleeding (0.25 h)

**T1** first, alone, before anything else. `debug=True` is a remote code execution hole; it costs
fifteen minutes and is the only task here that is genuinely urgent. Ship it as its own commit.

### Stage 1 — Build the safety net (2 h)

**T2 → T3**. Write tests against the legacy code _as it behaves today_, including the behaviour you
intend to change. They exist to tell you when a refactor altered something, not to bless the current
design. Delete or rewrite them as the design moves.

> This stage is the one trainees skip. Everything after it is a gamble without it.

### Stage 2 — Foundations (4 h)

**T4 → T5 → T6 → T7**. Bottom-up: configuration, then the model, then persistence. Each layer is
finished and tested before the next one leans on it. T6 is where atomic writes land, which is the
single highest-value change in the plan.

### Stage 3 — Architecture (3.75 h)

**T8 → T9 → T10 → T11**. The service layer first, then the factory, then the routes shrink onto it.

> **T9 is the riskiest task in the plan.** Removing the module-level globals touches every import in
> the project at once. Do it in one sitting, with the suite green before and after, and do not mix it
> with any other change in the same commit.

### Stage 4 — Surface (3 h)

**T12 → T13**, then **T14 → T15**. Presentation and documentation. Safe to interrupt; safe to defer
if the timebox runs out.

### Stage 5 — Close the gaps (1.5 h)

**T16**. With the design settled, fill in the edge cases the earlier tests did not reach: corrupt
files, partial records, boundary sizes, duplicate tags.

---

## Quick wins vs long-term

**Quick wins** — under 30 minutes each, no dependencies, ship immediately:

- T1 remove `debug=True` (0.25 h) — removes an RCE
- T4 extract `config.py` (0.5 h) — unblocks four later tasks
- T11 `POST` for deletion (0.25 h) — stops crawlers emptying the gallery
- T13 extract the stylesheet (0.5 h)

**Long-term** — the structural work, worth the time only because the tests exist first:

- T6 atomic writes — the difference between losing the gallery and not
- T8 + T9 service layer and factory — what makes the code testable at all
- T16 full edge-case coverage — what keeps it that way

---

## Risk assessment

| Task | Risk   | What could go wrong                                               | Mitigation                                                       |
| ---- | ------ | ----------------------------------------------------------------- | ---------------------------------------------------------------- |
| T5   | Medium | Renaming `tagz` → `tags` breaks every existing `photos_data.json` | Accepted and documented in the spec; delete the file and restart |
| T6   | Medium | `os.replace` behaves differently across filesystems               | Temp file created in the _same_ directory as the target          |
| T8   | Medium | Validation rejects input the old code accepted                    | Covered by T3; each rule gets its own test                       |
| T9   | High   | Import-time side effects vanish and something silently breaks     | Full suite green before and after; isolated commit               |
| T10  | Medium | Errors swallowed by flash messages instead of surfacing           | A test per error path asserting the message reaches the page     |

---

## Definition of done

A task is done when:

1. Its tests pass, and the whole suite still passes
2. Coverage has not dropped
3. The public API it touched carries a docstring and type hints
4. The app still uploads, lists and deletes a photo by hand
5. It is committed on its own, with a message naming the task id

---

## Verification

```bash
cd photo-gallery-legacy-python-solution
python -m venv .venv && .venv/Scripts/activate
pip install -r requirements-dev.txt
pytest
```

Expected, and what the reference solution actually produces:

```
55 passed
TOTAL  187 stmts  8 miss  96% coverage
```
