# Refactoring Specification — Photo Gallery (Python / Flask)

> Python variant of [`../REFACTORING_SPEC.md`](../REFACTORING_SPEC.md).
> Target codebase: `labs/lab-31-legacy-refactoring/photo-gallery-legacy-python/`.
> Reference implementation: `../photo-gallery-legacy-python-solution/`.

**Status**: Implemented
**Related**: `photo-gallery-legacy-python-solution/AGENTS.md`, `MIGRATION_PLAN.md`

---

## 1. Goals

| #   | Goal                     | Measurable outcome                                                                   |
| --- | ------------------------ | ------------------------------------------------------------------------------------ |
| G1  | Make refactoring safe    | A test suite covering every layer, above 70% line coverage                           |
| G2  | Stop accepting bad input | Size, MIME type, filename and tags validated before anything is written              |
| G3  | Survive bad data         | A corrupt or partially written store never crashes the app and never loses good rows |
| G4  | Make the code legible    | PEP 8 names, type hints and docstrings on every public function                      |
| G5  | Separate the concerns    | Routes hold no business rules; one storage instance, injected                        |
| G6  | Remove hidden coupling   | No module-level singletons; configuration in one place                               |

## 2. Scope

### In scope

- `models.py`, `storage_svc.py`, `comp1.py`, `thing.py`, `app.py`, `templates/index.html`
- Introducing a test suite and the dev dependencies it needs
- Introducing a configuration module and an application factory
- Correcting the persisted record shape (`fileName` → `filename`, `date` → `uploadedAt`, `tagz` → `tags`)

### Out of scope

- Replacing Flask with another framework
- Replacing the JSON file with a database
- Authentication, multi-user support, photo editing
- Deployment, containerisation, CI configuration
- Thumbnailing or any image processing

## 3. Functional requirements

| #    | Requirement                                                                               | Priority |
| ---- | ----------------------------------------------------------------------------------------- | -------- |
| FR-1 | An upload is rejected, with a message shown to the user, when no file was selected        | P1       |
| FR-2 | An upload above the configured size limit is rejected with a message naming the limit     | P1       |
| FR-3 | An upload whose MIME type is not in the allow-list is rejected with a message             | P1       |
| FR-4 | Tags are split on commas, trimmed, lowercased, de-duplicated, and bounded in count/length | P2       |
| FR-5 | A rejected upload leaves the gallery byte-for-byte unchanged                              | P1       |
| FR-6 | Photos are listed newest first                                                            | P3       |
| FR-7 | Deleting an unknown id reports it instead of failing silently                             | P2       |
| FR-8 | Deletion happens over `POST`, never `GET`                                                 | P2       |

## 4. Non-functional requirements

| #     | Requirement                                                                             | Priority |
| ----- | --------------------------------------------------------------------------------------- | -------- |
| NFR-1 | A write is atomic: an interrupted save never truncates the gallery                      | P1       |
| NFR-2 | A malformed record is skipped and logged; the valid records still load                  | P1       |
| NFR-3 | Unreadable or non-list JSON yields an empty gallery and a logged error, not a traceback | P1       |
| NFR-4 | Every public function carries a type hint and a docstring                               | P3       |
| NFR-5 | The storage path, size limit, allowed types and tag bounds are configurable             | P2       |
| NFR-6 | `debug=True` is never the committed default                                             | P1       |
| NFR-7 | Images carry meaningful `alt` text; every form control has a label                      | P3       |

## 5. Success criteria

The refactoring is done when all of the following hold:

- [x] `pytest` reports over 70% coverage — **achieved: 96% across 55 tests**
- [x] Every module, class and public function has a docstring
- [x] Every public function signature is annotated
- [x] No module-level `StorageSvc()` instances remain
- [x] `create_app(storage_path=...)` lets a test run against a temporary directory
- [x] Uploading a 3 MiB file returns a readable error, not a traceback
- [x] Uploading a PDF returns a readable error
- [x] Hand-corrupting `photos_data.json` does not crash the index page
- [x] Adding a broken record to a valid file still lists the valid ones
- [x] The persisted record uses `filename`, `uploadedAt`, `tags`
- [x] Upload, list and delete behave exactly as before for valid input

## 6. Constraints

- **Behaviour preserving**: the three user-visible features must keep working
- **Timebox**: the full migration fits in roughly two working days
- **No new runtime dependency**: only test-time dependencies may be added
- **Python 3.12+**: the target interpreter, matching the rest of the training
- **Breaking storage format accepted**: the existing `photos_data.json` shape is a bug,
  not a contract. Fixing `tagz` means old files will not load — acceptable here because the
  gallery is a lab artefact. In production this would demand a migration step, and that
  trade-off is worth stating out loud in the debrief.

## 7. Non-goals

Explicitly **not** attempted, so nobody plans for them:

- Concurrency safety beyond atomic replacement. The read-modify-write race remains;
  closing it properly means a lock or a database, and that is a different decision.
- Streaming uploads. Files are still read fully into memory, which is why the size limit matters.
- Internationalisation of the error messages.
- Any change to the visual design beyond what accessibility requires.
