# Lab 31: Refactoring Specification

**Project**: Legacy Photo Gallery Modernization  
**Date**: _[Current Date]_  
**Status**: Planning Phase

## 1. Goals

### Primary Goals

1. **Establish test coverage** to enable safe refactoring (target: >70%)
2. **Improve code maintainability** through consistent naming and clear structure
3. **Enhance type safety** by eliminating `any` types and using proper interfaces
4. **Add input validation** to prevent crashes and data corruption
5. **Implement proper error handling** for better user experience and debugging

### Secondary Goals

1. Add comprehensive documentation (JSDoc, README)
2. Centralize photo management logic in dedicated service
3. Extract configuration values to constants
4. Improve code organization and separation of concerns

## 2. Scope

### In Scope

- **Testing**: Add Vitest test suite for all components and services
- **Naming**: Rename all components, services, and files to follow Angular conventions
- **Types**: Create Photo interface, remove all `any` types
- **Validation**: Add file size/type validation, LocalStorage quota checks
- **Error Handling**: Add try-catch blocks, error states, user feedback
- **Documentation**: JSDoc comments, project README
- **Service Layer**: Create centralized PhotoService with signal-based state
- **Code Cleanup**: Remove hardcoded values, improve structure

### Out of Scope

- **UI Redesign**: Keep existing visual design and layout
- **New Features**: No new functionality (albums, sharing, editing, etc.)
- **Backend Integration**: Remain LocalStorage-based (no API)
- **Authentication**: No user accounts or login system
- **Advanced Features**: No image compression, filters, or manipulation
- **Migration to Different Framework**: Stay with Angular
- **Mobile-Specific Features**: Responsive design improvements only

## 3. Success Criteria

### Automated Validation

- ✅ **Test Coverage**: >70% code coverage across components and services
- ✅ **Linter**: Zero ESLint errors, zero TypeScript errors
- ✅ **Type Safety**: No `any` types except where absolutely necessary (with justification)
- ✅ **Build**: Project builds without warnings

### Code Quality Metrics

- ✅ **Naming Conventions**: All classes, methods, files follow Angular style guide
- ✅ **Documentation**: Every public class/method has JSDoc comment
- ✅ **Validation**: All user inputs validated before processing
- ✅ **Error Handling**: All async operations and potential failures have error handling

### Functional Requirements

- ✅ **No Breaking Changes**: All existing features continue to work
- ✅ **Data Preservation**: Existing photos in LocalStorage remain accessible
- ✅ **Input Validation**: Files >5MB rejected, non-images rejected
- ✅ **Error Feedback**: Users receive clear error messages for failures

### User Experience

- ✅ **Upload Flow**: Upload process works smoothly with validation feedback
- ✅ **Display**: Photos display correctly with tags
- ✅ **Deletion**: Delete works with confirmation (if time permits)
- ✅ **Error States**: Graceful handling of storage quota exceeded, corrupt data

## 4. Constraints

### Technical Constraints

- **Framework**: Must use Angular 21.x standalone components
- **Storage**: Must use LocalStorage (no backend/database)
- **Dependencies**: Minimize new dependencies (use built-in Angular features)
- **Browser Support**: Must work in Chrome, Firefox, Safari (modern versions)

### Time Constraints

- **Lab Duration**: Refactoring planning should take ~45-60 minutes
- **Implementation**: If students implement, should be completable in 2-3 hours
- **Focus**: Prioritize P1/P2 improvements over P3/P4 nice-to-haves

### Backwards Compatibility

- **Data Format**: Must read existing photos from LocalStorage
- **LocalStorage Key**: Can migrate data if key changes, but must support old format
- **Breaking Changes**: None allowed for end users

### Code Standards

- **Style Guide**: Follow Angular official style guide
- **TypeScript**: Use strict mode, no `any` without justification
- **Testing**: Use Vitest (already configured)
- **Documentation**: Use JSDoc format

## 5. Acceptance Criteria

### Must Have (P1)

- [ ] All components renamed to follow conventions (`PhotoUploadComponent`, `PhotoListComponent`)
- [ ] Photo interface defined with proper types
- [ ] File upload validation (size ≤5MB, type check)
- [ ] LocalStorage error handling (quota, parsing)
- [ ] Basic test suite (at least one test per component/service)
- [ ] No TypeScript `any` types in models or services
- [ ] JSDoc on all component classes
- [ ] README with setup instructions

### Should Have (P2)

- [ ] PhotoService with signal-based state management
- [ ] Test coverage >70%
- [ ] All validation logic tested
- [ ] Error messages displayed to users
- [ ] JSDoc on all public methods
- [ ] Configuration constants extracted
- [ ] Proper dependency injection with `inject()`

### Could Have (P3)

- [ ] Component tests with TestBed
- [ ] Loading states during file operations
- [ ] Improved UX with better feedback
- [ ] Accessibility improvements (ARIA labels)
- [ ] Architecture decision record (ADR)

## 6. Non-Goals (Explicitly Excluded)

### Features NOT Being Added

- ❌ Photo editing/filters
- ❌ Photo albums or collections
- ❌ Social sharing
- ❌ Backend API integration
- ❌ User authentication
- ❌ Cloud storage
- ❌ Image compression
- ❌ Bulk operations
- ❌ Search functionality beyond basic tag filtering

### Refactoring NOT In Scope

- ❌ Complete rewrite (incremental improvements only)
- ❌ Framework migration (staying with Angular)
- ❌ Major architectural changes (keeping component structure)
- ❌ Performance optimization (unless critical issue)
- ❌ SEO improvements
- ❌ PWA features
- ❌ Internationalization (i18n)

## 7. Risks and Mitigation

### Risk: Breaking Existing Functionality

- **Likelihood**: Medium
- **Impact**: High
- **Mitigation**:
  - Write tests before refactoring
  - Refactor incrementally with frequent validation
  - Keep original code in git history
  - Test with existing LocalStorage data

### Risk: Time Overrun

- **Likelihood**: High (for students new to refactoring)
- **Impact**: Medium
- **Mitigation**:
  - Clear prioritization (P1 > P2 > P3)
  - Focus on must-haves first
  - Set strict time limits per task
  - Have solution available for reference

### Risk: Introducing New Bugs

- **Likelihood**: Medium
- **Impact**: Medium
- **Mitigation**:
  - Test-driven approach (tests first)
  - Small, atomic commits
  - Manual testing after each change
  - Validation checklist before completion

### Risk: Scope Creep

- **Likelihood**: High (tempting to add features)
- **Impact**: Low (time wasted)
- **Mitigation**:
  - Strict adherence to "Out of Scope" list
  - Remind students: refactoring, not feature development
  - Time-box the exercise

## 8. Dependencies

### Technical Dependencies

- Node.js v22+ (for Nx and build tools)
- Nx workspace (already set up)
- Vitest (already configured)
- Angular 21.x (already installed)

### Knowledge Dependencies

- Understanding of Angular standalone components
- Basic TypeScript knowledge
- Familiarity with unit testing concepts
- Understanding of LocalStorage API

### Process Dependencies

- AGENTS.md (project context analysis) must be complete before starting
- Migration plan must be reviewed before implementation
- Tests should be written before or alongside refactoring

## 9. Success Metrics

### Quantitative Metrics

- **Test Coverage**: >70% (target: 80%)
- **Type Safety**: <5 `any` types in entire codebase
- **Documentation**: 100% of public APIs have JSDoc
- **Linter Errors**: 0 errors, <10 warnings
- **Build Time**: No significant increase

### Qualitative Metrics

- **Code Readability**: New developer can understand structure in <15 minutes
- **Maintainability**: Adding new photo operations is straightforward
- **Error Handling**: All failure modes handled gracefully
- **User Experience**: Clear feedback for all operations

## 10. Next Steps

1. **Review this specification** with stakeholders (trainer/peers)
2. **Create MIGRATION_PLAN.md** with detailed task breakdown
3. **Set up git branch** for refactoring work
4. **Begin with P1 tasks** (tests, naming, validation)
5. **Validate frequently** against success criteria
6. **Document decisions** as you go

---

**Note**: This specification defines WHAT we're improving and WHY. The MIGRATION_PLAN.md will define HOW and WHEN (task sequence, priorities, estimates).
