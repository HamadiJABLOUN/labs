# Lab 31 Solution: Legacy Code Refactoring

> **Audience: trainers.** This document contains the live-demo script, timing guidance and
> evaluation criteria. It is _not_ written for trainees.
>
> **Trainees** should read the artifacts themselves instead — they are the actual deliverable:
> `resources/` for the planning documents, and the `*-solution/` project folders for the code.

**Purpose**: Provide trainers and learners with a complete example of applying the agentic workflow to legacy code analysis and refactoring planning, plus the actual refactored code showing the "after" state.

## Solution Overview

This solution demonstrates how to systematically analyze a legacy codebase and create a comprehensive refactoring plan using AI-assisted agentic practices.

## 📁 Solution Structure

```
lab-31-legacy-refactoring-solution/
├── README.md                           # This file - trainer guide
└── resources/
      ├── REFACTORING_SPEC.md         # Refactoring goals & acceptance criteria  (TypeScript)
      ├── MIGRATION_PLAN.md           # 20-task implementation plan              (TypeScript)
      ├── python/                     # ⭐ Python variant of both planning docs
      │     ├── REFACTORING_SPEC.md
      │     └── MIGRATION_PLAN.md
      ├── java/                       # ⭐ Java variant of both planning docs
      │     ├── REFACTORING_SPEC.md
      │     └── MIGRATION_PLAN.md
      ├── photo-gallery-legacy-python-solution/  # ⭐ REFACTORED CODE (Flask, 55 tests)
      ├── photo-gallery-legacy-java-solution/    # ⭐ REFACTORED CODE (Spring Boot, 59 tests)
      └── photo-gallery-legacy-solution/ # ⭐ REFACTORED CODE
         ├── AGENTS.md                   # Legacy code analysis (context file)
         ├── README.md                   # Refactored solution documentation
         ├── src/app/
         │   ├── models/
         │   │   ├── photo.model.ts         # Proper Photo interface + validation
         │   │   └── photo.model.spec.ts    # 24 tests (vs 0 in legacy)
         │   ├── services/
         │   │   ├── photo-storage.service.ts  # Refactored service
         │   │   └── photo-storage.service.spec.ts  # 25 tests
         │   ├── components/
         │   │   ├── photo-upload.component.ts    # Refactored upload
         │   │   └── photo-list.component.ts      # Refactored list
         │   └── app.ts                   # Root component
         └── ...
```

**Key Deliverables:**

1. **AGENTS.md** - Complete legacy code analysis identifying 6 technical debt patterns
2. **REFACTORING_SPEC.md** - Goals, scope, acceptance criteria organized by priority
3. **MIGRATION_PLAN.md** - 20 tasks with effort estimates (21-27 hours)
4. **photo-gallery-legacy-solution/** - ⭐ **Actual working refactored code** (50 tests, >70% coverage)

## Language Variants

The lab ships the same legacy gallery in three stacks. Each has its own complete solution: the
context file, both planning documents, and a refactored project with a passing test suite.

| Stack                      | Legacy project (trainee)      | Refactored solution                               | Tests                        |
| -------------------------- | ----------------------------- | ------------------------------------------------- | ---------------------------- |
| **TypeScript** (Angular)   | `photo-gallery-legacy`        | `resources/photo-gallery-legacy-solution/`        | 50, Vitest                   |
| **Python** (Flask)         | `photo-gallery-legacy-python` | `resources/photo-gallery-legacy-python-solution/` | **55, pytest, 96% coverage** |
| **Java** (Spring Boot 3.5) | `photo-gallery-legacy-java`   | `resources/photo-gallery-legacy-java-solution/`   | **59, JUnit 5 + MockMvc**    |

The planning documents live alongside them:

- TypeScript: `resources/REFACTORING_SPEC.md`, `resources/MIGRATION_PLAN.md`
- Python: `resources/python/REFACTORING_SPEC.md`, `resources/python/MIGRATION_PLAN.md`
- Java: `resources/java/REFACTORING_SPEC.md`, `resources/java/MIGRATION_PLAN.md`

Each `AGENTS.md` sits inside its own solution project, mirroring where the trainee is asked to write it.

### What differs between the stacks, and why it is worth showing

The three variants carry the _same_ six debt patterns, but each language exposes a different one most
sharply. That contrast is the most valuable thing in the debrief:

- **TypeScript** — `any` everywhere. The type checker was available and was simply not used.
- **Python** — implicit contracts. The record is a bare `dict`; nothing states that `tagz` is a
  string rather than a list until something breaks at runtime. The variant also carries a hardcoded
  `debug=True`, which is a remote code execution hole rather than a style problem.
- **Java** — raw types and swallowed exceptions. `List load()` and `save(Object)` compile fine and
  fail at the cast. `StorageSvc.save()` catches `Exception` and does nothing, so a failed write
  reports success. It is also the only variant with a **stored XSS**: the HTML is built by string
  concatenation, so a filename containing a `<script>` tag executes.

Ask the room which debt their AI assistant surfaced first. In practice it finds the naming problems
immediately in all three, and the Java exception swallowing almost never — a good illustration of
why the analysis step needs a human reading the diff.

### Running the variants

```bash
# Python
cd resources/photo-gallery-legacy-python-solution
python -m venv .venv && .venv/Scripts/activate   # source .venv/bin/activate on macOS/Linux
pip install -r requirements-dev.txt
pytest                                            # 55 passed, 96% coverage
python app.py                                     # http://localhost:42312

# Java
cd resources/photo-gallery-legacy-java-solution
./mvnw test                                       # 59 tests, BUILD SUCCESS
./mvnw spring-boot:run                            # http://localhost:42313
```

On Windows, use `mvnw.cmd` instead of `./mvnw`.

## Trainer Demonstration Notes

### Live Demo Integration (15-20 minutes)

When presenting this solution, demonstrate the **Agentic Coding workflow in action**:

#### Part 1: Legacy Code Analysis (5-7 minutes)

**Show the Process**:

1. **Open the legacy codebase** in your IDE
2. **Use AI to analyze** technical debt:

   ```
   Prompt: "Analyze this photo gallery codebase and identify technical debt patterns.
   Focus on: missing tests, inconsistent naming, validation issues, hardcoded values,
   missing documentation, and tangled dependencies. Provide specific examples."
   ```

3. **Walk through AI's findings**:
   - Point out specific code examples on screen
   - Explain how AI identified patterns
   - Highlight most critical issues

4. **Emphasize systematic approach**:
   - Traditional: Developer manually reviews code, might miss issues
   - Agentic: AI systematically scans entire codebase, identifies patterns

#### Part 2: Context File Creation (3-5 minutes)

**Show the Process**:

1. **Create AGENTS.md** and explain its purpose
2. **Use AI to populate sections**:

   ```
   Prompt: "Based on your analysis, help me complete this AGENTS.md context file.
   Include: project overview, current state with identified issues, architecture
   description, tech stack, and refactoring goals."
   ```

3. **Demonstrate iteration**:
   - Show first AI response
   - Refine with follow-up questions
   - Highlight how context improves with each iteration

4. **Key Teaching Point**:
   - "This context file becomes our 'shared understanding' with AI"
   - "The better the context, the better AI assistance we'll get"

#### Part 3: Specification Writing (4-5 minutes)

**Show the Process**:

1. **Create REFACTORING_SPEC.md**
2. **Use AI to draft specification**:

   ```
   Prompt: "Using the AGENTS.md context and technical debt identified,
   create a refactoring specification with: goals, scope, success criteria,
   constraints, and non-goals."
   ```

3. **Review and refine**:
   - Check if goals are specific and measurable
   - Ensure scope is realistic
   - Verify constraints are acknowledged

4. **Contrast with traditional approach**:
   - Traditional: Vague "make it better" goals
   - Agentic: Specific, measurable success criteria

#### Part 4: Migration Plan (3-5 minutes)

**Show the Process**:

1. **Create MIGRATION_PLAN.md**
2. **Use AI to generate task breakdown**:

   ```
   Prompt: "Create a prioritized migration plan with: task list with dependencies,
   effort estimates in hours, risk assessment, recommended execution order.
   Organize by P1 (critical), P2 (high), P3 (medium), P4 (low)."
   ```

3. **Walk through prioritization logic**:
   - Why certain tasks are P1 (security, blocking issues)
   - Dependencies between tasks
   - Quick wins vs long-term improvements

4. **Highlight systematic thinking**:
   - Not random fixes
   - Strategic, prioritized approach
   - Risk-aware planning

### Key Teaching Points

**Throughout the demonstration, emphasize**:

1. **Structured Process**: Each phase builds on the previous
2. **AI as Collaborator**: Developer leads, AI assists with analysis
3. **Quality Focus**: Systematic approach catches issues manual review might miss
4. **Context is Critical**: AGENTS.md enables better AI assistance
5. **Iteration**: Refine AI outputs through dialogue

### Common Student Questions

**Q: "How long does this analysis take in real projects?"**
A: For a codebase this size (500-1000 LOC), about 45-60 minutes. Larger projects scale linearly but the process remains the same.

**Q: "What if AI misses something important?"**
A: AI is a tool, not a replacement for engineering judgment. Always review and validate AI's analysis. The systematic approach helps ensure thoroughness.

**Q: "Do I always need AGENTS.md?"**
A: For any non-trivial project, yes. Context files dramatically improve AI assistance quality. They're especially critical for legacy codebases.

**Q: "What if my prioritization differs from AI's?"**
A: Your expertise matters! Use AI's suggestions as input, but make final decisions based on business needs, technical constraints, and team capacity.

## Solution Artifacts

The `resources/photo-gallery-legacy-solution/` directory contains complete examples:

### AGENTS.md

Shows effective legacy code analysis documenting:

- Current technical debt with specific examples
- Architecture patterns (good and problematic)
- Risk areas requiring immediate attention
- Dependencies and constraints

### REFACTORING_SPEC.md

Demonstrates clear specification with:

- Measurable goals (e.g., "Achieve 80% test coverage")
- Bounded scope (what's included/excluded)
- Specific success criteria
- Acknowledged constraints (time, compatibility)

### MIGRATION_PLAN.md

Provides prioritized task breakdown with:

- 15-20 specific tasks organized by priority
- Effort estimates (2-16 hours per task)
- Dependency mapping
- Risk assessment for each task
- Recommended execution sequence

### photo-gallery-legacy-solution/

Complete reference implementation showing the "after" state:

- **Demonstrates all 6 improvements**: Clear naming, comprehensive tests, validation logic, configuration constants, full documentation, strict types
- **Working application**: Buildable Nx Angular app with 50 passing tests
- **Before/After comparison**: Side-by-side examples in README showing specific improvements
- **Educational value**: Students can explore real refactored code, not just planning documents

**Use in demos**:

```bash
# Show students the working refactored code
npx nx serve photo-gallery-legacy-solution

# Run tests to demonstrate coverage
npx nx test photo-gallery-legacy-solution --run
```

> **Note**: Compare the legacy code in `lab-31-legacy-refactoring/photo-gallery-legacy/src/app/` with the refactored code in `src/app/` to see the improvements (e.g., `comp1.ts` → `components/photo-upload.component.ts`).

## Evaluation Criteria

When reviewing student submissions, check:

- [ ] Context file captures all major technical debt
- [ ] Specification has measurable success criteria (not vague)
- [ ] Migration plan has realistic priorities (security > cosmetic)
- [ ] Tasks are specific and actionable (not "improve code quality")
- [ ] Effort estimates are in reasonable range
- [ ] Dependencies are identified

## Extensions and Variations

For advanced students or extended sessions:

1. **Actually implement P1 tasks** from the migration plan
2. **Measure improvement**: Run linters, test coverage before/after
3. **Compare approaches**: Manual refactoring vs AI-assisted
4. **Team exercise**: Different groups prioritize differently, compare results

## Additional Resources

- Example AGENTS.md templates
- Refactoring checklist
- Prioritization frameworks
- Risk assessment guides

---

**Trainer Reminder**: The goal is teaching **systematic thinking** and **effective AI collaboration**, not just completing the exercise. Students should leave understanding WHY this approach works, not just HOW to follow the steps.
