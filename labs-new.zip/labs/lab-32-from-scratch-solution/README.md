# Lab 32 Solution: Building from Scratch with Complete Agentic Workflow

> **Audience: trainers.** This document contains the live-demo script, timing guidance and
> evaluation criteria. It is _not_ written for trainees.
>
> **Trainees** should read the artifacts themselves instead — they are the actual deliverable:
> `resources/` for the planning documents, and the `*-solution/` project folders for the code.

**Purpose**: Provide trainers and learners with a complete example of applying all 5 phases of the agentic workflow to build a new feature from specification to working implementation.

## Solution Overview

This solution demonstrates the **complete agentic coding workflow** (Specify → Plan → Tasks → Implement → Validate) applied to building a photo gallery application from scratch.

## Language Tracks

The lab ships three tracks. The TypeScript one builds a browser UI; the Python and Java ones build the
**REST API behind it**, against one shared HTTP contract.

| Track                      | Solution project                                        | Tests                        |
| -------------------------- | ------------------------------------------------------- | ---------------------------- |
| **TypeScript** (Angular)   | `resources/photo-gallery-from-scratch-solution/`        | Vitest                       |
| **Python** (FastAPI)       | `resources/photo-gallery-from-scratch-python-solution/` | **71, pytest, 98% coverage** |
| **Java** (Spring Boot 3.5) | `resources/photo-gallery-from-scratch-java-solution/`   | **47, JUnit 5 + MockMvc**    |

Planning artifacts, one set per track:

- TypeScript: `resources/SPECIFICATION.md`, `IMPLEMENTATION_PLAN.md`, `TASKS.md`
- Python: `resources/python/` (same three files)
- Java: `resources/java/` (same three files)

### The shared contract

Both API tracks implement the same five endpoints and the same JSON payload, so a Python trainee and
a Java trainee can compare results directly:

| Method   | Path               | Success            | Errors |
| -------- | ------------------ | ------------------ | ------ |
| `POST`   | `/api/photos`      | `201` + Photo      | `422`  |
| `GET`    | `/api/photos`      | `200` + Photo[]    | ---    |
| `GET`    | `/api/photos/{id}` | `200` + Photo      | `404`  |
| `DELETE` | `/api/photos/{id}` | `204`              | `404`  |
| `GET`    | `/api/tags`        | `200` + TagStats[] | ---    |

### One divergence, kept on purpose

`POST /api/photos` with no `file` part returns **422 in FastAPI** and **400 in Spring**. FastAPI
treats a missing required part as request validation; Spring raises
`MissingServletRequestPartException`. Both are defensible.

It is left unaligned deliberately, and it is the best five minutes of the debrief: _the same
specification, implemented twice, still leaks framework opinions at the edges_. A contract that wants
identical codes has to name them. Every **domain** rule violation returns 422 in both.

### Two bugs the tests caught, and a review would not have

Worth showing, because both are invisible in a diff:

1. **Java — `Instant.now()` does not survive the JSON round-trip.** It carries nanoseconds the
   serialised form drops, so the photo read back is not `equal` to the one written. The failing
   assertion prints two timestamps that look identical. Fixed by truncating to milliseconds.
2. **Python — a `204` may not carry a body.** With `from __future__ import annotations`, the
   `-> None` return annotation is deferred to the string `"None"`, which FastAPI resolves into a
   response model. Startup then fails with _"Status code 204 must not have a response body"_ --- an
   error pointing at the status code rather than at the annotation. Fixed with `response_model=None`.

### Running the tracks

```bash
# Python
cd resources/photo-gallery-from-scratch-python-solution
python -m venv .venv && .venv/Scripts/activate   # source .venv/bin/activate on macOS/Linux
pip install -r requirements-dev.txt
pytest                                            # 71 passed, 98% coverage
python -m app                                     # http://127.0.0.1:42323/docs

# Java
cd resources/photo-gallery-from-scratch-java-solution
./mvnw test                                       # 47 tests, BUILD SUCCESS
./mvnw spring-boot:run                            # http://localhost:42322
```

On Windows, use `mvnw.cmd` instead of `./mvnw`.

## Trainer Demonstration Notes

### Live Demo Integration (20-25 minutes)

When presenting this solution, demonstrate **all 5 workflow phases in action**:

#### Phase 1: Specify (4-5 minutes)

**Show the Process**:

1. **Create SPECIFICATION.md** with AI assistance:

   ```
   Prompt: "Help me create a feature specification for a photo gallery with upload,
   tagging, and browsing capabilities. Include: user stories, functional requirements,
   acceptance criteria, success measures, and out-of-scope items."
   ```

2. **Walk through the specification**:
   - Point out 3-4 key user stories
   - Highlight how requirements are specific and testable
   - Show how acceptance criteria define "done"

3. **Key Teaching Point**:
   - "Clear specification prevents rework later"
   - "We're defining WHAT, not HOW (that comes in Plan phase)"

#### Phase 2: Plan (4-5 minutes)

**Show the Process**:

1. **Create IMPLEMENTATION_PLAN.md**:

   ```
   Prompt: "Based on SPECIFICATION.md, help me plan the implementation.
   Include: tech stack selection with rationale, architecture design,
   data model with interfaces, file structure, key technical decisions."
   ```

2. **Discuss key decisions**:
   - Why Angular standalone components?
   - Why signals for state management?
   - Why LocalStorage (not backend)?
   - Show data model (Photo, Tag interfaces)

3. **Emphasize architectural thinking**:
   - Traditional: Jump to code, figure it out as you go
   - Agentic: Think through architecture first, implement with confidence

#### Phase 3: Tasks (2-3 minutes)

**Show the Process**:

1. **Create TASKS.md** task breakdown:

   ```
   Prompt: "Break down the implementation into sequential tasks.
   Include: setup, models, services, components, integration, testing.
   Show dependencies and suggest execution order."
   ```

2. **Review task organization**:
   - Setup → Models → Service → Components → Integration → Tests
   - Dependencies make execution order clear
   - Parallelization opportunities identified

3. **Key Point**:
   - "Task breakdown prevents 'what do I build next?' paralysis"
   - "Clear sequence ensures steady progress"

#### Phase 4: Implement (8-10 minutes)

**Show the Process** (abbreviated for time):

1. **Show already-initialized project**:

   ```bash
   cd resources/photo-gallery-from-scratch-solution
   ```

2. **Walk through key implementations**:

   **Data Model** (1 min):
   - Open `photo.model.ts`
   - Show Photo interface with JSDoc
   - Point out validation functions

   **PhotoService** (2-3 min):
   - Open `photo.service.ts`
   - Highlight signal-based state: `photos = signal<Photo[]>([])`
   - Show LocalStorage persistence
   - Demonstrate AI-generated error handling

   **PhotoUploadComponent** (2-3 min):
   - Open `photo-upload.component.ts`
   - Show reactive form with validation
   - Demonstrate AI-generated file validation logic
   - Point out error handling and user feedback

   **PhotoListComponent** (1-2 min):
   - Open `photo-list.component.ts`
   - Show signal usage: `photos = this.photoService.photos`
   - Demonstrate tag filtering

3. **Run the application**:

   ```bash
   npx nx serve photo-gallery-from-scratch-solution
   ```

   - Upload a photo
   - Add tags
   - Filter by tag
   - Show it working!

4. **Key Teaching Points**:
   - "AI generated most of this code following our architecture plan"
   - "Because we had clear spec and plan, AI knew exactly what to build"
   - "We reviewed and refined, but AI handled implementation details"

#### Phase 5: Validate (2-3 minutes)

**Show the Process**:

1. **Run tests**:

   ```bash
   npx nx test photo-gallery-from-scratch-solution
   ```

   - Show test results (all passing)
   - Display coverage report (>80%)

2. **Review test file**:
   - Open `photo.service.spec.ts`
   - Show test cases for validation, edge cases, error handling
   - Point out AI generated comprehensive tests

3. **Manual validation**:
   - Check specification requirements one by one
   - "Does it upload photos?" ✓
   - "Does it handle invalid files?" ✓
   - "Does tag filtering work?" ✓
   - "Does data persist?" ✓

4. **Documentation check**:
   - Show project README
   - JSDoc comments throughout code
   - Everything documented

### Contrast: Traditional vs Agentic

**Throughout the demo, create side-by-side comparison**:

| Traditional Approach                  | Agentic Approach                  |
| ------------------------------------- | --------------------------------- |
| Vague idea → Start coding             | Clear spec → Implementation       |
| Figure out architecture as you go     | Architecture planned upfront      |
| "I'll write tests later" (never does) | Tests generated alongside code    |
| Documentation? What documentation?    | Comprehensive docs auto-generated |
| 2-3 days of work                      | 90 minutes with high quality      |

### Key Teaching Points

**Emphasize throughout**:

1. **Each Phase Has Purpose**:
   - Specify: Clarity on WHAT
   - Plan: Decisions on HOW
   - Tasks: Roadmap for execution
   - Implement: Building with confidence
   - Validate: Ensuring quality

2. **Context Enables Quality**:
   - SPECIFICATION.md tells AI what we're building
   - IMPLEMENTATION_PLAN.md tells AI how we're building it
   - AI generates code that matches our architecture

3. **Speed + Quality**:
   - Not "fast and messy" (Vibe Coding)
   - Not "slow and manual" (Traditional)
   - "Fast and systematic" (Agentic)

4. **Developer Control**:
   - You make strategic decisions
   - AI handles implementation details
   - You review and validate everything

### Common Student Questions

**Q: "This seems like a lot of upfront planning. Is it worth it?"**
A: Yes! The planning takes 30 minutes but saves hours of rework. You know exactly what you're building and how, so implementation is straightforward.

**Q: "What if requirements change mid-implementation?"**
A: Update the spec, regenerate affected parts of the plan/tasks, continue. The structured approach makes changes easier, not harder.

**Q: "Can I skip phases for small features?"**
A: For trivial changes, yes. But "small" features often grow. The workflow scales—use it as much as needed.

**Q: "What if AI generates wrong code?"**
A: That's why Validate phase exists! Always review AI outputs. Good context reduces errors, but verification is essential.

**Q: "How does this scale to larger projects?"**
A: Same process, more iterations. Break large projects into features, apply workflow to each feature.

## Solution Artifacts

The `resources/` directory contains:

### Documentation Artifacts

**SPECIFICATION.md**:

- 4 user stories with acceptance criteria
- 15 functional requirements
- Success criteria (measurable)
- Out-of-scope clearly defined

**IMPLEMENTATION_PLAN.md**:

- Tech stack with rationale
- Component architecture diagram
- Data model (Photo, Tag interfaces)
- File structure
- Key technical decisions explained

**TASKS.md** (optional, for reference):

- 20+ tasks organized by phase
- Dependencies identified
- Execution order suggested

### Code Implementation

**Complete working Angular application** in `photo-gallery-from-scratch-solution/`:

**Models** (`src/app/models/`):

- `photo.model.ts`: Photo interface with validation
- `tag.model.ts`: TagStats interface

**Services** (`src/app/services/`):

- `photo.service.ts`: Signal-based state management, LocalStorage persistence
- `photo.service.spec.ts`: Comprehensive unit tests (>80% coverage)

**Components** (`src/app/components/`):

- `photo-upload.component.ts`: File upload with validation, drag-and-drop
- `photo-list.component.ts`: Grid display with tag filtering and detail view

**App Root**:

- `app.component.ts`: Main app wiring all components
- `app.component.html`: Layout template
- `app.component.css`: Styling

### Tests

- Service unit tests with edge cases
- Component tests (optional for demo)
- 80%+ code coverage
- All tests passing

## Evaluation Criteria

When reviewing student submissions:

### Specification Quality

- [ ] User stories are clear and achievable
- [ ] Requirements are specific and testable
- [ ] Acceptance criteria define "done"
- [ ] Success criteria are measurable
- [ ] Out of scope is clearly stated

### Planning Quality

- [ ] Tech stack choices are justified
- [ ] Architecture is well-designed
- [ ] Data model is complete
- [ ] File structure is logical

### Implementation Quality

- [ ] Code follows Angular best practices
- [ ] Components are properly separated
- [ ] State management uses signals
- [ ] Validation is comprehensive
- [ ] Error handling is robust
- [ ] Code has JSDoc documentation

### Test Coverage

- [ ] PhotoService has unit tests
- [ ] Tests cover happy path and errors
- [ ] All tests pass
- [ ] Coverage >80%

### Validation

- [ ] All specification requirements met
- [ ] Application works as specified
- [ ] Edge cases handled
- [ ] Documentation complete

## Extensions and Variations

For advanced students or extended sessions:

1. **Add features**: Photo albums, sharing, advanced filtering
2. **Backend integration**: Replace LocalStorage with API
3. **Accessibility**: Add ARIA labels, keyboard navigation
4. **Performance**: Implement virtual scrolling for large galleries
5. **Testing**: Add E2E tests with Playwright
6. **Deployment**: Deploy to Netlify/Vercel

## Time Management Tips for Trainers

**If running short on time**:

- Skip Task phase walkthrough (show the document, don't detail it)
- Focus on 2-3 key components in Implementation phase
- Pre-run tests, show results without waiting

**If you have extra time**:

- Show AI iteration: First response → Refinement → Final code
- Demonstrate error handling: Upload invalid file, show graceful failure
- Compare with Lab 31 legacy code: Show quality difference

## Additional Resources

- Example specifications for other features
- Architecture decision record templates
- Testing strategy guides
- Deployment checklists

---

**Trainer Reminder**: This lab represents the **ideal agentic workflow**. Not every project will need all phases to this depth, but understanding the complete process helps students apply it appropriately to their real-world work. The goal is teaching **systematic, quality-focused development practices**, not just building a photo gallery.
