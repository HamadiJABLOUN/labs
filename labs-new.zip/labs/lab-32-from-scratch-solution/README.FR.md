# Lab 32 Solution : Construire de zéro avec un workflow agentique complet

> **Public : formateurs.** Ce document contient le script de démonstration live, les repères de
> timing et les critères d'évaluation. Il n'est _pas_ écrit pour les stagiaires.
>
> **Les stagiaires** liront plutôt les artefacts eux-mêmes — ce sont eux le vrai livrable :
> `resources/` pour les documents de cadrage, et les dossiers `*-solution/` pour le code.

**Objectif** : Fournir aux formateurs et aux apprenants un exemple complet d'application des 5 phases du workflow agentique pour construire une nouvelle fonctionnalité, de la spécification à l'implémentation fonctionnelle.

## Vue d'ensemble de la solution

Cette solution démontre le **workflow de coding agentique complet** (Specify → Plan → Tasks → Implement → Validate) appliqué à la construction d'une application de galerie photo de zéro.

## Parcours par langage

Le lab propose trois parcours. Celui en TypeScript construit une interface navigateur ; ceux en
Python et en Java construisent l'**API REST qui est derrière**, contre un même contrat HTTP.

| Parcours                   | Projet solution                                         | Tests                              |
| -------------------------- | ------------------------------------------------------- | ---------------------------------- |
| **TypeScript** (Angular)   | `resources/photo-gallery-from-scratch-solution/`        | Vitest                             |
| **Python** (FastAPI)       | `resources/photo-gallery-from-scratch-python-solution/` | **71, pytest, 98 % de couverture** |
| **Java** (Spring Boot 3.5) | `resources/photo-gallery-from-scratch-java-solution/`   | **47, JUnit 5 + MockMvc**          |

Les artefacts de cadrage, un jeu par parcours :

- TypeScript : `resources/SPECIFICATION.md`, `IMPLEMENTATION_PLAN.md`, `TASKS.md`
- Python : `resources/python/` (les trois mêmes fichiers)
- Java : `resources/java/` (les trois mêmes fichiers)

### Le contrat partagé

Les deux parcours API implémentent les mêmes cinq endpoints et le même payload JSON : un stagiaire
Python et un stagiaire Java peuvent donc comparer directement leurs résultats.

| Méthode  | Chemin             | Succès             | Erreurs |
| -------- | ------------------ | ------------------ | ------- |
| `POST`   | `/api/photos`      | `201` + Photo      | `422`   |
| `GET`    | `/api/photos`      | `200` + Photo[]    | ---     |
| `GET`    | `/api/photos/{id}` | `200` + Photo      | `404`   |
| `DELETE` | `/api/photos/{id}` | `204`              | `404`   |
| `GET`    | `/api/tags`        | `200` + TagStats[] | ---     |

### Une divergence, conservée volontairement

`POST /api/photos` sans partie `file` renvoie **422 en FastAPI** et **400 en Spring**. FastAPI traite
une partie requise manquante comme une validation de requête ; Spring lève
`MissingServletRequestPartException`. Les deux lectures se défendent.

Elle est laissée non alignée délibérément, et c'est le meilleur quart d'heure du débriefing : _la
même spécification, implémentée deux fois, laisse encore filtrer les partis pris du framework sur les
bords_. Un contrat qui veut des codes identiques doit les nommer. Toute violation d'une règle
**métier** renvoie 422 dans les deux cas.

### Deux bugs attrapés par les tests, que la relecture aurait laissés passer

À montrer, car tous deux sont invisibles dans un diff :

1. **Java — `Instant.now()` ne survit pas à l'aller-retour JSON.** Il porte des nanosecondes que la
   forme sérialisée perd : la photo relue n'est donc pas `equal` à celle écrite. L'assertion en échec
   affiche deux horodatages d'apparence identique. Corrigé par une troncature à la milliseconde.
2. **Python — un `204` ne peut pas porter de corps.** Avec `from __future__ import annotations`,
   l'annotation `-> None` est différée en la chaîne `"None"`, que FastAPI résout en modèle de
   réponse. Le démarrage échoue alors sur _« Status code 204 must not have a response body »_ --- une
   erreur qui pointe le code de statut, pas l'annotation. Corrigé par `response_model=None`.

### Lancer les parcours

```bash
# Python
cd resources/photo-gallery-from-scratch-python-solution
python -m venv .venv && .venv/Scripts/activate   # source .venv/bin/activate sous macOS/Linux
pip install -r requirements-dev.txt
pytest                                            # 71 passed, 98 % de couverture
python -m app                                     # http://127.0.0.1:42323/docs

# Java
cd resources/photo-gallery-from-scratch-java-solution
./mvnw test                                       # 47 tests, BUILD SUCCESS
./mvnw spring-boot:run                            # http://localhost:42322
```

Sous Windows, utilisez `mvnw.cmd` au lieu de `./mvnw`.

## Notes de démonstration pour le formateur

### Intégration de la démo live (20-25 minutes)

Lors de la présentation de cette solution, démontrez **les 5 phases du workflow en action** :

#### Phase 1 : Specify (4-5 minutes)

**Montrer le processus** :

1. **Créer SPECIFICATION.md** avec l'aide de l'IA :

   ```
   Prompt: "Help me create a feature specification for a photo gallery with upload,
   tagging, and browsing capabilities. Include: user stories, functional requirements,
   acceptance criteria, success measures, and out-of-scope items."
   ```

2. **Parcourir la spécification** :
   - Mettre en avant 3-4 user stories clés
   - Souligner en quoi les exigences sont précises et testables
   - Montrer comment les critères d'acceptation définissent le « done »

3. **Point pédagogique clé** :
   - « Une spécification claire évite les reprises plus tard »
   - « On définit le QUOI, pas le COMMENT (ça vient en phase Plan) »

#### Phase 2 : Plan (4-5 minutes)

**Montrer le processus** :

1. **Créer IMPLEMENTATION_PLAN.md** :

   ```
   Prompt: "Based on SPECIFICATION.md, help me plan the implementation.
   Include: tech stack selection with rationale, architecture design,
   data model with interfaces, file structure, key technical decisions."
   ```

2. **Discuter les décisions clés** :
   - Pourquoi des composants standalone Angular ?
   - Pourquoi des signals pour la gestion d'état ?
   - Pourquoi LocalStorage (et pas un backend) ?
   - Montrer le modèle de données (interfaces Photo, Tag)

3. **Insister sur la réflexion architecturale** :
   - Traditionnel : on fonce dans le code, on improvise en chemin
   - Agentique : on réfléchit à l'architecture d'abord, on implémente en confiance

#### Phase 3 : Tasks (2-3 minutes)

**Montrer le processus** :

1. **Créer le découpage en tâches TASKS.md** :

   ```
   Prompt: "Break down the implementation into sequential tasks.
   Include: setup, models, services, components, integration, testing.
   Show dependencies and suggest execution order."
   ```

2. **Revoir l'organisation des tâches** :
   - Setup → Modèles → Service → Composants → Intégration → Tests
   - Les dépendances rendent l'ordre d'exécution évident
   - Opportunités de parallélisation identifiées

3. **Point clé** :
   - « Le découpage en tâches évite la paralysie du "je construis quoi ensuite ?" »
   - « Une séquence claire garantit une progression régulière »

#### Phase 4 : Implement (8-10 minutes)

**Montrer le processus** (abrégé par manque de temps) :

1. **Montrer le projet déjà initialisé** :

   ```bash
   cd resources/photo-gallery-from-scratch-solution
   ```

2. **Parcourir les implémentations clés** :

   **Modèle de données** (1 min) :
   - Ouvrir `photo.model.ts`
   - Montrer l'interface Photo avec sa JSDoc
   - Mettre en avant les fonctions de validation

   **PhotoService** (2-3 min) :
   - Ouvrir `photo.service.ts`
   - Souligner l'état basé sur les signals : `photos = signal<Photo[]>([])`
   - Montrer la persistance LocalStorage
   - Démontrer la gestion d'erreur générée par l'IA

   **PhotoUploadComponent** (2-3 min) :
   - Ouvrir `photo-upload.component.ts`
   - Montrer le formulaire réactif avec validation
   - Démontrer la logique de validation de fichier générée par l'IA
   - Mettre en avant la gestion d'erreur et le retour utilisateur

   **PhotoListComponent** (1-2 min) :
   - Ouvrir `photo-list.component.ts`
   - Montrer l'usage des signals : `photos = this.photoService.photos`
   - Démontrer le filtrage par tag

3. **Lancer l'application** :

   ```bash
   npx nx serve photo-gallery-from-scratch-solution
   ```

   - Uploader une photo
   - Ajouter des tags
   - Filtrer par tag
   - Montrer que ça marche !

4. **Points pédagogiques clés** :
   - « L'IA a généré l'essentiel de ce code en suivant notre plan d'architecture »
   - « Comme on avait une spec et un plan clairs, l'IA savait exactement quoi construire »
   - « Nous avons relu et affiné, mais l'IA a géré les détails d'implémentation »

#### Phase 5 : Validate (2-3 minutes)

**Montrer le processus** :

1. **Lancer les tests** :

   ```bash
   npx nx test photo-gallery-from-scratch-solution
   ```

   - Montrer les résultats des tests (tous au vert)
   - Afficher le rapport de couverture (>80 %)

2. **Revoir le fichier de test** :
   - Ouvrir `photo.service.spec.ts`
   - Montrer les cas de test pour la validation, les cas limites, la gestion d'erreur
   - Souligner que l'IA a généré des tests complets

3. **Validation manuelle** :
   - Vérifier les exigences de la spécification une par une
   - « Est-ce que ça uploade les photos ? » ✓
   - « Est-ce que ça gère les fichiers invalides ? » ✓
   - « Est-ce que le filtrage par tag marche ? » ✓
   - « Est-ce que les données persistent ? » ✓

4. **Vérification de la documentation** :
   - Montrer le README du projet
   - Commentaires JSDoc dans tout le code
   - Tout est documenté

### Contraste : traditionnel vs agentique

**Tout au long de la démo, construire une comparaison côte à côte** :

| Approche traditionnelle                   | Approche agentique                   |
| ----------------------------------------- | ------------------------------------ |
| Idée floue → On code                      | Spec claire → Implémentation         |
| Architecture improvisée en chemin         | Architecture planifiée en amont      |
| « Je ferai les tests plus tard » (jamais) | Tests générés en même temps que code |
| De la doc ? Quelle doc ?                  | Doc complète générée automatiquement |
| 2-3 jours de travail                      | 90 minutes avec une haute qualité    |

### Points pédagogiques clés

**À souligner tout du long** :

1. **Chaque phase a un but** :
   - Specify : clarté sur le QUOI
   - Plan : décisions sur le COMMENT
   - Tasks : feuille de route d'exécution
   - Implement : construire en confiance
   - Validate : garantir la qualité

2. **Le contexte permet la qualité** :
   - SPECIFICATION.md dit à l'IA ce qu'on construit
   - IMPLEMENTATION_PLAN.md dit à l'IA comment on le construit
   - L'IA génère du code conforme à notre architecture

3. **Vitesse + qualité** :
   - Ni « rapide et bâclé » (Vibe Coding)
   - Ni « lent et manuel » (traditionnel)
   - « Rapide et systématique » (agentique)

4. **Contrôle du développeur** :
   - Vous prenez les décisions stratégiques
   - L'IA gère les détails d'implémentation
   - Vous relisez et validez tout

### Questions fréquentes des apprenants

**Q : « Ça fait beaucoup de planification en amont. Ça vaut le coup ? »**
R : Oui ! La planification prend 30 minutes mais évite des heures de reprise. Vous savez exactement quoi construire et comment, donc l'implémentation est directe.

**Q : « Et si les exigences changent en cours d'implémentation ? »**
R : Mettez à jour la spec, régénérez les parties impactées du plan/des tâches, continuez. L'approche structurée rend les changements plus faciles, pas plus difficiles.

**Q : « Puis-je sauter des phases pour de petites fonctionnalités ? »**
R : Pour des changements triviaux, oui. Mais les « petites » fonctionnalités grossissent souvent. Le workflow s'adapte — utilisez-en autant que nécessaire.

**Q : « Et si l'IA génère du code faux ? »**
R : C'est exactement pour ça qu'il y a la phase Validate ! Relisez toujours les sorties de l'IA. Un bon contexte réduit les erreurs, mais la vérification reste indispensable.

**Q : « Comment ça passe à l'échelle sur de plus gros projets ? »**
R : Même processus, plus d'itérations. Découpez les gros projets en fonctionnalités, appliquez le workflow à chacune.

## Artefacts de la solution

Le répertoire `resources/` contient :

### Artefacts de documentation

**SPECIFICATION.md** :

- 4 user stories avec critères d'acceptation
- 15 exigences fonctionnelles
- Critères de succès (mesurables)
- Hors-scope clairement défini

**IMPLEMENTATION_PLAN.md** :

- Stack technique avec justification
- Diagramme d'architecture des composants
- Modèle de données (interfaces Photo, Tag)
- Structure de fichiers
- Décisions techniques clés expliquées

**TASKS.md** (optionnel, pour référence) :

- 20+ tâches organisées par phase
- Dépendances identifiées
- Ordre d'exécution suggéré

### Implémentation du code

**Application Angular complète et fonctionnelle** dans `photo-gallery-from-scratch-solution/` :

**Modèles** (`src/app/models/`) :

- `photo.model.ts` : interface Photo avec validation
- `tag.model.ts` : interface TagStats

**Services** (`src/app/services/`) :

- `photo.service.ts` : gestion d'état à base de signals, persistance LocalStorage
- `photo.service.spec.ts` : tests unitaires complets (>80 % de couverture)

**Composants** (`src/app/components/`) :

- `photo-upload.component.ts` : upload de fichier avec validation, glisser-déposer
- `photo-list.component.ts` : affichage en grille avec filtrage par tag et vue détail

**Racine de l'app** :

- `app.component.ts` : app principale câblant tous les composants
- `app.component.html` : template de layout
- `app.component.css` : styles

### Tests

- Tests unitaires du service avec cas limites
- Tests de composants (optionnels pour la démo)
- 80 %+ de couverture de code
- Tous les tests passent

## Critères d'évaluation

Pour relire les rendus des apprenants :

### Qualité de la spécification

- [ ] Les user stories sont claires et réalisables
- [ ] Les exigences sont précises et testables
- [ ] Les critères d'acceptation définissent le « done »
- [ ] Les critères de succès sont mesurables
- [ ] Le hors-scope est clairement énoncé

### Qualité de la planification

- [ ] Les choix de stack technique sont justifiés
- [ ] L'architecture est bien conçue
- [ ] Le modèle de données est complet
- [ ] La structure de fichiers est logique

### Qualité de l'implémentation

- [ ] Le code suit les bonnes pratiques Angular
- [ ] Les composants sont correctement séparés
- [ ] La gestion d'état utilise les signals
- [ ] La validation est complète
- [ ] La gestion d'erreur est robuste
- [ ] Le code a une documentation JSDoc

### Couverture de tests

- [ ] PhotoService a des tests unitaires
- [ ] Les tests couvrent le cas nominal et les erreurs
- [ ] Tous les tests passent
- [ ] Couverture >80 %

### Validation

- [ ] Toutes les exigences de la spécification sont satisfaites
- [ ] L'application fonctionne comme spécifié
- [ ] Les cas limites sont gérés
- [ ] La documentation est complète

## Extensions et variantes

Pour les apprenants avancés ou les sessions rallongées :

1. **Ajouter des fonctionnalités** : albums photo, partage, filtrage avancé
2. **Intégration backend** : remplacer LocalStorage par une API
3. **Accessibilité** : ajouter des labels ARIA, la navigation au clavier
4. **Performance** : mettre en place le virtual scrolling pour les grandes galeries
5. **Tests** : ajouter des tests E2E avec Playwright
6. **Déploiement** : déployer sur Netlify/Vercel

## Conseils de gestion du temps pour les formateurs

**Si le temps manque** :

- Sauter le parcours de la phase Tasks (montrer le document sans le détailler)
- Se concentrer sur 2-3 composants clés en phase Implement
- Lancer les tests à l'avance, montrer les résultats sans attendre

**Si vous avez du temps en plus** :

- Montrer l'itération avec l'IA : première réponse → affinage → code final
- Démontrer la gestion d'erreur : uploader un fichier invalide, montrer l'échec propre
- Comparer avec le code legacy du Lab 31 : montrer la différence de qualité

## Ressources complémentaires

- Exemples de spécifications pour d'autres fonctionnalités
- Templates d'architecture decision record
- Guides de stratégie de test
- Checklists de déploiement

---

**Rappel formateur** : Ce lab représente le **workflow agentique idéal**. Tous les projets n'auront pas besoin de toutes les phases à ce niveau de détail, mais comprendre le processus complet aide les apprenants à l'appliquer à bon escient dans leur travail réel. Le but est d'enseigner des **pratiques de développement systématiques et centrées sur la qualité**, pas seulement de construire une galerie photo.
