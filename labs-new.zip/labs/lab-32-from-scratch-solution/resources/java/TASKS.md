# Task Breakdown — Photo Gallery API (Java / Spring Boot)

> Java variant of [`../TASKS.md`](../TASKS.md).
> Derived from [`SPECIFICATION.md`](SPECIFICATION.md) and [`IMPLEMENTATION_PLAN.md`](IMPLEMENTATION_PLAN.md).

**MVP** = the five endpoints working, validated, and tested. Everything marked _nice-to-have_ can be
dropped if the timebox runs out without making the deliverable incomplete.

---

## Phase 0 — Setup

| #   | Task                                                                      | MVP | Depends on | Parallel? |
| --- | ------------------------------------------------------------------------- | --- | ---------- | --------- |
| T1  | Generate the project (Spring Initializr or by hand), Java 17, web starter | ✅  | —          | —         |
| T2  | `application.properties`: port, multipart limits, `gallery.*` keys        | ✅  | T1         | —         |

> **Bootstrap** — either use [start.spring.io](https://start.spring.io) with _Spring Web_, or copy
> the `pom.xml` from the reference solution. Only `spring-boot-starter-web` and
> `spring-boot-starter-test` are needed.

## Phase 1 — Configuration and model

| #   | Task                                                             | MVP | Depends on | Parallel?  |
| --- | ---------------------------------------------------------------- | --- | ---------- | ---------- |
| T3  | `GalleryProperties` record + `@EnableConfigurationProperties`    | ✅  | T2         | —          |
| T4  | `Photo` record with validation in the compact constructor        | ✅  | T3         | —          |
| T5  | `Photo.parseTags()`: split, trim, lowercase, de-duplicate, bound | ✅  | T3         | with T4    |
| T6  | `TagStats`, `InvalidPhotoException`, `PhotoNotFoundException`    | ✅  | T1         | with T4/T5 |
| T7  | Tests for T4–T6                                                  | ✅  | T4, T5, T6 | —          |

> `@JsonCreator` on the constructor is what makes Jackson go through the validation instead of
> around it. Without it, deserialisation would build invalid records straight from disk.

## Phase 2 — Persistence

| #   | Task                                                                         | MVP | Depends on | Parallel? |
| --- | ---------------------------------------------------------------------------- | --- | ---------- | --------- |
| T8  | `PhotoRepository.findAll()` — read into `List<JsonNode>`, convert one by one | ✅  | T4         | —         |
| T9  | `PhotoRepository.saveAll()` — atomic: temp file + `Files.move`               | ✅  | T4         | —         |
| T10 | `deleteAll()`, plus the package-private `Path` constructor as a test seam    | ✅  | T9         | —         |
| T11 | Tests for T8–T10, including a deliberately corrupted file                    | ✅  | T8, T9     | —         |

> **T8 is subtler than it looks.** Deserialising straight into `List<Photo>` means one malformed
> record throws and the whole gallery disappears. Going through `JsonNode` and converting each
> element individually is what turns "lost everything" into "skipped one line".
>
> **T9 is the task with the highest value-per-line in the whole lab.** Writing straight onto the
> target file works in every manual test and loses the gallery the first time a write is interrupted.
>
> ⚠️ **T10 will bite you.** Adding the second constructor makes Spring fail at startup with
> _"No default constructor found"_, which points nowhere near the real cause. Annotate the
> `GalleryProperties` constructor with `@Autowired`.

## Phase 3 — Business logic

| #   | Task                                                  | MVP | Depends on | Parallel? |
| --- | ----------------------------------------------------- | --- | ---------- | --------- |
| T12 | `PhotoService.addPhoto()` — the five validation rules | ✅  | T8, T9     | —         |
| T13 | `PhotoService.listPhotos(tag)` — sort, then filter    | ✅  | T8         | with T12  |
| T14 | `getPhoto()` / `deletePhoto()`                        | ✅  | T8, T9     | with T13  |
| T15 | `tagStats()` — count, sort by count desc, break ties  | ✅  | T8         | with T13  |
| T16 | Tests for T12–T15                                     | ✅  | T12–T15    | —         |

> ⚠️ **T12 hides a bug you will only find with a test.** `Instant.now()` carries nanoseconds that the
> JSON round-trip drops, so the photo you read back is not `equal` to the one you wrote — and
> `assertThat(listPhotos()).containsExactly(photo)` fails with two timestamps that look identical in
> the output. Truncate to milliseconds at creation.

## Phase 4 — HTTP layer

| #   | Task                                                                     | MVP | Depends on | Parallel? |
| --- | ------------------------------------------------------------------------ | --- | ---------- | --------- |
| T17 | `PhotoController` skeleton, `@RestController`, `@RequestMapping("/api")` | ✅  | T12–T15    | —         |
| T18 | `POST /api/photos` — multipart in, `201` out                             | ✅  | T17        | —         |
| T19 | `GET /api/photos` with the optional `?tag=` filter                       | ✅  | T17        | with T18  |
| T20 | `GET /api/photos/{id}` and `DELETE /api/photos/{id}`                     | ✅  | T17        | with T18  |
| T21 | `GET /api/tags`                                                          | ✅  | T17        | with T18  |
| T22 | `ApiExceptionHandler`: `422` and `404` as `ProblemDetail`                | ✅  | T18–T21    | —         |
| T23 | `@SpringBootTest` + MockMvc covering the whole contract                  | ✅  | T18–T22    | —         |

> T22 is what lets the controller stay free of try/catch. Write it before T23, or the contract tests
> will assert `500` everywhere and you will chase the wrong problem.
>
> In T23, use `@DynamicPropertySource` to point `gallery.storage-path` at a `@TempDir`. Without it
> the test suite writes into the project directory and the tests become order-dependent.

## Phase 5 — Validation and documentation

| #   | Task                                                   | MVP | Depends on | Parallel? |
| --- | ------------------------------------------------------ | --- | ---------- | --------- |
| T24 | Check every acceptance criterion has a test            | ✅  | T23        | —         |
| T25 | Build with `-Xlint:all`; confirm no unchecked warnings | ✅  | T23        | with T24  |
| T26 | `README.md`: setup, run, test, endpoint table          | ✅  | T23        | with T24  |
| T27 | Javadoc on every public class and method               | ✅  | T22        | with T26  |
| T28 | Add `springdoc-openapi` for a generated schema         | ⬜  | T23        | —         |

## Critical path

```
T1 → T2 → T3 → T4 → T8/T9 → T12 → T17 → T18 → T22 → T23 → T24
```

Everything else hangs off that spine. Two people can work in parallel from T4 onwards; three from
T12 onwards, when the four service methods split cleanly.

## Definition of done

1. `./mvnw test` is green
2. Every acceptance criterion in `SPECIFICATION.md` maps to at least one test
3. Every public class and method carries Javadoc
4. The build emits no unchecked warnings
5. The JSON payload matches the Python variant

## Actual outcome

The reference implementation follows this breakdown: **47 tests, BUILD SUCCESS**, all five endpoints
live. Thirty-two of the tests run without booting a Spring context.
