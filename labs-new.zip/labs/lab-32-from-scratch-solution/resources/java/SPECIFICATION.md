# Photo Gallery API — Specification (Java / Spring Boot)

> Java variant of [`../SPECIFICATION.md`](../SPECIFICATION.md).
> Reference implementation: [`../photo-gallery-from-scratch-java-solution/`](../photo-gallery-from-scratch-java-solution/).

**Version**: 1.0 · **Status**: Implemented

---

## 1. Purpose and Scope

### 1.1 Purpose

Build a photo gallery **REST API**: upload photos, tag them, browse and filter by tag, fetch one, and
delete. The TypeScript variant of this lab builds a browser UI; this one builds the service behind it.

### 1.2 Why an API rather than a UI

The lab teaches the Specify → Plan → Tasks → Implement → Validate cycle. That cycle is easier to
_verify_ on an API: every acceptance criterion below maps onto one HTTP request and one assertion.
A UI needs a rendering harness before you can assert anything.

### 1.3 Scope

**In scope**

- Upload a photo with optional tags
- List photos, newest first, optionally filtered by one tag
- Fetch a single photo by id
- Delete a photo
- List every tag in use with its photo count
- File-based persistence surviving a restart
- Validation, with error responses that say what went wrong

**Out of scope**

- Any user interface
- Authentication, authorisation, multi-user support
- A database or JPA, thumbnailing, image processing
- Pagination, search beyond a single tag filter
- Deployment and containerisation

## 2. User Stories

| #   | As a…      | I want to…                      | So that…                                        |
| --- | ---------- | ------------------------------- | ----------------------------------------------- |
| US1 | API client | upload an image with tags       | the gallery grows with searchable metadata      |
| US2 | API client | list photos filtered by one tag | I can show a themed subset without fetching all |
| US3 | API client | fetch one photo by id           | I can render a detail view                      |
| US4 | API client | delete a photo                  | the gallery does not fill with mistakes         |
| US5 | API client | read tag counts                 | I can build a filter sidebar without scanning   |

## 3. The HTTP contract

This contract is **shared with the Python variant**. Both implementations satisfy it, which is what
makes the two tracks comparable in the debrief.

| Method   | Path               | Request                            | Success            | Errors |
| -------- | ------------------ | ---------------------------------- | ------------------ | ------ |
| `POST`   | `/api/photos`      | multipart: `file`, optional `tags` | `201` + Photo      | `422`  |
| `GET`    | `/api/photos`      | optional `?tag=`                   | `200` + Photo[]    | —      |
| `GET`    | `/api/photos/{id}` | —                                  | `200` + Photo      | `404`  |
| `DELETE` | `/api/photos/{id}` | —                                  | `204` no body      | `404`  |
| `GET`    | `/api/tags`        | —                                  | `200` + TagStats[] | —      |

### 3.1 Payloads

```jsonc
// Photo
{
  "id": "3f9a…",                       // hex, server-assigned
  "filename": "holiday.png",
  "dataUrl": "data:image/png;base64,…",
  "uploadedAt": "2026-09-23T10:55:58.702Z",
  "size": 4096,                        // bytes, decoded
  "tags": ["beach", "summer"]
}

// TagStats
{ "name": "beach", "count": 2 }
```

Errors use RFC 9457 `ProblemDetail`, which Spring serialises natively:

```jsonc
{ "type": "about:blank", "title": "Invalid photo", "status": 422, "detail": "unsupported file type: application/pdf", "timestamp": "…" }
```

## 4. Functional Requirements

### FR-001 — Upload a photo

| Criterion | Expected                                                                 |
| --------- | ------------------------------------------------------------------------ |
| AC-1      | A valid PNG/JPEG/GIF/WebP under 2 MiB returns `201` and the stored Photo |
| AC-2      | `id` is server-assigned and unique across uploads                        |
| AC-3      | `dataUrl` starts with `data:<mime>;base64,`                              |
| AC-4      | `size` is the decoded byte count, not the base64 length                  |
| AC-5      | An empty upload returns `422` mentioning "no file"                       |
| AC-6      | A file over 2 MiB returns `422` naming the limit                         |
| AC-7      | An unsupported MIME type returns `422` naming the type                   |
| AC-8      | A blank filename returns `422`                                           |
| AC-9      | A rejected upload leaves the gallery byte-for-byte unchanged             |

### FR-002 — Tag management

| Criterion | Expected                                          |
| --------- | ------------------------------------------------- |
| AC-1      | `tags` is split on commas, trimmed, lowercased    |
| AC-2      | Duplicates collapse; insertion order is preserved |
| AC-3      | Empty segments (`"a,,b"`) are dropped             |
| AC-4      | A tag over 32 characters returns `422`            |
| AC-5      | More than 10 tags returns `422`                   |
| AC-6      | Omitting `tags` yields `[]`, not an error         |

### FR-003 — List photos

| Criterion | Expected                                           |
| --------- | -------------------------------------------------- |
| AC-1      | Returns `200` and `[]` on an empty gallery         |
| AC-2      | Photos are ordered by `uploadedAt`, newest first   |
| AC-3      | `?tag=beach` returns only photos carrying that tag |
| AC-4      | The tag filter is case-insensitive                 |
| AC-5      | An unknown tag returns `[]`, not `404`             |

### FR-004 — Fetch and delete

| Criterion | Expected                                               |
| --------- | ------------------------------------------------------ |
| AC-1      | `GET /api/photos/{id}` returns the photo unchanged     |
| AC-2      | An unknown id returns `404` on both `GET` and `DELETE` |
| AC-3      | `DELETE` returns `204` with no body                    |
| AC-4      | Deleting one photo leaves every other photo intact     |

### FR-005 — Tag statistics

| Criterion | Expected                                                  |
| --------- | --------------------------------------------------------- |
| AC-1      | Returns every tag in use with its photo count             |
| AC-2      | Ordered by count descending                               |
| AC-3      | Ties break alphabetically, so the output is deterministic |
| AC-4      | Returns `[]` on an empty gallery                          |

### FR-006 — Persistence

| Criterion | Expected                                                               |
| --------- | ---------------------------------------------------------------------- |
| AC-1      | The gallery survives a process restart                                 |
| AC-2      | Writes are atomic: an interrupted write never truncates the gallery    |
| AC-3      | A corrupt file yields an empty gallery and a logged error, not a crash |
| AC-4      | One malformed record is skipped; the valid records still load          |

## 5. Non-Functional Requirements

| #     | Requirement                                                                 |
| ----- | --------------------------------------------------------------------------- |
| NFR-1 | Every public class and method carries Javadoc                               |
| NFR-2 | Storage path, size limit, allowed types and tag bounds are configurable     |
| NFR-3 | Test coverage above 80%                                                     |
| NFR-4 | No raw types; the build emits no unchecked warnings                         |
| NFR-5 | An invalid `Photo` cannot exist: validation lives in the record constructor |
| NFR-6 | The controller contains no try/catch for domain errors                      |

## 6. Success Criteria

- [x] Every acceptance criterion above has at least one test — **47 tests**
- [x] `./mvnw test` is green — **BUILD SUCCESS**
- [x] The API starts with `./mvnw spring-boot:run` and answers on port 42322
- [x] The JSON payload is identical to the Python variant
- [x] No raw types, no unchecked warnings

## 7. Known divergence from the Python variant

One case differs, and it is a framework default rather than a design choice:

| Case                                   | Java (Spring) | Python (FastAPI) |
| -------------------------------------- | ------------- | ---------------- |
| `POST /api/photos` with no `file` part | `400`         | `422`            |

Spring raises `MissingServletRequestPartException`, which maps to `400`; FastAPI treats a missing
required part as a request-validation failure (`422`). Both are defensible readings of a malformed
request. It is left as-is deliberately: **it is worth showing trainees that "same spec, two stacks"
still leaks framework opinions at the edges**, and that a contract has to name the codes explicitly
if it wants them identical.

Every _domain_ rule violation returns `422` in both.

## 8. Out of Scope

- Concurrency safety beyond atomic replacement. The read-modify-write race remains; closing it
  properly means a lock or a database, and that is a different decision.
- Streaming uploads. Files are read fully into memory, which is why the size limit matters.
- Bean Validation annotations. Validation lives in the record constructor instead, so an invalid
  `Photo` cannot exist anywhere in the system, not only at the HTTP edge.
- Rate limiting, caching, ETags.
