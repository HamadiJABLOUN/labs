# Implementation Plan — Photo Gallery API (Java / Spring Boot)

> Java variant of [`../IMPLEMENTATION_PLAN.md`](../IMPLEMENTATION_PLAN.md).
> Derived from [`SPECIFICATION.md`](SPECIFICATION.md).

---

## 1. Stack, and why

| Concern     | Choice                       | Why this one                                                                        |
| ----------- | ---------------------------- | ----------------------------------------------------------------------------------- |
| Framework   | Spring Boot 3.5.16, Java 17  | Matches the Java track in modules 4 and 6, so trainees reuse what they already know |
| Web         | `spring-boot-starter-web`    | MVC plus Jackson; nothing else needed for five endpoints                            |
| Validation  | The record's own constructor | An invalid `Photo` cannot be constructed anywhere, not only at the HTTP edge        |
| Errors      | `ProblemDetail` (RFC 9457)   | Built into Spring 6; no bespoke error DTO to invent and document                    |
| Persistence | JSON file via Jackson        | Matches the TypeScript variant's LocalStorage: nothing to install                   |
| Tests       | JUnit 5 + AssertJ + MockMvc  | `@TempDir` gives each test its own directory, so the suite is order-independent     |

**Rejected**: Bean Validation (`@NotBlank` and friends) — it validates the _request_, not the domain,
so a `Photo` built anywhere else would skip it. JPA plus a database (an ORM and a migration system
for a 300-line service). Lombok (the records already remove the boilerplate it would).

## 2. Architecture

Four layers, each depending only on the one below it:

```
   web/        HTTP only: parse, delegate. No try/catch for domain errors
     │
  service/     Business rules: what may enter the gallery, in what order it comes out
     │
 repository/   Persistence: atomic writes, tolerant reads
     │
   model/      Domain types: a Photo that exists is a Photo that validated
```

`config/GalleryProperties` sits beside all four. Nothing imports upward.

### Why this split matters here

The single most common failure in this lab is putting validation in the controller. It works, and
then the rules are unreachable from anywhere except an HTTP request — which means every test has to
boot a Spring context. Keeping the rules in `PhotoService` is what lets 37 of the 47 tests run
without one, in under a second instead of ten.

## 3. Data model

```java
public record Photo(
        String id,          // UUID hex, server-assigned
        String filename,
        String dataUrl,
        Instant uploadedAt,
        long size,          // decoded bytes, > 0
        List<String> tags) { }
```

Three decisions worth defending:

- **A record, not a class.** Immutability, `equals`, `hashCode` and `toString` come free, and the
  compact constructor gives one place to validate.
- **Validation in the constructor.** `new Photo(...)` with a blank filename throws. There is no path
  into the system that skips it — not deserialisation, not a test fixture, not a future caller.
- **`List.copyOf(tags)`.** Returns an unmodifiable list _and_ rejects nulls inside it. A record with
  a mutable field is only half immutable.

`TagStats` is a plain `{name, count}` record, computed on read rather than stored — there is no
second source of truth to keep in sync.

## 4. File structure

```
photo-gallery-from-scratch-java-solution/
├── pom.xml, mvnw, mvnw.cmd
└── src/
    ├── main/java/com/sfeir/photogallery/
    │   ├── PhotoGalleryApplication.java   bootstrap only
    │   ├── config/GalleryProperties.java  @ConfigurationProperties, gallery.*
    │   ├── model/Photo.java               record + parseTags()
    │   ├── model/TagStats.java
    │   ├── model/InvalidPhotoException.java
    │   ├── model/PhotoNotFoundException.java
    │   ├── repository/PhotoRepository.java
    │   ├── service/PhotoService.java
    │   ├── web/PhotoController.java
    │   └── web/ApiExceptionHandler.java
    ├── main/resources/application.properties
    └── test/java/com/sfeir/photogallery/…
```

## 5. Technical decisions

### 5.1 Configuration, not constants

`GalleryProperties` is a record bound to the `gallery.*` keys. Nothing in the business logic holds a
literal. Tests override `gallery.storage-path` through `@DynamicPropertySource`, which is what lets
the controller test run against a `@TempDir` instead of the developer's working directory.

### 5.2 A test seam on the repository

`PhotoRepository` has two constructors: the public one taking `GalleryProperties`, and a
package-private one taking a `Path` so a unit test can point at a temporary directory without a
Spring context.

> ⚠️ **Spring cannot choose between two constructors.** Without `@Autowired` on the production one,
> startup fails with a misleading _"No default constructor found"_. This is the same trap as in
> lab 31; it is worth hitting once deliberately.

### 5.3 Atomic writes

`saveAll()` writes to a temporary file **in the same directory** and then `Files.move(…,
REPLACE_EXISTING)`. Creating the temp file elsewhere would cross a filesystem boundary and lose
atomicity. An interrupted write leaves the previous gallery intact.

### 5.4 Tolerant reads

`findAll()` deserialises into `List<JsonNode>` first, then converts each node to a `Photo`
individually. A record that fails validation is logged and skipped rather than failing the whole
read. Deserialising straight into `List<Photo>` would make one bad entry lose the entire gallery.

The trade-off is that a corrupt file looks like an empty one, and the next write will overwrite it.
Acceptable for a lab artefact and explicitly noted; a production service would move the bad file
aside instead.

### 5.5 Errors at the edge, via `@RestControllerAdvice`

`InvalidPhotoException` and `PhotoNotFoundException` are raised where they are detected.
`ApiExceptionHandler` maps them to `422` and `404` as `ProblemDetail`. The controller therefore holds
no try/catch for domain errors, and the service knows nothing about HTTP.

### 5.6 Timestamps truncated to milliseconds

`Instant.now()` carries nanoseconds that the JSON round-trip does not preserve, so a photo read back
from disk would not `equal` the one written. Truncating at creation makes persistence lossless and
equality stable. **This was found by a failing test, not by review** — the same bug exists in the
lab 31 solution and is fixed the same way.

## 6. Test strategy

| Layer      | Tests | What it proves                                      |
| ---------- | ----- | --------------------------------------------------- |
| repository | 10    | Round-trips, survives corruption, writes atomically |
| service    | 22    | Every business rule, without a Spring context       |
| web        | 15    | Status codes, payload shape, the contract itself    |

Total: **47**. Thirty-two of those (repository + service) run without booting Spring.

Every acceptance criterion in the specification maps to at least one test. `@TempDir` gives each
test its own directory, so the suite is order-independent.

## 7. Known limits

- **Concurrency**: read-modify-write is not locked. Two simultaneous uploads can lose one. Fixing it
  properly means a lock or a database — out of scope, and stated in the spec.
- **Memory**: uploads are read whole. The 2 MiB limit is what keeps that safe.
- **No OpenAPI schema**: unlike the FastAPI variant, nothing generates one. Adding `springdoc-openapi`
  would close the gap; it is left out to keep the dependency list to a single starter.
