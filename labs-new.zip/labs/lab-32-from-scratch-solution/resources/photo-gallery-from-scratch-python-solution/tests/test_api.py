"""Tests for the HTTP layer."""

from __future__ import annotations

from app.config import MAX_FILE_SIZE
from tests.conftest import PNG_BYTES, upload


class TestUpload:
    def test_returns_201_and_the_created_photo(self, client):
        response = upload(client)
        assert response.status_code == 201

        body = response.json()
        assert body["filename"] == "holiday.png"
        assert body["tags"] == ["beach", "summer"]
        assert body["size"] == len(PNG_BYTES)
        assert body["dataUrl"].startswith("data:image/png;base64,")

    def test_uses_camel_case_in_the_payload(self, client):
        body = upload(client).json()
        assert set(body) == {"id", "filename", "dataUrl", "uploadedAt", "size", "tags"}

    def test_rejects_an_oversized_file(self, client):
        response = upload(client, content=b"x" * (MAX_FILE_SIZE + 1))
        assert response.status_code == 422
        assert "maximum" in response.json()["detail"]

    def test_rejects_an_unsupported_type(self, client):
        response = upload(client, filename="doc.pdf", content_type="application/pdf")
        assert response.status_code == 422
        assert "unsupported" in response.json()["detail"]

    def test_rejects_an_over_long_tag(self, client):
        assert upload(client, tags="x" * 33).status_code == 422

    def test_accepts_an_upload_with_no_tags(self, client):
        response = upload(client, tags=None)
        assert response.status_code == 201
        assert response.json()["tags"] == []

    def test_requires_the_file_part(self, client):
        assert client.post("/api/photos", data={"tags": "beach"}).status_code == 422


class TestListPhotos:
    def test_is_empty_to_begin_with(self, client):
        response = client.get("/api/photos")
        assert response.status_code == 200
        assert response.json() == []

    def test_returns_newest_first(self, client):
        upload(client, filename="first.png")
        upload(client, filename="second.png")
        assert [p["filename"] for p in client.get("/api/photos").json()] == [
            "second.png",
            "first.png",
        ]

    def test_filters_by_tag(self, client):
        upload(client, filename="beach.png", tags="beach")
        upload(client, filename="city.png", tags="city")

        response = client.get("/api/photos", params={"tag": "beach"})

        assert [p["filename"] for p in response.json()] == ["beach.png"]

    def test_an_unknown_tag_returns_an_empty_list(self, client):
        upload(client, tags="beach")
        assert client.get("/api/photos", params={"tag": "mountains"}).json() == []


class TestGetPhoto:
    def test_returns_the_photo(self, client):
        created = upload(client).json()
        response = client.get(f"/api/photos/{created['id']}")
        assert response.status_code == 200
        assert response.json() == created

    def test_returns_404_for_an_unknown_id(self, client):
        assert client.get("/api/photos/nope").status_code == 404


class TestDeletePhoto:
    def test_returns_204_and_removes_the_photo(self, client):
        created = upload(client).json()

        assert client.delete(f"/api/photos/{created['id']}").status_code == 204
        assert client.get("/api/photos").json() == []

    def test_returns_404_for_an_unknown_id(self, client):
        assert client.delete("/api/photos/nope").status_code == 404

    def test_leaves_the_other_photos_alone(self, client):
        keep = upload(client, filename="keep.png").json()
        drop = upload(client, filename="drop.png").json()

        client.delete(f"/api/photos/{drop['id']}")

        assert [p["filename"] for p in client.get("/api/photos").json()] == [keep["filename"]]


class TestTags:
    def test_is_empty_to_begin_with(self, client):
        assert client.get("/api/tags").json() == []

    def test_counts_each_tag_most_used_first(self, client):
        upload(client, tags="beach, summer")
        upload(client, tags="beach")

        assert client.get("/api/tags").json() == [
            {"name": "beach", "count": 2},
            {"name": "summer", "count": 1},
        ]


class TestPersistence:
    def test_the_gallery_survives_a_new_client(self, storage_path, client):
        upload(client, filename="kept.png")

        from app.main import create_app
        from fastapi.testclient import TestClient

        fresh = TestClient(create_app(storage_path=storage_path))

        assert [p["filename"] for p in fresh.get("/api/photos").json()] == ["kept.png"]


class TestOpenApi:
    def test_the_schema_is_served(self, client):
        response = client.get("/openapi.json")
        assert response.status_code == 200
        assert "/api/photos" in response.json()["paths"]
