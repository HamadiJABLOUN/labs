"""Tests for the business layer."""

from __future__ import annotations

import pytest

from app.config import MAX_FILE_SIZE
from app.models import InvalidPhotoError
from app.service import PhotoNotFoundError
from tests.conftest import PNG_BYTES


def add(service, **overrides):
    payload = dict(
        content=PNG_BYTES, filename="holiday.png", content_type="image/png", tags="beach"
    )
    payload.update(overrides)
    return service.add_photo(**payload)


class TestAddPhoto:
    def test_stores_a_valid_upload(self, service):
        photo = add(service)
        assert photo.filename == "holiday.png"
        assert photo.tags == ("beach",)
        assert photo.size == len(PNG_BYTES)
        assert service.list_photos() == [photo]

    def test_assigns_a_unique_id(self, service):
        assert add(service).id != add(service).id

    def test_encodes_as_a_data_url(self, service):
        assert add(service).data_url.startswith("data:image/png;base64,")

    @pytest.mark.parametrize(
        "overrides,message",
        [
            ({"content": b""}, "no file"),
            ({"content": b"x" * (MAX_FILE_SIZE + 1)}, "maximum"),
            ({"content_type": "application/pdf"}, "unsupported"),
            ({"filename": "   "}, "filename"),
            ({"tags": "x" * 33}, "exceeds"),
        ],
    )
    def test_rejects_invalid_uploads(self, service, overrides, message):
        with pytest.raises(InvalidPhotoError, match=message):
            add(service, **overrides)

    def test_a_rejected_upload_leaves_the_gallery_untouched(self, service):
        add(service)
        with pytest.raises(InvalidPhotoError):
            add(service, content_type="application/pdf")
        assert len(service.list_photos()) == 1


class TestListPhotos:
    def test_is_empty_to_begin_with(self, service):
        assert service.list_photos() == []

    def test_returns_newest_first(self, service):
        first = add(service, filename="first.png")
        second = add(service, filename="second.png")
        assert [p.filename for p in service.list_photos()] == [second.filename, first.filename]

    def test_filters_by_tag(self, service):
        add(service, filename="beach.png", tags="beach")
        add(service, filename="city.png", tags="city")
        assert [p.filename for p in service.list_photos("beach")] == ["beach.png"]

    def test_tag_filter_is_case_insensitive(self, service):
        add(service, filename="beach.png", tags="Beach")
        assert len(service.list_photos("BEACH")) == 1

    def test_an_unknown_tag_matches_nothing(self, service):
        add(service, tags="beach")
        assert service.list_photos("mountains") == []


class TestGetPhoto:
    def test_returns_the_photo(self, service):
        photo = add(service)
        assert service.get_photo(photo.id) == photo

    def test_raises_on_an_unknown_id(self, service):
        with pytest.raises(PhotoNotFoundError):
            service.get_photo("nope")


class TestDeletePhoto:
    def test_removes_an_existing_photo(self, service):
        photo = add(service)
        service.delete_photo(photo.id)
        assert service.list_photos() == []

    def test_raises_on_an_unknown_id(self, service):
        with pytest.raises(PhotoNotFoundError):
            service.delete_photo("nope")

    def test_leaves_the_other_photos_alone(self, service):
        keep = add(service, filename="keep.png")
        drop = add(service, filename="drop.png")
        service.delete_photo(drop.id)
        assert [p.filename for p in service.list_photos()] == [keep.filename]


class TestTagStats:
    def test_is_empty_to_begin_with(self, service):
        assert service.tag_stats() == []

    def test_counts_each_tag(self, service):
        add(service, tags="beach, summer")
        add(service, tags="beach")
        assert [(t.name, t.count) for t in service.tag_stats()] == [("beach", 2), ("summer", 1)]

    def test_breaks_ties_alphabetically(self, service):
        add(service, tags="zebra, alpha")
        assert [t.name for t in service.tag_stats()] == ["alpha", "zebra"]
