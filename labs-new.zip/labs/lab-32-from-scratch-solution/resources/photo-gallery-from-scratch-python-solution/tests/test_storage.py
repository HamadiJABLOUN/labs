"""Tests for the persistence layer."""

from __future__ import annotations

import json

from app.storage import PhotoRepository
from tests.conftest import make_photo


class TestLoad:
    def test_missing_file_is_an_empty_gallery(self, repository):
        assert repository.load() == []

    def test_reads_back_what_was_written(self, repository):
        photo = make_photo()
        repository.save([photo])
        assert repository.load() == [photo]

    def test_corrupt_json_does_not_raise(self, repository, storage_path):
        storage_path.write_text("{ not json", encoding="utf-8")
        assert repository.load() == []

    def test_a_non_list_payload_does_not_raise(self, repository, storage_path):
        storage_path.write_text('{"id": "x"}', encoding="utf-8")
        assert repository.load() == []

    def test_one_bad_record_does_not_hide_the_good_ones(self, repository, storage_path):
        good = make_photo(id="good")
        storage_path.write_text(
            json.dumps([good.model_dump(mode="json", by_alias=True), {"id": "broken"}]),
            encoding="utf-8",
        )
        assert [photo.id for photo in repository.load()] == ["good"]


class TestSave:
    def test_creates_parent_directories(self, tmp_path):
        nested = PhotoRepository(tmp_path / "deep" / "nested" / "photos.json")
        nested.save([make_photo()])
        assert nested.path.exists()

    def test_leaves_no_temporary_files_behind(self, repository, storage_path):
        repository.save([make_photo()])
        assert list(storage_path.parent.glob(".photos-*")) == []

    def test_replaces_the_previous_content(self, repository):
        repository.save([make_photo(id="first")])
        repository.save([make_photo(id="second")])
        assert [p.id for p in repository.load()] == ["second"]


class TestClear:
    def test_removes_the_file(self, repository):
        repository.save([make_photo()])
        repository.clear()
        assert repository.load() == []

    def test_is_safe_when_nothing_was_stored(self, repository):
        repository.clear()
