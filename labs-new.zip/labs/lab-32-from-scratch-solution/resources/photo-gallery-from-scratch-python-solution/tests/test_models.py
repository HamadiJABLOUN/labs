"""Tests for the domain models and tag parsing."""

from __future__ import annotations

from datetime import datetime

import pytest
from pydantic import ValidationError

from app.models import InvalidPhotoError, Photo, parse_tags
from tests.conftest import make_photo


class TestPhotoValidation:
    def test_accepts_a_well_formed_photo(self):
        photo = make_photo()
        assert photo.filename == "holiday.png"
        assert photo.tags == ("beach", "summer")

    @pytest.mark.parametrize(
        "field,value",
        [("id", ""), ("filename", ""), ("dataUrl", "not-a-data-url"), ("size", 0), ("size", -1)],
    )
    def test_rejects_invalid_fields(self, field, value):
        with pytest.raises(ValidationError):
            make_photo(**{field: value})

    def test_rejects_naive_timestamp(self):
        with pytest.raises(ValidationError, match="timezone-aware"):
            make_photo(uploadedAt=datetime(2026, 1, 1))

    def test_rejects_too_many_tags(self):
        with pytest.raises(ValidationError, match="at most"):
            make_photo(tags=tuple(f"tag{i}" for i in range(11)))

    def test_is_immutable(self):
        with pytest.raises(ValidationError):
            make_photo().filename = "other.png"


class TestSerialisation:
    def test_serialises_with_camel_case_aliases(self):
        raw = make_photo().model_dump(mode="json", by_alias=True)
        assert set(raw) == {"id", "filename", "dataUrl", "uploadedAt", "size", "tags"}

    def test_round_trips(self):
        photo = make_photo()
        assert Photo.model_validate(photo.model_dump(mode="json", by_alias=True)) == photo


class TestParseTags:
    @pytest.mark.parametrize(
        "raw,expected",
        [
            (None, ()),
            ("", ()),
            ("beach", ("beach",)),
            ("beach, summer", ("beach", "summer")),
            ("  Beach ,, SUMMER  ", ("beach", "summer")),
            ("beach, beach", ("beach",)),
        ],
    )
    def test_normalises(self, raw, expected):
        assert parse_tags(raw) == expected

    def test_rejects_an_over_long_tag(self):
        with pytest.raises(InvalidPhotoError, match="exceeds"):
            parse_tags("x" * 33)

    def test_rejects_too_many_tags(self):
        with pytest.raises(InvalidPhotoError, match="at most"):
            parse_tags(",".join(f"tag{i}" for i in range(11)))
