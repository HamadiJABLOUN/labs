"""Shared fixtures."""

from __future__ import annotations

import base64

import pytest
from fastapi.testclient import TestClient

from app.main import create_app
from app.models import Photo, utcnow
from app.service import PhotoService
from app.storage import PhotoRepository

PNG_BYTES = b"\x89PNG\r\n\x1a\n" + b"x" * 32


@pytest.fixture
def storage_path(tmp_path):
    return tmp_path / "photos_data.json"


@pytest.fixture
def repository(storage_path):
    return PhotoRepository(storage_path)


@pytest.fixture
def service(repository):
    return PhotoService(repository)


@pytest.fixture
def client(storage_path):
    return TestClient(create_app(storage_path=storage_path))


def make_photo(**overrides) -> Photo:
    defaults = dict(
        id="abc123",
        filename="holiday.png",
        dataUrl="data:image/png;base64," + base64.b64encode(PNG_BYTES).decode(),
        uploadedAt=utcnow(),
        size=len(PNG_BYTES),
        tags=("beach", "summer"),
    )
    defaults.update(overrides)
    return Photo(**defaults)


def upload(client, *, filename="holiday.png", content=PNG_BYTES,
           content_type="image/png", tags="beach, summer"):
    data = {"tags": tags} if tags is not None else {}
    return client.post(
        "/api/photos",
        files={"file": (filename, content, content_type)},
        data=data,
    )
