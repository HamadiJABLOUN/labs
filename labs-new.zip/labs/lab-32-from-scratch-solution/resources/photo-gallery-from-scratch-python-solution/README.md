# Photo Gallery API — Python / FastAPI

Reference implementation for [Lab 32](../../../lab-32-from-scratch/README.md), Python track.

Planning artifacts: [`../python/SPECIFICATION.md`](../python/SPECIFICATION.md) ·
[`../python/IMPLEMENTATION_PLAN.md`](../python/IMPLEMENTATION_PLAN.md) ·
[`../python/TASKS.md`](../python/TASKS.md)

## Setup

```bash
python -m venv .venv
.venv/Scripts/activate        # Windows
# source .venv/bin/activate   # macOS / Linux

pip install -r requirements-dev.txt
```

## Run

```bash
python -m app                 # http://127.0.0.1:42323
```

Interactive docs at `/docs`, the OpenAPI schema at `/openapi.json`.

## Test

```bash
pytest                        # 71 tests, 98% coverage
```

## Endpoints

| Method   | Path               | Request                            | Success            | Errors |
| -------- | ------------------ | ---------------------------------- | ------------------ | ------ |
| `POST`   | `/api/photos`      | multipart: `file`, optional `tags` | `201` + Photo      | `422`  |
| `GET`    | `/api/photos`      | optional `?tag=`                   | `200` + Photo[]    | —      |
| `GET`    | `/api/photos/{id}` | —                                  | `200` + Photo      | `404`  |
| `DELETE` | `/api/photos/{id}` | —                                  | `204` no body      | `404`  |
| `GET`    | `/api/tags`        | —                                  | `200` + TagStats[] | —      |

```bash
curl -F file=@photo.png -F tags="beach, summer" http://127.0.0.1:42323/api/photos
curl "http://127.0.0.1:42323/api/photos?tag=beach"
curl http://127.0.0.1:42323/api/tags
```

## Architecture

```
app/
├── config.py     every tunable, env-overridable
├── models.py     Photo (frozen, validated), TagStats, parse_tags
├── storage.py    PhotoRepository — atomic writes, tolerant reads
├── service.py    PhotoService — the business rules live here
├── api.py        thin HTTP layer
└── main.py       create_app() factory
```

Each layer depends only on the one below. 41 of the 71 tests run without an HTTP client, because the
rules are in the service rather than the routes.

## Configuration

| Environment variable          | Default            |
| ----------------------------- | ------------------ |
| `PHOTO_GALLERY_STORAGE`       | `photos_data.json` |
| `PHOTO_GALLERY_MAX_FILE_SIZE` | `2097152` (2 MiB)  |
| `PHOTO_GALLERY_PORT`          | `42323`            |

## Note on Python 3.14

The suite passes, but FastAPI and Starlette emit `DeprecationWarning` about
`asyncio.iscoroutinefunction`. Those come from the libraries, not this code. Target 3.12 for a quiet run.
