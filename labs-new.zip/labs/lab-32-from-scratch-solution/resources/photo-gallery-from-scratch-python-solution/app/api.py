"""HTTP layer. Thin by design: all rules live in :mod:`app.service`."""

from __future__ import annotations

from typing import Annotated

from fastapi import APIRouter, Depends, File, Form, HTTPException, Request, Response, UploadFile, status

from app.models import InvalidPhotoError, Photo, TagStats
from app.service import PhotoNotFoundError, PhotoService

router = APIRouter(prefix="/api", tags=["photos"])


def get_service(request: Request) -> PhotoService:
    """Return the PhotoService attached to the running application."""
    return request.app.state.photo_service


ServiceDep = Annotated[PhotoService, Depends(get_service)]


@router.get("/photos", response_model=list[Photo], response_model_by_alias=True)
def list_photos(service: ServiceDep, tag: str | None = None) -> list[Photo]:
    """List the gallery, newest first, optionally filtered by tag."""
    return service.list_photos(tag)


@router.get("/photos/{photo_id}", response_model=Photo, response_model_by_alias=True)
def get_photo(photo_id: str, service: ServiceDep) -> Photo:
    """Return a single photo, or 404 if the id is unknown."""
    try:
        return service.get_photo(photo_id)
    except PhotoNotFoundError:
        raise HTTPException(status.HTTP_404_NOT_FOUND, f"No photo with id {photo_id}") from None


@router.post(
    "/photos",
    response_model=Photo,
    response_model_by_alias=True,
    status_code=status.HTTP_201_CREATED,
)
async def upload_photo(
    service: ServiceDep,
    file: Annotated[UploadFile, File()],
    tags: Annotated[str | None, Form()] = None,
) -> Photo:
    """Accept an uploaded image, or explain why it was rejected."""
    try:
        return service.add_photo(
            content=await file.read(),
            filename=file.filename or "",
            content_type=file.content_type or "",
            tags=tags,
        )
    except InvalidPhotoError as exc:
        raise HTTPException(status.HTTP_422_UNPROCESSABLE_ENTITY, str(exc)) from exc


@router.delete(
    "/photos/{photo_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    response_class=Response,
    # `from __future__ import annotations` defers `-> None` to the string "None",
    # which FastAPI would otherwise resolve into a response model. 204 allows no body.
    response_model=None,
)
def delete_photo(photo_id: str, service: ServiceDep) -> None:
    """Delete a photo, or 404 if the id is unknown."""
    try:
        service.delete_photo(photo_id)
    except PhotoNotFoundError:
        raise HTTPException(status.HTTP_404_NOT_FOUND, f"No photo with id {photo_id}") from None


@router.get("/tags", response_model=list[TagStats])
def list_tags(service: ServiceDep) -> list[TagStats]:
    """Return every tag in use with its photo count, most used first."""
    return service.tag_stats()
