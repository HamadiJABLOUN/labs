"""Application factory."""

from __future__ import annotations

from pathlib import Path

from fastapi import FastAPI

from app.api import router
from app.config import STORAGE_PATH
from app.service import PhotoService
from app.storage import PhotoRepository

__all__ = ["create_app", "app"]


def create_app(storage_path: Path | None = None) -> FastAPI:
    """Build a configured application.

    Args:
        storage_path: where to persist the gallery. Defaults to
            :data:`app.config.STORAGE_PATH`; tests pass a temporary path.
    """
    application = FastAPI(
        title="Photo Gallery API",
        version="1.0.0",
        summary="Upload, tag, browse and delete photos.",
    )
    application.state.photo_service = PhotoService(PhotoRepository(storage_path or STORAGE_PATH))
    application.include_router(router)
    return application


app = create_app()
