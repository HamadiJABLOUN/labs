"""Application settings.

Every tunable lives here so nothing is hardcoded in the business logic.
Values can be overridden through environment variables.
"""

from __future__ import annotations

import os
from pathlib import Path

#: Where the gallery is persisted.
STORAGE_PATH: Path = Path(os.environ.get("PHOTO_GALLERY_STORAGE", "photos_data.json"))

#: Largest accepted upload, in bytes (2 MiB).
MAX_FILE_SIZE: int = int(os.environ.get("PHOTO_GALLERY_MAX_FILE_SIZE", 2 * 1024 * 1024))

#: MIME types the gallery accepts.
ALLOWED_MIME_TYPES: frozenset[str] = frozenset(
    {"image/png", "image/jpeg", "image/gif", "image/webp"}
)

#: Upper bound on the number of tags attached to a single photo.
MAX_TAGS: int = 10

#: Upper bound on the length of a single tag.
MAX_TAG_LENGTH: int = 32

#: Port the development server binds to.
PORT: int = int(os.environ.get("PHOTO_GALLERY_PORT", 42323))
