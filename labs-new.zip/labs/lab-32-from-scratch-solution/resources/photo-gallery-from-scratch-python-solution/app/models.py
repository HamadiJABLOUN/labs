"""Domain models and API schemas."""

from __future__ import annotations

import re
from datetime import datetime, timezone

from pydantic import BaseModel, ConfigDict, Field, field_validator

from app.config import MAX_TAG_LENGTH, MAX_TAGS

_DATA_URL = re.compile(r"^data:[\w.+-]+/[\w.+-]+;base64,")


class InvalidPhotoError(ValueError):
    """Raised when a photo, or an upload, fails validation."""


class Photo(BaseModel):
    """A stored photo.

    Immutable once created: the model is frozen, so a photo that exists is
    a photo that passed validation.
    """

    model_config = ConfigDict(frozen=True)

    id: str = Field(min_length=1)
    filename: str = Field(min_length=1)
    data_url: str = Field(serialization_alias="dataUrl", validation_alias="dataUrl")
    uploaded_at: datetime = Field(serialization_alias="uploadedAt", validation_alias="uploadedAt")
    size: int = Field(gt=0)
    tags: tuple[str, ...] = ()

    @field_validator("data_url")
    @classmethod
    def _check_data_url(cls, value: str) -> str:
        if not _DATA_URL.match(value):
            raise ValueError("data_url must be a base64 data URL")
        return value

    @field_validator("uploaded_at")
    @classmethod
    def _check_timezone(cls, value: datetime) -> datetime:
        if value.tzinfo is None:
            raise ValueError("uploaded_at must be timezone-aware")
        return value

    @field_validator("tags")
    @classmethod
    def _check_tag_count(cls, value: tuple[str, ...]) -> tuple[str, ...]:
        if len(value) > MAX_TAGS:
            raise ValueError(f"at most {MAX_TAGS} tags are allowed")
        return value


class TagStats(BaseModel):
    """How many photos carry a given tag."""

    name: str
    count: int = Field(ge=0)


def parse_tags(raw: str | None) -> tuple[str, ...]:
    """Turn a comma-separated tag string into normalised, unique tags.

    Empty segments are dropped, whitespace is trimmed, case is lowered, and
    insertion order is preserved.

    Raises:
        InvalidPhotoError: if a tag is too long, or there are too many.
    """
    if not raw:
        return ()

    seen: dict[str, None] = {}
    for chunk in raw.split(","):
        tag = chunk.strip().lower()
        if not tag:
            continue
        if len(tag) > MAX_TAG_LENGTH:
            raise InvalidPhotoError(f"tag '{tag}' exceeds {MAX_TAG_LENGTH} characters")
        seen.setdefault(tag, None)

    tags = tuple(seen)
    if len(tags) > MAX_TAGS:
        raise InvalidPhotoError(f"at most {MAX_TAGS} tags are allowed")
    return tags


def utcnow() -> datetime:
    """Return the current time as a timezone-aware UTC datetime."""
    return datetime.now(timezone.utc)
