"""Business logic. The routes stay thin: every rule lives here."""

from __future__ import annotations

import base64
import uuid
from collections import Counter

from app.config import ALLOWED_MIME_TYPES, MAX_FILE_SIZE
from app.models import InvalidPhotoError, Photo, TagStats, parse_tags, utcnow
from app.storage import PhotoRepository


class PhotoNotFoundError(LookupError):
    """Raised when a photo id does not exist."""


class PhotoService:
    """Coordinates validation, encoding, and persistence of photos."""

    def __init__(self, repository: PhotoRepository) -> None:
        self._repository = repository

    def list_photos(self, tag: str | None = None) -> list[Photo]:
        """Return the gallery, newest first, optionally filtered by one tag.

        Args:
            tag: if given, only photos carrying this tag are returned. The
                comparison is case-insensitive, matching how tags are stored.
        """
        photos = sorted(self._repository.load(), key=lambda p: p.uploaded_at, reverse=True)

        if tag is None:
            return photos

        needle = tag.strip().lower()
        return [photo for photo in photos if needle in photo.tags]

    def get_photo(self, photo_id: str) -> Photo:
        """Return a single photo.

        Raises:
            PhotoNotFoundError: if no photo carries this id.
        """
        for photo in self._repository.load():
            if photo.id == photo_id:
                return photo
        raise PhotoNotFoundError(photo_id)

    def add_photo(
        self, *, content: bytes, filename: str, content_type: str, tags: str | None
    ) -> Photo:
        """Validate, encode, and store an uploaded image.

        Raises:
            InvalidPhotoError: if the upload is empty, too large, of an
                unsupported type, or carries invalid tags.
        """
        if not content:
            raise InvalidPhotoError("no file was uploaded")
        if len(content) > MAX_FILE_SIZE:
            raise InvalidPhotoError(
                f"file is {len(content)} bytes, the maximum is {MAX_FILE_SIZE}"
            )
        if content_type not in ALLOWED_MIME_TYPES:
            raise InvalidPhotoError(f"unsupported file type: {content_type}")
        if not filename or not filename.strip():
            raise InvalidPhotoError("filename must not be empty")

        photo = Photo(
            id=uuid.uuid4().hex,
            filename=filename,
            dataUrl=f"data:{content_type};base64,{base64.b64encode(content).decode('ascii')}",
            uploadedAt=utcnow(),
            size=len(content),
            tags=parse_tags(tags),
        )

        photos = self._repository.load()
        photos.append(photo)
        self._repository.save(photos)
        return photo

    def delete_photo(self, photo_id: str) -> None:
        """Remove a photo by id.

        Raises:
            PhotoNotFoundError: if no photo carries this id.
        """
        photos = self._repository.load()
        remaining = [photo for photo in photos if photo.id != photo_id]

        if len(remaining) == len(photos):
            raise PhotoNotFoundError(photo_id)

        self._repository.save(remaining)

    def tag_stats(self) -> list[TagStats]:
        """Return every tag in use with its photo count, most used first.

        Ties are broken alphabetically, so the output is deterministic.
        """
        counter: Counter[str] = Counter()
        for photo in self._repository.load():
            counter.update(photo.tags)

        return [
            TagStats(name=name, count=count)
            for name, count in sorted(counter.items(), key=lambda item: (-item[1], item[0]))
        ]
