# Photo Gallery Project Context

## Tech Stack

- Angular 21.x standalone components
- Vite build tool
- Vitest testing
- LocalStorage persistence

## Conventions

- Use inject() for dependency injection
- Signal-based state management
- Reactive forms for user input
- Kebab-case for file names

## Architecture

- **Models**: `src/app/models/` — Photo and TagStats interfaces with validation
- **Services**: `src/app/services/` — PhotoService with signal-based state and LocalStorage persistence
- **Components**: `src/app/components/` — PhotoUploadComponent (file upload with validation), PhotoListComponent (grid display with filtering and deletion)

## Current Goals

- Build a complete photo gallery application following the agentic workflow
- Implement upload, tagging, filtering, and deletion features
- Achieve >80% test coverage with Vitest
- Follow Angular best practices with standalone components and signals
