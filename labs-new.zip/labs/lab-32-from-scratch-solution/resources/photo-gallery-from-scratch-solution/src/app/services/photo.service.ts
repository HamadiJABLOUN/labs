import { Injectable, signal, computed } from '@angular/core';
import { Photo, validateTags } from '../models/photo.model';
import { TagStats } from '../models/tag.model';

/**
 * Storage key for LocalStorage persistence.
 */
const STORAGE_KEY = 'photo-gallery:photos';

/**
 * Service for managing photo gallery data with signal-based state management.
 * 
 * Provides reactive state updates using Angular signals and handles
 * LocalStorage persistence with comprehensive error handling.
 * 
 * @example
 * ```typescript
 * const photoService = inject(PhotoService);
 * 
 * // Add a photo
 * photoService.addPhoto(newPhoto);
 * 
 * // Access photos reactively
 * const photos = photoService.photos();
 * 
 * // Get tag statistics
 * const tags = photoService.tagStats();
 * ```
 */
@Injectable({
  providedIn: 'root',
})
export class PhotoService {
  /**
   * Signal containing all photos.
   * 
   * Use this to reactively access the photo collection.
   */
  private readonly photosSignal = signal<Photo[]>([]);
  
  /**
   * Public read-only accessor for photos.
   */
  readonly photos = this.photosSignal.asReadonly();
  
  /**
   * Computed signal providing tag statistics.
   * 
   * Automatically recalculates when photos change.
   */
  readonly tagStats = computed(() => {
    const tagMap = new Map<string, number>();
    
    for (const photo of this.photosSignal()) {
      for (const tag of photo.tags) {
        tagMap.set(tag, (tagMap.get(tag) || 0) + 1);
      }
    }
    
    return Array.from(tagMap.entries())
      .map(([name, count]): TagStats => ({ name, count }))
      .sort((a, b) => b.count - a.count);
  });
  
  constructor() {
    this.loadFromStorage();
  }
  
  /**
   * Adds a new photo to the collection.
   * 
   * @param photo - The photo to add
   * @throws Error if photo validation fails or storage quota exceeded
   */
  addPhoto(photo: Photo): void {
    // Validate tags
    const tagValidation = validateTags(photo.tags);
    if (!tagValidation.valid) {
      throw new Error(tagValidation.error);
    }
    
    // Create updated array
    const updatedPhotos = [...this.photos(), photo];
    
    // Save to storage first
    this.savePhotosToStorage(updatedPhotos);
    
    // Only update signal if storage succeeds (prevents flickering)
    this.photosSignal.set(updatedPhotos);
  }
  
  /**
   * Removes a photo from the collection.
   * 
   * @param photoId - The ID of the photo to remove
   * @throws Error if photo not found
   */
  removePhoto(photoId: string): void {
    const currentPhotos = this.photosSignal();
    const photoIndex = currentPhotos.findIndex(p => p.id === photoId);
    
    if (photoIndex === -1) {
      throw new Error(`Photo with ID ${photoId} not found`);
    }
    
    const updatedPhotos = currentPhotos.filter(p => p.id !== photoId);
    
    // Save to storage first
    this.savePhotosToStorage(updatedPhotos);
    
    // Only update signal if storage succeeds
    this.photosSignal.set(updatedPhotos);
  }
  
  /**
   * Updates tags for a specific photo.
   * 
   * @param photoId - The ID of the photo to update
   * @param tags - The new tags array
   * @throws Error if photo not found or tag validation fails
   */
  updatePhotoTags(photoId: string, tags: string[]): void {
    const tagValidation = validateTags(tags);
    if (!tagValidation.valid) {
      throw new Error(tagValidation.error);
    }
    
    const currentPhotos = this.photosSignal();
    const photoIndex = currentPhotos.findIndex(p => p.id === photoId);
    
    if (photoIndex === -1) {
      throw new Error(`Photo with ID ${photoId} not found`);
    }
    
    const updatedPhotos = [...currentPhotos];
    updatedPhotos[photoIndex] = {
      ...updatedPhotos[photoIndex],
      tags,
    };
    
    // Save to storage first
    this.savePhotosToStorage(updatedPhotos);
    
    // Only update signal if storage succeeds
    this.photosSignal.set(updatedPhotos);
  }
  
  /**
   * Filters photos by tags (photos must have ALL specified tags).
   * 
   * @param tags - Array of tags to filter by
   * @returns Computed signal with filtered photos
   */
  filterByTags(tags: string[]) {
    return computed(() => {
      if (tags.length === 0) {
        return this.photosSignal();
      }
      
      return this.photosSignal().filter(photo =>
        tags.every(tag => photo.tags.includes(tag))
      );
    });
  }
  
  /**
   * Loads photos from LocalStorage.
   * 
   * Handles corrupt data gracefully by initializing empty array.
   */
  private loadFromStorage(): void {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (!stored) {
        return;
      }
      
      const parsed = JSON.parse(stored);
      
      // Convert date strings back to Date objects
      const photos: Photo[] = parsed.map((p: Photo) => ({
        ...p,
        uploadedAt: new Date(p.uploadedAt),
      }));
      
      this.photosSignal.set(photos);
    } catch (error) {
      console.error('Failed to load photos from storage:', error);
      // Initialize with empty array if storage is corrupt
      this.photosSignal.set([]);
    }
  }
  
  /**
   * Saves the given photos array to LocalStorage.
   * 
   * @param photos - The photos array to save
   * @throws Error if storage quota exceeded
   * @private
   */
  private savePhotosToStorage(photos: Photo[]): void {
    try {
      const json = JSON.stringify(photos);
      localStorage.setItem(STORAGE_KEY, json);
    } catch (error) {
      if (error instanceof DOMException && error.name === 'QuotaExceededError') {
        throw new Error('Storage quota exceeded. Please delete some photos.');
      }
      throw new Error('Failed to save photos to storage');
    }
  }

  /**
   * Saves current photos to LocalStorage.
   * 
   * @throws Error if storage quota exceeded
   */
  private saveToStorage(): void {
    this.savePhotosToStorage(this.photos());
  }
  
  /**
   * Clears all photos from the collection and storage.
   * 
   * Use with caution - this action cannot be undone.
   */
  clearAll(): void {
    this.photosSignal.set([]);
    localStorage.removeItem(STORAGE_KEY);
  }
}
