# Task Breakdown — Photo Gallery API (Python / FastAPI)

> Python variant of [`../TASKS.md`](../TASKS.md).
> Derived from [`SPECIFICATION.md`](SPECIFICATION.md) and [`IMPLEMENTATION_PLAN.md`](IMPLEMENTATION_PLAN.md).

**MVP** = the five endpoints working, validated, and tested. Everything marked _nice-to-have_ can be
dropped if the timebox runs out without making the deliverable incomplete.

---

## Phase 0 — Setup

| #   | Task                                                        | MVP | Depends on | Parallel? |
| --- | ----------------------------------------------------------- | --- | ---------- | --------- |
| T1  | Create the venv, `requirements.txt`, `requirements-dev.txt` | ✅  | —          | —         |
| T2  | Scaffold `app/` and `tests/`, add `pytest.ini`              | ✅  | T1         | —         |

> **Bootstrap command** (from the lab folder):
>
> ```bash
> python -m venv .venv && .venv/Scripts/activate
> pip install fastapi uvicorn[standard] python-multipart pytest pytest-cov httpx
> ```

## Phase 1 — Configuration and models

| #   | Task                                                                     | MVP | Depends on | Parallel?  |
| --- | ------------------------------------------------------------------------ | --- | ---------- | ---------- |
| T3  | `config.py`: storage path, size limit, MIME allow-list, tag bounds, port | ✅  | T2         | —          |
| T4  | `models.py`: the `Photo` model, frozen, with field validators            | ✅  | T3         | —          |
| T5  | `parse_tags()`: split, trim, lowercase, de-duplicate, bound              | ✅  | T3         | with T4    |
| T6  | `TagStats` model                                                         | ✅  | T2         | with T4/T5 |
| T7  | Tests for T4–T6                                                          | ✅  | T4, T5, T6 | —          |

> T4 and T5 touch the same file but not the same functions — two people can split them.

## Phase 2 — Persistence

| #   | Task                                                          | MVP | Depends on | Parallel? |
| --- | ------------------------------------------------------------- | --- | ---------- | --------- |
| T8  | `PhotoRepository.load()` — tolerant: skip and log bad records | ✅  | T4         | —         |
| T9  | `PhotoRepository.save()` — atomic: temp file + `os.replace`   | ✅  | T4         | —         |
| T10 | `PhotoRepository.clear()`                                     | ✅  | T9         | —         |
| T11 | Tests for T8–T10, including a deliberately corrupted file     | ✅  | T8, T9     | —         |

> **T9 is the task with the highest value-per-line in the whole lab.** Writing straight onto the
> target file works in every manual test and loses the gallery the first time a write is interrupted.

## Phase 3 — Business logic

| #   | Task                                                   | MVP | Depends on | Parallel? |
| --- | ------------------------------------------------------ | --- | ---------- | --------- |
| T12 | `PhotoService.add_photo()` — the five validation rules | ✅  | T8, T9     | —         |
| T13 | `PhotoService.list_photos(tag)` — sort, then filter    | ✅  | T8         | with T12  |
| T14 | `PhotoService.get_photo()` / `delete_photo()`          | ✅  | T8, T9     | with T13  |
| T15 | `PhotoService.tag_stats()` — count, sort, break ties   | ✅  | T8         | with T13  |
| T16 | Tests for T12–T15                                      | ✅  | T12–T15    | —         |

> These four can be split across people once T8/T9 exist: they share a repository but no state.

## Phase 4 — HTTP layer

| #   | Task                                                          | MVP | Depends on | Parallel? |
| --- | ------------------------------------------------------------- | --- | ---------- | --------- |
| T17 | `create_app()` factory taking `storage_path`                  | ✅  | T12–T15    | —         |
| T18 | `POST /api/photos` — multipart in, `201` out                  | ✅  | T17        | —         |
| T19 | `GET /api/photos` with the optional `?tag=` filter            | ✅  | T17        | with T18  |
| T20 | `GET /api/photos/{id}` and `DELETE /api/photos/{id}`          | ✅  | T17        | with T18  |
| T21 | `GET /api/tags`                                               | ✅  | T17        | with T18  |
| T22 | Map `InvalidPhotoError` → `422`, `PhotoNotFoundError` → `404` | ✅  | T18–T21    | —         |
| T23 | Tests for the whole contract                                  | ✅  | T18–T22    | —         |

> ⚠️ **T20 will bite you.** `DELETE` returns `204`, which must have no body. Because the module uses
> `from __future__ import annotations`, the `-> None` return annotation is deferred to the string
> `"None"`, FastAPI resolves it into a response model, and startup fails with
> _"Status code 204 must not have a response body"_ — an error that points at the status code rather
> than at the annotation. Pass `response_model=None` on the decorator.

## Phase 5 — Validation and documentation

| #   | Task                                           | MVP | Depends on | Parallel? |
| --- | ---------------------------------------------- | --- | ---------- | --------- |
| T24 | Check every acceptance criterion has a test    | ✅  | T23        | —         |
| T25 | Raise coverage above 80%                       | ✅  | T24        | —         |
| T26 | `README.md`: setup, run, test, endpoint table  | ✅  | T23        | with T24  |
| T27 | Check `/openapi.json` lists all five endpoints | ✅  | T23        | with T24  |
| T28 | `python -m app` launcher                       | ⬜  | T17        | with T26  |
| T29 | Exclude the launcher from coverage             | ⬜  | T28, T25   | —         |

## Critical path

```
T1 → T2 → T3 → T4 → T8/T9 → T12 → T17 → T18 → T22 → T23 → T24 → T25
```

Everything else hangs off that spine. Two people can work in parallel from T4 onwards; three from
T12 onwards, when the four service methods split cleanly.

## Definition of done

1. `pytest` is green and coverage is above 80%
2. Every acceptance criterion in `SPECIFICATION.md` maps to at least one test
3. Every public function carries a type hint and a docstring
4. `/openapi.json` lists the five endpoints
5. The JSON payload matches the Java variant

## Actual outcome

The reference implementation follows this breakdown: **71 tests, 98% coverage**, all five endpoints
live and documented.
