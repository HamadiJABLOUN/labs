# Implementation Plan — Photo Gallery API (Python / FastAPI)

> Python variant of [`../IMPLEMENTATION_PLAN.md`](../IMPLEMENTATION_PLAN.md).
> Derived from [`SPECIFICATION.md`](SPECIFICATION.md).

---

## 1. Stack, and why

| Concern     | Choice                    | Why this one                                                                                                           |
| ----------- | ------------------------- | ---------------------------------------------------------------------------------------------------------------------- |
| Framework   | FastAPI 0.115             | Generates the OpenAPI schema from the same type hints that validate requests — the contract cannot drift from the code |
| Validation  | Pydantic v2 models        | Validation lives in the model, so an invalid `Photo` cannot be constructed anywhere, not only at the HTTP edge         |
| Server      | uvicorn                   | The reference ASGI server; nothing exotic needed at this scale                                                         |
| Persistence | JSON file                 | Matches the TypeScript variant's LocalStorage: no service to install, and it keeps the lab about the _workflow_        |
| Tests       | pytest + httpx TestClient | Fixtures give each test its own `tmp_path`, so no test can see another's data                                          |
| Uploads     | python-multipart          | Required by FastAPI for `multipart/form-data`; no alternative worth debating                                           |

**Rejected**: Flask (no schema generation, validation would be hand-rolled), Django REST Framework
(an ORM and a migration system for a 200-line service), SQLite (persistence is not what the lab
teaches, and a file keeps the diff readable).

## 2. Architecture

Four layers, each depending only on the one below it:

```
      api.py        HTTP only: parse, delegate, map exceptions to status codes
        │
    service.py      Business rules: what may enter the gallery, in what order it comes out
        │
    storage.py      Persistence: atomic writes, tolerant reads
        │
    models.py       Domain types: a Photo that exists is a Photo that validated
```

`config.py` sits beside all four. Nothing imports upward.

### Why this split matters here

The single most common failure in this lab is putting validation in the route handler. It works, and
then the rules are unreachable from anywhere except an HTTP request — which means every test has to
go through the whole stack. Keeping the rules in `service.py` is what lets 41 of the 71 tests run
without a client at all.

## 3. Data model

```python
class Photo(BaseModel):
    model_config = ConfigDict(frozen=True)

    id: str                    # uuid4().hex, server-assigned
    filename: str
    data_url: str              # serialised as "dataUrl"
    uploaded_at: datetime      # serialised as "uploadedAt", timezone-aware
    size: int                  # decoded bytes, > 0
    tags: tuple[str, ...] = ()
```

Three decisions worth defending:

- **Frozen.** A photo is a fact about the past. Nothing should mutate one after it is stored, and
  freezing makes that a type error rather than a code-review comment.
- **`tuple` not `list` for tags.** A frozen model with a mutable field is only half frozen.
- **Aliases for the wire format.** Python code reads `photo.data_url`; the JSON says `dataUrl`.
  `serialization_alias` / `validation_alias` bridge the two, which is what keeps the payload
  identical to the Java variant without making the Python code look like Java.

`TagStats` is a plain `{name, count}` model, computed on read rather than stored — there is no second
source of truth to keep in sync.

## 4. File structure

```
photo-gallery-from-scratch-python-solution/
├── app/
│   ├── __init__.py
│   ├── __main__.py       python -m app  → uvicorn on port 42323
│   ├── config.py         every tunable, env-overridable
│   ├── models.py         Photo, TagStats, parse_tags, InvalidPhotoError
│   ├── storage.py        PhotoRepository
│   ├── service.py        PhotoService, PhotoNotFoundError
│   ├── api.py            APIRouter, dependency wiring, exception mapping
│   └── main.py           create_app() factory
├── tests/
│   ├── conftest.py       fixtures: tmp storage, service, client
│   ├── test_models.py    validation and tag parsing
│   ├── test_storage.py   persistence, corruption tolerance
│   ├── test_service.py   the business rules
│   └── test_api.py       the HTTP contract
├── requirements.txt / requirements-dev.txt
└── pytest.ini
```

## 5. Technical decisions

### 5.1 An application factory, not a module-level app

`create_app(storage_path=...)` takes the storage path as an argument. Without it, every test would
share one JSON file and the suite would be order-dependent. `app = create_app()` at module level
still gives uvicorn something to import.

The service is attached to `app.state` and read through a FastAPI dependency, which keeps the routes
free of imports from `service.py`.

### 5.2 Atomic writes

`save()` writes to a temporary file **in the same directory** and then calls `os.replace`, which is
atomic on POSIX and on Windows. Writing elsewhere and moving across a filesystem boundary would not
be. An interrupted write leaves the previous gallery intact.

### 5.3 Tolerant reads

`load()` never raises. An unreadable file, a non-list payload, or a record that fails validation is
logged and skipped. One malformed entry cannot take the gallery down.

The trade-off is that a corrupt file looks like an empty one, and the next write will overwrite it.
That is acceptable for a lab artefact and explicitly noted; a production service would move the bad
file aside rather than silently replace it.

### 5.4 Exceptions are domain-shaped, mapped at the edge

`InvalidPhotoError` and `PhotoNotFoundError` are raised where they are detected. `api.py` maps them
to `422` and `404`. The service knows nothing about HTTP, so it stays testable without a client.

### 5.5 Timestamps

`utcnow()` returns a timezone-aware UTC datetime, and the model rejects naive ones. A naive timestamp
compared against an aware one raises at runtime; rejecting it at construction turns a latent crash
into an immediate, obvious error.

### 5.6 The `-> None` trap on a 204

`DELETE` returns `204`, which must carry no body. With `from __future__ import annotations`, the
`-> None` return annotation is deferred to the string `"None"`, which FastAPI resolves into a
response model — and then asserts that a 204 must not have one. The route needs an explicit
`response_model=None`. This cost real debugging time and is called out in `TASKS.md`.

## 6. Test strategy

| Layer   | Tests | What it proves                                             |
| ------- | ----- | ---------------------------------------------------------- |
| models  | 19    | An invalid photo cannot be built; tags normalise correctly |
| storage | 10    | Round-trips, survives corruption, writes atomically        |
| service | 22    | Every business rule, in isolation from HTTP                |
| api     | 20    | Status codes, payload shape, the contract itself           |

Total: **71**. Forty-one of those (models + service) run without an HTTP client at all.

Every acceptance criterion in the specification maps to at least one test. The fixtures give each
test a fresh `tmp_path`, so the suite is order-independent and parallelisable.

## 7. Known limits

- **Concurrency**: read-modify-write is not locked. Two simultaneous uploads can lose one. Fixing it
  properly means a lock or a database — out of scope, and stated in the spec.
- **Memory**: uploads are read whole. The 2 MiB limit is what keeps that safe.
- **Python 3.14**: the suite passes, but FastAPI and Starlette emit `DeprecationWarning` about
  `asyncio.iscoroutinefunction`. Those come from the libraries, not this code. Target 3.12 for a
  quiet run.
