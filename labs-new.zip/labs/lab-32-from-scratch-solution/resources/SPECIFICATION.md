# Photo Gallery Application - Specification

## Document Control

**Version:** 1.0  
**Date:** 2024  
**Status:** Implemented  
**Stakeholders:** Training participants, instructors

## 1. Purpose and Scope

### 1.1 Purpose

Create a modern photo gallery web application demonstrating best practices in Angular development, signal-based state management, and comprehensive validation patterns.

### 1.2 Scope

**In Scope:**

- Photo upload with drag-and-drop support
- Tag-based organization and filtering
- LocalStorage persistence
- Responsive design
- Accessibility compliance (WCAG 2.1 AA)
- Comprehensive validation and error handling

**Out of Scope:**

- Backend API integration
- User authentication
- Multi-user support
- Photo editing features
- Cloud storage integration
- Server-side rendering

## 2. Functional Requirements

### 2.1 Photo Upload (FR-001)

**Priority:** P1 (Critical)

**Description:** Users must be able to upload photos with comprehensive validation.

**Acceptance Criteria:**

- **AC1.1:** Support file selection via file input dialog
- **AC1.2:** Support drag-and-drop file upload
- **AC1.3:** Display preview of selected photo before upload
- **AC1.4:** Show file name and size information
- **AC1.5:** Validate file type (JPEG, PNG, WebP only)
- **AC1.6:** Validate file size (maximum 5MB)
- **AC1.7:** Validate filename length (maximum 255 characters)
- **AC1.8:** Display clear error messages for validation failures

**User Story:**

```
As a user
I want to upload photos with validation
So that I can add quality photos to my gallery
```

### 2.2 Tag Management (FR-002)

**Priority:** P1 (Critical)

**Description:** Users must be able to add, remove, and filter photos by tags.

**Acceptance Criteria:**

- **AC2.1:** Add tags to photos during upload
- **AC2.2:** Maximum 20 tags per photo
- **AC2.3:** Tags must be 2-30 characters
- **AC2.4:** Tags must match pattern: lowercase, numbers, hyphens only
- **AC2.5:** Prevent duplicate tags on same photo
- **AC2.6:** Remove tags with one click
- **AC2.7:** Display tag count and constraints

**User Story:**

```
As a user
I want to organize photos with tags
So that I can easily find related photos later
```

### 2.3 Photo Gallery Display (FR-003)

**Priority:** P1 (Critical)

**Description:** Users must be able to view all photos in a responsive grid layout.

**Acceptance Criteria:**

- **AC3.1:** Display photos in responsive grid (adapts to screen size)
- **AC3.2:** Show photo filename, upload date, and file size
- **AC3.3:** Display associated tags for each photo
- **AC3.4:** Show total photo count
- **AC3.5:** Handle empty state gracefully
- **AC3.6:** Provide hover effects for interactivity

**User Story:**

```
As a user
I want to view all my photos in an organized grid
So that I can browse my photo collection easily
```

### 2.4 Tag Filtering (FR-004)

**Priority:** P2 (High)

**Description:** Users must be able to filter photos by selecting one or more tags.

**Acceptance Criteria:**

- **AC4.1:** Display sidebar with all available tags
- **AC4.2:** Show photo count for each tag
- **AC4.3:** Support multi-tag filtering (AND logic)
- **AC4.4:** Update gallery instantly when filters change
- **AC4.5:** Display active filter indicator
- **AC4.6:** Provide "Clear Filters" button
- **AC4.7:** Handle no-results state

**User Story:**

```
As a user
I want to filter photos by tags
So that I can quickly find photos with specific characteristics
```

### 2.5 Photo Deletion (FR-005)

**Priority:** P2 (High)

**Description:** Users must be able to delete unwanted photos.

**Acceptance Criteria:**

- **AC5.1:** Display delete button on each photo card
- **AC5.2:** Require confirmation before deletion
- **AC5.3:** Remove photo from gallery immediately
- **AC5.4:** Update tag statistics after deletion
- **AC5.5:** Persist deletion to LocalStorage

**User Story:**

```
As a user
I want to delete photos I no longer need
So that I can keep my gallery organized
```

### 2.6 Data Persistence (FR-006)

**Priority:** P1 (Critical)

**Description:** Photos must persist across browser sessions.

**Acceptance Criteria:**

- **AC6.1:** Save photos to LocalStorage automatically
- **AC6.2:** Load photos from LocalStorage on app initialization
- **AC6.3:** Handle LocalStorage quota exceeded gracefully
- **AC6.4:** Handle corrupted data gracefully
- **AC6.5:** Maintain data integrity across operations

**User Story:**

```
As a user
I want my photos saved automatically
So that I don't lose my work when I close the browser
```

## 3. Non-Functional Requirements

### 3.1 Performance (NFR-001)

**Priority:** P2 (High)

**Metrics:**

- Initial page load: < 2 seconds
- Photo upload: < 500ms (excluding file read)
- Filter application: < 100ms
- Tag statistics computation: < 50ms

### 3.2 Usability (NFR-002)

**Priority:** P1 (Critical)

**Requirements:**

- Intuitive UI requiring no training
- Clear visual feedback for all actions
- Consistent design patterns throughout
- Mobile-responsive design
- Touch-friendly targets (minimum 44x44 pixels)

### 3.3 Accessibility (NFR-003)

**Priority:** P1 (Critical)

**Requirements:**

- WCAG 2.1 Level AA compliance
- Keyboard navigation support
- Screen reader compatibility
- Focus indicators on interactive elements
- Semantic HTML structure
- ARIA labels where appropriate

### 3.4 Browser Support (NFR-004)

**Priority:** P2 (High)

**Supported Browsers:**

- Chrome 120+ (primary)
- Firefox 120+
- Safari 17+
- Edge 120+

### 3.5 Data Limits (NFR-005)

**Priority:** P2 (High)

**Constraints:**

- Maximum photos: Limited by LocalStorage (typically ~1000 photos)
- Maximum file size: 5MB per photo
- Maximum tags per photo: 20
- Maximum tag length: 30 characters

## 4. Technical Requirements

### 4.1 Architecture (TR-001)

- **Framework:** Angular 21.x with standalone components
- **State Management:** Signal-based reactive state
- **Build Tool:** Nx with esbuild bundler
- **Testing:** Vitest for unit tests
- **Language:** TypeScript 5.x (strict mode)
- **Code Quality:** ESLint with recommended rules

### 4.2 Data Models (TR-002)

**Photo Interface:**

```typescript
interface Photo {
  id: string; // UUID v4
  filename: string; // Original filename
  dataUrl: string; // Base64 encoded image data
  uploadedAt: Date; // Upload timestamp
  tags: string[]; // Associated tags
  size: number; // File size in bytes
}
```

**TagStats Interface:**

```typescript
interface TagStats {
  name: string; // Tag name
  count: number; // Number of photos with this tag
}
```

### 4.3 Validation Rules (TR-003)

**File Validation:**

- **Size:** 0 < size <= 5,242,880 bytes (5MB)
- **Type:** image/jpeg, image/png, image/webp
- **Filename:** 1-255 characters

**Tag Validation:**

- **Length:** 2-30 characters
- **Pattern:** /^[a-z0-9-]+$/
- **Count:** 0-20 tags per photo
- **Uniqueness:** No duplicate tags on same photo

### 4.4 Service Architecture (TR-004)

**PhotoService Responsibilities:**

- Maintain reactive photo collection (signal-based)
- Compute tag statistics (computed signal)
- Provide CRUD operations with validation
- Handle LocalStorage persistence
- Manage error scenarios

**Component Responsibilities:**

- PhotoUploadComponent: Handle file input, validation, tag entry
- PhotoListComponent: Display grid, filtering, deletion
- App Component: Coordinate layout and navigation

## 5. User Interface Requirements

### 5.1 Upload Section (UI-001)

- Prominent drag-and-drop zone with visual feedback
- File input button as alternative
- Clear constraint messaging (size, type limits)
- File preview with metadata
- Tag input with real-time validation
- Visual tag list with removal capability
- Upload button (enabled only when valid)
- Success/error message display

### 5.2 Gallery Section (UI-002)

- Responsive grid layout (auto-fill, min 280px columns)
- Photo cards with:
  - Image (4:3 aspect ratio)
  - Filename (truncated with tooltip)
  - Upload date and file size
  - Tag list (clickable for filtering)
  - Delete button (visible on hover)
- Empty state with helpful messaging
- Filtered state with active filter indicator

### 5.3 Filter Sidebar (UI-003)

- Sticky positioning (follows scroll)
- Checkbox list of all tags
- Photo count badge for each tag
- Clear filters button
- Empty state for no tags

### 5.4 Color Scheme (UI-004)

- **Primary:** #007bff (blue)
- **Secondary:** #6c757d (gray)
- **Success:** #28a745 (green)
- **Danger:** #dc3545 (red)
- **Warning:** #ffc107 (yellow)
- **Background:** #f5f5f5 (light gray)

## 6. Error Handling

### 6.1 Validation Errors (EH-001)

Display inline error messages for:

- File too large
- Invalid file type
- Filename too long
- Tag validation failures
- Tag count exceeded
- Duplicate tags

### 6.2 System Errors (EH-002)

Handle gracefully:

- LocalStorage quota exceeded
- Corrupted LocalStorage data
- Failed photo deletion
- File reading errors

### 6.3 User Guidance (EH-003)

Provide clear messaging:

- Constraint explanations
- Validation feedback
- Success confirmations
- Empty states with next steps

## 7. Testing Requirements

### 7.1 Unit Tests (TEST-001)

**Target Coverage:** >80%

**PhotoService Tests:**

- CRUD operations (add, remove, update)
- Validation enforcement
- Tag statistics computation
- LocalStorage persistence
- Error handling

**Component Tests:**

- File upload flow
- Tag management
- Filtering logic
- Deletion confirmation
- Empty state rendering

### 7.2 Integration Tests (TEST-002)

- Upload to gallery flow
- Filter and clear flow
- Delete and persist flow

### 7.3 Accessibility Tests (TEST-003)

- Keyboard navigation
- Screen reader compatibility
- Focus management
- ARIA labels

## 8. Success Criteria

### 8.1 Completion Criteria

- ✅ All functional requirements implemented
- ✅ All acceptance criteria met
- ✅ >80% test coverage achieved
- ✅ Zero ESLint errors
- ✅ WCAG 2.1 AA compliance verified
- ✅ All browsers supported and tested
- ✅ Documentation complete

### 8.2 Quality Metrics

- **Type Safety:** 100% (no 'any' types)
- **Test Coverage:** >80%
- **Bundle Size:** <500KB (uncompressed)
- **Lighthouse Score:** >90 (all categories)

## 9. Assumptions and Dependencies

### 9.1 Assumptions

- Users have modern browsers with LocalStorage support
- Photos are for personal use (no sharing features needed)
- Client-side only (no server required)
- Single user per browser profile

### 9.2 Dependencies

- @angular/core: ^19.0.0
- @angular/common: ^19.0.0
- @angular/forms: ^19.0.0
- TypeScript: ^5.0.0
- Nx: ^21.4.1
- Vitest: (as configured by Nx)

## 10. Open Questions and Decisions

### 10.1 Resolved Decisions

- **Q:** Use Vite or esbuild?
- **A:** esbuild (Nx Angular default, better integration)

- **Q:** Signal-based or RxJS state management?
- **A:** Signals (modern Angular pattern, simpler)

- **Q:** Inline styles or CSS files?
- **A:** Inline component styles (component encapsulation)

### 10.2 Future Considerations

- Backend API integration
- Cloud storage support
- Image optimization/thumbnails
- Batch operations
- Export/import functionality
- Photo editing capabilities
