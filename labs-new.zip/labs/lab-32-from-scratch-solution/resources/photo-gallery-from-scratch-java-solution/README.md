# Photo Gallery API — Java / Spring Boot

Reference implementation for [Lab 32](../../../lab-32-from-scratch/README.md), Java track.

Planning artifacts: [`../java/SPECIFICATION.md`](../java/SPECIFICATION.md) ·
[`../java/IMPLEMENTATION_PLAN.md`](../java/IMPLEMENTATION_PLAN.md) ·
[`../java/TASKS.md`](../java/TASKS.md)

## Requirements

JDK 17 or later. Maven comes via the wrapper.

## Run

```bash
./mvnw spring-boot:run        # mvnw.cmd on Windows — http://localhost:42322
```

## Test

```bash
./mvnw test                   # 47 tests
```

## Endpoints

| Method   | Path               | Request                            | Success            | Errors |
| -------- | ------------------ | ---------------------------------- | ------------------ | ------ |
| `POST`   | `/api/photos`      | multipart: `file`, optional `tags` | `201` + Photo      | `422`  |
| `GET`    | `/api/photos`      | optional `?tag=`                   | `200` + Photo[]    | —      |
| `GET`    | `/api/photos/{id}` | —                                  | `200` + Photo      | `404`  |
| `DELETE` | `/api/photos/{id}` | —                                  | `204` no body      | `404`  |
| `GET`    | `/api/tags`        | —                                  | `200` + TagStats[] | —      |

Errors use RFC 9457 `ProblemDetail`.

```bash
curl -F file=@photo.png -F tags="beach, summer" http://localhost:42322/api/photos
curl "http://localhost:42322/api/photos?tag=beach"
curl http://localhost:42322/api/tags
```

## Architecture

```
com/sfeir/photogallery/
├── config/GalleryProperties.java   @ConfigurationProperties, gallery.*
├── model/Photo.java                record, validated in the constructor
├── repository/PhotoRepository.java atomic writes, tolerant reads
├── service/PhotoService.java       the business rules live here
└── web/                            thin controller + @RestControllerAdvice
```

Each layer depends only on the one below. 32 of the 47 tests run without booting Spring, because the
rules are in the service rather than the controller.

## Configuration

Every key is in `application.properties`:

| Key                          | Default              |
| ---------------------------- | -------------------- |
| `server.port`                | `42322`              |
| `gallery.storage-path`       | `photos_data.json`   |
| `gallery.max-file-size`      | `2097152` (2 MiB)    |
| `gallery.max-tags`           | `10`                 |
| `gallery.max-tag-length`     | `32`                 |
| `gallery.allowed-mime-types` | png, jpeg, gif, webp |
