package com.sfeir.photogallery.repository;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatCode;

import com.sfeir.photogallery.model.Photo;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.stream.Stream;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

class PhotoRepositoryTest {

    @TempDir
    Path tempDir;

    Path galleryPath;
    PhotoRepository repository;

    @BeforeEach
    void setUp() {
        galleryPath = tempDir.resolve("photos_data.json");
        repository = new PhotoRepository(galleryPath);
    }

    static Photo photo(String id) {
        return new Photo(
                id,
                id + ".png",
                "data:image/png;base64,iVBORw0KGgo=",
                Instant.now().truncatedTo(ChronoUnit.MILLIS),
                42L,
                List.of("beach"));
    }

    @Test
    @DisplayName("a missing file is an empty gallery")
    void missingFileIsEmpty() {
        assertThat(repository.findAll()).isEmpty();
    }

    @Test
    @DisplayName("reads back what was written")
    void roundTrips() {
        Photo saved = photo("abc");
        repository.saveAll(List.of(saved));

        assertThat(repository.findAll()).containsExactly(saved);
    }

    @Test
    @DisplayName("corrupt JSON does not raise")
    void corruptJsonDoesNotRaise() throws IOException {
        Files.writeString(galleryPath, "{ not json");

        assertThat(repository.findAll()).isEmpty();
    }

    @Test
    @DisplayName("a non-list payload does not raise")
    void nonListDoesNotRaise() throws IOException {
        Files.writeString(galleryPath, "{\"id\": \"x\"}");

        assertThat(repository.findAll()).isEmpty();
    }

    @Test
    @DisplayName("one bad record does not hide the good ones")
    void skipsOnlyTheBadRecord() throws IOException {
        repository.saveAll(List.of(photo("good")));
        String json = Files.readString(galleryPath);
        // Splice a broken record in right after the opening bracket.
        String withBroken = "[ { \"id\": \"broken\" }," + json.substring(json.indexOf('[') + 1);
        Files.writeString(galleryPath, withBroken);

        assertThat(repository.findAll()).extracting(Photo::id).containsExactly("good");
    }

    @Test
    @DisplayName("creates parent directories")
    void createsParents() {
        PhotoRepository nested = new PhotoRepository(tempDir.resolve("deep/nested/photos.json"));

        nested.saveAll(List.of(photo("abc")));

        assertThat(nested.path()).exists();
    }

    @Test
    @DisplayName("leaves no temporary files behind")
    void leavesNoTempFiles() throws IOException {
        repository.saveAll(List.of(photo("abc")));

        try (Stream<Path> files = Files.list(tempDir)) {
            assertThat(files.map(p -> p.getFileName().toString()))
                    .noneMatch(name -> name.startsWith(".photos-"));
        }
    }

    @Test
    @DisplayName("replaces the previous content")
    void replacesPreviousContent() {
        repository.saveAll(List.of(photo("first")));
        repository.saveAll(List.of(photo("second")));

        assertThat(repository.findAll()).extracting(Photo::id).containsExactly("second");
    }

    @Test
    @DisplayName("deleteAll removes the file")
    void deleteAllRemovesTheFile() {
        repository.saveAll(List.of(photo("abc")));

        repository.deleteAll();

        assertThat(repository.findAll()).isEmpty();
    }

    @Test
    @DisplayName("deleteAll is safe when nothing was stored")
    void deleteAllIsSafeWhenEmpty() {
        assertThatCode(repository::deleteAll).doesNotThrowAnyException();
    }
}
