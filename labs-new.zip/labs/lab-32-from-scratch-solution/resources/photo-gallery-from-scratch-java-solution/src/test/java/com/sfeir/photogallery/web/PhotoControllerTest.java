package com.sfeir.photogallery.web;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.multipart;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sfeir.photogallery.service.PhotoService;
import java.nio.file.Path;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;

@SpringBootTest
@AutoConfigureMockMvc
class PhotoControllerTest {

    static final byte[] PNG = {(byte) 0x89, 'P', 'N', 'G', 1, 2, 3, 4};

    @TempDir
    static Path tempDir;

    @DynamicPropertySource
    static void galleryPath(DynamicPropertyRegistry registry) {
        registry.add("gallery.storage-path", () -> tempDir.resolve("photos_data.json").toString());
    }

    @Autowired
    MockMvc mvc;

    @Autowired
    PhotoService photos;

    @Autowired
    ObjectMapper mapper;

    @AfterEach
    void clearGallery() {
        photos.listPhotos(null).forEach(photo -> photos.deletePhoto(photo.id()));
    }

    ResultActions upload(String filename, String contentType, String tags) throws Exception {
        var request = multipart("/api/photos").file(new MockMultipartFile("file", filename, contentType, PNG));
        if (tags != null) {
            request.param("tags", tags);
        }
        return mvc.perform(request);
    }

    JsonNode body(ResultActions actions) throws Exception {
        return mapper.readTree(actions.andReturn().getResponse().getContentAsString());
    }

    @Nested
    @DisplayName("POST /api/photos")
    class Upload {

        @Test
        @DisplayName("returns 201 and the created photo")
        void returns201() throws Exception {
            JsonNode created = body(upload("holiday.png", "image/png", "beach, summer")
                    .andExpect(status().isCreated()));

            assertThat(created.get("filename").asText()).isEqualTo("holiday.png");
            assertThat(created.get("size").asLong()).isEqualTo(PNG.length);
            assertThat(created.get("dataUrl").asText()).startsWith("data:image/png;base64,");
            assertThat(created.get("tags")).hasSize(2);
        }

        @Test
        @DisplayName("uses the agreed field names")
        void usesAgreedFieldNames() throws Exception {
            JsonNode created = body(upload("holiday.png", "image/png", null));

            assertThat(created.fieldNames()).toIterable()
                    .containsExactlyInAnyOrder("id", "filename", "dataUrl", "uploadedAt", "size", "tags");
        }

        @Test
        @DisplayName("rejects an unsupported type with 422")
        void rejectsUnsupportedType() throws Exception {
            upload("doc.pdf", "application/pdf", null)
                    .andExpect(status().isUnprocessableEntity())
                    .andExpect(jsonPath("$.detail").value(org.hamcrest.Matchers.containsString("unsupported")));
        }

        @Test
        @DisplayName("rejects an over-long tag with 422")
        void rejectsOverLongTag() throws Exception {
            upload("a.png", "image/png", "x".repeat(33)).andExpect(status().isUnprocessableEntity());
        }

        @Test
        @DisplayName("accepts an upload with no tags")
        void acceptsNoTags() throws Exception {
            JsonNode created = body(upload("a.png", "image/png", null).andExpect(status().isCreated()));

            assertThat(created.get("tags")).isEmpty();
        }

        @Test
        @DisplayName("requires the file part")
        void requiresFilePart() throws Exception {
            mvc.perform(multipart("/api/photos").param("tags", "beach"))
                    .andExpect(status().isBadRequest());
        }
    }

    @Nested
    @DisplayName("GET /api/photos")
    class ListPhotos {

        @Test
        @DisplayName("is empty to begin with")
        void emptyToBeginWith() throws Exception {
            mvc.perform(get("/api/photos")).andExpect(status().isOk()).andExpect(jsonPath("$").isEmpty());
        }

        @Test
        @DisplayName("filters by tag")
        void filtersByTag() throws Exception {
            upload("beach.png", "image/png", "beach");
            upload("city.png", "image/png", "city");

            mvc.perform(get("/api/photos").param("tag", "beach"))
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$.length()").value(1))
                    .andExpect(jsonPath("$[0].filename").value("beach.png"));
        }

        @Test
        @DisplayName("an unknown tag returns an empty list")
        void unknownTagReturnsEmpty() throws Exception {
            upload("beach.png", "image/png", "beach");

            mvc.perform(get("/api/photos").param("tag", "mountains")).andExpect(jsonPath("$").isEmpty());
        }
    }

    @Nested
    @DisplayName("GET /api/photos/{id}")
    class GetPhoto {

        @Test
        @DisplayName("returns the photo")
        void returnsThePhoto() throws Exception {
            String id = body(upload("a.png", "image/png", null)).get("id").asText();

            mvc.perform(get("/api/photos/" + id))
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$.id").value(id));
        }

        @Test
        @DisplayName("returns 404 for an unknown id")
        void returns404() throws Exception {
            mvc.perform(get("/api/photos/nope")).andExpect(status().isNotFound());
        }
    }

    @Nested
    @DisplayName("DELETE /api/photos/{id}")
    class DeletePhoto {

        @Test
        @DisplayName("returns 204 and removes the photo")
        void returns204() throws Exception {
            String id = body(upload("a.png", "image/png", null)).get("id").asText();

            mvc.perform(delete("/api/photos/" + id)).andExpect(status().isNoContent());
            mvc.perform(get("/api/photos")).andExpect(jsonPath("$").isEmpty());
        }

        @Test
        @DisplayName("returns 404 for an unknown id")
        void returns404() throws Exception {
            mvc.perform(delete("/api/photos/nope")).andExpect(status().isNotFound());
        }
    }

    @Nested
    @DisplayName("GET /api/tags")
    class Tags {

        @Test
        @DisplayName("is empty to begin with")
        void emptyToBeginWith() throws Exception {
            mvc.perform(get("/api/tags")).andExpect(jsonPath("$").isEmpty());
        }

        @Test
        @DisplayName("counts each tag, most used first")
        void countsEachTag() throws Exception {
            upload("a.png", "image/png", "beach, summer");
            upload("b.png", "image/png", "beach");

            mvc.perform(get("/api/tags"))
                    .andExpect(jsonPath("$[0].name").value("beach"))
                    .andExpect(jsonPath("$[0].count").value(2))
                    .andExpect(jsonPath("$[1].name").value("summer"))
                    .andExpect(jsonPath("$[1].count").value(1));
        }
    }
}
