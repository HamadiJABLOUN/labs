package com.sfeir.photogallery.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import com.sfeir.photogallery.config.GalleryProperties;
import com.sfeir.photogallery.model.InvalidPhotoException;
import com.sfeir.photogallery.model.Photo;
import com.sfeir.photogallery.model.PhotoNotFoundException;
import com.sfeir.photogallery.model.TagStats;
import com.sfeir.photogallery.repository.PhotoRepository;
import java.nio.file.Path;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

class PhotoServiceTest {

    static final byte[] PNG = {(byte) 0x89, 'P', 'N', 'G', 1, 2, 3, 4};

    @TempDir
    Path tempDir;

    PhotoService service;
    GalleryProperties properties;

    @BeforeEach
    void setUp() {
        properties = new GalleryProperties(
                tempDir.resolve("photos_data.json").toString(),
                2 * 1024 * 1024,
                10,
                32,
                List.of("image/png", "image/jpeg"));
        service = new PhotoService(new PhotoRepository(properties), properties);
    }

    Photo add(String filename, String tags) {
        return service.addPhoto(PNG, filename, "image/png", tags);
    }

    @Nested
    @DisplayName("addPhoto")
    class AddPhoto {

        @Test
        @DisplayName("stores a valid upload")
        void storesValidUpload() {
            Photo photo = add("holiday.png", "beach");

            assertThat(photo.filename()).isEqualTo("holiday.png");
            assertThat(photo.tags()).containsExactly("beach");
            assertThat(photo.size()).isEqualTo(PNG.length);
            assertThat(service.listPhotos(null)).containsExactly(photo);
        }

        @Test
        @DisplayName("assigns a unique id")
        void assignsUniqueId() {
            assertThat(add("a.png", null).id()).isNotEqualTo(add("b.png", null).id());
        }

        @Test
        @DisplayName("encodes the image as a data URL")
        void encodesAsDataUrl() {
            assertThat(add("a.png", null).dataUrl()).startsWith("data:image/png;base64,");
        }

        @Test
        @DisplayName("rejects an empty upload")
        void rejectsEmptyUpload() {
            assertThatThrownBy(() -> service.addPhoto(new byte[0], "a.png", "image/png", null))
                    .isInstanceOf(InvalidPhotoException.class)
                    .hasMessageContaining("no file");
        }

        @Test
        @DisplayName("rejects an oversized upload")
        void rejectsOversizedUpload() {
            byte[] tooBig = new byte[(int) properties.maxFileSize() + 1];

            assertThatThrownBy(() -> service.addPhoto(tooBig, "a.png", "image/png", null))
                    .isInstanceOf(InvalidPhotoException.class)
                    .hasMessageContaining("maximum");
        }

        @Test
        @DisplayName("rejects an unsupported type")
        void rejectsUnsupportedType() {
            assertThatThrownBy(() -> service.addPhoto(PNG, "doc.pdf", "application/pdf", null))
                    .isInstanceOf(InvalidPhotoException.class)
                    .hasMessageContaining("unsupported");
        }

        @Test
        @DisplayName("rejects a blank filename")
        void rejectsBlankFilename() {
            assertThatThrownBy(() -> service.addPhoto(PNG, "  ", "image/png", null))
                    .isInstanceOf(InvalidPhotoException.class)
                    .hasMessageContaining("filename");
        }

        @Test
        @DisplayName("rejects an over-long tag")
        void rejectsOverLongTag() {
            assertThatThrownBy(() -> add("a.png", "x".repeat(33)))
                    .isInstanceOf(InvalidPhotoException.class)
                    .hasMessageContaining("exceeds");
        }

        @Test
        @DisplayName("a rejected upload leaves the gallery untouched")
        void rejectedUploadLeavesGalleryUntouched() {
            add("kept.png", null);

            assertThatThrownBy(() -> service.addPhoto(PNG, "doc.pdf", "application/pdf", null))
                    .isInstanceOf(InvalidPhotoException.class);

            assertThat(service.listPhotos(null)).hasSize(1);
        }
    }

    @Nested
    @DisplayName("listPhotos")
    class ListPhotos {

        @Test
        @DisplayName("is empty to begin with")
        void emptyToBeginWith() {
            assertThat(service.listPhotos(null)).isEmpty();
        }

        @Test
        @DisplayName("returns newest first")
        void returnsNewestFirst() throws InterruptedException {
            Photo first = add("first.png", null);
            Thread.sleep(5);
            Photo second = add("second.png", null);

            assertThat(service.listPhotos(null))
                    .extracting(Photo::filename)
                    .containsExactly(second.filename(), first.filename());
        }

        @Test
        @DisplayName("filters by tag")
        void filtersByTag() {
            add("beach.png", "beach");
            add("city.png", "city");

            assertThat(service.listPhotos("beach")).extracting(Photo::filename).containsExactly("beach.png");
        }

        @Test
        @DisplayName("the tag filter is case-insensitive")
        void tagFilterIsCaseInsensitive() {
            add("beach.png", "Beach");

            assertThat(service.listPhotos("BEACH")).hasSize(1);
        }

        @Test
        @DisplayName("an unknown tag matches nothing")
        void unknownTagMatchesNothing() {
            add("beach.png", "beach");

            assertThat(service.listPhotos("mountains")).isEmpty();
        }
    }

    @Nested
    @DisplayName("getPhoto")
    class GetPhoto {

        @Test
        @DisplayName("returns the photo")
        void returnsThePhoto() {
            Photo photo = add("a.png", null);

            assertThat(service.getPhoto(photo.id())).isEqualTo(photo);
        }

        @Test
        @DisplayName("raises on an unknown id")
        void raisesOnUnknownId() {
            assertThatThrownBy(() -> service.getPhoto("nope")).isInstanceOf(PhotoNotFoundException.class);
        }
    }

    @Nested
    @DisplayName("deletePhoto")
    class DeletePhoto {

        @Test
        @DisplayName("removes an existing photo")
        void removesExistingPhoto() {
            Photo photo = add("a.png", null);

            service.deletePhoto(photo.id());

            assertThat(service.listPhotos(null)).isEmpty();
        }

        @Test
        @DisplayName("raises on an unknown id")
        void raisesOnUnknownId() {
            assertThatThrownBy(() -> service.deletePhoto("nope")).isInstanceOf(PhotoNotFoundException.class);
        }

        @Test
        @DisplayName("leaves the other photos alone")
        void leavesOthersAlone() {
            Photo keep = add("keep.png", null);
            Photo drop = add("drop.png", null);

            service.deletePhoto(drop.id());

            assertThat(service.listPhotos(null)).extracting(Photo::filename).containsExactly(keep.filename());
        }
    }

    @Nested
    @DisplayName("tagStats")
    class TagStatistics {

        @Test
        @DisplayName("is empty to begin with")
        void emptyToBeginWith() {
            assertThat(service.tagStats()).isEmpty();
        }

        @Test
        @DisplayName("counts each tag, most used first")
        void countsEachTag() {
            add("a.png", "beach, summer");
            add("b.png", "beach");

            assertThat(service.tagStats())
                    .extracting(TagStats::name, TagStats::count)
                    .containsExactly(org.assertj.core.api.Assertions.tuple("beach", 2L),
                            org.assertj.core.api.Assertions.tuple("summer", 1L));
        }

        @Test
        @DisplayName("breaks ties alphabetically")
        void breaksTiesAlphabetically() {
            add("a.png", "zebra, alpha");

            assertThat(service.tagStats()).extracting(TagStats::name).containsExactly("alpha", "zebra");
        }
    }
}
