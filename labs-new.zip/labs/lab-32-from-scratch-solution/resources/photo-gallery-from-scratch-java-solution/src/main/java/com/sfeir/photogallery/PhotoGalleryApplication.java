package com.sfeir.photogallery;

import com.sfeir.photogallery.config.GalleryProperties;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;

/** Application entry point. Bootstrapping only. */
@SpringBootApplication
@EnableConfigurationProperties(GalleryProperties.class)
public class PhotoGalleryApplication {

    public static void main(String[] args) {
        SpringApplication.run(PhotoGalleryApplication.class, args);
    }
}
