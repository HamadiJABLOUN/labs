package com.sfeir.photogallery.web;

import com.sfeir.photogallery.model.InvalidPhotoException;
import com.sfeir.photogallery.model.PhotoNotFoundException;
import java.time.Instant;
import org.springframework.http.HttpStatus;
import org.springframework.http.ProblemDetail;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

/**
 * Turns domain exceptions into HTTP responses.
 *
 * <p>Keeping this in one place is what lets the controller stay free of
 * try/catch: a rule violation is thrown where it is detected and mapped here.
 */
@RestControllerAdvice
public class ApiExceptionHandler {

    /** A rule violation becomes 422, with the reason in {@code detail}. */
    @ExceptionHandler(InvalidPhotoException.class)
    public ProblemDetail onInvalidPhoto(InvalidPhotoException exception) {
        return problem(HttpStatus.UNPROCESSABLE_ENTITY, "Invalid photo", exception.getMessage());
    }

    /** An unknown id becomes 404. */
    @ExceptionHandler(PhotoNotFoundException.class)
    public ProblemDetail onPhotoNotFound(PhotoNotFoundException exception) {
        return problem(HttpStatus.NOT_FOUND, "Photo not found", exception.getMessage());
    }

    private static ProblemDetail problem(HttpStatus status, String title, String detail) {
        ProblemDetail body = ProblemDetail.forStatusAndDetail(status, detail);
        body.setTitle(title);
        body.setProperty("timestamp", Instant.now());
        return body;
    }
}
