package com.sfeir.photogallery.web;

import com.sfeir.photogallery.model.InvalidPhotoException;
import com.sfeir.photogallery.model.Photo;
import com.sfeir.photogallery.model.TagStats;
import com.sfeir.photogallery.service.PhotoService;
import java.io.IOException;
import java.util.List;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

/** HTTP layer. Thin by design: all rules live in {@link PhotoService}. */
@RestController
@RequestMapping("/api")
public class PhotoController {

    private final PhotoService photos;

    public PhotoController(PhotoService photos) {
        this.photos = photos;
    }

    /** Lists the gallery, newest first, optionally filtered by tag. */
    @GetMapping("/photos")
    public List<Photo> listPhotos(@RequestParam(required = false) String tag) {
        return photos.listPhotos(tag);
    }

    /** Returns a single photo, or 404 if the id is unknown. */
    @GetMapping("/photos/{id}")
    public Photo getPhoto(@PathVariable String id) {
        return photos.getPhoto(id);
    }

    /** Accepts an uploaded image, or explains why it was rejected. */
    @PostMapping(value = "/photos", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @ResponseStatus(HttpStatus.CREATED)
    public Photo uploadPhoto(
            @RequestParam("file") MultipartFile file,
            @RequestParam(value = "tags", required = false) String tags) {
        try {
            return photos.addPhoto(file.getBytes(), file.getOriginalFilename(), file.getContentType(), tags);
        } catch (IOException e) {
            throw new InvalidPhotoException("could not read the uploaded file");
        }
    }

    /** Deletes a photo, or 404 if the id is unknown. */
    @DeleteMapping("/photos/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deletePhoto(@PathVariable String id) {
        photos.deletePhoto(id);
    }

    /** Returns every tag in use with its photo count, most used first. */
    @GetMapping("/tags")
    public List<TagStats> listTags() {
        return photos.tagStats();
    }
}
