package com.sfeir.photogallery.service;

import com.sfeir.photogallery.config.GalleryProperties;
import com.sfeir.photogallery.model.InvalidPhotoException;
import com.sfeir.photogallery.model.Photo;
import com.sfeir.photogallery.model.PhotoNotFoundException;
import com.sfeir.photogallery.model.TagStats;
import com.sfeir.photogallery.repository.PhotoRepository;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import org.springframework.stereotype.Service;

/**
 * Business logic for the gallery.
 *
 * <p>The controller stays thin: every rule about what may enter the gallery
 * lives here.
 */
@Service
public class PhotoService {

    private final PhotoRepository repository;
    private final GalleryProperties properties;

    public PhotoService(PhotoRepository repository, GalleryProperties properties) {
        this.repository = repository;
        this.properties = properties;
    }

    /**
     * Returns the gallery, newest first, optionally filtered by one tag.
     *
     * @param tag if non-null, only photos carrying this tag are returned; the
     *            comparison is case-insensitive, matching how tags are stored
     * @return the matching photos, never {@code null}
     */
    public List<Photo> listPhotos(String tag) {
        List<Photo> photos = repository.findAll();
        photos.sort(Comparator.comparing(Photo::uploadedAt).reversed());

        if (tag == null) {
            return photos;
        }

        String needle = tag.trim().toLowerCase(Locale.ROOT);
        return photos.stream().filter(photo -> photo.tags().contains(needle)).toList();
    }

    /**
     * Returns a single photo.
     *
     * @param photoId the id to look up
     * @return the photo
     * @throws PhotoNotFoundException if no photo carries this id
     */
    public Photo getPhoto(String photoId) {
        return repository.findAll().stream()
                .filter(photo -> photo.id().equals(photoId))
                .findFirst()
                .orElseThrow(() -> new PhotoNotFoundException(photoId));
    }

    /**
     * Validates, encodes, and stores an uploaded image.
     *
     * @param content     the raw bytes of the uploaded file
     * @param filename    the original file name
     * @param contentType the MIME type reported by the client
     * @param tags        the raw comma-separated tag string, possibly {@code null}
     * @return the stored photo
     * @throws InvalidPhotoException if the upload is empty, too large, of an
     *                               unsupported type, or carries invalid tags
     */
    public Photo addPhoto(byte[] content, String filename, String contentType, String tags) {
        if (content == null || content.length == 0) {
            throw new InvalidPhotoException("no file was uploaded");
        }
        if (content.length > properties.maxFileSize()) {
            throw new InvalidPhotoException(
                    "file is " + content.length + " bytes, the maximum is " + properties.maxFileSize());
        }
        if (contentType == null || !properties.allowedMimeTypes().contains(contentType)) {
            throw new InvalidPhotoException("unsupported file type: " + contentType);
        }
        if (filename == null || filename.isBlank()) {
            throw new InvalidPhotoException("filename must not be empty");
        }

        Photo photo = new Photo(
                UUID.randomUUID().toString().replace("-", ""),
                filename,
                "data:" + contentType + ";base64," + Base64.getEncoder().encodeToString(content),
                // Truncated to milliseconds so a photo survives the JSON round-trip unchanged.
                Instant.now().truncatedTo(ChronoUnit.MILLIS),
                content.length,
                Photo.parseTags(tags, properties.maxTags(), properties.maxTagLength()));

        List<Photo> photos = new ArrayList<>(repository.findAll());
        photos.add(photo);
        repository.saveAll(photos);
        return photo;
    }

    /**
     * Removes a photo by id.
     *
     * @param photoId the id to remove
     * @throws PhotoNotFoundException if no photo carries this id
     */
    public void deletePhoto(String photoId) {
        List<Photo> photos = repository.findAll();
        List<Photo> remaining = photos.stream()
                .filter(photo -> !photo.id().equals(photoId))
                .toList();

        if (remaining.size() == photos.size()) {
            throw new PhotoNotFoundException(photoId);
        }

        repository.saveAll(new ArrayList<>(remaining));
    }

    /**
     * Returns every tag in use with its photo count, most used first.
     *
     * <p>Ties are broken alphabetically, so the output is deterministic.
     *
     * @return the tag statistics, never {@code null}
     */
    public List<TagStats> tagStats() {
        Map<String, Long> counts = new LinkedHashMap<>();
        for (Photo photo : repository.findAll()) {
            for (String tag : photo.tags()) {
                counts.merge(tag, 1L, Long::sum);
            }
        }

        return counts.entrySet().stream()
                .map(entry -> new TagStats(entry.getKey(), entry.getValue()))
                .sorted(Comparator.comparingLong(TagStats::count).reversed()
                        .thenComparing(TagStats::name))
                .toList();
    }
}
