package com.sfeir.photogallery.config;

import java.util.List;
import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * Externalised gallery configuration, bound from the {@code gallery.*} keys.
 *
 * @param storagePath      where the gallery is persisted
 * @param maxFileSize      largest accepted upload, in bytes
 * @param maxTags          most tags allowed on one photo
 * @param maxTagLength     longest accepted tag
 * @param allowedMimeTypes MIME types the gallery accepts
 */
@ConfigurationProperties(prefix = "gallery")
public record GalleryProperties(
        String storagePath,
        long maxFileSize,
        int maxTags,
        int maxTagLength,
        List<String> allowedMimeTypes) {
}
