package com.sfeir.photogallery.model;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.time.Instant;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.regex.Pattern;

/**
 * A stored photo.
 *
 * <p>Validation happens in the constructor, so a {@code Photo} that exists is a
 * {@code Photo} that passed validation.
 *
 * @param id         unique identifier, assigned at upload time
 * @param filename   the original file name, as submitted
 * @param dataUrl    the image encoded as a base64 data URL
 * @param uploadedAt upload timestamp
 * @param size       size of the decoded image in bytes
 * @param tags       normalised, de-duplicated tags
 */
public record Photo(
        String id,
        String filename,
        String dataUrl,
        Instant uploadedAt,
        long size,
        List<String> tags) {

    private static final Pattern DATA_URL = Pattern.compile("^data:[\\w.+-]+/[\\w.+-]+;base64,.*");

    @JsonCreator
    public Photo(
            @JsonProperty("id") String id,
            @JsonProperty("filename") String filename,
            @JsonProperty("dataUrl") String dataUrl,
            @JsonProperty("uploadedAt") Instant uploadedAt,
            @JsonProperty("size") long size,
            @JsonProperty("tags") List<String> tags) {
        if (id == null || id.isBlank()) {
            throw new InvalidPhotoException("id must not be empty");
        }
        if (filename == null || filename.isBlank()) {
            throw new InvalidPhotoException("filename must not be empty");
        }
        if (dataUrl == null || !DATA_URL.matcher(dataUrl).matches()) {
            throw new InvalidPhotoException("dataUrl must be a base64 data URL");
        }
        if (uploadedAt == null) {
            throw new InvalidPhotoException("uploadedAt must not be null");
        }
        if (size <= 0) {
            throw new InvalidPhotoException("size must be positive");
        }
        this.id = id;
        this.filename = filename;
        this.dataUrl = dataUrl;
        this.uploadedAt = uploadedAt;
        this.size = size;
        this.tags = List.copyOf(Objects.requireNonNullElse(tags, List.of()));
    }

    /**
     * Normalises a comma-separated tag string into unique, trimmed, lowercase tags.
     *
     * <p>Empty segments are dropped and insertion order is preserved.
     *
     * @param raw          the raw input, possibly {@code null}
     * @param maxTags      most tags allowed on one photo
     * @param maxTagLength longest accepted tag
     * @return the normalised tags, never {@code null}
     * @throws InvalidPhotoException if a tag is too long, or there are too many
     */
    public static List<String> parseTags(String raw, int maxTags, int maxTagLength) {
        if (raw == null || raw.isBlank()) {
            return List.of();
        }

        LinkedHashSet<String> tags = new LinkedHashSet<>();
        for (String chunk : raw.split(",")) {
            String tag = chunk.trim().toLowerCase(Locale.ROOT);
            if (tag.isEmpty()) {
                continue;
            }
            if (tag.length() > maxTagLength) {
                throw new InvalidPhotoException(
                        "tag " + tag + " exceeds " + maxTagLength + " characters");
            }
            tags.add(tag);
        }

        if (tags.size() > maxTags) {
            throw new InvalidPhotoException("at most " + maxTags + " tags are allowed");
        }
        return List.copyOf(tags);
    }
}
