package com.sfeir.photogallery.model;

/** Raised when a photo id does not exist. */
public class PhotoNotFoundException extends RuntimeException {

    public PhotoNotFoundException(String id) {
        super("No photo with id " + id);
    }
}
