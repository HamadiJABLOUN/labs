package com.sfeir.photogallery.repository;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.sfeir.photogallery.config.GalleryProperties;
import com.sfeir.photogallery.model.Photo;
import java.io.IOException;
import java.io.UncheckedIOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 * Reads and writes the gallery to a JSON file.
 *
 * <p>The path comes from configuration. Reads never throw on malformed data: a
 * corrupt record is logged and skipped, so one bad entry cannot take the whole
 * gallery down.
 */
@Repository
public class PhotoRepository {

    private static final Logger log = LoggerFactory.getLogger(PhotoRepository.class);

    private final Path path;
    private final ObjectMapper mapper;

    @Autowired
    public PhotoRepository(GalleryProperties properties) {
        this(Path.of(properties.storagePath()));
    }

    /** Test seam: lets a test point the repository at a temporary directory. */
    PhotoRepository(Path path) {
        this.path = path;
        this.mapper = new ObjectMapper().registerModule(new JavaTimeModule());
    }

    /** @return the file backing this repository. */
    public Path path() {
        return path;
    }

    /**
     * Returns every valid photo on disk, in insertion order.
     *
     * <p>A missing file yields an empty gallery; a corrupt file, or a record that
     * fails validation, is logged and skipped.
     */
    public List<Photo> findAll() {
        if (!Files.exists(path)) {
            return new ArrayList<>();
        }

        List<JsonNode> records;
        try {
            records = mapper.readValue(Files.readAllBytes(path), new TypeReference<List<JsonNode>>() {});
        } catch (IOException e) {
            log.error("Could not read gallery at {}", path, e);
            return new ArrayList<>();
        }

        List<Photo> photos = new ArrayList<>();
        for (JsonNode record : records) {
            try {
                photos.add(mapper.treeToValue(record, Photo.class));
            } catch (Exception e) {
                log.warn("Skipping malformed record in {}: {}", path, e.getMessage());
            }
        }
        return photos;
    }

    /**
     * Persists the gallery atomically.
     *
     * <p>Writes to a temporary file in the same directory, then moves it over the
     * target, so an interrupted write cannot truncate the gallery.
     *
     * @param photos the gallery to persist
     * @throws UncheckedIOException if the gallery cannot be written
     */
    public void saveAll(List<Photo> photos) {
        Path parent = path.toAbsolutePath().getParent();
        Path temp = null;
        try {
            Files.createDirectories(parent);
            temp = Files.createTempFile(parent, ".photos-", ".tmp");
            mapper.writerWithDefaultPrettyPrinter().writeValue(temp.toFile(), photos);
            Files.move(temp, path, StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException e) {
            if (temp != null) {
                try {
                    Files.deleteIfExists(temp);
                } catch (IOException suppressed) {
                    e.addSuppressed(suppressed);
                }
            }
            log.error("Could not write gallery to {}", path, e);
            throw new UncheckedIOException("Could not write gallery to " + path, e);
        }
    }

    /** Deletes the gallery file if it exists. */
    public void deleteAll() {
        try {
            Files.deleteIfExists(path);
        } catch (IOException e) {
            throw new UncheckedIOException("Could not clear gallery at " + path, e);
        }
    }
}
