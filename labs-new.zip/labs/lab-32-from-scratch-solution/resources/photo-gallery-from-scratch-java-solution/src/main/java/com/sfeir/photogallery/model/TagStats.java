package com.sfeir.photogallery.model;

/**
 * How many photos carry a given tag.
 *
 * @param name  the tag
 * @param count the number of photos carrying it
 */
public record TagStats(String name, long count) {
}
